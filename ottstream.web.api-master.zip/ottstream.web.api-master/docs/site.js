window.$docsify = {
  name: '',
  repo: '',
  loadSidebar: true,
  alias: {
    '/.*/_sidebar.md': '/_sidebar.md',
  },
};
