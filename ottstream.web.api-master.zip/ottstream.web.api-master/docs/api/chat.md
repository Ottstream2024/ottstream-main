# Chat Management API Documentation

This documentation outlines the chat management functionalities available through our API, focusing on operations such as chat creation, retrieval, updating, and deletion. All endpoints are prefixed with `/chats`.

## Endpoints Overview

### Chat Retrieval

- **Get All Chats**
  - **Endpoint**: `GET /chats/`
  - **Permissions Required**: `getChats`
  - **Description**: Retrieves a list of all chats based on query parameters.
  - **Validation**:
    - `search`: String (optional)
    - `sortBy`: String (optional)
    - `limit`: Number (optional, integer)
    - `client`: String (optional, must be a valid objectId)
    - `page`: Number (optional, integer)
    - `all`: Boolean (optional)
    - `name`: String (optional)
    - `sendNotification`: Boolean (optional)
    - `description`: String (optional)
    - `excel`: Boolean (optional)

- **Get Client Chats**
  - **Endpoint**: `GET /chats/client/:clientId`
  - **Permissions Required**: `getChat`
  - **Description**: Retrieves chats for a specified client.
  - **Validation**:
    - `clientId`: String (required, must be a valid objectId)
    - Additional query validations as in `getChats`

- **Get Provider Chats**
  - **Endpoint**: `GET /chats/provider`
  - **Permissions Required**: `getChats`
  - **Description**: Retrieves chats for the provider based on specific filters.
  - **Validation**:
    - `type`: String (optional, must be either 'client' or 'provider')
    - `unread`: Boolean (optional)

### Chat Creation

- **Create Chat**
  - **Endpoint**: `POST /chats/client/:clientId`
  - **Permissions Required**: `createChat`
  - **Description**: Creates a new chat for a specified client.
  - **Validation**:
    - `clientId`: String (required, must be a valid objectId)
    - `message`: String (optional)
    - `type`: String (optional)
    - `phone`: String (optional, can be empty or null)

### Chat Updating

- **Update Chat**
  - **Endpoint**: `PATCH /chats/client/:clientId`
  - **Permissions Required**: `updateChat`
  - **Description**: Updates an existing chat for a specified client.
  - **Validation**:
    - `chatId`: String (required, must be a valid objectId)
    - `chat`: String (optional)
    - `isPrivate`: Boolean (optional)
    - `sendNotification`: Boolean (optional)
    - `reminderDate`: Date (optional)
    - `client`: String (optional, must be a valid objectId)

### Chat Deletion

- **Delete Chat**
  - **Endpoint**: `DELETE /chats/client/:clientId`
  - **Permissions Required**: `deleteChat`
  - **Description**: Deletes a specified chat.
  - **Validation**:
    - `chatId`: String (required, must be a valid objectId)

### Additional Operations

- **Chat Enable/Disable Action**
  - **Endpoint**: Not specified in the given input
  - **Permissions Required**: Not specified in the given input
  - **Description**: Enables or disables a chat for sale.
  - **Validation**:
    - `enableForSale`: Boolean (required)
    - `chatId`: Array of Strings (required, each string must be a valid objectId)

## Postman Collection

A Postman collection for these API endpoints can be found here: [Insert Postman Collection Link]

This documentation aims to provide a comprehensive overview of the Chat Management API's capabilities, detailing each endpoint's purpose, required permissions, and validation rules. Ensure you have implemented the necessary security measures, including proper authentication and authorization, to protect these endpoints. Further details should be added as needed based on your API's complexity and requirements.
