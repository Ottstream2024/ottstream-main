# User Management API Documentation

This documentation outlines the user management functionalities available through our API, focusing on operations such as user creation, profile editing, settings management, and security. All endpoints are prefixed with `/users`.

## Endpoints Overview

### User Activities

- **Get User Activities**
  - **Endpoint**: `GET /users/activity/:user`
  - **Permissions Required**: `getUserActivitys`
  - **Description**: Retrieves activities for a specified user.

### User Creation and Listing

- **Create User**
  - **Endpoint**: `POST /users/`
  - **Permissions Required**: `createUser`
  - **Description**: Registers a new user with detailed information.
  - **Validation**:
    - `email`: String (required, must be a valid email address)
    - `password`: String (required, custom validation)
    - `confirmPassword`: String (required, must match `password`)
    - `firstname`: String (required)
    - `lastname`: String (required)
    - `color`: String (optional)
    - `phone`: Object (required, including `id`, `phoneNumber`, `countryCode`)
    - `avatar`: String (optional)
    - `accessEnable`: Boolean (optional)
    - `timezone`: String (optional)
    - `accessAnEnable`: Boolean (optional)
    - `address`: String (optional, custom objectId validation)
    - `showUnsuccessfulTransactions`: Boolean (optional)
    - `rolesInfo`: Object (optional, including roles such as `cashier`, `support`, etc.)
    - `provider`: String (optional, custom objectId validation)
    - `roles`: Array of Strings (optional, custom objectId validation for each item)

- **List Users**
  - **Endpoint**: `GET /users/`
  - **Permissions Required**: `getUsers`
  - **Description**: Retrieves a list of users based on query parameters.
  - **Validation**:
    - `state`: String (optional)
    - `role`: String (optional)
    - `lang`: String (optional)
    - `sortBy`: String (optional)
    - `limit`: Number (optional, integer)
    - `page`: Number (optional, integer)
    - `all`: Boolean (optional)
    - `search`: String (optional, trimmed)

### User Settings

- **Get User Settings**
  - **Endpoint**: `GET /users/settings`
  - **Permissions Required**: `getUserSettings`
  - **Description**: Fetches the settings for the currently authenticated user.

- **Set User Settings**
  - **Endpoint**: `PATCH /users/settings`
  - **Permissions Required**: `setUserSettings`
  - **Description**: Updates settings for the currently authenticated user.
  - **Validation**: Detailed validation schema for each setting including `saveHeader`, `defaultSettings`, and various user preferences as objects.

### User Email and Phone Verification

- **Check User Email**
  - **Endpoint**: `GET /users/email/check-mail`
  - **Description**: Checks if an email is associated with any user.
  - **Validation**:
    - `userId`: String (optional, custom objectId validation)
    - `email`: String (required, must be a valid email address)

- **Check User Phone**
  - **Endpoint**: `GET /users/phone/check-phone`
  - **Permissions Required**: `UserCheckPhone`
  - **Description**: Verifies if a phone number is linked to any user.
  - **Validation**:
    - `userId`: String (optional, custom objectId validation)
    - `phone`: String (required)

### User Profile Management

- **Update User**
  - **Endpoint**: `PATCH /users/edit/:userId`
  - **Permissions Required**: `updateUser`
  - **Description**: Updates user information for a specified user ID.
  - **Validation**: Comprehensive validation for updating user details such as `email`, `password`, `firstname`, `lastname`, and more, with specific fields requiring custom validation like `objectId`.

- **Delete User**
  - **Endpoint**: `DELETE /users/edit/:userId`
  - **Permissions Required**: `deleteUser`
  - **Description**: Deletes a specified user.

### Additional Operations

- **Reset Password**
  - **Endpoint**: `POST /users/reset-password`
  - **Permissions Required**: `resetPassword`
  - **Description**: Allows users to reset their password using a token.
  - **Validation**:
    - `token`: String (required)
    - `password`: String (required, custom validation)

- **Email Reset Password**
  - **Endpoint**: `POST /users/email/reset-password`
  - **Permissions Required**: `emailResetPassword`
  - **Description**: Initiates a password reset process by sending an email to the user.
  - **Validation**:
    - `email`: String (required, must be a valid email address)

- **Enable/Disable User**
  - **Endpoint**: `PATCH /users/enableDisable`
  - **Permissions Required**: `userEnableDisableAction`
  - **Description**: Enables or disables a user's access to the system.
  - **Validation**:
    - `accessEnable`: Boolean (required)
    - `userId`: Array of Strings (required, each string must pass custom objectId validation)

### User Registration and Activation

- **Get Registration Users**
  - **Endpoint**: `GET /users/registration`
  - **Permissions Required**: `getRegistrationUsers`
  - **Description**: Lists users filtering by registration specifics.
  - **Validation**:
    - Various query parameters for filtering including `sortBy`, `firstname`, `lastname`, `accessEnable`, and pagination options like `limit`, `page`, `all`, `excel`.

- **Get Active Users**
  - **Endpoint**: `GET /users/active`
  - **Permissions Required**: `getActiveUsers`
  - **Description**: Fetches users based on activity status, including filtering by login dates, status, and more.
  - **Validation**:
    - Comprehensive filtering capabilities including `sortBy`, `loginStartDate`, `loginEndDate`, `userStatus`, and pagination options.

### User Email and Phone Checks

- **Check User Email**
  - **Endpoint**: `GET /users/email/check-mail`
  - **Description**: Verifies if an email is already in use within the system.
  - **Validation**:
    - `email`: String (required, must be a valid email address)
    - `userId`: String (optional, custom objectId validation)

- **Check User Phone**
  - **Endpoint**: `GET /users/phone/check-phone`
  - **Permissions Required**: `UserCheckPhone`
  - **Description**: Confirms if a phone number is associated with any user account.
  - **Validation**:
    - `phone`: String (required)
    - `userId`: String (optional, custom objectId validation)

### Reset Login Count

- **Reset Login Count**
  - **Endpoint**: `GET /users/reset-login-count/:userId`
  - **Permissions Required**: `resetLoginCount`
  - **Description**: Resets the login attempt count for a specific user, useful for account unlock scenarios.
  - **Validation**:
    - `userId`: String (required, custom objectId validation)

### Telegram Password Operations

- **Generate Telegram Password**
  - **Endpoint**: `PATCH /users/telegram-generate-password/:userId`
  - **Permissions Required**: `generateTelegramPassword`
  - **Description**: Generates a temporary password for Telegram authentication.
  - **Validation**:
    - `userId`: String (required, custom objectId validation)

- **Send Telegram Password**
  - **Endpoint**: `POST /users/telegram-send-password/:userId`
  - **Permissions Required**: `generateTelegramPassword`
  - **Description**: Sends the generated Telegram password to the user.
  - **Validation**:
    - `userId`: String (required, custom objectId validation)
    - `type`: String (optional)
    - `value`: String (optional)

This documentation aims to provide a comprehensive overview of the User Management API's capabilities, detailing each endpoint's purpose, required permissions, and validation rules. Ensure you have implemented the necessary security measures, including proper authentication and authorization, to protect these endpoints. Further details should be added as needed based on your API's complexity and requirements.
