# Auth API Documentation

This section outlines the endpoints related to user management within our API, including user creation, activity tracking, settings management, and more. Each endpoint leverages specific permissions to ensure secure access control.

## Base URL

All API requests are made to the `/auth` base route.

## API Endpoints Overview

### Registration

- **Create User (`POST /auth/register-user-provider`)**
  - **Permissions Required**: `createUser`
  - **Description**: Registers a new user and provider with detailed information.
  - **Validation**:
    - `email`: String (required, must be a valid email address)
    - `password`: String (required, custom validation)
    - `firstname`: String (required)
    - `lastname`: String (required)
    - `companyName`: Array of objects (required, each containing `lang`: String, `name`: String)
    - `companyEmail`: String (required, must be a valid email address)
    - `website`: String (required)
    - `phone`: Object (required, containing `phoneNumber`: String, `countryCode`: String)
    - `description`: String (required)
    - `channelAmount`: Number (required)
    - `clientAmount`: Number (required)

### Login

- **User Login (`POST /auth/login`)**
  - **Permissions Required**: None explicitly required
  - **Description**: Authenticates a user and returns a token.
  - **Validation**:
    - `email`: String (required)
    - `password`: String (required)

### Social Logins

#### Google Authentication

- **Google Login (`GET /auth/google`)**
  - **Permissions Required**: None explicitly required
  - **Description**: Redirects the user to Google for authentication.

#### Facebook Authentication

- **Facebook Login (`GET /auth/facebook`)**
  - **Permissions Required**: None explicitly required
  - **Description**: Redirects the user to Facebook for authentication.

#### Twitter Authentication

- **Twitter Login (`GET /auth/twitter`)**
  - **Permissions Required**: None explicitly required
  - **Description**: Redirects the user to Twitter for authentication.

#### Microsoft Authentication

- **Microsoft Login (`GET /auth/microsoft`)**
  - **Permissions Required**: None explicitly required
  - **Description**: Redirects the user to Microsoft for authentication.

### Get User Info

- **Get User Info (`GET /auth/me`)**
  - **Permissions Required**: None explicitly required, but authentication is needed
  - **Description**: Retrieves information about the current authenticated user.

### Logout

- **Logout (`POST /auth/logout`)**
  - **Permissions Required**: None explicitly required, but authentication is needed
  - **Description**: Logs out the current user by invalidating their session.
  - **Validation**:
    - `refreshToken`: String (required)

### Refresh Tokens

- **Refresh Tokens (`POST /auth/refresh-tokens`)**
  - **Permissions Required**: None explicitly required
  - **Description**: Refreshes the authentication tokens.
  - **Validation**:
    - `refreshToken`: String (required)

### Forgot Password

- **Forgot Password (`POST /auth/forgot-password`)**
  - **Permissions Required**: None explicitly required
  - **Description**: Initiates the password reset process for a user.
  - **Validation**:
    - `email`: String (required, must be a valid email address)

### OTP Check

- **OTP Check (`POST /auth/otp-check`)**
  - **Permissions Required**: None explicitly required
  - **Description**: Validates the OTP sent to the user.
  - **Validation**:
    - `otp`: String (required)

### Email Check

- **Email Check (`POST /auth/email-check`)**
  - **Permissions Required**: None explicitly required
  - **Description**: Checks if an email is already in use.
  - **Validation**:
    - `email`: String (required)

### Reset Password

- **Reset Password (`POST /auth/reset-password`)**
  - **Permissions Required**: None explicitly required
  - **Description**: Allows a user to reset their password using a secure token.
  - **Validation**:
    - `token`: String (required)
    - `password`: String (required, custom validation)
    - `confirmPassword`: String (required, must match `password`)
