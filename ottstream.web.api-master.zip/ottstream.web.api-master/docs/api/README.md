# API Documentation

Welcome to the API documentation for our service. We provide comprehensive documentation to help you understand and integrate our APIs seamlessly into your projects. Our APIs are designed to be flexible, powerful, and easy to integrate, offering a wide range of functionalities to enhance your applications.

Our documentation is available in two formats: Swagger UI and Postman Collections. Both platforms offer interactive experiences for exploring our API endpoints, their specifications, and testing them in real-time.

## API Base URL

The base URL for all API requests is `https://panelapidev.ottstream.live/v1`. You will need to concatenate this base URL with the specific endpoint paths provided throughout this documentation to make requests. For example, if an endpoint is documented as `/users`, the full request URL will be `https://panelapidev.ottstream.live/v1/users`.

## Swagger UI Documentation

To view our interactive API documentation powered by Swagger UI, navigate to the following URL in your browser:

[Swagger UI Documentation](https://panelapidev.ottstream.live/v1/docs) (UNDER CONSTRUCTION, working on autogen)

This documentation page is automatically generated from the Swagger definitions written as comments in our route files. It allows you to explore the list of available APIs, understand their request/response schemas, and try out the APIs directly from your browser.

## Postman Collection

For those who prefer using Postman for API development and testing, we've also provided a Postman collection. This collection contains all our API endpoints, pre-configured requests, and environment variables to get you started quickly.

[Download Postman Collection](https://lunar-water-709728.postman.co)

## Getting Started

Whether you choose Swagger UI or Postman, our documentation provides all the necessary information to integrate with our APIs effectively. Here are a few steps to get you started:

1. **Choose Your Tool**: Decide whether you want to use Swagger UI or Postman based on your preference.
2. **Explore the APIs**: Browse through the available endpoints, request parameters, and response models.
3. **Concatenate the Base URL**: Remember to prepend `https://panelapidev.ottstream.live/v1` to the endpoint paths you wish to call.
4. **Authentication**: Ensure you understand the authentication mechanism required to access the APIs.
5. **Testing**: Utilize the interactive documentation in Swagger UI or import the Postman collection to test the APIs.

## Support

If you encounter any issues or have questions regarding our API documentation, feel free to reach out to our support team. We're here to help you integrate our services smoothly into your applications.

We look forward to supporting your application development and integration needs.
