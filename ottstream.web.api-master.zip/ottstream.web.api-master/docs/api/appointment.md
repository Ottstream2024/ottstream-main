# Calendar Event Management API Documentation

This documentation outlines the calendar event management functionalities available through our API. It covers operations such as event creation, retrieval, updating, commenting, and deletion.

## API Documentation URL

Swagger Documentation for this API is available here: [Swagger API Docs](https://panelapi.ottstream.live/api-docs/#/calendarEvents)

## Endpoints Overview

### Event Creation

- **Create Calendar Event**
  - **Endpoint**: `POST /`
  - **Permissions Required**: `createCalendarEvent`
  - **Description**: Creates a new calendar event with the provided details.
  - **Validation**:
    - `description`: String (optional, can be empty)
    - `title`: String (optional, can be empty)
    - `lat`: Number (optional, can be null)
    - `long`: Number (optional, can be null)
    - `client`: String (required, must be a valid objectId)
    - `paymentType`: String (required)
    - `paymentPrice`: Number (optional)
    - `location`: String (required, must be a valid objectId)
    - `customerAddress`: Object (optional)
    - `officeAddress`: Object (optional)
    - `startDate`: String (optional)
    - `endDate`: String (optional)
    - `state`: String (optional, can be empty or null)
    - `allDay`: Boolean (optional)
    - `equipmentInstaller`: String (required, must be a valid objectId)

### Event Retrieval

- **Get Calendar Events**
  - **Endpoint**: `GET /`
  - **Permissions Required**: `getCalendarEvent`
  - **Description**: Retrieves a list of calendar events based on query parameters.
  - **Validation**:
    - `search`: String (optional)
    - `sortBy`: String (optional)
    - `limit`: Number (optional, integer)
    - `type`: Number (optional)
    - `eventType`: String (optional)
    - `page`: Number (optional, integer)
    - `all`: Boolean (optional)
    - `paymentType`: String (optional)
    - `state`: String (optional)
    - `equipmentInstaller`: String (optional, must be a valid objectId)
    - `startDate`: String (optional)
    - `endDate`: String (optional)
    - `name`: String (optional)
    - `excel`: Boolean (optional)

- **Get Specific Calendar Event**
  - **Endpoint**: `GET /edit/:calendarEventId`
  - **Permissions Required**: `getCalendarEvent`
  - **Description**: Retrieves a specific calendar event by ID.
  - **Validation**:
    - `calendarEventId`: String (required, must be a valid objectId)

### Event Updating

- **Update Calendar Event**
  - **Endpoint**: `PATCH /edit/:calendarEventId`
  - **Permissions Required**: `updateCalendarEvent`
  - **Description**: Updates an existing calendar event by ID.
  - **Validation**:
    - `calendarEventId`: String (required, must be a valid objectId)
    - Additional body validations as in creation

### Event Commenting

- **Create Comment on Event**
  - **Endpoint**: `POST /comment/:calendarEventId`
  - **Permissions Required**: `updateCalendarEvent`
  - **Description**: Adds a comment to a specific calendar event.
  - **Validation**:
    - `comment`: String (required)
    - `isCancel`: Boolean (optional)

- **Update Comment on Event**
  - **Endpoint**: `PATCH /comment/:calendarEventId`
  - **Permissions Required**: `updateCalendarEvent`
  - **Description**: Updates a comment on a specific calendar event.
  - **Validation**:
    - `comment`: String (required)
    - `id`: String (required, must be a valid objectId)

### Event Deletion

- **Delete Calendar Event**
  - **Endpoint**: `DELETE /edit/:calendarEventId`
  - **Permissions Required**: `deleteCalendarEvent`
  - **Description**: Deletes a specific calendar event by ID.
  - **Validation**:
    - `calendarEventId`: String (required, must be a valid objectId)

This documentation provides a comprehensive overview of the Calendar Event Management API's capabilities, detailing each endpoint's purpose, required permissions, and validation rules. Ensure you have implemented necessary security measures, including proper authentication and authorization, to protect these endpoints. Further details should be added as needed based on your API's complexity and requirements.
