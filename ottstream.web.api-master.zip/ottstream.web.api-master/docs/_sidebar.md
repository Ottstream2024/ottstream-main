- [Home](/)
- [API Documentation](/api/)
  - [Authentication](/api/authentication.md)
  - [User](/api/user.md)
  - [Chat](/api/chat.md)
  - [Appointment](/api/appointment.md)
  <!-- - [Endpoints](/api/endpoints.md) -->
<!-- - [Guides](/guides/) -->
  <!-- - [Getting Started](/guides/get-started.md) -->