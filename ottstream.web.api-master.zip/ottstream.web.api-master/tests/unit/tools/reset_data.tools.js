/* eslint-disable no-unreachable */
/* eslint-disable no-continue */
/* eslint-disable no-await-in-loop */
/* eslint-disable no-param-reassign */
/* eslint-disable no-unused-vars */
/* eslint-disable no-restricted-syntax */
const resdis = require('redis');
const fs = require('fs');
const { ref, valid } = require('joi');
const excel = require('node-excel-export');
const { ThermalPrinter, PrinterTypes, CharacterSet, BreakLine } = require('node-thermal-printer');
const axios = require('axios');
const checkeeperSignature = require('checkeeper-signature');
const mongoose = require('mongoose');

// eslint-disable-next-line import/no-extraneous-dependencies
const { Config } = require('ottstream.services.config');
// eslint-disable-next-line import/no-extraneous-dependencies
const dataAccess = require('ottstream.dataaccess');

const path = require('path');
const config = require('../../../src/config');
// read config
const envPath = path.join(__dirname, '../.env');

Config.readEnv(envPath);

// set api ocnfig

config.initConfig();

// set dataacess config dataacess

dataAccess.config.initConfig(config.getConfig());
dataAccess.DbSetup.initDb();
const autoIncrement = require('../../../src/utils/mongoose-auto-increment');
const logger = require('../../../src/utils/logger/logger');
const ShippingService = require('../../../src/services/shiping/shipping.service');
const PrinterService = require('../../../src/services/printer/printer.service');
const InvoiceService = require('../../../src/services/payment/invoice.service');
const TwilioService = require('../../../src/services/sms/twilio.service');
const GeoIpService = require('../../../src/services/geoip/geoip.service');
const CardService = require('../../../src/services/payment/card.service');
const StatisticService = require('../../../src/services/statistics/statistic.service');

// const { ClientPaymentMethod, Client, ClientLocation, Credit, Transaction, User } = require('../../../src/models');
// eslint-disable-next-line no-unused-vars
const {
  Subscription,
  Package,
  OttProvider,
  Shipping,
  Notification,
  User,
  InvoiceClient,
  Client,
  ClientLocation,
  Invoice,
  Transaction,
  ClientPaymentMethod,
  PackageOption,
  Chat,
} = require('../../../src/models');
// eslint-disable-next-line no-unused-vars
const {
  // eslint-disable-next-line no-unused-vars
  clientRepository,
  // eslint-disable-next-line no-unused-vars
  clientLocationRepository,
  // eslint-disable-next-line no-unused-vars
  ottProviderRepository,
  // eslint-disable-next-line no-unused-vars
  subscriptionRepository,
  // eslint-disable-next-line no-unused-vars
  commentRepository,
  // eslint-disable-next-line no-unused-vars
  invoiceRepository,
  // eslint-disable-next-line no-unused-vars
  clientPaymentMethodRepository,
  packageRepository,
  ottProviderPrinterRepository,
  ottProviderOtherApiRepository,
  ottProviderPaymentGatewayRepository,
  serverRepository,
} = require('../../../src/repository');
// eslint-disable-next-line no-unused-vars
const SubscriptionService = require('../../../src/services/subscription/subscription.service');
const priceUtils = require('../../../src/utils/price/price_utils');
const TransactionService = require('../../../src/services/payment/transaction.service');
const StreetService = require('../../../src/services/street/street.service');

// eslint-disable-next-line no-unused-vars
const LocationSyncService = require('../../../src/services/sync/location/location_sync.service');
// const LocationSyncCrudService = require('../../../src/services/sync/location/location_sync_crud.service');
//
// const SubscriptionService = require('../../../src/services/subscription/subscription.service');
// const { clientRepository } = require('../../../src/repository');
// const EasyshipService = require('../../../src/services/shiping/merchant/easyship.service');
//
// // eslint-disable-next-line no-unused-vars
// const resetAllPasswords = async () => {
//   // await clientLocationRepository.resetAllPasswords();
//   let a = new EasyshipService();
//   let c = await a.getBoxes();
//   console.log(c);
// };
//
// // eslint-disable-next-line no-unused-vars
const updateAllSubscriptionStates = async () => {
  const clients = await clientRepository.getAll({ status: 1 });

  const len = clients.length;
  let cur = 0;
  // eslint-disable-next-line no-restricted-syntax
  for (const client of clients) {
    cur += 1;
    // eslint-disable-next-line no-await-in-loop
    await SubscriptionService.updateSubscriptionStates(client._id.toString());
    logger.info(`client updated ${cur}/${len}`);
  }
};
//
// // eslint-disable-next-line no-unused-vars
// const updateLocationsToHaveProviders = async () => {
//   const locations = await clientLocationRepository.getClientLocations({}, [{ path: 'clientId' }]);
//   logger.info(`locations to update provider field: ${locations.length}`);
//   // eslint-disable-next-line no-restricted-syntax
//   for (const location of locations) {
//     if (!location.clientId) {
//       logger.warn(`location has no client field`);
//     }
//     // eslint-disable-next-line no-await-in-loop
//     await clientLocationRepository.updateClientLocationById(location._id, { provider: location.clientId?.provider });
//     logger.info(`location ${location.clientId?.number_id} updated`);
//   }
// };
//
// // eslint-disable-next-line no-unused-vars
// const updateFields = async () => {
//   await clientLocationRepository.updateAll({}, { syncState: 2, password: ``, parentalCode: `` });
//   logger.info(`all location marked to sync`);
// };
//
// // eslint-disable-next-line no-unused-vars
// const generateAllInvoiceDisplayInfo = async () => {
//   // const allSubscriptions = await clientLocationRepository.updateAll({}, { syncState: 2, password: ``, parentalCode: `` });
//   logger.info(`all location marked to sync`);
// };
//
// // eslint-disable-next-line no-unused-vars
// const updateClientFileds = async () => {
//   // const allSubscriptions = await clientLocationRepository.updateAll({}, { syncState: 2, password: ``, parentalCode: `` });
//   const clients = await Client.find({});
//   const paymentMethods = await ClientPaymentMethod.find({});
//   const locations = await ClientLocation.find({});
//   const credits = await Credit.find({});
//   const transactions = await Transaction.find({});
//
//   await ClientLocation.updateMany({}, { paymentMethods: [], locations: [], credits: [], transactions: [] });
//   // eslint-disable-next-line no-restricted-syntax
//   for (const client of clients) {
//     const clientMethods = paymentMethods.filter((r) => r.clientId?.toString() === client._id.toString());
//     client.paymentMethods = clientMethods.map((r) => r._id);
//
//     const clientLocations = locations.filter((r) => r.clientId?.toString() === client._id.toString());
//     client.locations = clientLocations.map((r) => r._id);
//
//     const clientCredits = credits.filter((r) => r.clientId?.toString() === client._id.toString());
//     client.credits = clientCredits.map((r) => r._id);
//
//     const clientFromTransactions = transactions.filter((r) => r.from_client?.toString() === client._id.toString());
//     const clientToTransactions = transactions.filter((r) => r.to_client?.toString() === client._id.toString());
//     client.transactions = [];
//     client.transactions = client.transactions.concat(clientFromTransactions.map((r) => r._id));
//     client.transactions = client.transactions.concat(clientToTransactions.map((r) => r._id));
//     // eslint-disable-next-line no-await-in-loop
//     await client.save();
//     logger.info(
//       `locations: ${client.locations.length}, paymentMethods: ${client.paymentMethods.length},
//        credits: ${client.credits.length}, transactions: ${client.transactions.length}`
//     );
//   }
//
//   logger.info(`all client fields updated`);
// };
//
// // eslint-disable-next-line no-unused-vars
// const updateLocationFileds = async () => {
//   // const allSubscriptions = await clientLocationRepository.updateAll({}, { syncState: 2, password: ``, parentalCode: `` });
//   // const locations = await ClientLocation.find({});
//   // const subscriptions = await Subscription.find({});
//
//   // eslint-disable-next-line no-await-in-loop
//   // await ClientLocation.deleteMany({});
//   await ClientLocation.updateMany({}, { syncState: 0 });
//
//   // eslint-disable-next-line no-restricted-syntax
//   // for (const location of locations) {
//   //   const locationSubscriptions = subscriptions.filter((r) => r.location.toString() === location._id.toString());
//   //   location.subscriptions = locationSubscriptions.map((r) => r._id);
//   //
//   //   logger.info(`locations subscriptions: ${location.subscriptions.length}`);
//   //   if (location.subscriptions.length) {
//   //     // eslint-disable-next-line no-await-in-loop
//   //     await location.save();
//   //   }
//   // }
//
//   logger.info(`all location subscriptions updated`);
// };
// // eslint-disable-next-line no-unused-vars
// const updateUserSettings = async () => {
//   // const allSubscriptions = await clientLocationRepository.updateAll({}, { syncState: 2, password: ``, parentalCode: `` });
//   // const locations = await ClientLocation.find({});
//   // const subscriptions = await Subscription.find({});
//
//   // eslint-disable-next-line no-await-in-loop
//   // await ClientLocation.deleteMany({});
//   await User.updateMany({}, { settings: {} });
//
//   // eslint-disable-next-line no-restricted-syntax
//   // for (const location of locations) {
//   //   const locationSubscriptions = subscriptions.filter((r) => r.location.toString() === location._id.toString());
//   //   location.subscriptions = locationSubscriptions.map((r) => r._id);
//   //
//   //   logger.info(`locations subscriptions: ${location.subscriptions.length}`);
//   //   if (location.subscriptions.length) {
//   //     // eslint-disable-next-line no-await-in-loop
//   //     await location.save();
//   //   }
//   // }
//
//   logger.info(`all user settings updated`);
// };
//
// eslint-disable-next-line no-unused-vars
const updateKeywords = async () => {
  // const desiredDate = new Date('2023-05-20');
  // await ClientLocation.updateMany({ migrated: true }, { syncState: 2 });
  // await OttProvider.updateMany({ migrated: true }, { balance: 0, dept: 0 });
  // await ClientLocation.updateMany({ createdAt: { $gte: desiredDate } }, { sent: false });
  //
  // await clientLocationRepository.deleteMany({ migrated: true });
  // await clientRepository.deleteMany({ migrated: true });
  // await subscriptionRepository.deleteMany({ migrated: true });
  // await commentRepository.deleteMany({ migrated: true });
  /*
  const tvhouse = await OttProvider.findOne({ comment: 'TV House' });

  const tvHouseId = tvhouse._id.toString();
  const childOtts = await ottProviderRepository.getOttChilds(tvHouseId);
  // eslint-disable-next-line no-restricted-syntax
  for (const ott of childOtts) {
    // eslint-disable-next-line no-await-in-loop
    await OttProvider.deleteOne({ _id: ott._id });
  }
  await OttProvider.deleteOne({ _id: tvhouse._id });
  */
  // const providers = await OttProvider.find({ value: { $gt: 55 } });
  // // eslint-disable-next-line no-restricted-syntax
  // for (const ott of providers) {
  //   // eslint-disable-next-line no-await-in-loop
  //   await OttProvider.deleteOne({ _id: ott._id });
  // }
  // await OttProvider.deleteMany({ number: { $gt: 55 } });
  /*
  const providers = await OttProvider.find({ syncIdentifier: null });
  for (const ott of providers) {
    // eslint-disable-next-line no-await-in-loop
    await OttProvider.updateOne({ _id: ott._id }, { syncIdentifier: ott.name[0].name});
  }
  */
  // await clientRepository.deleteMany({ migrated: true });
  // await clientLocationRepository.deleteMany({ migrated: true });
  // eslint-disable-next-line no-restricted-syntax
  // for (const location of locations) {
  //   const locationSubscriptions = subscriptions.filter((r) => r.location.toString() === location._id.toString());
  //   location.subscriptions = locationSubscriptions.map((r) => r._id);
  //
  //   logger.info(`locations subscriptions: ${location.subscriptions.length}`);
  //   if (location.subscriptions.length) {
  //     // eslint-disable-next-line no-await-in-loop
  //     await location.save();
  //   }
  // }
  // const login = 449711767;
  // await ClientLocation.updateOne({ login }, { syncState: 2 });
  // await LocationSyncService.syncLocation(login);
};
// eslint-disable-next-line no-unused-vars
const resetSubscriptionLeftInvoices = async () => {
  // const desiredDate = new Date('2023-05-20');
  await ClientLocation.updateMany({ migrated: true }, { syncState: 1 });
  // await OttProvider.updateMany({ migrated: true }, { balance: 0, dept: 0 });
  // await ClientLocation.updateMany({ createdAt: { $gte: desiredDate } }, { sent: false });
  //
  // await clientLocationRepository.deleteMany({ migrated: true });
  // await clientRepository.deleteMany({ migrated: true });
  // await subscriptionRepository.deleteMany({ migrated: true });
  // await commentRepository.deleteMany({ migrated: true });
  /*
  const tvhouse = await OttProvider.findOne({ comment: 'TV House' });

  const tvHouseId = tvhouse._id.toString();
  const childOtts = await ottProviderRepository.getOttChilds(tvHouseId);
  // eslint-disable-next-line no-restricted-syntax
  for (const ott of childOtts) {
    // eslint-disable-next-line no-await-in-loop
    await OttProvider.deleteOne({ _id: ott._id });
  }
  await OttProvider.deleteOne({ _id: tvhouse._id });
  */
  // const providers = await OttProvider.find({ value: { $gt: 55 } });
  // // eslint-disable-next-line no-restricted-syntax
  // for (const ott of providers) {
  //   // eslint-disable-next-line no-await-in-loop
  //   await OttProvider.deleteOne({ _id: ott._id });
  // }
  // await OttProvider.deleteMany({ number: { $gt: 55 } });
  /*
  const providers = await OttProvider.find({ syncIdentifier: null });
  for (const ott of providers) {
    // eslint-disable-next-line no-await-in-loop
    await OttProvider.updateOne({ _id: ott._id }, { syncIdentifier: ott.name[0].name});
  }
  */
  // await clientRepository.deleteMany({ migrated: true });
  // await clientLocationRepository.deleteMany({ migrated: true });
  // eslint-disable-next-line no-restricted-syntax
  // for (const location of locations) {
  //   const locationSubscriptions = subscriptions.filter((r) => r.location.toString() === location._id.toString());
  //   location.subscriptions = locationSubscriptions.map((r) => r._id);
  //
  //   logger.info(`locations subscriptions: ${location.subscriptions.length}`);
  //   if (location.subscriptions.length) {
  //     // eslint-disable-next-line no-await-in-loop
  //     await location.save();
  //   }
  // }
  // const login = 449711767;
  // await ClientLocation.updateOne({ login }, { syncState: 2 });
  // await LocationSyncService.syncLocation(login);
};
// eslint-disable-next-line no-unused-vars
const setProviderIdentifier = async () => {
  // await OttProvider.updateOne({ _id: '645799071c5b7b1510f5388c' }, { syncIdentifier: 'E World New' });
  // await OttProvider.updateOne({ _id: '645799691c5b7b1510f69c66' }, { syncIdentifier: 'moidomtvusa' });
  // await OttProvider.updateOne({ _id: '645799771c5b7b1510f6c9bc' }, { syncIdentifier: 'HighNet TV' });
  // await OttProvider.updateOne({ _id: '6457996b1c5b7b1510f6a2f0' }, { syncIdentifier: 'HDzona TV' });
  // await OttProvider.updateOne({ _id: '645799af1c5b7b1510f799d5' }, { syncIdentifier: 'Heru TV' });
  // await OttProvider.updateOne({ _id: '6457997d1c5b7b1510f6dc99' }, { syncIdentifier: 'Moi Dom' });
  await OttProvider.updateOne({ 'name.name': 'E World New' }, { syncIdentifier: 'E World New' });
  await OttProvider.updateOne({ 'name.name': 'moidomtvusa' }, { syncIdentifier: 'moidomtvusa' });
  await OttProvider.updateOne({ 'name.name': 'HighNet TV' }, { syncIdentifier: 'HighNet TV' });
  await OttProvider.updateOne({ 'name.name': 'HDzona TV' }, { syncIdentifier: 'HDzona TV' });
  await OttProvider.updateOne({ 'name.name': 'Heru TV' }, { syncIdentifier: 'Heru TV' });
  await OttProvider.updateOne({ 'name.name': 'Moi Dom' }, { syncIdentifier: 'Moi Dom' });

  // eslint-disable-next-line no-restricted-syntax
  // for (const location of locations) {
  //   const locationSubscriptions = subscriptions.filter((r) => r.location.toString() === location._id.toString());
  //   location.subscriptions = locationSubscriptions.map((r) => r._id);
  //
  //   logger.info(`locations subscriptions: ${location.subscriptions.length}`);
  //   if (location.subscriptions.length) {
  //     // eslint-disable-next-line no-await-in-loop
  //     await location.save();
  //   }
  // }
};
// eslint-disable-next-line no-unused-vars
// const middlewareTestFunction = async () => {
//   const allRemoteLocations = await LocationSyncCrudService.getLocations();
//   const autoStarts = allRemoteLocations.filter((r) => r.autostart_status === -1);
//   // eslint-disable-next-line no-restricted-syntax
//   for (const currentAutostart of autoStarts) {
//     const biggerDevices = currentAutostart.devices.filter(
//       (r) => r.time_update > currentAutostart.packet_start || r.time_create > currentAutostart.packet_start
//     );
//     let minimumAutoStart = new Date().getTime() / 1000;
//     const compareDate = currentAutostart.packet_start;
//     let diff = currentAutostart.packet_expire;
//     // eslint-disable-next-line guard-for-in,no-restricted-syntax
//     for (const device of biggerDevices) {
//       if (device.time_create >= compareDate && device.time_create - compareDate < diff) {
//         diff = device.time_create - compareDate;
//         minimumAutoStart = device.time_create;
//       }
//       if (device.time_update >= compareDate && device.time_update - compareDate < diff) {
//         diff = device.time_update - compareDate;
//         minimumAutoStart = device.time_update;
//       }
//     }
//     logger.info(`updating ${currentAutostart.packet_start} to ${minimumAutoStart}`);
//   }
// };

const subscriptionUpdate = async () => {
  let current = 1;
  const clients = await clientRepository.getAll({ status: 1 });
  // const locations = await clientLocationRepository.getAll();
  const subscriptions = await subscriptionRepository.getList({ state: 1 });
  // eslint-disable-next-line no-restricted-syntax
  for (const subscription of subscriptions) {
    // eslint-disable-next-line no-plusplus
    if (subscription.endDate.getTime() < new Date().getTime()) {
      // eslint-disable-next-line no-plusplus
      logger.info(`subscription outdated ${current++}/${clients.length}`);
      // eslint-disable-next-line no-await-in-loop
      await Subscription.updateOne({ _id: subscription._id }, { state: 0 });
    } else {
      // eslint-disable-next-line no-plusplus
      logger.info(`subscription up to date ${current++}/${clients.length}`);
    }
  }
  // current = 1;
  // eslint-disable-next-line no-restricted-syntax
  const all = clients.length;
  let cur = 0;
  for (const client of clients) {
    cur += 1;
    // eslint-disable-next-line no-plusplus
    logger.info(`updating client ${current++}/${clients.length}`);
    // eslint-disable-next-line no-await-in-loop
    await SubscriptionService.updateSubscriptionStates(client._id.toString());
    logger.info(`updated client ${cur}/${all}`);
  }
};

// eslint-disable-next-line no-unused-vars
// const subscriptionFixFunction = async () => {
//   const clients = await clientRepository.getAll({ status: 1, subscriptionState: { $ne: 0} });
//   const clientsDict = clients.reduce((obj, item) => {
//     // eslint-disable-next-line no-param-reassign
//     obj[item._id.toString()] = item;
//     return obj;
//   }, {});
//   // for(const client of clients) {
//   //   await Client.updateOne({ _id: client._id }, { subscriptionState: 0});
//   //     await ClientLocation.updateMany({ clientId: client._id}, { subscriptionState: 0});
//   // }
//   // return;
//   // await Subscription.updateOne({ _id: subscription._id }, { state: 0 });
//   let current = 1;
//   const locations = await clientLocationRepository.getAll();
//   const subscriptions = await subscriptionRepository.getList({ state: 1 });
//   // eslint-disable-next-line no-restricted-syntax
//   const allSubscriptionsDect = subscriptions.reduce((obj, item) => {
//     // eslint-disable-next-line no-param-reassign
//     obj[item.client.toString()] = item;
//     return obj;
//   }, {});
//   const badClients = [];
//   for (const key of Object.keys(allSubscriptionsDect)) {
//     if (!clientsDict[key]) {
//       badClients.push(key);
//       await Subscription.updateMany({ client: key }, { state: 0})
//     }
//   }
//   const locationsDict = locations.reduce((obj, item) => {
//     if (item.subscriptionState === 3 || item.subscriptionState === 1) {
//       obj[item.clientId.toString()] = item;
//     }
//     return obj;
//   }, {});
//   // logger.info(`active subscription rows ${subscriptions.length}`);
//   // // eslint-disable-next-line no-restricted-syntax
//   // for (const subscription of subscriptions) {
//   //   // eslint-disable-next-line no-unused-vars
//   //   const { endDate, leftInvoiceGenerated, isActive } = subscription;
//   //   const currentDate = new Date();
//   //
//   //   const diff = endDate.getTime() - currentDate.getTime();
//   //   const leftHours = diff / 1000 / 60 / 60;
//   //   const hasExpired = leftHours <= 0;
//   //   if (hasExpired) {
//   //     // eslint-disable-next-line no-await-in-loop
//   //     awaitsubscriptionUpdate subscriptionRepository.updateSubscriptionById(subscription._id.toString(), { state: 0 });
//   //     // eslint-disable-next-line no-plusplus
//   //     logger.info(`still active ${current++}/${subscriptions.length}`);
//   //   } else {
//   //     // eslint-disable-next-line no-plusplus
//   //     logger.info(`still active ${current++}/${subscriptions.length}`);
//   //   }
//   // }
//   // eslint-disable-next-line no-restricted-syntax
//   // for (const client of clients) {
//   //   // eslint-disable-next-line no-plusplus
//   //   logger.info(`updating client ${current++}/${count}`);
//   //   // eslint-disable-next-line no-await-in-loop
//   //   await SubscriptionService.updateSubscriptionStates(client._id.toString());
//   // }
// };

// eslint-disable-next-line no-unused-vars
const testFunction = async () => {
  const filter = {
    'info.locations.subscriptionExpireDate': { $lte: new Date('2023-06-23') },
  };

  const clients = await Client.find(filter);
  logger.info(`clients: ${clients.length}`);
};

// eslint-disable-next-line no-unused-vars
const invoiceTestFunction = async () => {
  const packages = await packageRepository.getList({});
  const clients = await clientRepository.getAll({});
  const providers = await ottProviderRepository.getList({});
  const packageDict = packages.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    if (item._id) {
      obj[item._id.toString()] = item;
    }
    return obj;
  }, {});
  const clientDict = clients.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    if (item._id) {
      obj[item._id.toString()] = item;
    }
    return obj;
  }, {});
  const providerDict = providers.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    if (item._id) {
      obj[item._id.toString()] = item;
    }
    return obj;
  }, {});
  const invoices = await Invoice.find({ state: 1 });
  const subscriptions = await Subscription.find({});
  const newSubscriptionsDict = subscriptions
    .filter((r) => !r.migrated)
    .reduce((obj, item) => {
      // eslint-disable-next-line no-param-reassign
      if (!obj[item.client.toString()]) {
        obj[item.client.toString()] = [];
      }
      obj[item.client.toString()].push(item);
      return obj;
    }, {});
  const returnSubscriptionDict = subscriptions.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    if (item.returnInvoice) {
      obj[item.returnInvoice.toString()] = item;
    }
    return obj;
  }, {});
  const locationPackageSubscriptionDict = subscriptions.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    obj[item.location.toString() + item.package.toString()] = item;
    return obj;
  }, {});
  const buys = [];
  const refunds = [];
  const both = [];
  for (const invoice of invoices) {
    const isBuy = invoice.payloadCalculated.locations.filter((r) => r.packageInfos.length > 0 && r.totalPrice !== 0).length;
    const isRefund = invoice.payloadCalculated.locations.filter(
      (r) => r.packageRemoves.length > 0 && r.totalPrice !== 0
    ).length;
    let buyPackages = [];
    let refundPackages = [];

    if (isBuy) {
      const { locationId } = invoice.payloadCalculated.locations.filter(
        (r) => r.packageInfos.length > 0 && r.totalPrice !== 0
      )[0];
      buyPackages = invoice.payloadCalculated.locations.filter((r) => r.packageInfos.length > 0 && r.totalPrice !== 0)[0]
        .packageInfos;
      const subscriptionKey = locationId + buyPackages[0];
      if (!locationPackageSubscriptionDict[subscriptionKey]) {
        const a = 1;
      } else if (invoice.payloadCalculated.totalPrice >= 0) {
        // if (providerDict[clientDict[invoice.payload.client].provider]._id.toString() !== '6457997d1c5b7b1510f6dc99')
        //   continue;
        buys.push({
          type: 'buy',
          packages: buyPackages,
          client: invoice.payload.client,
          provider: clientDict[invoice.payload.client].provider,
          providerObject: providerDict[clientDict[invoice.payload.client].provider],
          location: invoice.payloadCalculated.locations.filter((r) => r.packageInfos.length > 0 && r.totalPrice !== 0)[0]
            .locationId,
          month: invoice.payloadCalculated.locations.filter((r) => r.packageInfos.length > 0 && r.totalPrice !== 0)[0].month,
          day: invoice.payloadCalculated.locations.filter((r) => r.packageInfos.length > 0 && r.totalPrice !== 0)[0].day,
          room: invoice.payloadCalculated.locations.filter((r) => r.packageInfos.length > 0 && r.totalPrice !== 0)[0].room,
          locationLogin: invoice.payloadCalculated.locations.filter(
            (r) => r.packageInfos.length > 0 && r.totalPrice !== 0
          )[0].locationLogin,
          locationPayload: invoice.payloadCalculated.locations.filter(
            (r) => r.packageInfos.length > 0 && r.totalPrice !== 0
          )[0],
          startDate: locationPackageSubscriptionDict[subscriptionKey].startDate,
          totalPrice: invoice.payloadCalculated.totalPrice,
          clientAddress: invoice.generateDisplayInfo.clientAddress,
          endDate: invoice.payloadCalculated.locations
            .filter((r) => r.packageInfos.length > 0 && r.totalPrice !== 0)[0]
            .packages.filter((a) => a.totalPrice > 0 && a.expireNew)[0].expireNew,
          subscriptions: newSubscriptionsDict[invoice.payload.client],
          invoiceDate: invoice.createdAt,
          invoiceNumber: invoice.number,
        });
      }
    }
    if (isRefund) {
      refundPackages = invoice.payloadCalculated.locations.filter(
        (r) => r.packageRemoves.length > 0 && r.totalPrice !== 0
      )[0].packageRemoves;
      const subscriptionKey = invoice._id.toString();
      const subscriptionKey2 =
        invoice.payloadCalculated.locations.filter((r) => r.packageRemoves.length > 0 && r.totalPrice !== 0)[0].locationId +
        refundPackages[0];
      if (!returnSubscriptionDict[subscriptionKey] && !locationPackageSubscriptionDict[subscriptionKey2]) {
        const a = 1;
      }
      refunds.push({
        type: 'sell',
        packages: refundPackages,
        client: invoice.payload.client,
        provider: clientDict[invoice.payload.client].provider,
        providerObject: providerDict[clientDict[invoice.payload.client].provider],
        locationPayload: invoice.payloadCalculated.locations.filter(
          (r) => r.packageRemoves.length > 0 && r.totalPrice !== 0
        )[0],
        location: invoice.payloadCalculated.locations.filter((r) => r.packageRemoves.length > 0 && r.totalPrice !== 0)[0]
          .locationId,
        month: invoice.payloadCalculated.locations.filter((r) => r.packageRemoves.length > 0 && r.totalPrice !== 0)[0].month,
        day: invoice.payloadCalculated.locations.filter((r) => r.packageRemoves.length > 0 && r.totalPrice !== 0)[0].day,
        room: invoice.payloadCalculated.locations.filter((r) => r.packageRemoves.length > 0 && r.totalPrice !== 0)[0].room,
        locationLogin: invoice.payloadCalculated.locations.filter(
          (r) => r.packageRemoves.length > 0 && r.totalPrice !== 0
        )[0].locationLogin,
        startDate: invoice.startDate,
        totalPrice: invoice.payloadCalculated.totalPrice,
        clientAddress: invoice.generateDisplayInfo.clientAddress,
        endDate: returnSubscriptionDict[subscriptionKey]
          ? returnSubscriptionDict[subscriptionKey].endDate
          : !locationPackageSubscriptionDict[subscriptionKey2].endDate,
        subscriptions: newSubscriptionsDict[invoice.payload.client],
        invoiceDate: invoice.createdAt,
        invoiceNumber: invoice.number,
      });
    }
  }

  const _packages = await packageRepository.getPackages({ id: '643f160caeda58fc19cf5b2f' });

  const _packagesDict = _packages.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    obj[item._id.toString()] = item;
    return obj;
  }, {});

  const columnSettings = [
    'provider',
    'client',
    'login',
    'clientPay',
    'due',
    'packages',
    'startDate',
    'endDate',
    'interval',
    'invoiceDate',
    'invoiceNumber',
  ];

  let bigUpdates = 0;
  const inputItems = [];
  // eslint-disable-next-line no-restricted-syntax

  for (const buy of buys) {
    const providerName = buy.providerObject.name[0].name;
    // if (buy.providerObject._id.toString() !== '6457997d1c5b7b1510f6dc99')
    //   continue;
    const clientName = buy.clientAddress ? `${buy.clientAddress.firstname} ${buy.clientAddress.lastname}` : buy.client;
    const pattern = /\b\w*test\w*\b/gi;
    if (pattern.test(clientName.toLowerCase())) continue;
    if (buy.subscriptions.filter((r) => r.location.toString() === buy.location)[0].returnInvoice) continue;
    const login = buy.locationLogin;
    const packageNames = buy.packages.map((r) => packageDict[r].name[packageDict[r].name.length - 1].name).toString();
    const startDate = buy.startDate.toDateString();
    const endDate = buy.endDate.toDateString();
    const payedToProvider = buy.totalPrice.toFixed(2);
    const diff = buy.endDate.getTime() - buy.startDate.getTime();
    const diffHours = diff / 1000 / 60 / 60;
    let toParent = 0;

    const curDate = new Date(buy.endDate); // Current date

    if (buy.day) {
      curDate.setDate(curDate.getDate() - buy.day);
    }
    if (buy.month) {
      curDate.setMonth(curDate.getMonth() - buy.month);
    }

    for (const packageId of buy.packages) {
      const currentPackage = _packagesDict[packageId];

      const toResaleTotalPrice = priceUtils.calculateDateIntervalPrice(
        currentPackage.option,
        buy.day || buy.month ? curDate : buy.startDate,
        buy.endDate,
        buy.room,
        false,
        null,
        null
      );
      if (toResaleTotalPrice !== -1) {
        toParent += toResaleTotalPrice;
      }
    }
    if (diffHours >= 30 * 24 * 3) {
      // eslint-disable-next-line no-plusplus
      bigUpdates++;
    }

    const saveItem = {
      provider: providerName,
      client: clientName,
      login,
      clientPay: payedToProvider,
      due: toParent.toFixed(2),
      packages: packageNames,
      startDate: buy.day || buy.month ? curDate : buy.startDate,
      endDate: buy.endDate,
      interval: `${buy.month ? buy.month : 0}m, ${buy.day ? buy.day : 0}d`,
      invoiceDate: buy.invoiceDate,
      invoiceNumber: buy.invoiceNumber,
    };
    logger.info(
      `provider: ${providerName}, client: ${clientName}, login: ${login}, packages: ${packageNames}, interval ${curDate.toString()} - ${endDate}, payed: ${payedToProvider}, ${
        buy.month ? buy.month : 0
      }m, ${buy.day ? buy.day : 0}d, due: ${toParent.toFixed(2)}`
    );
    inputItems.push(saveItem);
  }

  const inputItemsDict = inputItems.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    if (!obj[item.provider]) obj[item.provider] = [];
    obj[item.provider].push(item);
    return obj;
  }, {});

  for (const inputItemKey of Object.keys(inputItemsDict)) {
    const currentInputItems = inputItemsDict[inputItemKey];

    const orderItems = [];
    for (const inputItem of currentInputItems) {
      const list = [];
      for (const settings of columnSettings) {
        list.push({
          value: inputItem[settings],
          key: settings,
          name: settings,
        });
      }
      orderItems.push(list);
    }

    const specification = {};
    logger.info(`exporting excel`);

    const dataset1 = [];
    const dataset2 = [];

    let due1 = 0;
    let due2 = 0;
    // Set the common year, month, and minutes
    const year = 2023;
    const month = 6; // June (zero-based index)
    const minutes = 0;

    // Dates between June 1st to 10th
    const date1 = new Date(year, month, 1, 0, minutes); // June 1st, 00:30
    const date2 = new Date(year, month, 10, 23, 59, 59); // June 10th, 23:59:59

    // Dates between June 11th to 20th
    const date3 = new Date(year, month, 21, 0, minutes); // June 11th, 00:30
    const date4 = new Date(year, month, 30, 23, 59, 59); // June 20th, 23:59:59

    for (const orderItem of orderItems) {
      const currentItem = {};
      for (const item of orderItem) {
        currentItem[item.key] = item.value;
        if (item.key === 'due') {
          currentItem[item.key] = parseFloat(item.value);
        }
        const nameLength = item.name?.length ?? 5;
        specification[item.key] = {
          displayName: item.name,
          width: (nameLength > 6 ? nameLength * 10 : nameLength * 14) + 70,
          headerStyle: {
            fill: {
              fgColor: {
                rgb: 'FFFFFFFF',
              },
            },
            font: {
              color: {
                rgb: 'FF000000',
              },
              sz: 12,
              bold: true,
              underline: false,
            },
          },
        };
      }
      if (currentItem.invoiceDate >= date1 && currentItem.invoiceDate <= date2) {
        due1 += parseFloat(currentItem.due);
        dataset1.push(currentItem);
      }
      if (currentItem.invoiceDate >= date3 && currentItem.invoiceDate <= date4) {
        due2 += parseFloat(currentItem.due);
        dataset2.push(currentItem);
      }
    }

    dataset1.push({
      due: due1.toFixed(2),
    });
    dataset2.push({
      due: due2.toFixed(2),
    });

    // This function will return Buffer
    const curExcel1 = excel.buildExport([
      // <- Notice that this is an array. Pass multiple sheets to create multi sheet report
      {
        name: 'Report', // <- Specify sheet name (optional)
        // heading, // <- Raw heading array (optional)
        // merges, // <- Merge cell ranges
        specification, // <- Report specification
        data: dataset1, // <-- Report data
      },
    ]);

    // Save the Excel file
    // fs.writeFileSync(`${inputItemKey}-1-10-july.xlsx`, curExcel1);

    // This function will return Buffer
    const curExcel2 = excel.buildExport([
      // <- Notice that this is an array. Pass multiple sheets to create multi sheet report
      {
        name: 'Report', // <- Specify sheet name (optional)
        // heading, // <- Raw heading array (optional)
        // merges, // <- Merge cell ranges
        specification, // <- Report specification
        data: dataset2, // <-- Report data
      },
    ]);

    // Save the Excel file
    // fs.writeFileSync(`${inputItemKey}-21-30.xlsx`, curExcel2);
  }

  logger.info(`buys ${buys.length}, refunds ${refunds.length}, both: ${both.length}, big updates ${bigUpdates}`);
};

// eslint-disable-next-line no-unused-vars
const leftInvoiceFunction = async () => {
  const year = 2023;
  const month = 5; // June (zero-based index)
  const minutes = 30;
  const date1 = new Date(year, month, 25, 0, minutes); // June 1st, 00:30
  const subscriptions = await subscriptionRepository.getList({ leftInvoiceGenerated: true, updatedAt: { $gt: date1 } });

  const subscriptionsDict = subscriptions.reduce((obj, item) => {
    if (!obj[item.location.toString()]) {
      obj[item.location.toString()] = [];
    }
    // eslint-disable-next-line no-param-reassign
    obj[item.location.toString()].push(item);
    return obj;
  }, {});

  const all = Object.keys(subscriptionsDict).length;
  const cur = 1;
  for (const locationId of Object.keys(subscriptionsDict)) {
    // const leftInvoices = await invoiceRepository.getList({ location: locationId, sent: false})
    //
    //
    // // const subs = subscriptionsDict[locationId];
    // // const curSubs = subs.filter(r=>r.endDate.getTime() === subs[subs.length - 1].endDate.getTime());
    // // for (const curSub of curSubs) {
    // //   await Subscription.updateMany({_id: curSub._id.toString()}, { leftInvoiceGenerated: false })
    // // }
    // for(const invoice of leftInvoices) {
    //   // await Invoice.deleteOne({ _id: invoice._id.toString() });
    //   logger.info(`invoice number: ${invoice.number}`)
    // }
    // logger.info(`reseted leftGenerated ${cur++}/${all}`)
  }
  logger.info(`overall done ${cur - 1}/${all}`);
};

const balanceFixFunction = async () => {
  const packages = await packageRepository.getList({});
  const clients = await clientRepository.getAll({});
  const providers = await ottProviderRepository.getList({});
  const packageDict = packages.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    if (item._id) {
      obj[item._id.toString()] = item;
    }
    return obj;
  }, {});
  const clientDict = clients.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    if (item._id) {
      obj[item._id.toString()] = item;
    }
    return obj;
  }, {});
  const providerDict = providers.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    if (item._id) {
      obj[item._id.toString()] = item;
    }
    return obj;
  }, {});
  const invoices = await Invoice.find({ state: 1 });
  const subscriptions = await Subscription.find({});
  const newSubscriptionsDict = subscriptions
    .filter((r) => !r.migrated)
    .reduce((obj, item) => {
      // eslint-disable-next-line no-param-reassign
      if (!obj[item.client.toString()]) {
        obj[item.client.toString()] = [];
      }
      obj[item.client.toString()].push(item);
      return obj;
    }, {});
  const returnSubscriptionDict = subscriptions.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    if (item.returnInvoice) {
      obj[item.returnInvoice.toString()] = item;
    }
    return obj;
  }, {});
  const locationPackageSubscriptionDict = subscriptions.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    obj[item.location.toString() + item.package.toString()] = item;
    return obj;
  }, {});
  const buys = [];
  const refunds = [];
  const both = [];
  for (const invoice of invoices) {
    const isBuy = invoice.payloadCalculated.locations.filter((r) => r.packageInfos.length > 0 && r.totalPrice !== 0).length;
    const isRefund = invoice.payloadCalculated.locations.filter(
      (r) => r.packageRemoves.length > 0 && r.totalPrice !== 0
    ).length;
    let buyPackages = [];
    let refundPackages = [];

    if (isBuy) {
      const { locationId } = invoice.payloadCalculated.locations.filter(
        (r) => r.packageInfos.length > 0 && r.totalPrice !== 0
      )[0];
      buyPackages = invoice.payloadCalculated.locations.filter((r) => r.packageInfos.length > 0 && r.totalPrice !== 0)[0]
        .packageInfos;
      const subscriptionKey = locationId + buyPackages[0];
      if (!locationPackageSubscriptionDict[subscriptionKey]) {
        const a = 1;
      } else if (invoice.payloadCalculated.totalPrice >= 0) {
        // if (providerDict[clientDict[invoice.payload.client].provider]._id.toString() !== '6457997d1c5b7b1510f6dc99')
        //   continue;
        buys.push({
          type: 'buy',
          packages: buyPackages,
          client: invoice.payload.client,
          provider: clientDict[invoice.payload.client].provider,
          providerObject: providerDict[clientDict[invoice.payload.client].provider],
          location: invoice.payloadCalculated.locations.filter((r) => r.packageInfos.length > 0 && r.totalPrice !== 0)[0]
            .locationId,
          month: invoice.payloadCalculated.locations.filter((r) => r.packageInfos.length > 0 && r.totalPrice !== 0)[0].month,
          day: invoice.payloadCalculated.locations.filter((r) => r.packageInfos.length > 0 && r.totalPrice !== 0)[0].day,
          room: invoice.payloadCalculated.locations.filter((r) => r.packageInfos.length > 0 && r.totalPrice !== 0)[0].room,
          locationLogin: invoice.payloadCalculated.locations.filter(
            (r) => r.packageInfos.length > 0 && r.totalPrice !== 0
          )[0].locationLogin,
          locationPayload: invoice.payloadCalculated.locations.filter(
            (r) => r.packageInfos.length > 0 && r.totalPrice !== 0
          )[0],
          startDate: locationPackageSubscriptionDict[subscriptionKey].startDate,
          totalPrice: invoice.payloadCalculated.totalPrice,
          clientAddress: invoice.generateDisplayInfo.clientAddress,
          endDate: invoice.payloadCalculated.locations
            .filter((r) => r.packageInfos.length > 0 && r.totalPrice !== 0)[0]
            .packages.filter((a) => a.totalPrice > 0)[0].expireNew,
          subscriptions: newSubscriptionsDict[invoice.payload.client],
          invoiceDate: invoice.createdAt,
          invoiceNumber: invoice.number,
        });
      }
    }
    if (isRefund) {
      refundPackages = invoice.payloadCalculated.locations.filter(
        (r) => r.packageRemoves.length > 0 && r.totalPrice !== 0
      )[0].packageRemoves;
      const subscriptionKey = invoice._id.toString();
      const subscriptionKey2 =
        invoice.payloadCalculated.locations.filter((r) => r.packageRemoves.length > 0 && r.totalPrice !== 0)[0].locationId +
        refundPackages[0];
      if (!returnSubscriptionDict[subscriptionKey] && !locationPackageSubscriptionDict[subscriptionKey2]) {
        const a = 1;
      }
      refunds.push({
        type: 'sell',
        packages: refundPackages,
        client: invoice.payload.client,
        provider: clientDict[invoice.payload.client].provider,
        providerObject: providerDict[clientDict[invoice.payload.client].provider],
        locationPayload: invoice.payloadCalculated.locations.filter(
          (r) => r.packageRemoves.length > 0 && r.totalPrice !== 0
        )[0],
        location: invoice.payloadCalculated.locations.filter((r) => r.packageRemoves.length > 0 && r.totalPrice !== 0)[0]
          .locationId,
        month: invoice.payloadCalculated.locations.filter((r) => r.packageRemoves.length > 0 && r.totalPrice !== 0)[0].month,
        day: invoice.payloadCalculated.locations.filter((r) => r.packageRemoves.length > 0 && r.totalPrice !== 0)[0].day,
        room: invoice.payloadCalculated.locations.filter((r) => r.packageRemoves.length > 0 && r.totalPrice !== 0)[0].room,
        locationLogin: invoice.payloadCalculated.locations.filter(
          (r) => r.packageRemoves.length > 0 && r.totalPrice !== 0
        )[0].locationLogin,
        startDate: invoice.startDate,
        totalPrice: invoice.payloadCalculated.totalPrice,
        clientAddress: invoice.generateDisplayInfo.clientAddress,
        endDate: returnSubscriptionDict[subscriptionKey]
          ? returnSubscriptionDict[subscriptionKey].endDate
          : !locationPackageSubscriptionDict[subscriptionKey2].endDate,
        subscriptions: newSubscriptionsDict[invoice.payload.client],
        invoiceDate: invoice.createdAt,
        invoiceNumber: invoice.number,
      });
    }
  }
  //
  logger.info(`buys ${buys.length}, refunds ${refunds.length}, both: ${both.length}`);
};

const leftResetFunction = async () => {
  const list = ['INV-784324', 'INV-741307', 'INV-276631', 'INV-679734', 'INV-790087', 'INV-36003', 'INV-756582'];
  const invoices = await invoiceRepository.getList({ number: { $in: list } });
  logger.info(`infoice: ${invoices.length}`);
  for (const invoice of invoices) {
    await Invoice.deleteOne({ _id: invoice._id.toString() });
    logger.info(`deleted invoice ${invoice.number}`);
  }
};

const transactionsFix = async () => {
  // const allTransactions = await Transaction.find({}).populate([{ path: 'invoice' }]);
  // const removeTransactions = allTransactions.filter((r) => !r.invoice && r.source_type === 'PAY_INVOICE');
  // const refundFixTransactions = await Transaction.find().populate([{ path: 'invoice' }]);
  // for (const transaction of refundFixTransactions) {
  //   if (transaction.invoice) {
  //     if (transaction?.invoice?.payloadCalculated?.btnText === 'Refund') {
  //       await Transaction.updateOne({ _id: transaction._id.toString() }, { isRefund: true });
  //     }
  //   }
  // }
  // logger.info(`transactions isRefund updated`);

  // await Transaction.updateMany({ source_type: 'ADD_BALANCE' }, { transaction_type: 'TO_B' });

  // logger.info(`transactions add balance updated`);
  // await Transaction.updateMany({ transaction_type: 'TO_B' }, { fixed: true });
  // await Transaction.updateMany({ transaction_type: 'B_TO_B', invoice: { $eq: null } }, { fixed: true });
  // update transactions execution Date
  // {
  //   const transactions = await Transaction.find();
  //   for (const transaction of transactions) {
  //     if (transaction.executionDate) continue;
  //     transaction.executionDate = transaction.createdAt;
  //     await transaction.save();
  //   }
  // }

  // {
  //   const transactions = await Transaction.find({}).populate([{ path: 'invoice' }]);

  //   const invoicePayTransactions = transactions.filter(
  //     (r) => r.source_type === 'PAY_INVOICE' && r.state && r.invoice
  //     // r.invoice.payloadCalculated.locations.filter((a) => a.toParents).length
  //   );
  //   for (const transaction of invoicePayTransactions) {
  //     await Transaction.updateOne(
  //       { _id: transaction._id.toString() },
  //       { provider: transaction.invoice.provider._id.toString() }
  //     );
  //   }
  // }

  const packages = await packageRepository.getList({});
  const clients = await clientRepository.getAll({});
  const providers = await ottProviderRepository.getList({});
  const packageDict = packages.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    if (item._id) {
      obj[item._id.toString()] = item;
    }
    return obj;
  }, {});
  const clientDict = clients.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    if (item._id) {
      obj[item._id.toString()] = item;
    }
    return obj;
  }, {});
  const providerDict = providers.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    if (item._id) {
      obj[item._id.toString()] = item;
    }
    return obj;
  }, {});
  const invoices = await Invoice.find({ state: 1 });
  const subscriptions = await Subscription.find({});
  const newSubscriptionsDict = subscriptions
    .filter((r) => !r.migrated)
    .reduce((obj, item) => {
      // eslint-disable-next-line no-param-reassign
      if (!obj[item.client.toString()]) {
        obj[item.client.toString()] = [];
      }
      obj[item.client.toString()].push(item);
      return obj;
    }, {});
  const returnSubscriptionDict = subscriptions.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    if (item.returnInvoice) {
      obj[item.returnInvoice.toString()] = item;
    }
    return obj;
  }, {});
  const locationPackageSubscriptionDict = subscriptions.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    const currentKey = item.location.toString() + item.package.toString();
    if (!obj[currentKey]) obj[currentKey] = [];
    obj[currentKey].push(item);
    return obj;
  }, {});
  const eWordId = '645799071c5b7b1510f5388c';
  const baseNewId = '64579b471c5b7b1510f824b5';
  const iboxNewId = '64579b471c5b7b1510f824d9';
  const premiumNewId = '64579b471c5b7b1510f8247f';
  const premiumPlusId = '64579b471c5b7b1510f823a7';
  const premiumId = '64579b471c5b7b1510f82449';
  const basePlusId = '64579b471c5b7b1510f824a3';
  const childs = await ottProviderRepository.getOttChilds(eWordId);
  let subProviders = childs.map((r) => r.id);
  subProviders = subProviders.concat(eWordId);
  subProviders = subProviders.concat('643f160caeda58fc19cf5b2f');

  const notCaluclatedPrices = [];
  {
    const globalParentOtts = {};
    const globalParentOttPackages = {};
    for (const currentProvider of providers) {
      const provider = currentProvider._id.toString(); // '647876c7643f847e32e437de';
      // if (!subProviders.filter((r) => r === provider).length) continue;
      // if (provider !== '645799071c5b7b1510f5388c') continue;
      const ottProvider = await OttProvider.findOne({ _id: provider });
      const parentOtts = await ottProviderRepository.getOttParents(provider);
      const parentOttPackages = {};
      // eslint-disable-next-line no-restricted-syntax
      for (const parentOtt of parentOtts) {
        const parentOttKey = parentOtt._id.toString();
        // eslint-disable-next-line no-await-in-loop
        const currentParentPackages = await packageRepository.getPackages({ id: parentOtt._id.toString() });
        const currentParentPackagesDict = currentParentPackages.reduce((obj, item) => {
          // eslint-disable-next-line no-param-reassign
          obj[item._id.toString()] = item;
          return obj;
        }, {});
        parentOttPackages[parentOttKey] = currentParentPackagesDict;
      }
      globalParentOtts[provider] = parentOtts;
      globalParentOttPackages[provider] = parentOttPackages;
    }

    const transactions = await Transaction.find({}).populate([{ path: 'invoice' }]);

    const invoicePayTransactions = transactions.filter(
      (r) => r.source_type === 'PAY_INVOICE' && r.state === 1 && r.invoice && r.invoice.state === 1
      // r.invoice.payloadCalculated.locations.filter((a) => a.toParents).length
    );

    const buys = [];
    const sells = [];
    const buysSells = [];
    const hasBadPrice = (_dict, parentId, pricePackageId) => {
      return (
        !(Array.isArray(_dict[parentId][pricePackageId].option)
          ? _dict[parentId][pricePackageId].option.length
          : _dict[parentId][pricePackageId].option?.prices?.length) ||
        !(
          _dict[parentId][pricePackageId].option?.prices?.length &&
          _dict[parentId][pricePackageId].option?.prices.filter((r) => !r.clientType)[0]?.priceItems?.length
        )
      );
    };
    const AllinvoicePayTransactions = invoicePayTransactions; // .filter((r) => r.number === 'TR-203390');
    for (const payedTransaction of AllinvoicePayTransactions) {
      const provider = payedTransaction.invoice.provider.toString();
      const currentProvider = providers.filter((r) => r.id === provider)[0];
      const isBuy = payedTransaction.invoice.payloadCalculated.locations.filter(
        (r) => r.packageInfos.length > 0 && r.totalPrice !== 0 && r.packages.filter((a) => a.expireNew).length
      ).length;
      const isRefund = payedTransaction.invoice.payloadCalculated.locations.filter(
        (r) => r.packageRemoves.length > 0 && r.totalPrice !== 0 && !r.packages.filter((a) => a.expireNew).length
      ).length;

      if (isBuy && isRefund) {
        continue;
        buysSells.push(1);
      } else if (isBuy) {
        const { locationId } = payedTransaction.invoice.payloadCalculated.locations.filter(
          (r) => r.packageInfos.length > 0 && r.totalPrice !== 0
        )[0];
        const buyPackages = payedTransaction.invoice.payloadCalculated.locations.filter(
          (r) => r.packageInfos.length > 0 && r.totalPrice !== 0
        )[0].packageInfos;
        if (
          !payedTransaction.invoice.payloadCalculated.locations
            .filter((r) => r.packageInfos.length > 0 && r.totalPrice !== 0)[0]
            .packages.filter((a) => a.totalPrice !== 0).length
        ) {
          const a = 1;
        }
        let interesetKey = null;
        for (const pack of buyPackages) {
          if (
            locationPackageSubscriptionDict[locationId + pack].filter(
              (r) => r.invoice?.toString() === payedTransaction.invoice.id
            ).length
          )
            interesetKey = locationId + pack;
        }
        const buyObject = {
          type: 'buy',
          packages: buyPackages,
          client: payedTransaction.invoice.payload.client,
          provider: clientDict[payedTransaction.invoice.payload.client].provider,
          providerObject: providerDict[clientDict[payedTransaction.invoice.payload.client].provider],
          location: payedTransaction.invoice.payloadCalculated.locations.filter(
            (r) => r.packageInfos.length > 0 && r.totalPrice !== 0
          )[0].locationId,
          month: payedTransaction.invoice.payloadCalculated.locations.filter(
            (r) => r.packageInfos.length > 0 && r.totalPrice !== 0
          )[0].month,
          day: payedTransaction.invoice.payloadCalculated.locations.filter(
            (r) => r.packageInfos.length > 0 && r.totalPrice !== 0
          )[0].day,
          room: payedTransaction.invoice.payloadCalculated.locations.filter(
            (r) => r.packageInfos.length > 0 && r.totalPrice !== 0
          )[0].room,
          locationLogin: payedTransaction.invoice.payloadCalculated.locations.filter(
            (r) => r.packageInfos.length > 0 && r.totalPrice !== 0
          )[0].locationLogin,
          locationPayload: payedTransaction.invoice.payloadCalculated.locations.filter(
            (r) => r.packageInfos.length > 0 && r.totalPrice !== 0
          )[0],

          startDate: interesetKey
            ? locationPackageSubscriptionDict[interesetKey].filter(
                (r) => r.invoice?.toString() === payedTransaction.invoice.id
              )[0].createdAt
            : null,
          totalPrice: payedTransaction.invoice.payloadCalculated.totalPrice,
          clientAddress: payedTransaction.invoice.generateDisplayInfo.clientAddress,
          endDate: payedTransaction.invoice.payloadCalculated.locations
            .filter((r) => r.packageInfos.length > 0 && r.totalPrice !== 0)[0]
            .packages.filter((a) => a.expireNew)[0].expireNew,
          subscriptions: newSubscriptionsDict[payedTransaction.invoice.payload.client],
          invoiceDate: payedTransaction.invoice.createdAt,
          invoiceNumber: payedTransaction.invoice.number,
        };
        buys.push(buyObject);

        if (
          buyObject.packages.filter((r) => r === iboxNewId || r === baseNewId).length &&
          !buyObject.packages.filter((r) => r === basePlusId).length
        ) {
          buyObject.packages = buyObject.packages.filter((r) => r !== iboxNewId && r !== baseNewId);
          logger.info(`package replace to basePlus for invoice ${buyObject.invoiceNumber}`);
          buyObject.packages.push(basePlusId);
        }

        if (
          buyObject.packages.filter((r) => r === premiumNewId || r === premiumPlusId).length &&
          !buyObject.packages.filter((r) => r === premiumId).length
        ) {
          buyObject.packages = buyObject.packages.filter((r) => r !== premiumNewId && r !== premiumPlusId);
          logger.info(`package replace to premium for invoice ${buyObject.invoiceNumber}`);
          buyObject.packages.push(premiumId);
        }
        const curDate = new Date(buyObject.endDate); // Current date

        if (buyObject.day) {
          curDate.setDate(curDate.getDate() - buyObject.day);
        }
        if (buyObject.month) {
          curDate.setMonth(curDate.getMonth() - buyObject.month);
        }
        const toParents = {};
        let currentPayer = currentProvider._id.toString();
        let curPriceGroup = currentProvider.priceGroup;
        // eslint-disable-next-line no-restricted-syntax
        for (const parentOtt of globalParentOtts[provider]) {
          let parentOttKey = parentOtt._id.toString();
          toParents[parentOttKey] = { amount: 0 };

          let currentParentPackagesDict = globalParentOttPackages[provider][parentOttKey];

          for (const packageId of buyObject.packages) {
            const pricePackageId = packageId;
            if (hasBadPrice(globalParentOttPackages[provider], parentOttKey, pricePackageId)) {
              if (hasBadPrice(globalParentOttPackages[provider], parentOttKey, pricePackageId)) {
                parentOttKey = globalParentOtts[provider][globalParentOtts[provider].length - 1]._id.toString();
                logger.info(`package using parent price for invoice ${buyObject.invoiceNumber}`);
              }
            }
            currentParentPackagesDict = globalParentOttPackages[provider][parentOttKey];
            if (currentParentPackagesDict[pricePackageId]) {
              const curPlus = priceUtils.calculateDateIntervalPrice(
                currentParentPackagesDict[pricePackageId].option,
                buyObject.day || buyObject.month ? curDate : buyObject.startDate,
                buyObject.endDate,
                buyObject.room,
                false,
                curPriceGroup,
                null
              );
              if (curPlus !== -1 && curPlus !== null && typeof curPlus !== 'undefined') {
                toParents[parentOtt._id.toString()].amount += curPlus !== null ? curPlus : 0;
              } else {
                const badCase = true;
                notCaluclatedPrices.push({
                  option: currentParentPackagesDict[pricePackageId].option,
                  package: pricePackageId,
                  invoicePackages: buyObject.packages,
                  invoice: buyObject.invoiceNumber,
                });
                logger.info(
                  `login has bas++ but also has ${currentParentPackagesDict[pricePackageId].name[0].name} with no price`
                );
              }
            } else {
              const a = 1;
            }
          }
          toParents[parentOtt._id.toString()].from = currentPayer;
          currentPayer = parentOtt._id.toString();
          curPriceGroup = parentOtt.priceGroup;
        }
        const target = payedTransaction.invoice.payloadCalculated;
        target.locations.filter((r) => r.packageInfos.length > 0 && r.totalPrice !== 0)[0].toParents = toParents;
        await Invoice.updateOne(
          { _id: payedTransaction.invoice._id.toString() },
          { payloadCalculated: payedTransaction.invoice.payloadCalculated }
        );
        const payedParent = false;

        // clean old transactions
        const deleted = await Transaction.deleteMany({
          invoice: payedTransaction.invoice._id.toString(),
          source_type: 'EXECUTE_INVOICE',
          transaction_type: 'B_TO_B',
        });
        // continue;
        for (const curParentKey of Object.keys(toParents)) {
          const curPay = toParents[curParentKey];
          if (curPay.amount !== 0 && curPay.from) {
            const curUser = await User.findOne({ _id: payedTransaction.invoice.user }).populate([{ path: 'provider' }]);
            const transaction = await TransactionService.createInvoiceExecutionTransaction(
              payedTransaction.invoice,
              curPay.amount > 0 ? curPay.from : curParentKey,
              curPay.amount > 0 ? curParentKey : curPay.from,
              Math.abs(curPay.amount),
              curPay.amount < 0,
              curUser || { provider: { id: payedTransaction.invoice.provider } }
            );
            const newExecutionDate = new Date(payedTransaction.invoice.createdAt);
            newExecutionDate.setMinutes(newExecutionDate.getMinutes() + 1);
            const updatedTransaction = await Transaction.updateOne(
              { _id: transaction._id.toString() },
              {
                state: 1,
                executionDate: newExecutionDate,
                payloadExecuted: true,
              }
            );
            // const executed = await TransactionService.executeTransaction(transaction);
            // if (executed) payedParent = true;
          }
        }
      } else if (isRefund) {
        // if (payedTransaction.invoice.number !== 'INV-262891') continue;
        await Invoice.updateOne({ _id: payedTransaction.invoice._id.toString() }, { isRefund: true });
        const { locationId } = payedTransaction.invoice.payloadCalculated.locations.filter(
          (r) => r.packageRemoves.length > 0 && r.totalPrice !== 0
        )[0];
        const refundPackages = payedTransaction.invoice.payloadCalculated.locations.filter(
          (r) => r.packageRemoves.length > 0 && r.totalPrice !== 0
        )[0].packageRemoves;
        const subscriptionKey = locationId + refundPackages[0];
        if (
          !payedTransaction.invoice.payloadCalculated.locations
            .filter((r) => r.packageRemoves.length > 0 && r.totalPrice !== 0)[0]
            .packages.filter((a) => a.totalPrice !== 0).length
        ) {
          const a = 1;
        }
        const refundObject = {
          type: 'sell',
          packages: refundPackages,
          client: payedTransaction.invoice.payload.client,
          provider: clientDict[payedTransaction.invoice.payload.client].provider,
          providerObject: providerDict[clientDict[payedTransaction.invoice.payload.client].provider],
          location: payedTransaction.invoice.payloadCalculated.locations.filter(
            (r) => r.packageRemoves.length > 0 && r.totalPrice !== 0
          )[0].locationId,
          month: payedTransaction.invoice.payloadCalculated.locations.filter(
            (r) => r.packageRemoves.length > 0 && r.totalPrice !== 0
          )[0].month,
          day: payedTransaction.invoice.payloadCalculated.locations.filter(
            (r) => r.packageRemoves.length > 0 && r.totalPrice !== 0
          )[0].day,
          room: payedTransaction.invoice.payloadCalculated.locations.filter(
            (r) => r.packageRemoves.length > 0 && r.totalPrice !== 0
          )[0].room,
          locationLogin: payedTransaction.invoice.payloadCalculated.locations.filter(
            (r) => r.packageRemoves.length > 0 && r.totalPrice !== 0
          )[0].locationLogin,
          locationPayload: payedTransaction.invoice.payloadCalculated.locations.filter(
            (r) => r.packageRemoves.length > 0 && r.totalPrice !== 0
          )[0],

          startDate: payedTransaction.invoice.createdAt,
          totalPrice: payedTransaction.invoice.payloadCalculated.totalPrice,
          clientAddress: payedTransaction.invoice.generateDisplayInfo.clientAddress,
          endDate: payedTransaction.invoice?.payloadCalculated?.locations.filter((r) => r.locationId === locationId)[0]
            ?.packages[0].expireDate,
          subscriptions: newSubscriptionsDict[payedTransaction.invoice.payload.client],
          invoiceDate: payedTransaction.invoice.createdAt,
          invoiceNumber: payedTransaction.invoice.number,
        };
        sells.push(refundObject);

        const curDate = new Date(refundObject.endDate); // Current date

        if (
          refundObject.packages.filter((r) => r === iboxNewId && r === baseNewId).length &&
          !refundObject.packages.filter((r) => r === basePlusId).length
        ) {
          refundObject.packages = refundObject.packages.filter((r) => r !== iboxNewId && r !== baseNewId);

          logger.info(`package replace to basePlus for invoice ${refundObject.invoiceNumber}`);
          refundObject.packages.push(basePlusId);
        }

        if (
          refundObject.packages.filter((r) => r === premiumNewId && r === premiumPlusId).length &&
          !refundObject.packages.filter((r) => r === premiumId).length
        ) {
          refundObject.packages = refundObject.packages.filter((r) => r !== premiumNewId && r !== premiumPlusId);
          logger.info(`package replace to basePlus for invoice ${refundObject.invoiceNumber}`);
          refundObject.packages.push(premiumId);
        }
        const toParents = {};
        let currentPayer = currentProvider._id.toString();
        let curPriceGroup = currentProvider.priceGroup;
        // eslint-disable-next-line no-restricted-syntax
        for (const parentOtt of globalParentOtts[provider]) {
          let parentOttKey = parentOtt._id.toString();
          toParents[parentOtt._id.toString()] = { amount: 0 };

          let currentParentPackagesDict = globalParentOttPackages[provider][parentOtt._id.toString()];

          for (const packageId of refundObject.packages) {
            const pricePackageId = packageId;
            if (hasBadPrice(globalParentOttPackages[provider], parentOttKey, pricePackageId)) {
              if (hasBadPrice(globalParentOttPackages[provider], parentOttKey, pricePackageId)) {
                parentOttKey = globalParentOtts[provider][globalParentOtts[provider].length - 1]._id.toString();
                logger.info(`package using parent price for invoice ${refundObject.invoiceNumber}`);
              }
            }
            currentParentPackagesDict = globalParentOttPackages[provider][parentOttKey];
            if (currentParentPackagesDict[pricePackageId]) {
              const curPlus = priceUtils.calculateDateIntervalPrice(
                currentParentPackagesDict[pricePackageId].option,
                refundObject.startDate,
                refundObject.endDate,
                refundObject.room,
                false,
                curPriceGroup,
                null
              );
              if (curPlus !== -1 && curPlus !== null && typeof curPlus !== 'undefined') {
                toParents[parentOtt._id.toString()].amount += curPlus !== null ? -curPlus : 0;
              } else {
                notCaluclatedPrices.push({
                  option: currentParentPackagesDict[pricePackageId].option,
                  package: pricePackageId,
                  invoicePackages: refundObject.packages,
                  invoice: refundObject.invoiceNumber,
                });
                const badCase = true;
                logger.info(
                  `login has bas++ but also has ${currentParentPackagesDict[pricePackageId].name[0].name} with no price`
                );
              }
            } else {
              const a = 1;
            }
          }
          toParents[parentOtt._id.toString()].from = currentPayer;
          currentPayer = parentOtt._id.toString();
          curPriceGroup = parentOtt.priceGroup;
        }
        const target = payedTransaction.invoice.payloadCalculated;
        target.locations.filter((r) => r.packageRemoves.length > 0 && r.totalPrice !== 0)[0].toParents = toParents;
        await Invoice.updateOne(
          { _id: payedTransaction.invoice._id.toString() },
          { payloadCalculated: payedTransaction.invoice.payloadCalculated }
        );
        const payedParent = false;

        // clean old transactions
        const deleted = await Transaction.deleteMany({
          invoice: payedTransaction.invoice._id.toString(),
          source_type: 'EXECUTE_INVOICE',
          transaction_type: 'B_TO_B',
        });
        // continue;
        for (const curParentKey of Object.keys(toParents)) {
          const curPay = toParents[curParentKey];
          if (curPay.amount !== 0 && curPay.from) {
            const curUser = await User.findOne({ _id: payedTransaction.invoice.user }).populate([{ path: 'provider' }]);
            const transaction = await TransactionService.createInvoiceExecutionTransaction(
              payedTransaction.invoice,
              curPay.amount > 0 ? curPay.from : curParentKey,
              curPay.amount > 0 ? curParentKey : curPay.from,
              Math.abs(curPay.amount),
              curPay.amount < 0,
              curUser || { provider: { id: payedTransaction.invoice.provider } }
            );
            const newExecutionDate = new Date(payedTransaction.invoice.createdAt);
            newExecutionDate.setMinutes(newExecutionDate.getMinutes() + 1);
            const updatedTransaction = await Transaction.updateOne(
              { _id: transaction._id.toString() },
              {
                state: 1,
                isRefund: true,
                executionDate: newExecutionDate,
                payloadExecuted: true,
              }
            );
            // const executed = await TransactionService.executeTransaction(transaction);
            // if (executed) payedParent = true;
          }
        }
      }
    }
  }
  logger.info(`not calculated Transactions ${notCaluclatedPrices.length}`);
  for (const currentProvider of providers) {
    const provider = currentProvider._id.toString(); // '647876c7643f847e32e437de';
    // if (!subProviders.filter((r) => r === provider).length) continue;
    // if (provider !== '645799071c5b7b1510f5388c') continue;
    const ottProvider = await OttProvider.findOne({ _id: provider });
    const oldBalance = ottProvider.balance;
    let transactions = await Transaction.find({
      $or: [{ provider }, { to_provider: provider }, { from_provider: provider }],
    }).populate([{ path: 'invoice' }]);

    transactions = await Transaction.find({
      $or: [{ to_provider: provider }, { from_provider: provider }],
    }).populate([{ path: 'invoice' }]);
    const interesetedTransactions = transactions.filter(
      (r) => (r.transaction_type === 'B_TO_B' || r.transaction_type === 'TO_B') && r.fixed !== true
    );
    // let inBalance = 0;
    // for (const transaction of inTransactions) {
    //   if (transaction.source_type === 'EXECUTE_INVOICE' && transaction.to_type === transaction.from_type) {
    //   } else {
    //     inBalance += transaction.amount;
    //   }
    // }
    // let outBalance = 0;
    // for (const transaction of outTransactions) {
    //   outBalance += transaction.amount;
    // }
    // const totalBalance = inBalance - outBalance;
    // const initialBalance = oldBalance - totalBalance;
    const interesetedTransactionsSorted = interesetedTransactions.sort((a, b) => a.date - b.date);
    // if (interesetedTransactionsSorted.length && typeof interesetedTransactionsSorted[0].balanceBefore !== 'undefined') {
    //   oldBalance = interesetedTransactionsSorted[0].balanceBefore;
    // }
    let finalBalance = 0;
    for (const transaction of interesetedTransactionsSorted) {
      if (
        transaction.state === 1 &&
        (transaction.transaction_type === 'B_TO_B' || transaction.transaction_type === 'TO_B')
      ) {
        if (!transaction.balanceHistory) transaction.balanceHistory = {};
        if (transaction.to_provider?.toString() === provider) {
          transaction.balanceHistory[transaction.to_provider?.toString()] = {};
          transaction.balanceHistory[transaction.to_provider?.toString()].balanceBefore = finalBalance;
          if (
            transaction.from_type === transaction.to_type &&
            (transaction.source_type === 'EXECUTE_INVOICE' || transaction.source_type === 'ADD_BALANCE')
          ) {
            if (transaction.transaction_type === 'TO_B') finalBalance += Math.abs(transaction.amount);
          }
          transaction.balanceHistory[transaction.to_provider?.toString()].balanceAfter = finalBalance;
        } else if (transaction.from_provider?.toString() === provider) {
          transaction.balanceHistory[transaction.from_provider?.toString()] = {};
          transaction.balanceHistory[transaction.from_provider?.toString()].balanceBefore = finalBalance;
          if (
            transaction.from_type === transaction.to_type &&
            (transaction.source_type === 'EXECUTE_INVOICE' || transaction.source_type === 'ADD_BALANCE')
          ) {
            if (!(transaction.source_type === 'EXECUTE_INVOICE' && transaction.isRefund))
              finalBalance -= Math.abs(transaction.amount);
          }
          transaction.balanceHistory[transaction.from_provider?.toString()].balanceAfter = finalBalance;
        }
      }
      await transaction.save();
    }
    ottProvider.balance = finalBalance;
    await OttProvider.updateOne({ _id: ottProvider._id.toString() }, { balance: finalBalance });
    logger.info(`executed transactions: ${transactions.length}, totalBalance" ${ottProvider.balance}`);
  }
};

const clientsFix = async () => {
  let clients = await Client.find({ status: 1 });
  let hasBillingOn = clients.filter((r) => r?.finance?.paperlessBilling === true);
  logger.info(`hasPaperless: ${hasBillingOn.length}`);
  let index = 0;
  for (const client of clients) {
    index += 1;
    let { finance } = client;
    if (!finance) {
      finance = { paperlessBilling: false };
    } else {
      finance.paperlessBilling = !finance.paperlessBilling;
    }

    await Client.updateOne({ _id: client._id.toString() }, { finance });
    logger.info(`updating paperless ${index}/${clients.length}`);
  }
  clients = await Client.find({ status: 1 });
  hasBillingOn = clients.filter((r) => !r?.finance?.paperlessBilling);
  logger.info(`hasPaperless after swtich: ${hasBillingOn.length}`);
};
const fixInvoices = async () => {
  const clients = await Client.find({ status: 1 });
  const filteredClients = clients.filter((r) => !r.finance || !r.finance.paperlessBilling);
  logger.info(`disabled paperlessBillings: ${filteredClients.length}`);
  let theirInvoices = [];
  for (const client of filteredClients) {
    const invoices = await await Invoice.find({ type: 2, client: client._id.toString() });
    theirInvoices = theirInvoices.concat(invoices);
  }

  for (const invoice of theirInvoices) {
    await Invoice.deleteOne({ _id: invoice._id.toString() });
  }
  logger.info(`invoices with disabled paperlessBillings: ${theirInvoices.length}`);
};

const creditCardsFix = async () => {
  const transactionsWithCards = await Transaction.find({ transaction_type: 'C_TO_A' });
  const cardNumberFix = transactionsWithCards.filter((r) => r.sourcePay && (r.sourcePay.cardNumber || r.sourcePay.cvc));
  for (const transaction of cardNumberFix) {
    if (transaction.sourcePay) {
      const sourcePay = { ...(transaction.sourcePay.toJSON ? transaction.sourcePay.toJSON() : transaction.sourcePay) };
      if (sourcePay.cardNumber) {
        sourcePay.cardNumber = TransactionService.hideCardNumber(sourcePay.cardNumber);
      }
      if (sourcePay.cvc) {
        sourcePay.cvc = TransactionService.hideCVC(sourcePay.cvc);
      }
      await Transaction.updateOne({ _id: transaction.id }, { sourcePay });
    }
  }
  logger.info(`card transactions: ${cardNumberFix}`);
};

const fixMoneyOrders = async () => {
  const transactionsWithCheckMoneyOrder = await Transaction.find({
    $or: [{ transaction_type: 'CH_TO_B' }, { transaction_type: 'MO_TO_B' }],
  });
  let ok = 0;
  let notNormal = 0;
  let updated = 0;
  for (const transaction of transactionsWithCheckMoneyOrder) {
    let { sourcePay } = transaction;
    if (transaction.transaction_type === 'CH_TO_B') {
      if (typeof transaction.sourcePay === 'string') {
        sourcePay = {
          number: sourcePay,
        };
        await Transaction.updateOne({ _id: transaction._id.toString() }, { sourcePay });
        updated += 1;
      } else if (transaction.sourcePay?.number) {
        ok += 1;
      } else {
        notNormal += 1;
      }
    }
    if (transaction.transaction_type === 'MO_TO_B') {
      if (typeof transaction.sourcePay === 'string') {
        sourcePay = {
          number: sourcePay,
        };
        await Transaction.updateOne({ _id: transaction._id.toString() }, { sourcePay });
        updated += 1;
      } else if (transaction.sourcePay?.number) {
        ok += 1;
      } else {
        if (typeof transaction.sourcePay === 'object') {
          sourcePay = {
            number: '',
          };
          for (const key of Object.keys(transaction.sourcePay)) {
            sourcePay.number = `${sourcePay.number}${transaction.sourcePay[key]}`;
          }
          await Transaction.updateOne({ _id: transaction._id.toString() }, { sourcePay });
        }
        notNormal += 1;
      }
    }
  }

  logger.info(`ok: ${ok}, updated: ${updated}, notNormal: ${notNormal}`);
};

const fixRecurring = async () => {
  let hdZonaRecurring = 0;
  let updateToNotRecurring = 0;
  const subscriptions = await Subscription.find({ state: 1 }).populate([{ path: 'client' }]);
  for (const subscription of subscriptions) {
    const { recurringPayment } = subscription;
    if (recurringPayment) {
      if (subscription?.client?.provider && subscription?.client?.provider?.toString() !== '645799af1c5b7b1510f799d5') {
        await Subscription.updateOne({ _id: subscription._id.toString() }, { recurringPayment: false });
        updateToNotRecurring += 1;
        logger.info(`updating recuring to FALSE`);
      } else {
        const clientPayments = await clientPaymentMethodRepository.getClientPaymentMethods(
          subscription?.client?._id.toString()
        );
        if (clientPayments.length) {
          hdZonaRecurring += 1;
          await Subscription.updateMany({ state: 1, client: subscription?.client?._id.toString() });
        }
      }
    }
  }
  logger.info(`hdzona recurring ${hdZonaRecurring}, updated to not recurring ${updateToNotRecurring}`);
};

const testShipping = async () => {
  const response = await ShippingService.createLabel({
    easyship_shipment_id: 'ESUS158932731',
    provider: '645799071c5b7b1510f5388c',
  });
  const a = 1;
};

const fixInvoiceSentType = async () => {
  const invoices = await Invoice.find({ sent: true });
  let cur = 0;
  for (const invoice of invoices) {
    cur += 1;
    let type = 'print';
    if (invoice.postalMethodId) type = 'postal';
    await Invoice.updateOne({ _id: invoice._id.toString() }, { sentType: type });
    logger.info(`updating invoice${cur}/${invoices.length}`);
  }
};

const awaitClientSubscription = async () => {
  await SubscriptionService.updateSubscriptionStates('647899974a7b10c3f941c98e');
  logger.info(`done`);
};

const fixAutopaymentTransactions = async () => {
  const invoices = await Invoice.find({ type: 1, user: { $eq: null } });
  const transactions = await Transaction.find({ source_type: 'PAY_INVOICE', user: { $eq: null } });
  for (const transaction of transactions) {
    const sourcePay = { ...transaction.sourcePay };
    sourcePay.merchant = 'authorize';
    await Transaction.updateOne({ _id: transaction._id.toString() }, { autopayment: true, sourcePay });
    await Invoice.updateOne({ _id: transaction.invoice.toString() }, { autopayment: true });
  }
  logger.info(`done`);
};

const thermalReceptPrinter = async () => {
  const printer = new ThermalPrinter({
    type: PrinterTypes.EPSON, // Printer type: 'star' or 'epson'
    interface: 'tcp://141.136.88.164', // Printer interface
    characterSet: CharacterSet.PC437_USA, // Printer character set - default: SLOVENIA
    removeSpecialCharacters: false, // Removes special characters - default: false
    lineCharacter: '=', // Set character for lines - default: "-"
    breakLine: BreakLine.WORD, // Break line after WORD or CHARACTERS. Disabled with NONE - default: WORD
    options: {
      // Additional options
      timeout: 5000, // Connection timeout (ms) [applicable only for network printers] - default: 3000
    },
  });

  const isConnected = await printer.isPrinterConnected(); // Check if printer is connected, return bool of status
  try {
    await printer.cut();
    await printer.printImage('/home/harut/Desktop/1.png');
    await printer.cut();
    await printer.execute(); // Executes all the commands. Returns success or throws error
    // const raw = await printer.raw(Buffer.from('Hello world')); // Print instantly. Returns success or throws error
  } catch (e) {
    logger.error(e);
  }
};

const subscriptionsFilterTest = async () => {
  const subs = await Subscription.find({}).populate([{ path: 'location' }]);
  const subsDict = subs.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    if (item.location && item.location._id) {
      if (!obj[item.location._id.toString()]) {
        obj[item.location._id.toString()] = [];
      }
      obj[item.location._id.toString()].push(item);
    }
    return obj;
  }, {});

  // get problematics
  const bothList = [];
  const bothClients = [];
  for (const key of Object.keys(subsDict)) {
    const curList = subsDict[key];
    const both =
      curList.filter((r) => r.isActive && r.state === 1).length &&
      curList.filter((r) => !r.isActive && r.state === 1).length;
    // filter which has no state === 1 but has isActive different
    if (both) {
      bothList.push(subsDict[key]);
      for (const sub of subsDict[key]) {
        if (!sub.isActive && sub.state === 1) {
          await Subscription.updateOne({ _id: sub._id.toString() }, { isActive: 1 });
          logger.info(`updated isActive`);
        }
      }
      bothClients.push(curList[0].location);
    }
  }
  for (const location of bothClients) {
    logger.info(`problematic login: client ${location.login}`);
  }
  logger.info(`list: ${bothList.length}`);
};

// const moment = require('moment-timezone');

// const moment = require('moment');

const fixLocationTimezones = async () => {
  const locations = await ClientLocation.find({}).populate([{ path: 'clientId' }]);
  const hasTimezone = locations.filter((r) => r.timezone);
  for (const location of locations) {
    const offsetString = location.timezone; // For example

    const provider = await OttProvider.findOne({ _id: location.clientId.provider });

    if (provider.timezone) {
      const saveTimezone = provider.timezone;
      await ClientLocation.updateOne({ _id: location._id.toString() }, { timezone: saveTimezone });
      logger.info(`provider: ${provider.timezone}, location: ${location.timezone}, now: ${saveTimezone}`);
      logger.info(`provider timezones: ${provider.timezone}`);
    } else {
      logger.info(`provider name: ${provider.name[0].name}`);
      // const offset = parseInt(location.timezone);
      // const timestamp = moment.utc().add(offset, 'hours').unix() * 1000;

      // const zones = moment.tz.names().filter((zoneName) => {
      //   const zone = moment.tz.zone(zoneName);
      //   const zoneOffset = -zone.utcOffset(timestamp) / 60;
      //   return zoneOffset === offset;
      // });

      // const exists = zones.filter((r) => r === provider.timezone);
    }
  }
  logger.info(`done fixing transaction timezones`);
};

// const testClover = async () => {
//   const sdk = require('api')('@clover-platform');

//   sdk.auth('96d5b2b2-3267-c6cf-2195-43c23dd4a21e');
//   sdk
//     .getApiKey()
//     .then(({ data }) => console.log(data))
//     .catch((err) => console.error(err));
// };

const checkeeperTest = async () => {
  const API_ENDPOINT = 'https://my.checkeeper.com/api/v2/bank/lookup/';
  const TOKEN = '7tTd1Em8RouB1lIo94TrFnXE'; // Replace with your token
  const SECRET = 'HoNBUF9Hrle0yoyOFf&1lDqAcGp*Pr5$'; // Replace with your secret
  const options = {
    secretKey: SECRET,
  };
  {
    const obj = {
      token: TOKEN,
      country: 'US',
    };

    const signature = checkeeperSignature(obj, options);

    // eslint-disable-next-line no-inner-declarations
    async function isApiKeyValid() {
      try {
        const response = await axios.post(API_ENDPOINT, {
          token: TOKEN,
          signature,
          country: 'US',
        });

        // Inspect the response to determine if the key is valid. The exact condition can depend on the API's response structure.
        if (response.data && response.data.success) {
          logger.info('API key is valid!');
          return true;
        }
        logger.info('API key is invalid!');
        return false;
      } catch (error) {
        logger.info('Error checking API key:', error.message);
        return false;
      }
    }
    const isValid = await isApiKeyValid();
  }
  {
    const CREATE_URL = 'https://my.checkeeper.com/api/v2/check/create/';
    const createData = {
      token: TOKEN,
      test: '0',
      date: '2020-06-14',
      check_number: '5004',
      amount: '5,230.00',
      memo: 'Widget supply order',
      bank_routing: '121042882',
      bank_account: '7004197294',
      return_pdf: '1',
      payer: {
        name: 'Moi',
        address: {
          line1: '827 Random Street',
          line2: 'Suite 102',
        },
        city: 'Anytown',
        state: 'NY',
        zip: '14850',
      },
      payee: {
        name: "Bob's Supplies",
        address: {
          line1: '114 Project Lane',
        },
        city: 'Tinkertown',
        state: 'CA',
        zip: '90210',
        country: 'US',
      },
      template: 'KKKK',
    };
    let signature = checkeeperSignature(createData, options);

    // eslint-disable-next-line no-inner-declarations
    async function createCheck() {
      try {
        const response = await axios.post(CREATE_URL, { ...createData, signature });

        // Inspect the response to determine if the key is valid. The exact condition can depend on the API's response structure.
        if (response.data && response.data.success) {
          logger.info('API key is valid!');
          return response.data.check;
          return true;
        }
        logger.info('API key is invalid!');
        return false;
      } catch (error) {
        logger.info('Error checking API key:', error.message);
        return false;
      }
    }

    // const check = { id: 'LWnzXorXHEjPndvNbDJQDUz-YpVnhWHgpMTY' };
    const check = await createCheck();

    const obj = {
      token: TOKEN,
      check_id: check.id,
    };

    signature = checkeeperSignature(obj, options);

    // eslint-disable-next-line no-inner-declarations
    async function getStatus() {
      try {
        const response = await axios.post(`https://my.checkeeper.com/api/v2/check/status/`, {
          token: TOKEN,
          check_id: check.id,
          signature,
        });

        // Inspect the response to determine if the key is valid. The exact condition can depend on the API's response structure.
        if (response.data && response.data.success) {
          logger.info('API key is valid!');
          return true;
        }
        logger.info('API key is invalid!');
        return false;
      } catch (error) {
        logger.info('Error checking API key:', error.message);
        return false;
      }
    }
    const isValidResponse = await getStatus();

    const imageObj = {
      token: TOKEN,
      check_id: check.id,
    };

    signature = checkeeperSignature(imageObj, options);

    // eslint-disable-next-line no-inner-declarations
    async function getImage() {
      try {
        const response = await axios.post(`https://my.checkeeper.com/api/v2/check/image/`, {
          token: TOKEN,
          check_id: check.id,
          signature,
        });

        // Inspect the response to determine if the key is valid. The exact condition can depend on the API's response structure.
        if (response.data && response.data.success) {
          logger.info('API key is valid!');
          return true;
        }
        logger.info('API key is invalid!');
        return false;
      } catch (error) {
        logger.info('Error checking API key:', error.message);
        return false;
      }
    }
    const getImageResponse = await getImage();

    // const APPROVE_URL = 'https://my.checkeeper.com/api/v2/check/approve/';
    // const approveData = {
    //   token: TOKEN,
    //   check_id: check.id,
    // };
    // signature = checkeeperSignature(approveData, options);

    // // eslint-disable-next-line no-inner-declarations
    // async function approveCheck() {
    //   try {
    //     const response = await axios.post(APPROVE_URL, { ...approveData, signature });

    //     // Inspect the response to determine if the key is valid. The exact condition can depend on the API's response structure.
    //     if (response.data && response.data.success) {
    //       logger.info('API key is valid!');
    //       return true;
    //     }
    //     logger.info('API key is invalid!');
    //     return false;
    //   } catch (error) {
    //     logger.info('Error checking API key:', error.message);
    //     return false;
    //   }
    // }

    // await approveCheck();
  }
};

const cancelBadEndDateInvoices = async () => {
  const subscriptions = await Subscription.find({});

  const subscriptionsByLocations = subscriptions.reduce((obj, item) => {
    if (!obj[item.location.toString()]) {
      obj[item.location.toString()] = [];
    }
    // eslint-disable-next-line no-param-reassign
    obj[item.location.toString()].push(item);
    return obj;
  }, {});
  for (const locationId of Object.keys(subscriptionsByLocations)) {
    const locationSubscriptions = subscriptionsByLocations[locationId];

    const locationSubscriptionGroupedinvoice = locationSubscriptions.reduce((obj, item) => {
      if (!item.invoice) return obj;
      if (!obj[item.invoice.toString()]) {
        obj[item.invoice.toString()] = [];
      }
      // eslint-disable-next-line no-param-reassign
      obj[item.invoice.toString()].push(item);
      return obj;
    }, {});

    // end date bad case
    let unnormalCast = false;
    let unnormalFixed = false;
    if (Object.keys(locationSubscriptionGroupedinvoice).length > 1) {
      const lastGroup =
        locationSubscriptionGroupedinvoice[
          Object.keys(locationSubscriptionGroupedinvoice)[Object.keys(locationSubscriptionGroupedinvoice).length - 1]
        ];
      const preLastGroup =
        locationSubscriptionGroupedinvoice[
          Object.keys(locationSubscriptionGroupedinvoice)[Object.keys(locationSubscriptionGroupedinvoice).length - 2]
        ];

      const lastHasCanceled = lastGroup.filter((r) => r.returnInvoice).length;
      const preLastHasCanceled = preLastGroup.filter((r) => r.returnInvoice).length;
      if (!lastHasCanceled && !preLastHasCanceled) {
        lastGroup.forEach((sub) => {
          const packageSubsInPreLast = preLastGroup.filter((r) => r.package.toString() === sub.package.toString());
          if (packageSubsInPreLast.length) {
            if (packageSubsInPreLast[0].endDate >= sub.endDate) {
              unnormalCast = true;
            }
          }
        });

        if (unnormalCast) {
          const lastInvoice = await Invoice.findOne({ _id: lastGroup[0].invoice.toString() });
          const preLastInvoice = await Invoice.findOne({ _id: preLastGroup[0].invoice.toString() });
          const user = await User.findOne({ _id: lastInvoice.user }).populate([{ path: 'provider' }]);
          const cancelResult = await InvoiceService.cancelInvoice(lastInvoice, user);
          const executeResult = await InvoiceService.executeInvoice(preLastInvoice, user);
          unnormalFixed = true;
        }
      }
    }
    if (unnormalCast) {
      logger.info(
        `location ${locationId}, client: ${locationSubscriptions[0].client}, checkouts: ${
          Object.keys(locationSubscriptionGroupedinvoice).length
        }, fixed: ${unnormalFixed}`
      );
    }
  }
  logger.info(`number of locations with subscriptions ${Object.keys(subscriptionsByLocations).length}`);
};

const fixClientFinancePackages = async () => {
  const clients = await Client.find({ status: 1 });
  const toFix = clients.filter((r) => r.finance && typeof r.finance.forPackages !== 'undefined');
  let cur = 0;
  for (const client of toFix) {
    if (!client.finance.forPackages || !mongoose.Types.ObjectId.isValid(client.finance.forPackages)) {
      const a = 1;
      const { finance } = client;
      finance.forPackages = null;
      await Client.updateOne({ _id: client._id.toString() }, { finance });
      cur += 1;
      logger.info(`fixing number: ${cur}`);
    }
  }
};

const { clientSharedRepository } = require('../../../src/repository');
const CloverService = require('../../../src/services/payment/merchant/clover.service');
const TokenService = require('../../../src/services/token/token.service');

const clientLocationSubscriptionInfoAdd = async () => {
  const clients = await Client.find({ status: 1 });
  let cur = 0;
  for (const client of clients) {
    cur += 1;
    await SubscriptionService.updateSubscriptionStates(client._id.toString());
    logger.info(`updating client ${cur}/${clients.length}`);
  }
};

const cleanShippings = async () => {
  const shippings = await Shipping.find({});
  const toDeleteShippings = shippings.filter((r) => !r.easyship_shipment_id);
  for (const toDelete of toDeleteShippings) {
    await Shipping.deleteOne({ _id: toDelete._id.toString() });
  }
  logger.info(`done`);
};

const fixFees = async () => {
  const transactions = await Transaction.find({}).populate([{ path: 'invoice' }]);
  const all = transactions.length;
  let current = 0;
  for (const transaction of transactions) {
    if (transaction.amount + transaction.fee !== transaction.totalAmount) {
      const a = 1;
      const { bankFee } = transaction.invoice.payloadCalculated;
      if (transaction.fee && !bankFee) {
        await Transaction.updateOne(
          { _id: transaction._id.toString() },
          { fee: bankFee, totalAmount: transaction.amount + bankFee }
        );
        const updateObject = { payloadCalculated: transaction.invoice.payloadCalculated };
        updateObject.totalPrice = updateObject.price + bankFee;
        await Invoice.updateOne({ _id: transaction.invoice._id.toString() }, updateObject);
      } else {
        await Transaction.updateOne(
          { _id: transaction._id.toString() },
          { amount: transaction.totalAmount - transaction.fee }
        );
      }
    }
    continue;
    current += 1;
    let fee = 0;
    if (transaction.fee) fee = transaction.fee;
    let totalAmount = 0;
    if (transaction.totalAmount) totalAmount = transaction.totalAmount;
    let amount = 0;
    if (transaction.amount) amount = transaction.amount;
    if (transaction.source_type === 'PAY_INVOICE') {
      if (transaction.invoice?.payloadCalculated?.bankFee) {
        fee = transaction.invoice?.payloadCalculated?.bankFee;
      }
      if (transaction.transaction_type !== 'C_TO_A') {
        if (fee) {
          const updateObject = { payloadCalculated: transaction.invoice.payloadCalculated };
          updateObject.payloadCalculated.totalPrice -= updateObject.payloadCalculated.bankFee;
          updateObject.totalAmount = transaction.invoice.totalAmount - updateObject.payloadCalculated.bankFee;
          updateObject.amount = updateObject.totalAmount;
          updateObject.payloadCalculated.bankFee = 0;
          await Invoice.updateOne({ _id: transaction.invoice._id.toString() }, updateObject);

          logger.info(`fixing invoice ${transaction.invoice.number}`);

          if (!totalAmount) {
            logger.info(
              `fixing (not C_TO_A) ${transaction.number} from amount: ${amount}, fee: ${fee}, totalAmount: ${totalAmount}`
            );
            amount -= fee;
            totalAmount = amount;
            logger.info(
              `fixing (not C_TO_A) ${transaction.number} to amount: ${amount}, fee: ${fee}, totalAmount: ${totalAmount}`
            );
          }
        } else {
          fee = 0;
          totalAmount = amount;
          logger.info(
            `fixing (normal case) ${transaction.number} to amount: ${amount}, fee: ${fee}, totalAmount: ${totalAmount}`
          );
        }
      } else if (!totalAmount) {
        logger.info(`fixing (C_TO_A) ${transaction.number} to amount: ${amount}, fee: ${fee}, totalAmount: ${totalAmount}`);
        totalAmount = amount;
        amount -= fee;
        logger.info(`fixing (C_TO_A) ${transaction.number} to amount: ${amount}, fee: ${fee}, totalAmount: ${totalAmount}`);
      } else {
        amount -= fee;
        logger.info(`fixing (C_TO_A) ${transaction.number} to amount: ${amount}, fee: ${fee}, totalAmount: ${totalAmount}`);
      }
    } else {
      fee = 0;
      totalAmount = amount + fee;
    }
    await Transaction.updateOne({ _id: transaction._id.toString() }, { fee, totalAmount, amount });
    logger.info(`transaction ${current}/${all}`);
  }
  logger.info(`done fixing`);
};
function isFirstLetterAlphabetic(str) {
  return /^[A-Za-z]/.test(str);
}

const clientAddressCheck = async () => {
  // const mapImageResult = StreetService.getMapImage(
  //   {
  //     lat: 44.1231321,
  //     long: 40.0123123,
  //   },
  //   {},
  //   { key: 'AIzaSyAij3x_iuPKGdiX7kOJT0oThOxuv9lOGJI' }
  // );
  const ewordId = '645799071c5b7b1510f5388c';
  const childOtts = await ottProviderRepository.getOttChilds(ewordId);
  const ottIdList = childOtts.map((r) => r.id);
  ottIdList.push(ewordId);
  const eWordClients = await Client.find({ status: 1, provider: { $in: ottIdList } });
  const otherClients = await Client.find({ status: 1, provider: { $nin: ottIdList } });
  const authData = {
    authId: '5b8ebc83-788c-d791-203e-a3ed479549ae',
    authToken: 'C40Fx0tmrPO39mIxNjQg',
    license: 'us-core-cloud',
  };

  const googleCred = { key: 'AIzaSyAij3x_iuPKGdiX7kOJT0oThOxuv9lOGJI' };
  let current = 0;
  for (const eWordClient of eWordClients) {
    current += 1;
    logger.info(`client: ${eWordClient.id}, current ${current}/${eWordClients.length}`);

    const { addresses } = eWordClient;
    for (const address of addresses) {
      const validtaionResult = await StreetService.validateClientAddress(address, authData);
      if (validtaionResult.status === true) {
        address.isValid = validtaionResult.isValid;
        if (!validtaionResult.isValid) address.validationMessage = validtaionResult.validationMessages.toString();
        address.validationObject = {
          newaddress: validtaionResult.newAddress,
          oldAddress: validtaionResult.oldAddress,
        };
        if (address.validationObject.newaddress) {
          const imageResult = await StreetService.getMapImage(
            {
              lat: address.validationObject.newaddress.lat,
              long: address.validationObject.newaddress.long,
              address: address.validationObject.newaddress.delivery_line_1,
            },
            {},
            googleCred
          );
          if (imageResult.status) {
            address.image = imageResult.image;
          }
        }
      } else {
        logger.error(validtaionResult.messages.toString());
      }
      const a = 1;
    }

    await Client.updateOne({ _id: eWordClient._id.toString() }, { addresses });
  }

  const otherClientsWrong = otherClients.filter(
    (r) => r.addresses.filter((a) => !a.address || !a.city || !a.province || !a.zip).length
  );
  const otherClientsRight = otherClients.filter(
    (r) => r.addresses.filter((a) => a.address && a.city && a.province && a.zip).length
  );
  logger.info(
    `otherClients: ${otherClients.length}, wrongs: ${otherClientsWrong.length} rights: ${otherClientsRight.length}`
  );
  for (const otherClient of otherClientsWrong) {
    const { addresses } = otherClient;
    for (const address of addresses) {
      address.isValid = false;
    }
    await Client.updateOne(
      { _id: otherClient._id.toString() },
      { isValid: false, validationMessage: 'client has invalid address' }
    );
  }
  for (const otherClient of otherClientsRight) {
    const { addresses } = otherClient;
    for (const address of addresses) {
      address.isValid = true;
    }
    await Client.updateOne(
      { _id: otherClient._id.toString() },
      { isValid: true, validationMessage: 'client has valid address' }
    );
  }
  logger.info(`done`);
  return;
  const client = {};
  const addressClients = client.filter((r) => r.addresses && r.addresses.length && r.subscriptionActivationDate);
  // !a.address || !a.city || !a.province || !a.zip ||
  const addressWrongs = addressClients.filter(
    (r) => r.addresses.filter((a) => !a.address || !a.city || !a.province || !a.zip).length
  );
  const suiteWrongs = addressClients.filter(
    (r) =>
      r.addresses.filter(
        (a) => a.address && a.city && a.province && a.zip && !(isFirstLetterAlphabetic(a.suite) || !a.suite)
      ).length
  );
};

const fixSubscriptionMigrationWrongDate = async () => {
  const result = await GeoIpService.look('2603:8000:9c44:2000:Ca7:F050:8281:7678');

  const ewordId = '645799071c5b7b1510f5388c';
  const childOtts = await ottProviderRepository.getOttChilds(ewordId);
  const ottIdList = childOtts.map((r) => r.id);
  ottIdList.push(ewordId);
  const subsriptions = await Subscription.find({ state: 1, provider: { $in: ottIdList } }).populate([{ path: 'location' }]);

  const subsriptionsDict = subsriptions.reduce((obj, item) => {
    const key = item.location?.login || item.client.toString();
    // eslint-disable-next-line no-param-reassign
    if (!obj[key]) obj[key] = [];
    // eslint-disable-next-line no-param-reassign
    obj[key].push(item);
    return obj;
  }, {});

  const subDict = {};
  for (const key of Object.keys(subsriptionsDict)) {
    const subs = subsriptionsDict[key];
    if (!subs.filter((r) => !r.migrated).length) {
      if (!subs.filter((r) => r.isActive).length) subDict[key] = subs;
    }
  }

  for (const key of Object.keys(subDict)) {
    const subs = subDict[key];
    for (const sub of subs) {
      const { startDate, endDate } = sub;
      startDate.setFullYear(startDate.getFullYear() - 1);
      endDate.setFullYear(endDate.getFullYear() - 1);
      await Subscription.updateOne({ _id: sub._id.toString() }, { startDate, endDate, state: 0 });
    }
    await SubscriptionService.updateSubscriptionStates(subs[0].client.toString());
  }
};

const syncCards = async (providerId) => {
  const clients = await Client.find({ provider: { $in: [providerId] } });
  const clientIds = clients.map((r) => r.id);
  const paymentMethods = await ClientPaymentMethod.find({ clientId: { $in: clientIds } });
  logger.info(`hdzona payments: ${paymentMethods.length}`);
  let current = 0;
  for (const currentPaymentMethod of paymentMethods) {
    current += 1;
    let paymentMethod = currentPaymentMethod;
    const validMethod = await CardService.clientPaymentMethodValidator(paymentMethod.clientId, paymentMethod);

    if (validMethod.status) {
      paymentMethod = validMethod.paymentMethod;
      if (
        paymentMethod.creditCard &&
        paymentMethod.creditCard.billingAddress &&
        paymentMethod.creditCard.phone &&
        paymentMethod.creditCard.number
      ) {
        paymentMethod.creditCard.billingAddress.phone = paymentMethod.creditCard.billingAddress.phone.number;
      }
    }
    const syncResult = await CardService.syncCard(paymentMethod.clientId, paymentMethod);
    if (syncResult.status) {
      syncResult.paymentObject.isValid = true;
      syncResult.paymentObject.creditCard = TransactionService.hideCard(syncResult.paymentObject.creditCard);
      const updatedPaymentMethod = await clientPaymentMethodRepository.updateClientPaymentMethodById(
        paymentMethod.id,
        syncResult.paymentObject
      );
    }
    logger.info(`client payment methods ${current}/${paymentMethods.length}`);
  }
};

const fixRecurringFinanceCards = async () => {
  const clients = await Client.find({ 'finance.forPackages': { $ne: null } }).populate([{ path: 'finance.forPackages' }]);

  for (const client of clients) {
    if (!client.finance.forPackages?._id) {
      logger.info(`client card fixed ${client.id}`);
      const finance = { ...client.finance.toJSON() };
      finance.forPackages = null;
      await Client.updateOne({ _id: client.id }, { finance });
    }
  }
  /**
  const clients = await Client.find({ 'finance.forPackages': { $ne: null } });
  logger.info(`clients with recurring cards ${clients.length}`);
  let index = 0;
  const list = [];
  const updateFinance = async (client) => {
    const finance = { ...client.finance.toJSON() };
    finance.forPackages = null;
    await Client.updateOne({ _id: client.id }, { finance });
    const updated = await Client.findOne({ _id: client.id });
    const a = 1;
  };
  for (const client of clients) {
    if (client.finance.forPackages) {
      try {
        const paymentMethods = await clientPaymentMethodRepository.getClientPaymentMethodById(client.finance.forPackages);
        logger.info(`client: ${client.id} paymentmethods`);
        if (!paymentMethods) {
          index += 1;
          logger.info(`fixing client card not found: ${client.id}`);
          await updateFinance(client);
        } else if (paymentMethods.clientId.toString() !== client.id.toString()) {
          index += 1;
          list.push(client.id);
          logger.info(`fixing client not his card: ${client.id}`);
          await updateFinance(client);
        }
      } catch (ex) {
        logger.error(ex);
        logger.info(`fixing client: ${client.id}`);
        await updateFinance(client);
      }
    } else {
      logger.info(`client: ${client.id} forPackages null`);
    }
  }
  logger.info(`fixed cards: ${index}`);
  logger.info(list.toString()); */
};

const fixBadCancels = async () => {
  logger.info(`fixing bad cancels`);
  let index = 1;
  const subscriptions = await Subscription.find({ returnInvoice: { $ne: null }, state: 1 });
  for (const sub of subscriptions) {
    index += 1;
    await Subscription.updateOne({ _id: sub._id.toString() }, { state: 0 });
    await SubscriptionService.updateSubscriptionStates(sub.client.toString());
    logger.info(`fixed ${index}/${subscriptions.length}`);
  }
  logger.info(`done`);
};

const findDeleteDublicateCancels = async () => {
  logger.info(`fixing findDeleteDublicateCancels`);
  // let index = 1;
  // const subscriptions = await Subscription.find({ returnInvoice: { $ne: null }, state: 1 });
  // for (const sub of subscriptions) {
  //   index += 1;
  //   await Subscription.updateOne({ _id: sub._id.toString() }, { state: 0 });
  //   await SubscriptionService.updateSubscriptionStates(sub.client.toString());
  //   logger.info(`fixed ${index}/${subscriptions.length}`);
  // }
  logger.info(`done`);
};

const updateClientSubscriptionStatuses = async () => {
  logger.info(`fixing updateClientSubscriptionStatuses`);
  let index = 1;
  const clients = await Client.find({ status: 1 });
  for (const client of clients) {
    index += 1;
    // await LocationSyncService.syncLocation(client.info.locations[0].login);
    await SubscriptionService.updateSubscriptionStates(client._id.toString());
    logger.info(`fixed ${index}/${clients.length}`);
  }
  logger.info(`done`);
};

const cloverCards = async () => {
  const iboxId = '6457997d1c5b7b1510f6dc99';
  const paymentGateways = await ottProviderPaymentGatewayRepository.getOttProviderPaymentGatewayByProviderId(iboxId);
  if (!paymentGateways || !paymentGateways.length) return;
  const paymentGateway = paymentGateways[0];
  const { secretKey, merchantId } = paymentGateway.clover;
  const getCustomerListResponse = await CloverService.getCusomerList({ limit: 1000 }, secretKey, merchantId);
  const remoteCustomers = getCustomerListResponse.data.elements;
  let index = 0;
  let foundPhoneIndex = 0;
  const foundCustomers = [];
  for (const remoteCustomer of remoteCustomers) {
    if (remoteCustomer?.phoneNumbers?.elements?.length) {
      let foundPhone = false;
      const remoteCustomerPhone = remoteCustomer?.phoneNumbers?.elements[0];
      const { phoneNumber } = remoteCustomerPhone;
      if (phoneNumber) {
        const clients = await clientRepository.getClientsByName({ search: phoneNumber, providers: [iboxId] }, {});
        if (clients.results.length) {
          foundCustomers.push({
            clients: clients.results,
            remoteCustomer,
            phoneNumber,
          });
          foundPhone = true;
          foundPhoneIndex += 1;
        }
      }
      index += 1;
      logger.info(`doing ${index}/${remoteCustomers.length}, found: ${foundPhone}`);
    }
  }

  const cleanCustomers = [];
  const cleanCards = [];
  const moreThanOneClient = [];
  let okCards = 0;
  for (const foundCustomer of foundCustomers) {
    if (foundCustomer.clients.length > 1) {
      moreThanOneClient.push({
        phoneNumber: foundCustomer.phoneNumber,
        remoteCustomer: foundCustomer.remoteCustomer,
      });
      logger.info(`client: phone ${foundCustomer.phoneNumber} more than 1 client`);
      continue;
    }

    const client = foundCustomer.clients[0];
    const clientPaymentMethods = await clientPaymentMethodRepository.getClientPaymentMethodByClientId(client.id);
    if (!clientPaymentMethods || (!clientPaymentMethods.length && foundCustomer.remoteCustomer?.cards?.elements?.length)) {
      logger.info(`client has no payment method but has clover cards: ${foundCustomer.phoneNumber}`);
      cleanCustomers.push({
        remoteCustomer: foundCustomer.remoteCustomer,
        client,
        remoteCards: foundCustomer.remoteCustomer?.cards?.elements,
      });
      continue;
    }
    for (const clientPaymentMethod of clientPaymentMethods) {
      if (!clientPaymentMethod.creditCard) continue;

      const remoteCards = foundCustomer.remoteCustomer?.cards?.elements;
      const { cardNumber } = clientPaymentMethod.creditCard;

      for (const remoteCard of remoteCards) {
        const { first6, id } = remoteCard;
        if (cardNumber.search(first6) === -1) {
          cleanCards.push({
            remoteCards: [remoteCard],
            remoteCustomer: foundCustomer.remoteCustomer,
            client,
            clientPaymentMethods,
          });
        } else {
          okCards += 1;
        }
      }
    }

    // for(const clientPaymentMethod of clientPaymentMethods) {
    //   if (clientPaymentMethod.)
    // }
  }
  logger.info(
    `customers: ${remoteCustomers.length}, cleanCards: ${cleanCards.length}, cleanCustomers: ${cleanCustomers.length}, more than one client: ${moreThanOneClient.length} okay: ${okCards},`
  );
  logger.info(`client cards`);
  logger.info(`${cleanCards.map((r) => r.remoteCustomer.id).toString()}`);
  logger.info(`client customers`);
  logger.info(`${cleanCustomers.map((r) => r.remoteCustomer.id).toString()}`);
  logger.info(`more than one phone client`);
  logger.info(`${moreThanOneClient.map((r) => `phone: ${r.phoneNumber} clover: ${r.remoteCustomer.id}`).toString()}`);
};

const fixChats = async () => {
  const chats = await Chat.find({});
  for (const chat of chats) {
    await Chat.updateOne(
      { _id: chat._id.toString() },
      { provider: chat.to_provider || chat.from_provider, client: chat.to_client || chat.from_client }
    );
    // await Chat.updateOne({ _id: chat._id.toString() }, { user: null });
  }
  logger.info(`done fixing chats`);
};

mongoose
  .connect(config.getConfig().mongoose.url, config.getConfig().mongoose.options)
  .then(async () => {
    logger.info('Connected to MongoDB');
    autoIncrement.initialize(mongoose.connection);

    // await resetSubscriptionLeftInvoices();
    // await middlewareTestFunction();
    // await subscriptionFixFunction();
    // await invoiceTestFunction();
    // await leftResetFunction();
    // await balanceFixFunction();
    // await subs
    // await TwilioService.sendSms(
    //   { fromNumber: '+18554850662', toNumber: '+16263546606', body: 'body' },
    //   'ACc103aa49cbcaebf1a81ba18b4999cce2',
    //   '75bc668afa86dd8c9607fbe877859e80'
    // );
    // .criptionUpdate();
    // await subscriptionsFilterTest();
    // await awaitClientSubscription();
    // await awaitClientSubscription();
    // await transactionsFix();
    // await fixAutopaymentTransactions();
    // await testClover();
    // await awaitClientSubscription();
    // await thermalReceptPrinter();
    // await LocationSyncService.syncLocation('81520619');
    // const subs = await Subscription.find({});
    // const actives = subs.filter((r) => r.state === 1);

    // let cur = 0;
    // for (const sub of actives) {
    //   cur += 1;
    //   const inactive = subs.filter(
    //     (r) => r.state === 1 && r.invoice && sub.invoice && r.invoice.toString() === sub.invoice.toString()
    //   );
    //   logger.info(`skip ${cur}/${actives.length}`);
    //   if (inactive.length) {
    //     logger.info(`done ${cur}/${actives.length}`);
    //     await Subscription.updateMany({ invoice: inactive[0].invoice.toString() }, { state: 1 });
    //     await SubscriptionService.updateSubscriptionStates(inactive[0].client.toString());
    //     const location = await clientLocationRepository.getClientLocationById(inactive[0].location.toString());
    //     await LocationSyncService.syncLocation(location.login);
    //   }
    // }

    // await awaitClientSubscription();
    // const subs = await Subscription.find({ state: 1 });

    // const invoiceSubs = subs.filter((r) => r.returnInvoice);
    // for (const subscription of invoiceSubs) {
    //   // TODO remove subsc
    //   const invoice = await Invoice.findOne({ _id: subscription.returnInvoice });
    //   const location = await ClientLocation.findOne({ _id: subscription.location });
    //   const { refund } = invoice.payloadCalculated;
    //   await Subscription.updateOne({ _id: subscription._id.toString() }, { state: 0 });
    //   if (location) {
    //     logger.info(`refund: ${subscription.location} login: ${location.login}`);
    //     await LocationSyncService.syncLocation(location.login);
    //   }
    // }
    // logger.info(`begin fixing transactions`);
    // await transactionsFix();
    // logger.info(`all done`);
    // const ewordId = '645799071c5b7b1510f5388c';

    // const childOtts = await ottProviderRepository.getOttChilds(ewordId);
    // const ottIdList = childOtts.map((r) => r.id);
    // ottIdList.push(ewordId);
    // const client = await Client.find({ status: 1, provider: { $in: ottIdList } });
    // const addressClients = client.filter((r) => r.addresses && r.addresses.length && r.subscriptionActivationDate);
    // // !a.address || !a.city || !a.province || !a.zip ||
    // const addressWrongs = addressClients.filter(
    //   (r) => r.addresses.filter((a) => !a.address || !a.city || !a.province || !a.zip).length
    // );
    // const suiteWrongs = addressClients.filter(
    //   (r) =>
    //     r.addresses.filter(
    //       (a) => a.address && a.city && a.province && a.zip && !(isFirstLetterAlphabetic(a.suite) || !a.suite)
    //     ).length
    // );
    // const a = 1;

    // Replace with your ac10/16/2023 09:00';
    // const format = 'MM/DD/YYYY HH:mm';

    // const date = moment(dateString, format);

    // console.logtual API endpoint and key
    // const a = 1;
    // const ott = await OttProvider.updateOne(
    //   { _id: '645799071c5b7b1510f5388c' },
    //   { name: [{ lang: 'en', name: 'E World' }] }
    // );
    // const _packages = await Package.find({});
    // for (const _package of _packages) {
    //   await PackageOption.updateMany({ package: _package.id }, { state: _package.state });
    // }
    // logger.info(`done`);
    // await clientsFix();
    // await fixInvoices();
    // await creditCardsFix();
    // await fixMoneyOrders();
    // await testShipping();
    // await fixRecurring();
    // await fixInvoiceSentType();

    // const dateString = '10/16/2023 09:00';
    // const format = 'MM/DD/YYYY HH:mm';

    // const date = moment(dateString, format);

    // console.log(date.year()); // This will log the date as a string
    // await fixLocationTimezones();
    await checkeeperTest();
    // await cancelBadEndDateInvoices();
    // await fixClientFinancePackages();
    // await clientLocationSubscriptionInfoAdd();
    // await updateAllSubscriptionStates();
    // await clientsFix();
    // await cleanShippings();

    // const transactions = await CloverService.getUnsetteledTransactions('96d5b2b2-3267-c6cf-2195-43c23dd4a21e');

    // const data = await CloverService.getTransactionDetails(
    //   '96d5b2b2-3267-c6cf-2195-43c23dd4a21e',
    //   'YK03A6PB5T6G1',
    //   'X9871QAB4PHNE'
    // );
    // const a = 1;

    // const asd = 1;
    // const token = await TokenService.generateToken({ asd });
    // let isValid = await TokenService.validateToken(token);
    // const deleted = await TokenService.deactivateToken(token);
    // isValid = await TokenService.validateToken(token);
    // const a = 1;

    // await syncCards('645799af1c5b7b1510f799d5');
    // await fixRecurringFinanceCards();
    // await clientAddressCheck();
    // await fixSmartStreet();

    // await fixBadCancels();
    // await findDeleteDublicateCancels();
    // await updateClientSubscriptionStatuses();

    // await cloverCards();
    // await LocationSyncService.syncLocation('55617744');
    // await updateClientSubscriptionStatuses();
    // await fixRecurringFinanceCards();

    // const israelId = '647876d5643f847e32e46273';
    // const moidomId = '64787669643f847e32e32500';
    // const kidiId = '647876bd643f847e32e4192e';
    // const servers = await serverRepository.getList({});
    // let logins = 0;
    // const clients = await Client.find({ status: 1, provider: { $in: [israelId, moidomId, kidiId] } });
    // for (const client of clients) {
    //   if (client?.info?.locations?.length) {
    //     for (const location of client.info.locations) {
    //       logins += 1;
    //       logger.info(`logins ${logins} updated`);
    //       await ClientLocation.updateOne({ login: location.login }, { server: servers[1].id, syncState: 2 });
    //       // await LocationSyncService.syncLocation(location.login, false);
    //     }
    //   }
    // }

    // const provider = await ottProviderRepository.getBaseOttProvider();
    // const info = await StatisticService.getTransactions(provider.id.toString());
    // await StatisticService.recalculateInvoices(info.clients, provider.id.toString());
    // await updateAllSubscriptionStates();
    // const date = new Date();
    // date.setHours(date.getHours() - 1);
    // const transactions = await Transaction.find({ createdAt: { $gte: date }, transactionType: 'C_TO_A' });
    // const toFix = transactions.filter((r) => r.state !== 1 && r.autopayment);
    // for (const transaction of toFix) {
    //   await Subscription.updateOne(
    //     { client: transaction.from_client.toString(), state: 1 },
    //     { recurringPayCount: 0, recurringDate: null }
    //   );
    // }
    // const a = 1;
    // await fixChats();
    // await subscriptionUpdate();
  })
  .catch((error) => {
    logger.error(error);
  });
