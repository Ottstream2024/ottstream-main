// const config = require('../../../src/config');
require('../../../src/services');
const mongoose = require('mongoose');
const autoIncrement = require('../../../src/utils/mongoose-auto-increment');
const serviceCollection = require('../../../src/services/service_collection');
const logger = require('../../../src/utils/logger/logger');
const config = require('../../../src/config');
const priceUtils = require('../../../src/utils/price/price_utils');

mongoose
  .connect(config.getConfig().mongoose.url, config.getConfig().mongoose.options)
  .then(() => {
    logger.info('Connected to MongoDB');
    autoIncrement.initialize(mongoose.connection);

    const checkeeperService = serviceCollection.getService('checkeeperService');
    // checkeeperService
    //   .mailTransaction(`625eaa55829623210c45aede`)
    //   .then((data) => {
    //     // eslint-disable-next-line no-console
    //     logger.info(data.status, data.message);
    //   })
    //   .catch((error) => {
    //     logger.error(error, false);
    //   });
    checkeeperService
      .getCheckList(priceUtils.addUTCYears(new Date(), -1), new Date())
      .then((data) => {
        // eslint-disable-next-line no-console
        logger.info(data.status, data.status ? data.data : data.message);
      })
      .catch((error) => {
        logger.error(error, false);
      });
  })
  .catch((error) => {
    logger.error(error);
  });
