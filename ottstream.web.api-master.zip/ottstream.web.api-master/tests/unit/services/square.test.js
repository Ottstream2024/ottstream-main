/* eslint-disable prettier/prettier */
/* eslint-disable radix */
/* eslint-disable import/no-extraneous-dependencies *//* eslint-disable prettier/prettier */
/* eslint-disable prefer-destructuring */
/* eslint-disable prettier/prettier */
/* eslint-disable no-console */
/* eslint-disable no-plusplus */
/* eslint-disable spaced-comment */
/* eslint-disable prettier/prettier */
/* eslint-disable no-unused-vars */
/* eslint-disable prettier/prettier */
const SQUARE_APPLICATION_ID = 'sandbox-sq0idb-kFhNq-LiSgCQjGvRIErUAw';
const SQUARE_ACCESS_TOKEN = 'EAAAEPM9XtEvWOdYqVOTpf9mxdAVs2zUIE4lqXntSKJyHz2oR99szFeqnPISGvRD';
const SQUARE_PORT = 3242;
const SQUARE_NODE_ENV = 'sandbox';
/* test values */
const env = SQUARE_NODE_ENV;
const accessToken = SQUARE_ACCESS_TOKEN;
const squareApplicationId = SQUARE_APPLICATION_ID;
const { Client } = require('square');
const { v4: uuidv4 } = require("uuid");
const LocationInfo = require("../models/location-info");
const CatalogList = require("../models/catalog-list");
// Set Square credentials
const config = {
    accessToken,
    environment: env
};

// Extract instances of Api that are used
// You can add additional APIs here if you so choose
const {
    catalogApi,
    locationsApi,
    ordersApi,
    paymentsApi,
    loyaltyApi,
    cardsApi
} = new Client(config);

async function CreateOrder(req, res, next) {
    // const {
    //     itemVarId,
    //     itemId,
    //     itemQuantity,
    //     locationId
    // } = req.body;

    /*********************************************************************************************** */
    // Set to retrieve ITEM and IMAGE CatalogObjects
    const types = "ITEM,IMAGE"; // To retrieve TAX or CATEGORY objects add them to types
    try {
        // Retrieves locations in order to display the store name
        const { result: { locations } } = await locationsApi.listLocations();
        // Get CatalogItem and CatalogImage object
        const { result: { objects } } = await catalogApi.listCatalog(undefined, types);

        // Renders index view, with catalog and location information
        // res.render("index", {
        const items = new CatalogList(objects).items;
        const locationInfo = new LocationInfo(locations[0]); // take the first location for the sake of simplicity.
        // });
        // } catch (error) {
        //     next(error);
        // }
        /************************************************************************************************* */
        // try {
        const orderRequestBody = {
            idempotencyKey: uuidv4(), // Unique identifier for request
            order: {
                locationId: locationInfo.id,
                lineItems: [{
                    quantity: '2', //manual
                    catalogObjectId: items[3].defaultVariationId // Id for CatalogItem object
                }]
            }
        };
        // Apply the taxes that's related to this catalog item.
        // Order API doesn't calculate the tax automatically even if you have apply the tax to the catalog item
        // You must add the tax yourself when create order.
        const { result: { object } } = await catalogApi.retrieveCatalogObject(objects[3].id);
        if (!!object.itemData.taxIds && object.itemData.taxIds.length > 0) {
            orderRequestBody.order.taxes = [];
            for (let i = 0; i < object.itemData.taxIds.length; i++) {
                orderRequestBody.order.taxes.push({
                    catalogObjectId: object.itemData.taxIds[i],
                    scope: "ORDER",
                });
            }
        }
        const { result: { order } } = await ordersApi.createOrder(orderRequestBody);
        console.log(order.id, 'locationId');
        // res.redirect(`/checkout/choose-delivery-pickup?orderId=${order.id}&locationId=${locationId}`);


        const {
            //orderId,
            //locationId,
            //idempotencyKey,
            token,
        } = req.body;

        // get the latest order information in case the price is changed from a different session
        // const { result: { orders } } = await ordersApi.batchRetrieveOrders({
        //     locationId,
        //     orderIds: [orderId],
        // });
        // const order = orders[0];
        if (order.totalMoney.amount > 0) {
            try {
                // Payment can only be made when order amount is greater than 0
                const { result: { payment } } = await paymentsApi.createPayment({
                    sourceId: token, // Card nonce created by the payment form
                    idempotencyKey: orderRequestBody.idempotencyKey,
                    amountMoney: order.totalMoney, // Provides total amount of money and currency to charge for the order.
                    orderId: order.id, // Order that is associated with the payment
                });

                const result = JSON.stringify(payment, (key, value) => {
                    return typeof value === "bigint" ? parseInt(value) : value;
                }, 4);
                res.json(result);

            } catch (error) {
                res.json(error.result);
            }
        } else {
            try {
                // Settle an order with a total of 0.
                const { result: { payment } } = await ordersApi.payOrder(order.id, {
                    idempotencyKey: orderRequestBody.idempotencyKey
                });

                const result = JSON.stringify(payment, (key, value) => {
                    return typeof value === "bigint" ? parseInt(value) : value;
                }, 4);
                res.json(result);

            } catch (error) {
                res.json(error.result);
            }
        }

    } catch (ex) {
        console.log(ex.message);
    }
}

CreateOrder();