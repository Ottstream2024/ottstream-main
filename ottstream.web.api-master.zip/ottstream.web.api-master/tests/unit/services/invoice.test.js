// const config = require('../../../src/config');
require('../../../src/services');
const fs = require('fs');
const puppeteer = require('puppeteer');
const config = require('../../../src/config');

// eslint-disable-next-line security/detect-non-literal-fs-filename
fs.readFile(`${config.getConfig().file.file_storage_path}./index.html`, async (error, data) => {
  if (error) {
    throw error;
  }
  const savePath = `${config.getConfig().file.file_storage_path}./index.pdf`;

  const html = data.toString();

  // launch a new chrome instance
  const browser = await puppeteer.launch({
    headless: true,
  });

  try {
    // create a new page
    const page = await browser.newPage();

    // set your html as the pages content
    await page.setContent(html, {
      waitUntil: 'load',
    });

    // or a .pdf file
    await page.pdf({
      format: 'A4',
      path: savePath,
    });
    // eslint-disable-next-line no-empty
  } catch (exception) {}
  // close the browser
  await browser.close();
});
