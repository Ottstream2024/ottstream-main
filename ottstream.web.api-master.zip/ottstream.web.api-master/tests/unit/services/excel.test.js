// // const config = require('../../../src/config');
// require('../../../src/services');
// const serviceCollection = require('../../../src/services/service_collection');
// const logger = require('../../../src/utils/logger/logger');
//
// const excelService = serviceCollection.getService('excelService');
// stripeService
//   .payoutTransaction(_cardInfo, _orderInfo, null, _skey)
//   .then((data) => {
//     // eslint-disable-next-line no-console
//     console.log(data);
//   })
//   .catch((error) => {
//     logger.error(error, false);
//   });
