// const config = require('../../../src/config');
/* const logger = require('../../../src/utils/logger/logger');
const { taxJarService } = require('../../../src/services');

taxJarService
  .getCategories()
  .then((data) => {
    if (data.categories && data.categories.forEach) {
      data.categories.forEach((item) => {
        logger.info(`name: ${item?.name} code: ${item.product_tax_code}`, false);
      });
    }
  })
  .catch((error) => {
    logger.error(error, false);
  });

taxJarService
  .validateAddress('am', 'Yerevan', '0501', 'Yerevan', undefined)
  .then((data) => {
    if (data.addresses && data.addresses.forEach) {
      data.addresses.forEach((item) => {
        logger.info(`name: ${item?.name} code: ${item.product_tax_code}`, false);
      });
    }
  })
  .catch((error) => {
    logger.error(error, false);
  }); */
