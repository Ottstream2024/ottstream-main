// const config = require('../../../src/config');
const logger = require('../../../src/utils/logger/logger');
const { stripeService } = require('../../../src/services');

const _skey = 'sk_test_51KkPYNDK2DEgxR88BESgETcgYowpZrzDCGJSGTatql3dKMTXclPpqHcDDtwX9X1XKp6bqW9paDVeMKIRGHJHs8FP00bv6KZGak';

const _cardInfo = {
  billingAddress: { suite: '', address: 'T. Krpeyan 38', country: 'AM', city: 'Talin', zip: '0501', phone: '091773460' },
  cardNumber: '4242424242424242',
  cardholderName: 'Harutyun KamalyaN',
  anExistingAddress: true,
  existingAddress: '6239cd306c996926c7614d1f',
  cvc: '456',
  month: '04',
  year: '23',
  brand: 'visa',
  updatedAt: '2022-04-07T10:24:05.848Z',
  id: '62458674c057dce44ab0ebc3',
};

const _orderInfo = {
  amount: 6700,
  email: '',
  invoiceNumber: 'INV-735650',
  description: 'invoice payment',
};

stripeService
  .payoutTransaction(_cardInfo, _orderInfo, null, _skey)
  .then((data) => {
    // eslint-disable-next-line no-console
    console.log(data);
  })
  .catch((error) => {
    logger.error(error, false);
  });
