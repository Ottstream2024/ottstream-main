const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
// eslint-disable-next-line import/no-unresolved
const faker = require('faker');
const User = require('../../src/models');

const password = 'password1';
const salt = bcrypt.genSaltSync(8);
const hashedPassword = bcrypt.hashSync(password, salt);

const userOne = {
  email: 'info@ottstream.live',
  password: 'asdASD#2!',
  firstname: 'Hamlet',
  lastname: 'Arshakyan',
  companyName: [{ name: 'OttStream', lang: 'en' }],
  companyEmail: 'info@otwtstream.live',
  website: 'ottstream.live',
  phone: { phoneNumber: '+16126223546606', countryCode: 'us' },
  description: 'OttStream company',
  channelAmount: 5,
  clientAmount: 300,
};

const userTwo = {
  _id: mongoose.Types.ObjectId(),
  name: faker.name.findName(),
  email: faker.internet.email().toLowerCase(),
  password,
  role: 'user',
};

const admin = {
  _id: mongoose.Types.ObjectId(),
  name: faker.name.findName(),
  email: faker.internet.email().toLowerCase(),
  password,
  role: 'admin',
};

const insertUsers = async (users) => {
  await User.insertMany(users.map((user) => ({ ...user, password: hashedPassword })));
};

module.exports = {
  userOne,
  userTwo,
  admin,
  insertUsers,
};
