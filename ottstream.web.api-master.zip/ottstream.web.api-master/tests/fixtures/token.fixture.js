const moment = require('moment');
const config = require('../../src/config');
const { tokenRepository } = require('../../src/repository');
const { userOne, admin } = require('./user.fixture');

const accessTokenExpires = moment().add(config.getConfig().jwt.accessExpirationMinutes, 'minutes');
const userOneAccessToken = tokenRepository.generateToken(userOne._id, accessTokenExpires);
const adminAccessToken = tokenRepository.generateToken(admin._id, accessTokenExpires);

module.exports = {
  userOneAccessToken,
  adminAccessToken,
};
