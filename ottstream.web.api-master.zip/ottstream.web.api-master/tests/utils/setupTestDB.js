const mongoose = require('mongoose');
const autoIncrement = require('../../src/utils/mongoose-auto-increment');
const config = require('../../src/config');

const setupTestDB = () => {
  beforeAll(async () => {
    await mongoose.connect(config.getConfig().mongoose.url, config.getConfig().mongoose.options);
    autoIncrement.initialize(mongoose.connection);
  });

  beforeEach(async () => {
    await Promise.all(
      Object.values(mongoose.connection.collections).map(async (collection) => {
        if (collection.modelName === 'IdentityCounter') return;
        collection.deleteMany();
      })
    );
  });

  afterAll(async () => {
    // await mongoose.disconnect();
  });
};

module.exports = setupTestDB;
