const request = require('supertest');
// const faker = require('faker');
const httpStatus = require('http-status');
const httpMocks = require('node-mocks-http');
const moment = require('moment');
const bcrypt = require('bcryptjs');
const app = require('../../src/app');
const config = require('../../src/config');
const auth = require('../../src/middlewares/auth');
const { tokenRepository } = require('../../src/repository');
const EmailService = require('../../src/services/email/EmailService.service');
const ApiError = require('../../src/api/utils/error/ApiError');
const setupTestDB = require('../utils/setupTestDB');
const { User, Token } = require('../../src/models');
const { roleRights } = require('../../src/api/config/roles');
const { userOne, admin, insertUsers } = require('../fixtures/user.fixture');
const { userOneAccessToken, adminAccessToken } = require('../fixtures/token.fixture');
const { ottProviderRepository } = require('../../src/repository');

setupTestDB();

describe('Auth routes', () => {
  describe('POST /v1/auth/register', () => {
    let newUser;
    beforeEach(() => {
      newUser = {
        email: 'info@ottstream.live',
        password: 'asdASD#2!',
        firstname: 'Hamlet',
        lastname: 'Arshakyan',
        companyName: [{ name: 'OttStream', lang: 'en' }],
        companyEmail: 'info@otwtstream.live',
        website: 'ottstream.live',
        phone: { phoneNumber: '+16126223546606', countryCode: 'us' },
        description: 'OttStream company',
        channelAmount: 5,
        clientAmount: 300,
      };
    });

    test('should return 201 and successfully register user if request data is ok', async () => {
      await request(app).post('/v1/auth/register-user-provider').send(newUser).expect(httpStatus.CREATED);

      const dbOtt = await ottProviderRepository.getBaseOttProvider();
      expect(dbOtt).toBeDefined();
      expect(dbOtt._id).not.toBe(null);
      expect(dbOtt.user).not.toBe(null);
      expect(dbOtt.user._id).not.toBe(null);
      expect(dbOtt.user.state).toEqual(1);
      expect(dbOtt.type).toEqual(0);
      expect(dbOtt.state).toEqual(1);
      // expect(res.body.user).not.toHaveProperty('password');
      // expect(res.body.user).toEqual({ id: expect.anything(), email: newUser.email, state: 1 });
      //
      // const dbUser = await User.findById(res.body.user.id);
      // expect(dbUser).toBeDefined();
      // expect(dbUser.password).not.toBe(newUser.password);
      // expect(dbUser).toMatchObject({ name: newUser.name, email: newUser.email, role: 'user' });
      //
      // expect(res.body.tokens).toEqual({
      //   access: { token: expect.anything(), expires: expect.anything() },
      //   refresh: { token: expect.anything(), expires: expect.anything() },
      // });
    });

    test('should return 400 error if email is invalid', async () => {
      newUser.email = 'invalidEmail';

      await request(app).post('/v1/auth/register-user-provider').send(newUser).expect(httpStatus.BAD_REQUEST);
    });

    test('should return 400 error if email is already used', async () => {
      // await insertUsers([userOne]);
      await request(app).post('/v1/auth/register-user-provider').send(newUser).expect(httpStatus.CREATED);

      await request(app).post('/v1/auth/register-user-provider').send(newUser).expect(httpStatus.BAD_REQUEST);
    });

    test('should return 400 error if password length is less than 8 characters', async () => {
      newUser.password = 'passwo1';

      await request(app).post('/v1/auth/register-user-provider').send(newUser).expect(httpStatus.BAD_REQUEST);
    });

    test('should return 400 error if password does not contain both letters and numbers', async () => {
      newUser.password = 'password';

      await request(app).post('/v1/auth/register-user-provider').send(newUser).expect(httpStatus.BAD_REQUEST);

      newUser.password = '11111111';

      await request(app).post('/v1/auth/register-user-provider').send(newUser).expect(httpStatus.BAD_REQUEST);
    });
  });

  describe('POST /v1/auth/login', () => {
    test('should return 200 and login user if email and password match', async () => {
      await request(app).post('/v1/auth/register-user-provider').send(userOne).expect(httpStatus.CREATED);
      const loginCredentials = {
        email: userOne.email,
        password: userOne.password,
      };

      const res = await request(app).post('/v1/auth/login').send(loginCredentials).expect(httpStatus.OK);

      expect(res.body.updatedUser).toBeDefined();
      expect(res.body.updatedUser.email).toEqual(userOne.email);

      expect(res.body.tokens).toEqual({
        access: { token: expect.anything(), expires: expect.anything() },
        refresh: { token: expect.anything(), expires: expect.anything() },
      });
    });

    test('should return 401 error if there are no users with that email', async () => {
      const loginCredentials = {
        email: userOne.email,
        password: userOne.password,
      };

      const res = await request(app).post('/v1/auth/login').send(loginCredentials).expect(httpStatus.UNAUTHORIZED);

      expect(res.body).toEqual({ code: httpStatus.UNAUTHORIZED, message: 'Incorrect email or password' });
    });

    test('should return 401 error if password is wrong', async () => {
      await request(app).post('/v1/auth/register-user-provider').send(userOne).expect(httpStatus.CREATED);
      const loginCredentials = {
        email: userOne.email,
        password: 'wrongPassword1',
      };

      const res = await request(app).post('/v1/auth/login').send(loginCredentials).expect(httpStatus.UNAUTHORIZED);

      expect(res.body).toEqual({ code: httpStatus.UNAUTHORIZED, message: 'Incorrect email or password' });
    });
  });

  describe('POST /v1/auth/logout', () => {
    test('should return 204 if refresh token is valid', async () => {
      await request(app).post('/v1/auth/register-user-provider').send(userOne).expect(httpStatus.CREATED);
      const dbOtt = await ottProviderRepository.getBaseOttProvider();
      const expires = moment().add(config.getConfig().jwt.refreshExpirationDays, 'days');
      const refreshToken = tokenRepository.generateToken(dbOtt._id, expires);
      await tokenRepository.saveToken(refreshToken, dbOtt._id, expires, 'refresh');

      await request(app).post('/v1/auth/logout').send({ refreshToken }).expect(httpStatus.NO_CONTENT);

      const dbRefreshTokenDoc = await Token.findOne({ token: refreshToken });
      expect(dbRefreshTokenDoc).toBe(null);
    });

    test('should return 400 error if refresh token is missing from request body', async () => {
      await request(app).post('/v1/auth/logout').send().expect(httpStatus.BAD_REQUEST);
    });

    test('should return 404 error if refresh token is not found in the database', async () => {
      await request(app).post('/v1/auth/register-user-provider').send(userOne).expect(httpStatus.CREATED);
      const expires = moment().add(config.getConfig().jwt.refreshExpirationDays, 'days');
      const dbOtt = await ottProviderRepository.getBaseOttProvider();
      const refreshToken = tokenRepository.generateToken(dbOtt._id, expires);

      await request(app).post('/v1/auth/logout').send({ refreshToken }).expect(httpStatus.NOT_FOUND);
    });

    test('should return 404 error if refresh token is blacklisted', async () => {
      await request(app).post('/v1/auth/register-user-provider').send(userOne).expect(httpStatus.CREATED);
      const dbOtt = await ottProviderRepository.getBaseOttProvider();
      const expires = moment().add(config.getConfig().jwt.refreshExpirationDays, 'days');
      const refreshToken = tokenRepository.generateToken(dbOtt._id, expires);
      await tokenRepository.saveToken(refreshToken, dbOtt._id, expires, 'refresh', true);

      await request(app).post('/v1/auth/logout').send({ refreshToken }).expect(httpStatus.NOT_FOUND);
    });
  });

  describe('POST /v1/auth/refresh-tokens', () => {
    test('should return 200 and new auth tokens if refresh token is valid', async () => {
      await request(app).post('/v1/auth/register-user-provider').send(userOne).expect(httpStatus.CREATED);
      const dbOtt = await ottProviderRepository.getBaseOttProvider();
      const expires = moment().add(config.getConfig().jwt.refreshExpirationDays, 'days');
      const refreshToken = tokenRepository.generateToken(dbOtt._id, expires);
      await tokenRepository.saveToken(refreshToken, dbOtt._id, expires, 'refresh');

      const res = await request(app).post('/v1/auth/refresh-tokens').send({ refreshToken }).expect(httpStatus.OK);

      expect(res.body).toEqual({
        access: { token: expect.anything(), expires: expect.anything() },
        refresh: { token: expect.anything(), expires: expect.anything() },
      });

      const dbRefreshTokenDoc = await Token.findOne({ token: res.body.refresh.token });
      expect(dbRefreshTokenDoc).toMatchObject({ type: 'refresh', user: userOne._id, blacklisted: false });

      const dbRefreshTokenCount = await Token.countDocuments();
      expect(dbRefreshTokenCount).toBe(1);
    });

    test('should return 400 error if refresh token is missing from request body', async () => {
      await request(app).post('/v1/auth/refresh-tokens').send().expect(httpStatus.BAD_REQUEST);
    });

    test('should return 401 error if refresh token is signed using an invalid secret', async () => {
      await insertUsers([userOne]);
      const expires = moment().add(config.getConfig().jwt.refreshExpirationDays, 'days');
      const refreshToken = tokenRepository.generateToken(userOne._id, expires, 'invalidSecret');
      await tokenRepository.saveToken(refreshToken, userOne._id, expires, 'refresh');

      await request(app).post('/v1/auth/refresh-tokens').send({ refreshToken }).expect(httpStatus.UNAUTHORIZED);
    });

    test('should return 401 error if refresh token is not found in the database', async () => {
      await insertUsers([userOne]);
      const expires = moment().add(config.getConfig().jwt.refreshExpirationDays, 'days');
      const refreshToken = tokenRepository.generateToken(userOne._id, expires);

      await request(app).post('/v1/auth/refresh-tokens').send({ refreshToken }).expect(httpStatus.UNAUTHORIZED);
    });

    test('should return 401 error if refresh token is blacklisted', async () => {
      await insertUsers([userOne]);
      const expires = moment().add(config.getConfig().jwt.refreshExpirationDays, 'days');
      const refreshToken = tokenRepository.generateToken(userOne._id, expires);
      await tokenRepository.saveToken(refreshToken, userOne._id, expires, 'refresh', true);

      await request(app).post('/v1/auth/refresh-tokens').send({ refreshToken }).expect(httpStatus.UNAUTHORIZED);
    });

    test('should return 401 error if refresh token is expired', async () => {
      await insertUsers([userOne]);
      const expires = moment().subtract(1, 'minutes');
      const refreshToken = tokenRepository.generateToken(userOne._id, expires);
      await tokenRepository.saveToken(refreshToken, userOne._id, expires, 'refresh');

      await request(app).post('/v1/auth/refresh-tokens').send({ refreshToken }).expect(httpStatus.UNAUTHORIZED);
    });

    test('should return 401 error if user is not found', async () => {
      const expires = moment().add(config.getConfig().jwt.refreshExpirationDays, 'days');
      const refreshToken = tokenRepository.generateToken(userOne._id, expires);
      await tokenRepository.saveToken(refreshToken, userOne._id, expires, 'refresh');

      await request(app).post('/v1/auth/refresh-tokens').send({ refreshToken }).expect(httpStatus.UNAUTHORIZED);
    });
  });

  describe('POST /v1/auth/forgot-password', () => {
    beforeEach(() => {
      jest.spyOn(EmailService.GetTransport(), 'sendMail').mockResolvedValue();
    });

    test('should return 204 and send reset password email to the user', async () => {
      await insertUsers([userOne]);
      const sendResetPasswordEmailSpy = jest.spyOn(EmailService, 'sendResetPasswordEmail');

      await request(app).post('/v1/auth/forgot-password').send({ email: userOne.email }).expect(httpStatus.NO_CONTENT);

      expect(sendResetPasswordEmailSpy).toHaveBeenCalledWith(userOne.email, expect.any(String));
      const resetPasswordToken = sendResetPasswordEmailSpy.mock.calls[0][1];
      const dbResetPasswordTokenDoc = await Token.findOne({ token: resetPasswordToken, user: userOne._id });
      expect(dbResetPasswordTokenDoc).toBeDefined();
    });

    test('should return 400 if email is missing', async () => {
      await insertUsers([userOne]);

      await request(app).post('/v1/auth/forgot-password').send().expect(httpStatus.BAD_REQUEST);
    });

    test('should return 404 if email does not belong to any user', async () => {
      await request(app).post('/v1/auth/forgot-password').send({ email: userOne.email }).expect(httpStatus.NOT_FOUND);
    });
  });

  describe('POST /v1/auth/reset-password', () => {
    test('should return 204 and reset the password', async () => {
      await insertUsers([userOne]);
      const expires = moment().add(config.getConfig().jwt.resetPasswordExpirationMinutes, 'minutes');
      const resetPasswordToken = tokenRepository.generateToken(userOne._id, expires);
      await tokenRepository.saveToken(resetPasswordToken, userOne._id, expires, 'resetPassword');

      await request(app)
        .post('/v1/auth/reset-password')
        .query({ token: resetPasswordToken })
        .send({ password: 'password2' })
        .expect(httpStatus.NO_CONTENT);

      const dbUser = await User.findById(userOne._id);
      const isPasswordMatch = await bcrypt.compare('password2', dbUser.password);
      expect(isPasswordMatch).toBe(true);

      const dbResetPasswordTokenCount = await Token.countDocuments({ user: userOne._id, type: 'resetPassword' });
      expect(dbResetPasswordTokenCount).toBe(0);
    });

    test('should return 400 if reset password token is missing', async () => {
      await insertUsers([userOne]);

      await request(app).post('/v1/auth/reset-password').send({ password: 'password2' }).expect(httpStatus.BAD_REQUEST);
    });

    test('should return 401 if reset password token is blacklisted', async () => {
      await insertUsers([userOne]);
      const expires = moment().add(config.getConfig().jwt.resetPasswordExpirationMinutes, 'minutes');
      const resetPasswordToken = tokenRepository.generateToken(userOne._id, expires);
      await tokenRepository.saveToken(resetPasswordToken, userOne._id, expires, 'resetPassword', true);

      await request(app)
        .post('/v1/auth/reset-password')
        .query({ token: resetPasswordToken })
        .send({ password: 'password2' })
        .expect(httpStatus.UNAUTHORIZED);
    });

    test('should return 401 if reset password token is expired', async () => {
      await insertUsers([userOne]);
      const expires = moment().subtract(1, 'minutes');
      const resetPasswordToken = tokenRepository.generateToken(userOne._id, expires);
      await tokenRepository.saveToken(resetPasswordToken, userOne._id, expires, 'resetPassword');

      await request(app)
        .post('/v1/auth/reset-password')
        .query({ token: resetPasswordToken })
        .send({ password: 'password2' })
        .expect(httpStatus.UNAUTHORIZED);
    });

    test('should return 401 if user is not found', async () => {
      const expires = moment().add(config.getConfig().jwt.resetPasswordExpirationMinutes, 'minutes');
      const resetPasswordToken = tokenRepository.generateToken(userOne._id, expires);
      await tokenRepository.saveToken(resetPasswordToken, userOne._id, expires, 'resetPassword');

      await request(app)
        .post('/v1/auth/reset-password')
        .query({ token: resetPasswordToken })
        .send({ password: 'password2' })
        .expect(httpStatus.UNAUTHORIZED);
    });

    test('should return 400 if password is missing or invalid', async () => {
      await insertUsers([userOne]);
      const expires = moment().add(config.getConfig().jwt.resetPasswordExpirationMinutes, 'minutes');
      const resetPasswordToken = tokenRepository.generateToken(userOne._id, expires);
      await tokenRepository.saveToken(resetPasswordToken, userOne._id, expires, 'resetPassword');

      await request(app).post('/v1/auth/reset-password').query({ token: resetPasswordToken }).expect(httpStatus.BAD_REQUEST);

      await request(app)
        .post('/v1/auth/reset-password')
        .query({ token: resetPasswordToken })
        .send({ password: 'short1' })
        .expect(httpStatus.BAD_REQUEST);

      await request(app)
        .post('/v1/auth/reset-password')
        .query({ token: resetPasswordToken })
        .send({ password: 'password' })
        .expect(httpStatus.BAD_REQUEST);

      await request(app)
        .post('/v1/auth/reset-password')
        .query({ token: resetPasswordToken })
        .send({ password: '11111111' })
        .expect(httpStatus.BAD_REQUEST);
    });
  });
});

describe('Auth middleware', () => {
  test('should call next with no errors if access token is valid', async () => {
    await insertUsers([userOne]);
    const req = httpMocks.createRequest({ headers: { Authorization: `Bearer ${userOneAccessToken}` } });
    const next = jest.fn();

    await auth()(req, httpMocks.createResponse(), next);

    expect(next).toHaveBeenCalledWith();
    expect(req.user._id).toEqual(userOne._id);
  });

  test('should call next with unauthorized error if access token is not found in header', async () => {
    await insertUsers([userOne]);
    const req = httpMocks.createRequest();
    const next = jest.fn();

    await auth()(req, httpMocks.createResponse(), next);

    expect(next).toHaveBeenCalledWith(expect.any(ApiError));
    expect(next).toHaveBeenCalledWith(
      expect.objectContaining({ statusCode: httpStatus.UNAUTHORIZED, message: 'Please authenticate' })
    );
  });

  test('should call next with unauthorized error if access token is not a valid jwt token', async () => {
    await insertUsers([userOne]);
    const req = httpMocks.createRequest({ headers: { Authorization: 'Bearer randomToken' } });
    const next = jest.fn();

    await auth()(req, httpMocks.createResponse(), next);

    expect(next).toHaveBeenCalledWith(expect.any(ApiError));
    expect(next).toHaveBeenCalledWith(
      expect.objectContaining({ statusCode: httpStatus.UNAUTHORIZED, message: 'Please authenticate' })
    );
  });

  test('should call next with unauthorized error if access token is generated with an invalid secret', async () => {
    await insertUsers([userOne]);
    const tokenExpires = moment().add(config.getConfig().jwt.accessExpirationMinutes, 'minutes');
    const accessToken = tokenRepository.generateToken(userOne._id, tokenExpires, 'invalidSecret');
    const req = httpMocks.createRequest({ headers: { Authorization: `Bearer ${accessToken}` } });
    const next = jest.fn();

    await auth()(req, httpMocks.createResponse(), next);

    expect(next).toHaveBeenCalledWith(expect.any(ApiError));
    expect(next).toHaveBeenCalledWith(
      expect.objectContaining({ statusCode: httpStatus.UNAUTHORIZED, message: 'Please authenticate' })
    );
  });

  test('should call next with unauthorized error if access token is expired', async () => {
    await insertUsers([userOne]);
    const tokenExpires = moment().subtract(1, 'minutes');
    const accessToken = tokenRepository.generateToken(userOne._id, tokenExpires);
    const req = httpMocks.createRequest({ headers: { Authorization: `Bearer ${accessToken}` } });
    const next = jest.fn();

    await auth()(req, httpMocks.createResponse(), next);

    expect(next).toHaveBeenCalledWith(expect.any(ApiError));
    expect(next).toHaveBeenCalledWith(
      expect.objectContaining({ statusCode: httpStatus.UNAUTHORIZED, message: 'Please authenticate' })
    );
  });

  test('should call next with unauthorized error if user is not found', async () => {
    const req = httpMocks.createRequest({ headers: { Authorization: `Bearer ${userOneAccessToken}` } });
    const next = jest.fn();

    await auth()(req, httpMocks.createResponse(), next);

    expect(next).toHaveBeenCalledWith(expect.any(ApiError));
    expect(next).toHaveBeenCalledWith(
      expect.objectContaining({ statusCode: httpStatus.UNAUTHORIZED, message: 'Please authenticate' })
    );
  });

  test('should call next with forbidden error if user does not have required rights and userId is not in params', async () => {
    await insertUsers([userOne]);
    const req = httpMocks.createRequest({ headers: { Authorization: `Bearer ${userOneAccessToken}` } });
    const next = jest.fn();

    await auth('anyRight')(req, httpMocks.createResponse(), next);

    expect(next).toHaveBeenCalledWith(expect.any(ApiError));
    expect(next).toHaveBeenCalledWith(expect.objectContaining({ statusCode: httpStatus.FORBIDDEN, message: 'Forbidden' }));
  });

  test('should call next with no errors if user does not have required rights but userId is in params', async () => {
    await insertUsers([userOne]);
    const req = httpMocks.createRequest({
      headers: { Authorization: `Bearer ${userOneAccessToken}` },
      params: { userId: userOne._id.toHexString() },
    });
    const next = jest.fn();

    await auth('anyRight')(req, httpMocks.createResponse(), next);

    expect(next).toHaveBeenCalledWith();
  });

  test('should call next with no errors if user has required rights', async () => {
    await insertUsers([admin]);
    const req = httpMocks.createRequest({
      headers: { Authorization: `Bearer ${adminAccessToken}` },
      params: { userId: userOne._id.toHexString() },
    });
    const next = jest.fn();

    await auth(...roleRights.get('admin'))(req, httpMocks.createResponse(), next);

    expect(next).toHaveBeenCalledWith();
  });
});
