class LocationSyncModel {
  // eslint-disable-next-line no-unused-vars,no-useless-constructor,no-empty-function
  constructor(props) {}
}

module.exports = LocationSyncModel;
