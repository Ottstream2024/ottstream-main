// eslint-disable-next-line
function depthExport (importedObject) {
  let obj = {};
  // eslint-disable-next-line
  for (const key in importedObject) {
    obj = { ...obj, ...{ [key]: (...args) => importedObject[key](...args) } };
  }
  return obj;
}
module.exports = depthExport;
