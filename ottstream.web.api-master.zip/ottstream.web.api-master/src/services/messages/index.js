const { messagesRepository, chatMembersRepository } = require('../../repository');

class MessagesService {
  // eslint-disable-next-line
  async create(user, body) {
    const messageBody = { ...body };
    const chatMember = await chatMembersRepository.registerMember(user);
    messageBody.author = chatMember;
    messageBody.provider = 'provider';
    return messagesRepository.create(messageBody);
  }

  // eslint-disable-next-lines
  // eslint-disable-next-line no-unused-vars
  // eslint-disable-next-line class-methods-use-this
  async getMessagesByConversation(user, query) {
    const filter = { conversation: query.conversation };
    return messagesRepository.getList(filter, query.limit, query.page);
  }
}

module.exports = MessagesService;
