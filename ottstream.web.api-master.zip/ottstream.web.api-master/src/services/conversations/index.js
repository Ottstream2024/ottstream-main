const { conversationRepository, userRepository, chatMembersRepository } = require('../../repository');

class ConversationsService {
  // eslint-disable-next-line
  // eslint-disable-next-line class-methods-use-this
  async createConversation(user, body) {
    const conversationBody = {};
    conversationBody.members = [];
    // eslint-disable-next-line
    const author = await chatMembersRepository.registerUserMember(user._doc);
    conversationBody.name = `${user.firstname} ${user.lastname}`;
    conversationBody.type = 'single';
    conversationBody.members.push(author);
    const memberUser = await userRepository.getUserById(body.userId);
    if (!memberUser) return { status: false, message: 'Missing target member!' };
    const chatExistsMember = await chatMembersRepository.registerUserMember(memberUser._doc);
    conversationBody.members.push(chatExistsMember);
    return conversationRepository.create(conversationBody);
  }

  // eslint-disable-next-line no-unused-vars
  // eslint-disable-next-line class-methods-use-this
  // eslint-disable-next-line lines-between-class-members
  // eslint-disable-next-line class-methods-use-this
  async createClientConversation(user, body) {
    return { user, body };
  }

  // eslint-disable-next-line class-methods-use-this
  // eslint-disable-next-line lines-between-class-members
  // eslint-disable-next-line class-methods-use-this
  async getConversations(user, type, query) {
    const { limit, page } = query;
    const filter = {};
    let result = [];
    if (type === 'client') {
      filter.provider = user.provider.name;
      result = await conversationRepository.getList(filter, limit, page);
    } else {
      const member = await chatMembersRepository.registerUserMember(user._doc);
      result = await conversationRepository.getUsersList(member.id, query.limit, query.page);
    }
    return result;
  }

  // eslint-disable-next-line
  // eslint-disable-next-line class-methods-use-this
  // eslint-disable-next-line lines-between-class-members
  // eslint-disable-next-line class-methods-use-this
  async createGroupConversation(user, body) {
    const conversationBody = {};
    const author = await chatMembersRepository.registerUserMember(user._doc);
    conversationBody.name = body.name;
    conversationBody.members = [];
    conversationBody.type = 'group';
    body.members.map(async (item) => {
      const member = await userRepository.getUserById(item);
      conversationBody.members.push(member);
    });
    conversationBody.members.push(author);
    // eslint-disable-next-line no-return-await
    return conversationRepository.create(conversationBody);
  }

  // eslint-disable-next-line
  // eslint-disable-next-line class-methods-use-this
  async getMemberById(user, id) {
    const userMemberId = chatMembersRepository.findByUserId(user._id);
    return conversationRepository.getConversation([userMemberId, id]);
  }

  // eslint-disable-next-line no-unused-vars
  // eslint-disable-next-line class-methods-use-this
  async findConversation(user, type, search) {
    const membersList = await chatMembersRepository.find(search);
    return membersList;
  }
}

module.exports = ConversationsService;
