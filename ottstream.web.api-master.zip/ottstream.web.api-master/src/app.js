const express = require('express');
const helmet = require('helmet');
// const xss = require('xss-clean');
// const mongoSanitize = require('express-mongo-sanitize');
const compression = require('compression');
const cors = require('cors');
const passport = require('passport');
const httpStatus = require('http-status');
// const GoogleStrategy = require('passport-google-oauth20').Strategy;
const jwt = require('jsonwebtoken');
const path = require('path');
const swaggerUi = require('swagger-ui-express');
// eslint-disable-next-line import/no-unresolved
const lib = require('ottstream.swagger.autogenerate');
const fs = require('fs');
const config = require('./config');
const morgan = require('./config/morgan');
const { jwtStrategy, googleStrategy, googleAuthCodeStrategy } = require('./api/config/passport');
const { authLimiter } = require('./middlewares/rateLimiter');
const routes = require('./api/routes/v1');
const { errorConverter, errorHandler } = require('./middlewares/error');
const ApiError = require('./api/utils/error/ApiError');
const serviceCollection = require('./services/service_collection');
const ChatService = require('./services/chat/ChatService');
const { userRepository } = require('./repository');

const socketService = serviceCollection.getService('socketService');
const app = express();

if (config.getConfig().env !== 'test') {
  app.use(morgan.successHandler);
  app.use(morgan.errorHandler);
}

// set security HTTP headers
app.use(helmet());

// parse json request body
app.use(express.json());

// parse urlencoded request body
app.use(express.urlencoded({ extended: true }));

// sanitize request data
// app.use(xss());
// app.use(mongoSanitize());
// TODO refactor this part (comments failed to send html data)

// gzip compressionprocessSocketStreams
app.use(compression());

app.use(cors('*'));

app.set('json replacer', function (key, value) {
  if (this[key] instanceof Date) {
    // Your own custom date serialization
    // eslint-disable-next-line no-param-reassign
    value = this[key].toString();
  }

  return value;
});

if (!fs.existsSync('./storage')) {
  fs.mkdirSync('./storage');
}

// jwt authentication
app.use(passport.initialize());
passport.use('jwt', jwtStrategy);
passport.use('google', googleStrategy);
passport.use('google-authcode', googleAuthCodeStrategy);

// Serialize user object to session
passport.serializeUser((user, done) => {
  // console.log(user, 'iserS');
  done(null, user);
});

// Deserialize user object from session
passport.deserializeUser((obj, done) => {
  // console.log(obj);
  done(null, obj);
});
// passport.use('google-authcode', googleAuthCodeStrategy);
// passport.use(
//   new GoogleStrategy(
//     {
//       clientID: '154517203770-91krjdqdt4fp8sv715tep72s7c0kslni.apps.googleusercontent.com',
//       clientSecret: '4rTjqcVYUDvj1YKkbkfZOYNE',
//       callbackURL: '/auth/google/redirect',
//     },
//     (accessToken) => {
//       console.log('access token: ', accessToken);
//     }
//   ) // TODO continue from here
// );

// limit repeated failed requests to auth endpoints
if (config.getConfig().env === 'production') {
  app.use('/v1/auth', authLimiter);
}

require('express-ws')(app);

app.ws('/echo', async (ws, req) => {
  try {
    const accessToken = req.query.token;
    const decodedToken = jwt.verify(req.query.token, config.getConfig().jwt.secret);
    const userId = decodedToken.sub;
    const user = await userRepository.getUserById(userId);

    if (user && user.provider) {
      const providerId = user.provider._id.toString();
      socketService.addClient(providerId, userId, ws);
      socketService.printClients();

      ws.on('message', async (msg) => {
        const data = JSON.parse(msg);
        if (data.action === 'addGroup' || data.action === 'removeGroup') {
          socketService.onUserMessage(userId, data);
        } else if (data.action === 'chatUserTyping') {
          await ChatService.userTyping(true, data.userId, data.clientId, accessToken);
        }
      });

      ws.on('close', function () {
        socketService.removeClient(userId, ws);
        socketService.printClients();
      });

      ws.send(`OK`);
    }
  } catch (err) {
    // Handle token verification error
    // logger.error('JWT verification failed:', err.message);
    ws.close();
  }
});

// v1 api routes
app.use('/v1', routes);

// v1 api routes
app.use('/docs', express.static(path.join(__dirname, '..', 'docs')));
const validations = require('./api/validations');
const { excludedMiddlewares } = require('./constants/middlewares');

const doc = lib.generate({
  server: new lib.Config({
    title: 'OttStream API Documentation',
    descriotion: 'Ottstream api documentation',
    version: '1.0',
    basePath: 'http://localhost:3000',
    host: 'http://localhost:3000',
  }),
  router: routes,
  parentPath: '/v1',
  validations: { ...validations },
  excludeMiddlewares: excludedMiddlewares,
});

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(doc));

// send back a 404 error for any unknown api request
app.use((req, res, next) => {
  next(new ApiError(httpStatus.NOT_FOUND, 'Not found'));
});

// convert error to ApiError, if needed
app.use(errorConverter);

// handle error
app.use(errorHandler);

module.exports = app;
