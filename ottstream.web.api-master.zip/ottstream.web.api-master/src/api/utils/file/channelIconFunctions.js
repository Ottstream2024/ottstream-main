const fs = require('fs');
const path = require('path');
const { channelRepository } = require('../../../repository');
const { channelIconSetRepository } = require('../../../repository');
const { iconTypeRepository } = require('../../../repository');

async function channelSetImageDestinationFunction(self, req, file, cb) {
  const iconSet = await channelIconSetRepository.getChannelIconSetById(req.query.iconSet);
  const iconType = await iconTypeRepository.getIconTypeById(req.query.iconType);
  const channel = await channelRepository.getChannelById(req.query.channel);
  const finalPath = path.join(
    self.storagePath,
    'channels',
    channel.number.toString(),
    iconSet.number.toString(),
    `${iconType.ratiox}x${iconType.ratioy}`
  );
  if (req.query.original) {
    // eslint-disable-next-line security/detect-non-literal-fs-filename
    fs.rmdirSync(finalPath, { recursive: true });
  }
  // eslint-disable-next-line security/detect-non-literal-fs-filename
  if (!fs.existsSync(finalPath)) {
    // eslint-disable-next-line security/detect-non-literal-fs-filename
    fs.mkdirSync(finalPath, { recursive: true });
  }
  cb(null, finalPath);
}

async function channelSetImageFileNameFunction(self, req, file, cb) {
  const channel = await channelRepository.getChannelById(req.query.channel);
  let fileName = `${channel.number}`;
  if (req.query.original) fileName += '_original';
  const ext = path.extname(file.originalname);
  // const tempName = uuid();
  const filename = `${fileName}${ext}`;
  // const fileName = file.originalname.toLowerCase().split(' ').join('-');
  cb(null, filename);
}

module.exports = {
  channelSetImageDestinationFunction,
  channelSetImageFileNameFunction,
};
