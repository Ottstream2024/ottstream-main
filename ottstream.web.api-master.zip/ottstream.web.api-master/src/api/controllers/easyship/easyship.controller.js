const EasyshipService = require('../../../services/shiping/merchant/easyship.service');
const depthExport = require('../../../services/export/depth.export');

const rates = async (req, res) => {
  // eslint-disable-next-line no-useless-catch
  try {
    const response = await EasyshipService.getRates();
    res.send(response.data);
  } catch (e) {
    throw e;
  }
};

const createShipment = async (req, res) => {
  const easyshipService = new EasyshipService();
  await easyshipService.createShipment(req.body, res);
};

const labels = async (req, res) => {
  const easyshipService = new EasyshipService();
  await easyshipService.labels(req.body, res);
};

const updateShipment = async (req, res) => {
  const easyshipService = new EasyshipService();
  await easyshipService.updateShipment(req.body, req.params.id, res);
};

const getShipment = async (req, res) => {
  const easyshipService = new EasyshipService();
  await easyshipService.getShipment(req.params.id, res);
};

const getShipments = async (req, res) => {
  // eslint-disable-next-line no-useless-catch
  try {
    const response = await EasyshipService.getShipments();
    res.send(response.data);
  } catch (e) {
    throw e;
  }
};

const deleteShipment = async (req, res) => {
  const easyshipService = new EasyshipService();
  await easyshipService.deleteShipment(req.params.id, res);
};

const warehouseState = async (req, res) => {
  const easyshipService = new EasyshipService();
  await easyshipService.warehouseState(req.body, res);
};

const pickupSlots = async (req, res) => {
  const easyshipService = new EasyshipService();
  await easyshipService.pickupSlots(req.params.id, res);
};

const requestPickup = async (req, res) => {
  const easyshipService = new EasyshipService();
  await easyshipService.requestPickup(req.body, res);
};

const getCheckpoints = async (req, res) => {
  const easyshipService = new EasyshipService();
  await easyshipService.getCheckpoints(req.params.id, res);
};

const getStatus = async (req, res) => {
  const easyshipService = new EasyshipService();
  await easyshipService.getStatus(req.params.id, res);
};
const getItemCategories = async (req, res) => {
  const easyshipService = new EasyshipService();
  await easyshipService.getItemCategories(res);
};

const getBoxes = async (req, res) => {
  // eslint-disable-next-line no-useless-catch
  try {
    const response = await EasyshipService.getBoxes(req.user.provider.id);
    res.send(response.data);
  } catch (e) {
    throw e;
  }
};

module.exports = depthExport({
  rates,
  createShipment,
  labels,
  updateShipment,
  getShipment,
  getShipments,
  deleteShipment,
  warehouseState,
  pickupSlots,
  requestPickup,
  getCheckpoints,
  getStatus,
  getItemCategories,
  getBoxes,
});
