const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { fileRepository } = require('../../../repository');
const config = require('../../../config');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createFile = catchAsync(async (req, res) => {
  const file = await fileRepository.createFile(req.file, req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(file, req.user));
});

const createChannelIconFile = catchAsync(async (req, res) => {
  const file = await fileRepository.createChannelIconFile(req.file, req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(file, req.user));
});

const getFiles = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await fileRepository.queryFiles(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getFile = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const file = await fileRepository.getFileById(req.params.fileId, options);
  if (!file) {
    throw new ApiError(httpStatus.NOT_FOUND, 'File not found');
  }
  res.sendFile(file.path, { root: config.getConfig().file.root_path });
});

const updateFile = catchAsync(async (req, res) => {
  const file = await fileRepository.updateFileById(req.params.fileId, req.body);
  res.send(TimezoneService.LocalizeObject(file, req.user));
});

const deleteFile = catchAsync(async (req, res) => {
  await fileRepository.deleteFileById(req.params.fileId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createFile,
  createChannelIconFile,
  getFiles,
  getFile,
  updateFile,
  deleteFile,
});
