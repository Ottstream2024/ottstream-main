const catchAsync = require('../../../utils/helpers/catchAsync');
const serviceCollection = require('../../../services/service_collection');
const logger = require('../../../utils/logger/logger');
const LocationSyncService = require('../../../services/sync/location/location_sync.service');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const syncLocations = catchAsync(async (req, res) => {
  try {
    const response = {
      success: true,
    };
    logger.info(`location sync manually call...`);
    await LocationSyncService.syncLocations();
    res.send(TimezoneService.LocalizeObject(response));
  } catch (ex) {
    logger.error(ex);
    throw ex;
  }
});

module.exports = depthExport({
  syncLocations,
});
