const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { languageUnitRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createLanguageUnit = catchAsync(async (req, res) => {
  const languageUnit = await languageUnitRepository.createLanguageUnit(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(languageUnit, req.user));
});

const getLanguageUnits = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await languageUnitRepository.queryLanguageUnits(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getLanguageUnit = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const languageUnit = await languageUnitRepository.getLanguageUnitById(req.params.languageUnitId, options);
  if (!languageUnit) {
    throw new ApiError(httpStatus.NOT_FOUND, 'LanguageUnit not found');
  }
  res.send(TimezoneService.LocalizeObject(languageUnit, req.user));
});

const updateLanguageUnit = catchAsync(async (req, res) => {
  const languageUnit = await languageUnitRepository.updateLanguageUnitById(req.params.languageUnitId, req.body);
  res.send(TimezoneService.LocalizeObject(languageUnit, req.user));
});

const deleteLanguageUnit = catchAsync(async (req, res) => {
  await languageUnitRepository.deleteLanguageUnitById(req.params.languageUnitId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createLanguageUnit,
  getLanguageUnits,
  getLanguageUnit,
  updateLanguageUnit,
  deleteLanguageUnit,
});
