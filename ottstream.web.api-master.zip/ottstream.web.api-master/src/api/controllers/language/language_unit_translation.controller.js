const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { languageUnitTranslationRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createLanguageUnitTranslation = catchAsync(async (req, res) => {
  const languageUnitTranslation = await languageUnitTranslationRepository.createLanguageUnitTranslation(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(languageUnitTranslation, req.user));
});

const getLanguageUnitTranslations = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['user']);
  const options = pick(req.query, ['id', 'sortBy', 'limit', 'page', 'all']);
  const result = await languageUnitTranslationRepository.queryLanguageUnitTranslations(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getLanguageUnitTranslation = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const languageUnitTranslation = await languageUnitTranslationRepository.getLanguageUnitTranslationById(
    req.params.languageUnitTranslationId,
    options
  );
  if (!languageUnitTranslation) {
    throw new ApiError(httpStatus.NOT_FOUND, 'LanguageUnitTranslation not found');
  }
  res.send(TimezoneService.LocalizeObject(languageUnitTranslation, req.user));
});

const updateLanguageUnitTranslation = catchAsync(async (req, res) => {
  const languageUnitTranslation = await languageUnitTranslationRepository.updateLanguageUnitTranslationById(
    req.params.languageId,
    req.body
  );
  res.send(TimezoneService.LocalizeObject(languageUnitTranslation, req.user));
});

const deleteLanguageUnitTranslation = catchAsync(async (req, res) => {
  await languageUnitTranslationRepository.deleteLanguageUnitTranslationById(req.params.languageUnitTranslationId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createLanguageUnitTranslation,
  getLanguageUnitTranslations,
  getLanguageUnitTranslation,
  updateLanguageUnitTranslation,
  deleteLanguageUnitTranslation,
});
