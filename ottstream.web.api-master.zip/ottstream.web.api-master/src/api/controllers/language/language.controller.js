const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { languageRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createLanguage = catchAsync(async (req, res) => {
  const language = await languageRepository.createLanguage(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(language, req.user));
});

const getLanguages = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  if (options.sortBy) {
    options.sortBy = ['order:asc', options.sortBy];
  }
  const result = await languageRepository.queryLanguages(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getSystemLanguages = catchAsync(async (req, res) => {
  const languagesWithTranslations = await languageRepository.querySystemLanguages();
  res.send(TimezoneService.LocalizeObject({ languagesWithTranslations }, req.user));
});

const getLanguage = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const language = await languageRepository.getLanguageById(req.params.languageId, options);
  if (!language) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Language not found');
  }
  res.send(TimezoneService.LocalizeObject(language, req.user));
});

const updateLanguage = catchAsync(async (req, res) => {
  const language = await languageRepository.updateLanguageById(req.params.languageId, req.body);
  res.send(TimezoneService.LocalizeObject(language, req.user));
});

const deleteLanguage = catchAsync(async (req, res) => {
  await languageRepository.deleteLanguageById(req.params.languageId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createLanguage,
  getLanguages,
  getSystemLanguages,
  getLanguage,
  updateLanguage,
  deleteLanguage,
});
