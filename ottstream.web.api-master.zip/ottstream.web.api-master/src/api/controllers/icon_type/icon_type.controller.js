const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { iconTypeRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createIconType = catchAsync(async (req, res) => {
  const iconType = await iconTypeRepository.createIconType(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(iconType, req.user));
});

const getIconTypes = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await iconTypeRepository.queryIconTypes(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getIconType = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const iconType = await iconTypeRepository.getIconTypeById(req.params.iconTypeId, options);
  if (!iconType) {
    throw new ApiError(httpStatus.NOT_FOUND, 'IconType not found');
  }
  res.send(TimezoneService.LocalizeObject(iconType, req.user));
});

const updateIconType = catchAsync(async (req, res) => {
  const iconType = await iconTypeRepository.updateIconTypeById(req.params.iconTypeId, req.body);
  res.send(TimezoneService.LocalizeObject(iconType, req.user));
});

const deleteIconType = catchAsync(async (req, res) => {
  await iconTypeRepository.deleteIconTypeById(req.params.iconTypeId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createIconType,
  getIconTypes,
  getIconType,
  updateIconType,
  deleteIconType,
});
