const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const {
  subscriptionRepository,
  clientLocationRepository,
  clientRepository,
  packageRepository,
  invoiceRepository,
} = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const SubscriptionService = require('../../../services/subscription/subscription.service');
const depthExport = require('../../../services/export/depth.export');

const TimezoneService = serviceCollection.getService('timezoneService', true);

const createSubscription = catchAsync(async (req, res) => {
  const channel = await subscriptionRepository.createSubscription(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(channel, req.user));
});

const subscribeLocationToPackage = catchAsync(async (req, res) => {
  const location = await clientLocationRepository.getClientLocationById(req.body.locationId);
  const _package = await packageRepository.getPackageById(req.body.packageId);
  const channel = await subscriptionRepository.subscribeLocationToPackage(location, _package, req.body);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(channel, req.user));
});

const checkout = catchAsync(async (req, res) => {
  const payload = req.body;
  const { client } = payload;
  const clientInfo = await clientRepository.getClientById(client);
  const calculatedPayload = await SubscriptionService.calculateSubscription(false, payload, clientInfo.provider);
  // generated info

  const generateDisplayInfo = {
    client,
    clientAddress:
      clientInfo.addresses && clientInfo.addresses.filter((r) => r.forContactInvoice).length
        ? clientInfo.addresses.filter((r) => r.forContactInvoice)[0]
        : null,
    locationsInfo: {
      totalTax: calculatedPayload.totalTax,
      bankFee: calculatedPayload.bankFee,
      locationTax: calculatedPayload.locationTax,
      locations: calculatedPayload.locations,
    },
    equipmentInfo: {
      totalTax: calculatedPayload.totalTax,
      bankFee: calculatedPayload.bankFee,
      equipmentTax: calculatedPayload.equipmentTax,
      equipments: calculatedPayload.equipments,
      equipment: calculatedPayload.equipment,
    },
    refund: calculatedPayload.refund,
    lastPaymentType: calculatedPayload.refund,
    availablePaymentTypes: calculatedPayload.availablePaymentTypes,
  };
  const invoice =
    calculatedPayload.totalPrice >= 0
      ? await invoiceRepository.createSubscriptionInvoice(
          1,
          false,
          calculatedPayload.totalPrice,
          payload,
          calculatedPayload,
          generateDisplayInfo,
          clientInfo.provider._id.toString(),
          client,
          null, // TODO add location here
          req.user
        )
      : await invoiceRepository.createSubscriptionRefundInvoice(
          calculatedPayload.totalPrice,
          payload,
          calculatedPayload,
          generateDisplayInfo,
          clientInfo.provider._id.toString(),
          client,
          req.user
        );
  res.send(TimezoneService.LocalizeObject(invoice, req.user));
});

const getSubscriptions = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['client', 'location', 'isActive']);
  // const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  if (!filter.client && !filter.location) {
    throw new ApiError(400, 'client or location ID should be provided');
  }
  const getFilter = { status: 1 };
  if (filter.client) {
    getFilter.client = filter.client;
  }
  if (filter.location) {
    getFilter.location = filter.location;
  }
  if (filter.isActive) {
    getFilter.isActive = filter.isActive;
  }
  const locationGroupedSubscriptions = await subscriptionRepository.getList(
    getFilter,
    [
      { path: 'package', select: '_id name' },
      { path: 'invoice', select: '_id createdAt updatedAt' },
      { path: 'returnInvoice', select: '_id createdAt updatedAt' },
    ],
    { package: 1, endDate: 1, invoice: 1, returnInvoice: 1, updatedAt: 1, createdAt: 1, state: 1 }
  );
  const response = {
    active: [],
    inactive: [],
  };
  if (locationGroupedSubscriptions.filter((r) => r.state === 1).length) {
    response.active = locationGroupedSubscriptions
      .filter((r) => r.state === 1)
      .map((r) => {
        return {
          subscription: r._id.toString(),
          package: r.package,
          expireDate: r.endDate,
        };
      });
  } else {
    let itemWithHighestCreatedAt = null;
    let itemWithHighestReturnCreatedAt = null;
    let latestSubscriptionGroups = [];
    if (locationGroupedSubscriptions.length) {
      itemWithHighestCreatedAt = locationGroupedSubscriptions.reduce((max, item) => {
        if (!max.invoice) return item;
        return item.invoice?.createdAt?.getTime() > max.invoice?.createdAt?.getTime() ? item : max;
      });
      itemWithHighestReturnCreatedAt = locationGroupedSubscriptions.reduce((max, item) => {
        if (!max.returnInvoice) return item;
        return item.returnInvoice?.createdAt?.getTime() > max.returnInvoice?.createdAt?.getTime() ? item : max;
      });

      if (
        (itemWithHighestCreatedAt.invoice &&
          itemWithHighestReturnCreatedAt.returnInvoice &&
          itemWithHighestReturnCreatedAt?.returnInvoice?.createdAt.getTime() >
            itemWithHighestCreatedAt?.invoice?.createdAt.getTime()) ||
        (itemWithHighestReturnCreatedAt.returnInvoice && !itemWithHighestCreatedAt.invoice)
      ) {
        latestSubscriptionGroups = locationGroupedSubscriptions.filter(
          (r) => r.returnInvoice?.id === itemWithHighestReturnCreatedAt?.returnInvoice?.id
        );
      } else if (
        (itemWithHighestCreatedAt.invoice &&
          itemWithHighestReturnCreatedAt.returnInvoice &&
          itemWithHighestReturnCreatedAt?.returnInvoice?.createdAt.getTime() <=
            itemWithHighestCreatedAt?.invoice?.createdAt.getTime()) ||
        (itemWithHighestCreatedAt.invoice && !itemWithHighestReturnCreatedAt.returnInvoice)
      ) {
        latestSubscriptionGroups = locationGroupedSubscriptions.filter(
          (r) => r.invoice?.id === itemWithHighestCreatedAt?.invoice?.id
        );
      } else {
        latestSubscriptionGroups = locationGroupedSubscriptions;
      }
    }
    response.inactive = latestSubscriptionGroups.map((r) => {
      return {
        subscription: r._id.toString(),
        package: r.package,
        expireDate: r.updatedAt,
      };
    });
  }
  res.send(TimezoneService.LocalizeObject(response, req.user));
});

const getClientSubscriptions = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user', 'type']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await subscriptionRepository.queryClientSubscriptions(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getLocationSubscriptions = catchAsync(async (req, res) => {
  const client = await clientRepository.getClientById(req.body.client);
  if (!client) throw new ApiError(`client ${req.body.client} not found`);
  if (!client.provider) throw new ApiError(`client provider ${req.body.client} not found`);
  const calculatedPayload = await SubscriptionService.calculateSubscription(true, req.body, client.provider);
  res.send(
    TimezoneService.LocalizeObject(calculatedPayload, req.user, ['createdAt', 'updatedAt', 'expireNew', 'expireDate'])
  );
});

const getUserSubscription = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role']);
  filter.author = req.user._id;
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await subscriptionRepository.querySubscriptions(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getSubscription = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await subscriptionRepository.getSubscriptionById(req.params.subscriptionId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Subscription not found');
  }
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const generateLocationInvoice = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await subscriptionRepository.getSubscriptionById(req.params.subscriptionId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Subscription not found');
  }
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updateSubscription = catchAsync(async (req, res) => {
  const channel = await subscriptionRepository.updateSubscriptionById(req.params.subscriptionId, req.body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updateLocationSubscriptions = catchAsync(async (req, res) => {
  const channel = await subscriptionRepository.updateSubscriptionById(req.params.subscriptionId, req.body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const unsubscribeLocationFromPackage = catchAsync(async (req, res) => {
  const channel = await subscriptionRepository.updateSubscriptionById(req.params.subscriptionId, req.body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const deleteSubscription = catchAsync(async (req, res) => {
  await subscriptionRepository.deleteSubscriptionById(req.params.subscriptionId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createSubscription,
  subscribeLocationToPackage,
  checkout,
  unsubscribeLocationFromPackage,
  updateLocationSubscriptions,
  generateLocationInvoice,
  getClientSubscriptions,
  getSubscriptions,
  getSubscription,
  getLocationSubscriptions,
  getUserSubscription,
  updateSubscription,
  deleteSubscription,
});
