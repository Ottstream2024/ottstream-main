const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { priceGroupRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createPriceGroup = catchAsync(async (req, res) => {
  const channel = await priceGroupRepository.createPriceGroup(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(channel, req.user));
});

const getPriceGroups = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user', 'type', 'provider']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  if (!filter.provider) filter.provider = req.user.provider._id.toString();
  const result = await priceGroupRepository.queryPriceGroups(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getUserPriceGroup = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role']);
  filter.author = req.user._id;
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await priceGroupRepository.queryPriceGroups(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getPriceGroup = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await priceGroupRepository.getPriceGroupById(req.params.priceGroupId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'PriceGroup not found');
  }
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updatePriceGroup = catchAsync(async (req, res) => {
  const channel = await priceGroupRepository.updatePriceGroupById(req.params.priceGroupId, req.body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const deletePriceGroup = catchAsync(async (req, res) => {
  await priceGroupRepository.deletePriceGroupById(req.params.priceGroupId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createPriceGroup,
  getPriceGroups,
  getPriceGroup,
  getUserPriceGroup,
  updatePriceGroup,
  deletePriceGroup,
});
