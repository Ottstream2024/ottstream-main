const httpStatus = require('http-status');
const queue = require('queue');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { chatRepository } = require('../../../repository');
const { smsRepository } = require('../../../repository');
const { ottProviderRepository } = require('../../../repository');
// const chatTypes = require('../../../config/chat_types');
const serviceCollection = require('../../../services/service_collection');
const BroadcastService = require('../../../services/socket/broadcastService.service');
const TwilioService = require('../../../services/sms/twilio.service');
const logger = require('../../../utils/logger/logger');
const { clientRepository, ottProviderConversationProviderRepository } = require('../../../repository');

const smsSendQueue = queue({ results: [], autostart: true, timeout: 0, concurrency: 10 });
const depthExport = require('../../../services/export/depth.export');

// eslint-disable-next-line no-unused-vars
smsSendQueue.on('timeout', async (next, job) => {
  next();
});

// get notified when jobs complete
// eslint-disable-next-line no-unused-vars
smsSendQueue.on('success', async (result, job) => {
  // eslint-disable-next-line no-await-in-loop

  await BroadcastService.broadcastToGroup(`chat-client-mini-${result.clientId}`, `chat-client-mini-${result.clientId}`, {
    action: 'newChat',
    chat: result.chat,
  });

  await BroadcastService.broadcastToProvider(result.providerId, `provider-chat`, {
    action: 'newChat',
    chat: result.chat,
  });

  await BroadcastService.broadcastToGroup(`chat-client-${result.clientId}`, `chat-client-${result.clientId}`, {
    action: 'newChat',
    chat: result.chat,
  });
});
const TimezoneService = serviceCollection.getService('timezoneService', true);

const createChat = catchAsync(async (req, res) => {
  try {
    const response = { status: false, message: '' };
    const { clientId } = req.params;
    const { message, phone, type } = req.body;
    const client = await clientRepository.getClientById(clientId);

    const userId = req.user.id;

    if (!client) throw new ApiError(400, `client not found`);
    const chat = await chatRepository.createChat({
      to_client: client.id,
      client: client.id,
      from_provider: client.provider.id,
      provider: client.provider.id,
      deliveryState: 2,
      deliveryDate: new Date(),
      deliverySystem: 'twilio',
      message,
      readState: 0,
      byUser: userId,
    });
    if (!chat) {
      response.status = false;
      response.message = `chat creation error`;
    }
    response.status = true;
    response.chat = chat;
    if (type === 'sms') {
      const currentProvider = await ottProviderRepository.getOttProviderById(client.provider.id);
      let hasValidSmsProvider = false;
      const conversationApis =
        await ottProviderConversationProviderRepository.getOttProviderConversationProviderByProviderId(currentProvider.id);
      hasValidSmsProvider = conversationApis.length && conversationApis[0].twilio && conversationApis[0].twilio.isValid;
      if (!hasValidSmsProvider) {
        response.status = false;
        response.message = 'no valid sms provider';
      }

      if (response.status) {
        const func = async (cb) => {
          const sendResponse = { status: true, message: '' };
          try {
            const interesetedPhones = client.phones.filter((r) => r.forMessages && (phone ? r.phone === phone : true));
            if (interesetedPhones.length) {
              const currentPhone = interesetedPhones[0].phone;
              // eslint-disable-next-line no-unused-vars
              const currentConfigs = conversationApis[0].twilio;
              // eslint-disable-next-line no-undef
              const twilioResponse = await TwilioService.sendSms(
                {
                  fromNumber: currentConfigs.fromNumber,
                  toNumber: currentPhone,
                  body: message,
                },
                {
                  sId: currentConfigs.sId,
                  authToken: currentConfigs.authToken,
                },
                {
                  provider: currentProvider.id,
                  user: req.user.id,
                }
              );
              sendResponse.status = twilioResponse.status;
              sendResponse.message = twilioResponse.message;
              sendResponse.data = twilioResponse.data;

              if (!twilioResponse.status) {
                cb(null, {
                  chat,
                  clientId: client.id,
                  message: twilioResponse?.data?.status === 401 ? `twilio 401 authentication error` : twilioResponse.error,
                  status: false,
                });
                return;
              }
              const sms = await smsRepository.createSms({
                deliveryState: 1,
                messageId: twilioResponse.data.id,
                deliverySystem: 'twilio',
                message,
                provider: client.provider,
                user: userId,
              });
              chatRepository.updateChatById(chat.id, {
                deliveryDate: new Date(),
                deliveryMessage: twilioResponse.message,
                sms: sms.id,
                deliveryState: sendResponse.status ? 1 : 0,
              });
            }

            cb(null, {
              chat,
              clientId: client.id,
              providerId: client.provider.id,
              twilioData: sendResponse.data,
              message: hasValidSmsProvider ? 'sms sent' : 'no sms provider setup',
              status: sendResponse.status,
            });
          } catch (ex) {
            logger.error(ex);
            cb(null, {
              chat,
              clientId: client.id,
              message: ex.message ?? ex,
              status: false,
            });
          }
        };
        smsSendQueue.push(func);
        response.message = `sms have been added to sms queue`;
      }
    }

    await BroadcastService.broadcastToGroup(`client-${client.id}`, `chat-info-${client.id}`, {
      action: 'newChat',
      chat,
    });

    await BroadcastService.broadcastToGroup(`client-${client.id}`, `client-${client.id}`, {
      action: 'newChat',
      chat,
    });
    res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(response, req.user));
  } catch (ex) {
    logger.error(ex);
  }
});

const getChats = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['excel', 'client']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await chatRepository.queryChats(filter, options);
  // eslint-disable-next-line no-param-reassign,no-return-assign
  result.results.forEach((item, i) => {
    result.results[i] = item.toJSON();
    if (item.reminderDate) result.results[i].reminderDateFormated = new Date(item.reminderDate);
    const tempUser = { ...result.results[i].user };
    result.results[i].user = {
      firstname: tempUser.firstname,
      lastname: tempUser.lastname,
    };
  });
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportChatTable(result.results, req.user, 'chatSettings', 'chatTable');
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  res.send(TimezoneService.LocalizeObject(result, req.user, { reminderDate: true }));
});

const getChat = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await chatRepository.getChatById(req.params.chatId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Chat not found');
  }
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const getClientChats = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['search']);
  const options = pick(req.query, ['sortBy', 'limit', 'page']);
  filter.from_client = req.params.clientId;
  filter.to_client = req.params.clientId;
  const result = await chatRepository.queryChats(filter, options);

  // check unreads
  const unreads = result.results.filter((r) => r.readState === 0);
  if (unreads.length) {
    await chatRepository.updateMany({ _id: { $in: unreads.map((r) => r._id.toString()) } }, { readState: 1 });
  }
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getProviderChats = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['search', 'type', 'unread']);
  const options = pick(req.query, ['sortBy', 'limit', 'page']);
  filter.provider = req.user.provider.id;
  if (!filter.unread) {
    const result = await chatRepository.queryProviderChats(filter, options);
    res.send(TimezoneService.LocalizeObject(result, req.user));
  } else {
    const result = await chatRepository.queryProviderCountChats(filter, options);
    res.send(TimezoneService.LocalizeObject(result, req.user));
  }
});

const updateChat = catchAsync(async (req, res) => {
  const saveBody = { ...req.body };
  saveBody.updateUser = req.user._id.toString();
  const chat = await chatRepository.getChatById(req.params.chatId);
  if (!chat) throw new ApiError(`chat not found by that id`);
  if (
    chat.reminderDate &&
    saveBody.reminderDate &&
    chat.reminderDate.getTime() !== saveBody.reminderDate.getTime() &&
    chat.sendNotification
  ) {
    saveBody.notified = false;
  }
  const channel = await chatRepository.updateChatById(req.params.chatId, saveBody);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const chatEnableDisableAction = catchAsync(async (req, res) => {
  const item = await chatRepository.chatsActionById(req.body);
  res.send(TimezoneService.LocalizeObject(item, req.user));
});

const deleteChat = catchAsync(async (req, res) => {
  await chatRepository.deleteChatById(req.params.chatId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createChat,
  getChats,
  getClientChats,
  getChat,
  updateChat,
  getProviderChats,
  deleteChat,
  chatEnableDisableAction,
});
