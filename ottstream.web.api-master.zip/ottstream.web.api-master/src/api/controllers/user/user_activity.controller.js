const pick = require('../../../utils/helpers/pick');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { userActivityRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const depthExport = require('../../../services/export/depth.export');

const TimezoneService = serviceCollection.getService('timezoneService', true);

const getUserActivitys = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['type', 'search', 'excel', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  if (!req.params.user) filter.provider = req.user.provider._id.toString();
  else filter.user = req.params.user;
  const result = await userActivityRepository.queryUserActivitys(filter, options, req.user);
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportUserListTable(result.results, req.user, 'defaultSettings', 'defaultSettingsColumns');
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

module.exports = depthExport({
  getUserActivitys,
});
