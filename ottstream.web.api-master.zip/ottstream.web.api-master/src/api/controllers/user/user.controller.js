const httpStatus = require('http-status');
const queue = require('queue');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const {
  userRepository,
  tokenRepository,
  ottProviderRepository,
  ottProviderConversationProviderRepository,
} = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const TwilioService = require('../../../services/sms/twilio.service');
const RoleService = require('../../../services/role/role.service');
const EmailService = require('../../../services/email/EmailService.service');
const { randomNumberSequence } = require('../../../utils/crypto/random');
const logger = require('../../../utils/logger/logger');
const BroadcastService = require('../../../services/socket/broadcastService.service');
const depthExport = require('../../../services/export/depth.export');

const smsSendQueue = queue({ results: [], autostart: true, timeout: 0, concurrency: 1 });

// eslint-disable-next-line no-unused-vars
smsSendQueue.on('timeout', async (next, job) => {
  next();
});

// get notified when jobs complete
// eslint-disable-next-line no-unused-vars
smsSendQueue.on('success', async (result, job) => {
  // eslint-disable-next-line no-await-in-loop

  let channelName = `user-telegram-info`;
  if (result.invoiceId) channelName += `-${result.invoiceId}`;
  await BroadcastService.broadcastToUser(result.notifyToUser, channelName, {
    status: result.status,
    message: result.message,
  });
});

const TimezoneService = serviceCollection.getService('timezoneService', true);

const sendTelegramLoginPasswordWorker = async (req, user) => {
  const response = { success: true };
  const providerId = user.provider._id ? user.provider._id.toString() : user.provider.toString();
  const currentProvider = await ottProviderRepository.getOttProviderById(providerId);
  let hasValidSmsProvider = false;
  const conversationApis = await ottProviderConversationProviderRepository.getOttProviderConversationProviderByProviderId(
    currentProvider.id
  );
  hasValidSmsProvider = conversationApis.length && conversationApis[0].twilio && conversationApis[0].twilio.isValid;
  const conversationApi = conversationApis.length ? conversationApis[0] : null;
  // eslint-disable-next-line no-unused-vars
  const { type, value } = req.body;
  const sendEmail = type === 'email_phone' || type === 'email';
  const sendPhone = type === 'email_phone' || type === 'phone';
  if (!sendEmail && !sendPhone) {
    response.message = `no sent type selected`;
    response.noSetup = true;
    return response;
  }
  if (sendPhone && !hasValidSmsProvider) {
    response.message = `no sms probvder is setup`;
    response.noSetup = true;
    return response;
  }
  const func = async (cb) => {
    const sendResponse = { status: true, message: '' };
    try {
      // cb(null, {
      //   notifyToProvider: req.user.provider.id,
      //   notifyToUser: req.user.id,
      //   hasValidSmsProvider,
      //   message: 'twilio connection error',
      //   status: false,
      // });
      // eslint-disable-next-line no-unused-vars
      let emailSent = false;
      let twilioSent = false;
      let message = `telegram login: ${user.telegramLogin} password: ${user.telegramPassword}`;
      if (conversationApi?.telegram?.info?.username) {
        message += ` link: https://t.me/${conversationApi?.telegram?.info?.username}`;
      }
      // eslint-disable-next-line no-unused-vars
      if (sendEmail && (user.email || value)) {
        const email = user.email || value;
        await EmailService.sendCheckEmail(email, `telegram login password`, message, providerId);
        emailSent = true;
      }
      if (sendPhone && user.phone?.phoneNumber) {
        const sendToPhone = value || user.phone?.phoneNumber;
        // eslint-disable-next-line no-unused-vars
        const currentConfigs = conversationApis[0].twilio;
        // eslint-disable-next-line no-undef
        const twilioResponse = await TwilioService.sendSms(
          {
            fromNumber: currentConfigs.fromNumber,
            toNumber: sendToPhone,
            body: message,
          },
          {
            sId: currentConfigs.sId,
            authToken: currentConfigs.authToken,
          },
          {
            provider: currentProvider.id,
            user: req.user.id,
          }
        );
        sendResponse.status = twilioResponse.status;
        sendResponse.message = twilioResponse.message;
        sendResponse.data = twilioResponse.data;
        twilioSent = true;
      }
      if (twilioSent || emailSent) {
        logger.info(`telegram login and password sent to user`);
      }

      cb(null, {
        notifyToProvider: req.user.provider.id,
        notifyToUser: req.user.id,
        emailSent,
        hasValidSmsProvider,
        twilioData: sendResponse.data,
        message: hasValidSmsProvider ? 'telegram login pass message sent' : 'no message (email, phone) provider setup',
        status: sendResponse.status,
      });
    } catch (ex) {
      logger.error(ex);
      cb(null, {
        notifyToProvider: req.user.provider.id,
        notifyToUser: req.user.id,
        message: ex.message ?? ex,
        status: false,
      });
    }
  };
  if (smsSendQueue.length) {
    logger.warn(`sms sending task is already running`);
    response.message = `sms in sending queue: please wait`;
  } else {
    smsSendQueue.push(func);
    response.message = `telegram login pass have been added to sms queue`;
  }
  return response;
};
const createUser = catchAsync(async (req, res) => {
  const { body } = req;
  body.state = 1;
  const user = await userRepository.createUser(req.body, req.geoIpInfo);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(user, req.user));
});

const UserCheckEmail = catchAsync(async (req, res) => {
  const response = await userRepository.UserCheckEmail(req.query);
  res.send(TimezoneService.LocalizeObject(response, req.user));
});

const UserCheckPhone = catchAsync(async (req, res) => {
  const response = await userRepository.UserCheckPhone(req.query);
  res.send(TimezoneService.LocalizeObject(response, req.user));
});

const getUsers = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['state', 'role']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await userRepository.queryUsers(filter, options, req.user);
  // eslint-disable-next-line no-restricted-syntax
  for (const item of result.results) {
    const permissionsObject = RoleService.GetUserPermissions(item, true);
    item.permissions = permissionsObject.permissions;
  }
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getRegistrationUsers = catchAsync(async (req, res) => {
  const filter = pick(req.query, [
    'lastActiveTime',
    'createTime',
    'firstname',
    'lastname',
    'email',
    'search',
    'roles',
    'accessEnable',
    'admin',
    'cashier',
    'advancedCashier',
    'equipmentInstaller',
    'support',
    'excel',
  ]);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  filter.registrations = true;
  const result = await userRepository.queryUsers(filter, options, req.user);
  // eslint-disable-next-line no-restricted-syntax
  for (const item of result.results) {
    const permissionsObject = RoleService.GetUserPermissions(item, true);
    item.permissions = permissionsObject.permissions;
  }
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportUserListTable(result.results, req.user, 'defaultSettings', 'defaultSettingsColumns');
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getCalendarUsers = catchAsync(async (req, res) => {
  const filter = pick(req.query, [
    'lastActiveTime',
    'createTime',
    'firstname',
    'lastname',
    'email',
    'search',
    'roles',
    'accessEnable',
    'admin',
    'cashier',
    'advancedCashier',
    'equipmentInstaller',
    'support',
    'excel',
  ]);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  filter.registrations = false;
  const result = await userRepository.queryUsers(filter, options, req.user);
  // eslint-disable-next-line no-restricted-syntax
  for (const item of result.results) {
    const permissionsObject = RoleService.GetUserPermissions(item, true);
    item.permissions = permissionsObject.permissions;
  }
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportUserListTable(result.results, req.user, 'defaultSettings', 'defaultSettingsColumns');
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getActiveUsers = catchAsync(async (req, res) => {
  const filter = pick(req.query, [
    'loginStartDate',
    'loginEndDate',
    'loginStatus',
    'userStatus',
    'id',
    'search',
    'ipAddressesSearch',
    'city',
    'country',
    'role',
    'excel',
  ]);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await userRepository.queryActiveUsers(filter, options, req.user);
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportUserActivityTable(
      result.results,
      req.user,
      'userActivitySettings',
      'userActivityTable'
    );
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getUser = catchAsync(async (req, res) => {
  const user = await userRepository.getUserById(req.params.userId);
  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }
  const permissionsObject = RoleService.GetUserPermissions(user, true);
  const userObject = user.toJSON();
  userObject.permissions = permissionsObject.permissions;
  res.send(TimezoneService.LocalizeObject(userObject, req.user));
});

const getPermissionUser = catchAsync(async (req, res) => {
  const user = await userRepository.getUserById(req.params.userId);
  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }
  const sendUser = user.toJSON();
  const permissionsObject = RoleService.GetUserPermissions(req.user, true);
  sendUser.permissions = permissionsObject.permissions;
  res.send(
    TimezoneService.LocalizeObject(
      { permissions: permissionsObject.permissions, redirect: permissionsObject.redirect },
      req.user
    )
  );
});

const updateUser = catchAsync(async (req, res) => {
  const data = await userRepository.findDifferentAndUpdateUser(req);
  const { newUser, disable } = data;
  // eslint-disable-next-line no-unused-expressions
  disable
    ? await BroadcastService.broadcastToAppointment({
        body: data,
      })
    : null;

  const sendUser = newUser.toJSON();
  const permissionsObject = RoleService.GetUserPermissions(req.user, true);
  sendUser.permissions = permissionsObject.permissions;
  res.send(TimezoneService.LocalizeObject(sendUser, req.user));
});

const deleteMultiply = catchAsync(async (req, res) => {
  await userRepository.deleteMultiplyUserById(req.body);
  res.status(httpStatus.NO_CONTENT).send();
});

const deleteUser = catchAsync(async (req, res) => {
  await userRepository.deleteUserById(req.params.userId);
  res.status(httpStatus.NO_CONTENT).send();
});

const userEnableDisableAction = catchAsync(async (req, res) => {
  const item = await userRepository.userActionById(req.body);
  res.send(TimezoneService.LocalizeObject(item, req.user));
});

const setUserSettings = catchAsync(async (req, res) => {
  const result = await userRepository.updateUserSettings(req.user._id, req.body);
  res.send(TimezoneService.LocalizeObject(result.settings, req.user));
});

const getUserSettings = catchAsync(async (req, res) => {
  const user = await userRepository.getUserById(req.user._id);
  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }
  res.send(TimezoneService.LocalizeObject(user.settings, req.user));
});

const resetPassword = catchAsync(async (req, res) => {
  const result = await userRepository.resetPassword(req.body.token, req.body.password);
  const user = await userRepository.getUserByEmail(req.body.email);
  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }
  await EmailService.sendResetPasswordEmail(req.body.email, result, user.firstname);
  res.status(httpStatus.NO_CONTENT).send();
});

const emailResetPassword = catchAsync(async (req, res) => {
  const user = await userRepository.getUserByEmail(req.body.email);
  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }
  const token = await tokenRepository.verifyEmailToken(user._id, 'resetPassword');
  await EmailService.sendEmailResetPasswordToken(req.body.email, user.firstname, token);
  res.status(httpStatus.NO_CONTENT).send();
});

const generateTelegramPassword = catchAsync(async (req, res) => {
  const { userId } = req.params;
  const user = await userRepository.getUserById(userId);
  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }

  const updatedUser = await userRepository.updateUserById(
    { _id: user._id.toString() },
    { telegramLogin: randomNumberSequence(6), telegramPassword: randomNumberSequence(6) }
  );

  res.send(
    TimezoneService.LocalizeObject(
      {
        user: updatedUser,
      },
      user
    )
  );
});

const sendTelegramPassword = catchAsync(async (req, res) => {
  const { userId } = req.params;
  const user = await userRepository.getUserById(userId);
  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }
  const response = await sendTelegramLoginPasswordWorker(req, user);
  response.user = user;
  res.send(TimezoneService.LocalizeObject(response, user));
});

const resetLoginCount = catchAsync(async (req, res) => {
  await userRepository.resetLoginCount(req.params.userId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createUser,
  getUsers,
  getRegistrationUsers,
  getActiveUsers,
  getUser,
  getPermissionUser,
  updateUser,
  deleteMultiply,
  deleteUser,
  userEnableDisableAction,
  setUserSettings,
  getUserSettings,
  generateTelegramPassword,
  sendTelegramPassword,
  getCalendarUsers,
  resetPassword,
  emailResetPassword,
  resetLoginCount,
  UserCheckEmail,
  UserCheckPhone,
});
