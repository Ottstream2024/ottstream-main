const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { serverRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createServer = catchAsync(async (req, res) => {
  const channel = await serverRepository.createServer(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(channel, req.user));
});

const getServers = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  filter.status = 1;
  const result = await serverRepository.queryServers(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getServer = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await serverRepository.getServerById(req.params.serverId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Server not found');
  }
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updateServer = catchAsync(async (req, res) => {
  const channel = await serverRepository.updateServerById(req.params.serverId, req.body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const disableEnableServer = catchAsync(async (req, res) => {
  const channel = await serverRepository.disableEnableServerById(req.params.serverId, req.body.status);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const disableEnableServers = catchAsync(async (req, res) => {
  const disableEnable = req.body.action === 1;
  // eslint-disable-next-line no-restricted-syntax
  for (const item of req.body.servers) {
    // eslint-disable-next-line no-await-in-loop
    await serverRepository.disableEnableServerById(item, disableEnable);
  }
  res.send(true);
});

const deleteServer = catchAsync(async (req, res) => {
  await serverRepository.deleteServerById(req.params.serverId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createServer,
  getServers,
  getServer,
  updateServer,
  disableEnableServer,
  disableEnableServers,
  deleteServer,
});
