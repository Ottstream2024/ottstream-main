const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const {
  packageRepository,
  discountRepository,
  priceGroupRepository,
  ottProviderRepository,
} = require('../../../repository');
const priceUtils = require('../../../utils/price/price_utils');
const serviceCollection = require('../../../services/service_collection');
const BroadcastService = require('../../../services/socket/broadcastService.service');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const getParentPrices = async (provider, _package) => {
  let parentPrice = [];
  if (provider.parent) {
    const _parentPackageOption = await packageRepository.getPackageOption(_package._id, provider.parent);
    parentPrice = await priceUtils.getPackagePriceTable(
      _parentPackageOption,
      provider.priceGroup?.toString(),
      null, // TODO get current active discount for  req.user.provider._id.toString()
      false
    );
    const activeDiscounts = await discountRepository.getActiveDiscountsForProvider(provider.parent);
    const selectedDiscount = activeDiscounts.length ? activeDiscounts[0] : null; // TODO get discount for package
    const parentPriceDiscount = await priceUtils.getPackagePriceTable(
      _parentPackageOption,
      provider.priceGroup?.toString(),
      selectedDiscount?._id.toString() ?? null, // TODO get current active discount for  req.user.provider._id.toString()
      false
    );
    // eslint-disable-next-line guard-for-in,no-restricted-syntax
    for (const item of parentPriceDiscount) {
      const filtered = parentPrice.filter((r) => r.md === item.md);
      if (filtered.length) {
        // eslint-disable-next-line guard-for-in,no-restricted-syntax
        for (const k in parentPrice[0].rooms) {
          parentPrice[0].rooms[k].priceDiscounted = item.rooms[k].price;
        }
      }
    }
  }
  return parentPrice;
};

const mergePackagePriceTableWithParent = async (parentPrices, packagePrices) => {
  // eslint-disable-next-line no-restricted-syntax
  const parentMdList = [];
  // eslint-disable-next-line no-restricted-syntax
  for (const item of parentPrices) {
    parentMdList.push(item.md);
  }
  if (parentPrices.length) {
    // eslint-disable-next-line no-restricted-syntax
    for (const currentPrice of packagePrices) {
      // eslint-disable-next-line no-await-in-loop
      const nearestInterval = priceUtils.findNearestIntervalInList(parentMdList, currentPrice.md);

      // eslint-disable-next-line guard-for-in,no-restricted-syntax
      for (const k in currentPrice.rooms) {
        const currentPriceRoom = currentPrice.rooms[k];

        const parentNearestPricesForInterval = parentPrices.filter((r) => r.md === nearestInterval)[0];
        {
          const parentNearestRoomPrice = priceUtils.calculateRoomPriceFromRoomPrices(
            parentNearestPricesForInterval.rooms,
            currentPriceRoom.room
          );

          currentPriceRoom.priceParent = priceUtils.calculateIntervalPriceByInterval(
            // eslint-disable-next-line radix
            parseInt(parentNearestPricesForInterval.md[0]),
            parentNearestPricesForInterval.md[1],
            {
              price: parentNearestRoomPrice,
              room: currentPriceRoom.room,
              // eslint-disable-next-line radix
              interval: parseInt(parentNearestPricesForInterval.md[0]),
              intervalType: parentNearestPricesForInterval.md[1],
            }
          );
        }
        {
          const parentNearestRoomPriceDiscounted = priceUtils.calculateRoomPriceFromRoomPrices(
            parentNearestPricesForInterval.rooms,
            currentPriceRoom.room,
            'priceDiscounted'
          );

          currentPriceRoom.priceParentDiscounted = priceUtils.calculateIntervalPriceByInterval(
            parentNearestPricesForInterval.md,
            parentNearestRoomPriceDiscounted,
            currentPrice.md
          );
        }
      }
    }
  }
  return packagePrices;
};

const createDefaultPrice = catchAsync(async (req, res) => {
  const _package = await packageRepository.getPackageById(req.params.packageId);
  if (!_package) throw new ApiError(httpStatus.BAD_REQUEST, 'package not found');
  const parentPrices = await getParentPrices(req.user.provider, _package);
  const _packageOption = await packageRepository.getOrCreatePackageOption(_package._id, req.user);
  const _updatedPackageOption = priceUtils.addPackageDefaultPrice(
    _packageOption,
    req.body.clientType,
    req.body.interval,
    req.body.intervalType,
    req.body.prices
  );
  await _updatedPackageOption.save();
  const list = await priceUtils.getPackagePriceTable(
    _updatedPackageOption,
    req.body.priceGroup,
    req.body.discount,
    req.body.clientType
  );

  res.send(
    TimezoneService.LocalizeObject(
      {
        parentPrices,
        prices: await mergePackagePriceTableWithParent(parentPrices, list),
      },
      req.user
    )
  );
});

const createPrice = catchAsync(async (req, res) => {
  const _package = await packageRepository.getPackageById(req.params.packageId);
  if (!_package) throw new ApiError(httpStatus.BAD_REQUEST, 'package not found');

  const parentPrices = await getParentPrices(req.user.provider, _package);

  const _packageOption = await packageRepository.getOrCreatePackageOption(_package._id, req.user);
  let percent;
  if (req.body.priceGroup) {
    const priceGroup = await priceGroupRepository.getPriceGroupById(req.body.priceGroup);
    if (!priceGroup) throw new ApiError(httpStatus.BAD_REQUEST, 'priceGroup not found');
    percent = priceGroup.percent;
  }
  const _updatedPackageOption = priceUtils.editPackagePrices(
    _packageOption,
    req.body.clientType,
    req.body.priceGroup,
    percent,
    req.body.discount,
    req.body.editPrices,
    req.body.removePrices
  );
  await _updatedPackageOption.save();
  const list = await priceUtils.getPackagePriceTable(
    _updatedPackageOption,
    req.body.priceGroup,
    req.body.discount,
    req.body.clientType
  );
  res.send(
    TimezoneService.LocalizeObject(
      {
        parentPrices,
        prices: await mergePackagePriceTableWithParent(parentPrices, list),
      },
      req.user
    )
  );
});

const addPrice = catchAsync(async (req, res) => {
  const _package = await packageRepository.getPackageById(req.params.packageId);
  if (!_package) throw new ApiError(httpStatus.BAD_REQUEST, 'package not found');

  const parentPrices = await getParentPrices(req.user.provider, _package);

  const _packageOption = await packageRepository.getOrCreatePackageOption(_package._id, req.user);
  const _updatedPackageOption = priceUtils.addPackagePrice(
    _packageOption,
    req.body.clientType,
    req.body.interval,
    req.body.intervalType,
    [0, 0, 0, 0, 0]
  );
  await _updatedPackageOption.save();
  const list = await priceUtils.getPackagePriceTable(
    _updatedPackageOption,
    req.body.priceGroup,
    req.body.discount,
    req.body.clientType
  );
  res.send(
    TimezoneService.LocalizeObject(
      {
        parentPrices,
        prices: await mergePackagePriceTableWithParent(parentPrices, list),
      },
      req.user
    )
  );
});

const getPackagePrice = catchAsync(async (req, res) => {
  const _package = await packageRepository.getPackageById(req.params.packageId);
  if (!_package) throw new ApiError(httpStatus.BAD_REQUEST, 'package not found');
  const _packageOption = await packageRepository.getOrCreatePackageOption(_package._id, req.user);

  const parentPrices = await getParentPrices(req.user.provider, _package);

  const list = await priceUtils.getPackagePriceTable(
    _packageOption,
    req.query.priceGroup,
    req.query.discount,
    req.query.clientType
  );
  // eslint-disable-next-line no-restricted-syntax
  // for (const listItem of list) {
  //
  //   await
  // }
  res.send(
    TimezoneService.LocalizeObject(
      {
        parentPrices,
        prices: await mergePackagePriceTableWithParent(parentPrices, list),
      },
      req.user
    )
  );
});

const createPackage = catchAsync(async (req, res) => {
  const channel = await packageRepository.createPackage(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(channel, req.user));
});

const getPackages = catchAsync(async (req, res) => {
  const filter = pick(req.query, [
    'name',
    'role',
    'user',
    'search',
    'room',
    'parentDiscounts',
    'clientPriceGroup',
    'clientDiscounts',
    'providerPriceGroup',
    'providerDiscounts',
    'clientsFrom',
    'clientsTo',
    'clientsTotalFrom',
    'clientsTotalTo',
    'vEnable',
    'tEnable',
    'aEnable',
    'excel',
  ]);
  // const providers = [
  //   '6457996b1c5b7b1510f6a2f0',
  //   '645799771c5b7b1510f6c9bc',
  //   '6457997d1c5b7b1510f6dc99',
  //   '645799af1c5b7b1510f799d5',
  // ];
  // const currentProvider = req.user.provider._id.toString();
  // if (providers.includes(currentProvider)) {
  //   const parentOptions = await packageRepository.getOptionsList({ provider: '645799071c5b7b1510f5388c' });
  //   const ownOptions = await packageRepository.getOptionsList({ provider: currentProvider });
  //   if (ownOptions.length) {
  //     // eslint-disable-next-line no-restricted-syntax
  //     for (const ownOption of ownOptions) {
  //       const foundParentOptions = parentOptions.filter((r) => r.package.toString() === ownOption.package.toString());
  //       let parentOption = null;
  //       // eslint-disable-next-line prefer-destructuring
  //       if (foundParentOptions.length) parentOption = foundParentOptions[0];
  //       if (parentOption) {
  //         // eslint-disable-next-line no-await-in-loop
  //         await packageRepository.updatePackageOption(
  //           {
  //             prices: parentOption.prices,
  //           },
  //           ownOption.package,
  //           req.user.provider._id.toString()
  //         );
  //       }
  //
  //       // if (packageOption.prices.length === 1) {
  //       //   const priceObject = packageOption.prices[0];
  //       //   if (priceObject) {
  //       //     const copyObject = { ...priceObject.toJSON() };
  //       //     copyObject.clientType = false;
  //       //     delete copyObject._id;
  //       //     delete copyObject.createdAt;
  //       //     delete copyObject.updatedAt;
  //       //     if (copyObject.priceItems) {
  //       //       // eslint-disable-next-line no-restricted-syntax
  //       //       for (const priceItems of copyObject.priceItems) {
  //       //         delete priceItems._id;
  //       //         delete priceItems.createdAt;
  //       //         delete priceItems.updatedAt;
  //       //       }
  //       //       packageOption.prices.push(copyObject);
  //       //       // eslint-disable-next-line no-await-in-loop
  //       //       await packageRepository.updatePackageOption(
  //       //         {
  //       //           prices: packageOption.prices,
  //       //         },
  //       //         packageOption.package,
  //       //         req.user.provider._id.toString()
  //       //       );
  //       //     }
  //       //   }
  //       // } else if (packageOption.prices.length === 2) {
  //       //   const prices = [];
  //       //   prices.push(packageOption.prices[0].toJSON());
  //       //   prices.push(packageOption.prices[1].toJSON());
  //       //   prices[1].clientType = false;
  //       //   // eslint-disable-next-line no-await-in-loop
  //       //   await packageRepository.updatePackageOption(
  //       //     {
  //       //       prices,
  //       //     },
  //       //     packageOption.package,
  //       //     req.user.provider._id.toString()
  //       //   );
  //       // }
  //     }
  //   } else {
  //     // eslint-disable-next-line no-restricted-syntax
  //     for (const parentOption of parentOptions) {
  //       // eslint-disable-next-line prefer-destructuring
  //       if (parentOption) {
  //         // eslint-disable-next-line no-await-in-loop
  //         await packageRepository.createPackageOption(
  //           {
  //             prices: parentOption.prices,
  //           },
  //           parentOption.package.toString(),
  //           req.user.provider._id.toString(),
  //           req.user
  //         );
  //       }
  //
  //       // if (packageOption.prices.length === 1) {
  //       //   const priceObject = packageOption.prices[0];
  //       //   if (priceObject) {
  //       //     const copyObject = { ...priceObject.toJSON() };
  //       //     copyObject.clientType = false;
  //       //     delete copyObject._id;
  //       //     delete copyObject.createdAt;
  //       //     delete copyObject.updatedAt;
  //       //     if (copyObject.priceItems) {
  //       //       // eslint-disable-next-line no-restricted-syntax
  //       //       for (const priceItems of copyObject.priceItems) {
  //       //         delete priceItems._id;
  //       //         delete priceItems.createdAt;
  //       //         delete priceItems.updatedAt;
  //       //       }
  //       //       packageOption.prices.push(copyObject);
  //       //       // eslint-disable-next-line no-await-in-loop
  //       //       await packageRepository.updatePackageOption(
  //       //         {
  //       //           prices: packageOption.prices,
  //       //         },
  //       //         packageOption.package,
  //       //         req.user.provider._id.toString()
  //       //       );
  //       //     }
  //       //   }
  //       // } else if (packageOption.prices.length === 2) {
  //       //   const prices = [];
  //       //   prices.push(packageOption.prices[0].toJSON());
  //       //   prices.push(packageOption.prices[1].toJSON());
  //       //   prices[1].clientType = false;
  //       //   // eslint-disable-next-line no-await-in-loop
  //       //   await packageRepository.updatePackageOption(
  //       //     {
  //       //       prices,
  //       //     },
  //       //     packageOption.package,
  //       //     req.user.provider._id.toString()
  //       //   );
  //       // }
  //     }
  //   }
  // }
  // const ownOptions = await packageRepository.getOptionsList({ provider: req.user.provider._id.toString() });
  // if (!ownOptions.length) {
  //   // const packageOptions = await packageRepository.getOptionsList({ provider: '645799071c5b7b1510f5388c' });
  //   // eslint-disable-next-line no-restricted-syntax
  //   // for (const packageOption of packageOptions) {
  //   //   // eslint-disable-next-line no-await-in-loop
  //   //   // await packageRepository.createPackageOption(
  //   //   //   {
  //   //   //     sampleOption: packageOptions.sampleOption,
  //   //   //     prices: packageOptions.prices,
  //   //   //   },
  //   //   //   packageOption.package,
  //   //   //   req.user.provider._id.toString(),
  //   //   //   req.user
  //   //   // );
  //   // }
  // }
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  options.limit = 1000;
  const result = await packageRepository.queryPackages(filter, options, req.user);
  const parentOttPackages = [];
  if (req.user.provider.type !== 0) {
    const parentOtts = await ottProviderRepository.getOttParents(req.user.provider.id.toString());
    // eslint-disable-next-line no-restricted-syntax
    for (const parentOtt of parentOtts) {
      // eslint-disable-next-line no-await-in-loop
      const currentParentPackages = await packageRepository.getPackageOptions(parentOtt._id.toString());
      const currentParentPackagesDict = currentParentPackages.reduce((obj, item) => {
        // eslint-disable-next-line no-param-reassign
        obj[item.package.toString()] = item;
        return obj;
      }, {});
      parentOttPackages.push(currentParentPackagesDict);
    }
  }
  const buyCheck = req.user.provider.type !== 0;
  // eslint-disable-next-line no-await-in-loop
  const ownParentPackages = await packageRepository.getPackageOptions(req.user.provider.id);
  const ownParentPackagesDict = ownParentPackages.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    obj[item.package.toString()] = item;
    return obj;
  }, {});
  result.results = result.results.filter((r) => (buyCheck ? r.buyPrice && r.buyPrice > 0 : true));
  result.results.forEach((item, index) => {
    result.results[index].allowDisable = true;
    if (buyCheck) {
      const parentHasDisabled = parentOttPackages.filter(
        (a) => typeof a[item._id.toString()] !== 'undefined' && !a[item._id.toString()].state
      ).length;
      result.results[index].allowDisable = !parentHasDisabled;
      result.results[index].state = parentHasDisabled
        ? 0
        : ownParentPackagesDict[item.id] &&
          ownParentPackagesDict[item.id].state &&
          ownParentPackagesDict[item.id].state === 1;
    } else {
      result.results[index].allowDisable = true;
      result.results[index].state = !!(ownParentPackagesDict[item.id] && ownParentPackagesDict[item.id].state === 1);
    }
  });
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportListByUserSettings(result.results, req.user, 'packagesSettings', 'packagesTable');
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getPackage = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await packageRepository.getPackageById(req.params.packageId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Package not found');
  }
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updatePackage = catchAsync(async (req, res) => {
  const channel = await packageRepository.updatePackageById(req.params.packageId, req.body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const disableEnablePackage = catchAsync(async (req, res) => {
  const providerId = req.user.provider.id;
  const providers = await ottProviderRepository.getOttChilds([providerId]); // TODO uncheck if works
  providers.forEach(async (provider) => {
    await BroadcastService.broadcastToProvider(provider.id, 'package-info', {
      status: true,
      message: `package list get`,
    });
  });
  await BroadcastService.broadcastToProvider(providerId, 'package-info', {
    status: true,
    message: `package list get`,
  });
  const channel = await packageRepository.disableEnablePackageById(req.params.packageId, providerId, req.body.state);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const disableEnablePackages = catchAsync(async (req, res) => {
  const disableEnable = req.body.action === 1;
  // eslint-disable-next-line no-restricted-syntax
  for (const item of req.body.packages) {
    // eslint-disable-next-line no-await-in-loop
    await packageRepository.disableEnablePackageById(item, req.user.provider.id, disableEnable);
  }
  res.send(true);
});

const deletePackage = catchAsync(async (req, res) => {
  await packageRepository.deletePackageById(req.params.packageId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  addPrice,
  createPrice,
  createDefaultPrice,
  getPackagePrice,
  createPackage,
  getPackages,
  getPackage,
  updatePackage,
  disableEnablePackage,
  disableEnablePackages,
  deletePackage,
});
