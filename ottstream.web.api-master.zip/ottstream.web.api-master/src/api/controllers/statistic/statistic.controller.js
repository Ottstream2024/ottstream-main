/* eslint-disable no-await-in-loop */
const queue = require('queue');
const catchAsync = require('../../../utils/helpers/catchAsync');
const BroadcastService = require('../../../services/socket/broadcastService.service');
const StatisticService = require('../../../services/statistics/statistic.service');
const { ottProviderRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const printQueue = queue({ results: [], autostart: true, timeout: 0, concurrency: 1 });

// eslint-disable-next-line no-unused-vars
printQueue.on('timeout', async (next, job) => {
  next();
});

// get notified when jobs complete
// eslint-disable-next-line no-unused-vars
printQueue.on('success', async (result, job) => {
  // eslint-disable-next-line no-await-in-loop

  await BroadcastService.broadcastToProvider(result.notifyToProvider, 'invoice-info', {
    status: result.status,
    message: result.message,
  });
});

const getServiceSubscriptionInfo = catchAsync(async (req, res) => {
  const info = await StatisticService.getServiceSubscriptionInfo(req.user.provider.id);
  res.send(info);
});

const getServiceTelegramInfo = catchAsync(async (req, res) => {
  const info = await StatisticService.getServiceTelegramInfo(req.user.provider.id);
  res.send(info);
});

const getTransactions = catchAsync(async (req, res) => {
  const base = await ottProviderRepository.getBaseOttProvider();
  const toProvider = base.id;
  const fromProvider = null;
  const fromClient = '647c70ece905f463951173ee';
  const info = await StatisticService.getTransactions(toProvider, fromProvider, fromClient);
  res.send(TimezoneService.LocalizeObject(info, req.user, {}, 'YYYY-MM-DD hh:mm'));
  // res.send(TimezoneService.LocalizeObject(info, req.user, {}, 'M/D/YYYY'));
});

const recalculateInvoice = catchAsync(async (req, res) => {
  const base = await ottProviderRepository.getBaseOttProvider();
  const toProvider = base.id;
  const fromProvider = null;
  const fromClient = '647c70ece905f463951173ee';
  const info = await StatisticService.getTransactions(toProvider, fromProvider, fromClient);
  await StatisticService.recalculateInvoices(info.clients, toProvider);
  res.send(TimezoneService.LocalizeObject({ success: true }, req.user));
});

const getBillStatisticInfo = catchAsync(async (req, res) => {
  const info = await StatisticService.getPostalScheduleInfo(req.user.provider.id);
  res.send(info);
});

module.exports = depthExport({
  getBillStatisticInfo,
  getServiceSubscriptionInfo,
  getServiceTelegramInfo,
  getTransactions,
  recalculateInvoice,
});
