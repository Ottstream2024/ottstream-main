// authorization
module.exports.authController = require('./auth/auth.controller');
module.exports.creditController = require('./payment/credit.controller');
module.exports.balanceController = require('./payment/balance.controller');
module.exports.invoiceController = require('./payment/invoice.controller');
module.exports.transactionController = require('./payment/transaction.controller');

// system and user
module.exports.systemVariableController = require('./system/system_variable.controller');
module.exports.userController = require('./user/user.controller');
module.exports.userActivityController = require('./user/user_activity.controller');
module.exports.permissionController = require('./role/permission.controller');
module.exports.roleController = require('./role/role.controller');
module.exports.countryController = require('./country/country.controller');
module.exports.currencyController = require('./currency/currency.controller');
module.exports.currencyCountryController = require('./currency/currency_country.controller');
module.exports.iconTypeController = require('./icon_type/icon_type.controller');

// language
module.exports.languageController = require('./language/language.controller');
module.exports.languageUnitController = require('./language/language_unit.controller');
module.exports.languageUnitTranslationController = require('./language/language_unit_translation.controller');

// ottprovider
module.exports.ottProviderController = require('./ottprovider/ottprovider.controller');
module.exports.ottProviderAddressController = require('./ottprovider/ottprovider_address.controller');
module.exports.ottProviderEmailController = require('./ottprovider/ottprovider_email.controller');
module.exports.ottProviderPhoneController = require('./ottprovider/ottprovider_phone.controller');
module.exports.ottProviderShippingProviderController = require('./ottprovider/ottprovider_shipping_provider.controller');
module.exports.ottProviderConversationProviderController = require('./ottprovider/ottprovider_conversation_provider.controller');
module.exports.ottProviderPaymentGatewayController = require('./ottprovider/ottprovider_payment_gateway.controller');
module.exports.ottProviderOtherApiController = require('./ottprovider/ottprovider_other_api.controller');
module.exports.ottProviderPritnerController = require('./ottprovider/ottprovider_printer.controller');
module.exports.ottProviderUiController = require('./ottprovider/ottprovider_ui.controller');
module.exports.ottProviderInfoController = require('./ottprovider/ottprovider_info.controller');
module.exports.ottProviderPaymentMethodController = require('./ottprovider/ottprovider_payment_method.controller');
module.exports.ottProviderInvoiceController = require('./ottprovider/ottprovider_invoice.controller');
module.exports.ottProviderPermissionController = require('./ottprovider/ottprovider_permission.controller');

// payment
module.exports.creditCardController = require('./payment/credit_card/credit_card.controller');
module.exports.paymentGatewayController = require('./payment/payment_gateway.controller');
module.exports.paymentMethodController = require('./payment/payment_method.controller');
module.exports.paymentImplementationController = require('./payment/payment_implementation.controller');

// channel
module.exports.channelController = require('./channel/channel.controller');
module.exports.packageController = require('./package/package.controller');
module.exports.priceGroupController = require('./price/price_group.controller');

// discount
module.exports.discountController = require('./discount/discount.controller');

// client
module.exports.clientController = require('./client/client.controller');
module.exports.clientPaymentMethodController = require('./client/client_payment_method.controller');
module.exports.clientPackageController = require('./client/client_package.controller');
module.exports.clientLocationController = require('./client/client_location.controller');
module.exports.clientProfileController = require('./client/client_profile.controller');
module.exports.clientUsedDeviceController = require('./client/client_used_device.controller');
module.exports.clientUsedDeviceActivityController = require('./client/client_used_device_activity.controller');
module.exports.ageGroupController = require('./client/age_group.controller');

// easyship
module.exports.easyshipController = require('./easyship/easyship.controller');

// server
module.exports.serverController = require('./server/server.controller');

// channel group
module.exports.groupController = require('./group/group.controller');

// icon
module.exports.iconController = require('./icon/icon.controller');

// subscription
module.exports.subscriptionController = require('./subscription/subscription.controller');

// equipment
module.exports.equipmentController = require('./equipment/equipment.controller');
module.exports.equipmentTypeController = require('./equipment/equipment_type.controller');
module.exports.equipmentInstallerController = require('./equipment/equipment_installer.controller');

// calendar
module.exports.calendarEventController = require('./calendar/calendar_event.controller');

// backup
module.exports.backupController = require('./backup/backup.controller');

// comment
module.exports.commentController = require('./comment/comment.controller');

// notification
module.exports.notificationController = require('./notification/notification.controller');

// shipping
module.exports.shippingController = require('./shipping/shipping.controller');

// control
module.exports.controlController = require('./control/control.controller');

// bank name
module.exports.bankeNameController = require('./payment/bank_name.controller');

// webhook
module.exports.webHookController = require('./webhook/webhook.controller');

// statistic
module.exports.statisticController = require('./statistic/statistic.controller');

// chat
module.exports.chatController = require('./chat/chat.controller');

// help
module.exports.helpController = require('./help/help.controller');
