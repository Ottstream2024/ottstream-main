const httpStatus = require('http-status');
const moment = require('moment-timezone');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { commentRepository } = require('../../../repository');
// const commentTypes = require('../../../config/comment_types');
const serviceCollection = require('../../../services/service_collection');
const logger = require('../../../utils/logger/logger');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const fixReminderdate = (reminderDate, req) => {
  let datePart = reminderDate.split(' ')[0];
  const timePart = reminderDate.split(' ')[1];

  if (datePart && timePart) {
    const [hour, minute] = timePart.split(':');
    // Input timezone string
    const timezoneString = req.user.provider.timezone;

    // Get the current offset in minutes
    const offsetInMinutes = moment.tz(timezoneString).utcOffset();

    // Convert offset to hours and minutes
    const offsetHours = Math.floor(offsetInMinutes / 60);
    // filter.executionStartDate = new Date(Date.UTC(2023, 9, 2, 12, 0, 0));
    // filter.executionEndDate = new Date(Date.UTC(2023, 9, 2, 12, 0, 0));
    datePart = new Date(datePart);
    datePart.setHours(hour, minute, 0);

    // Get the time zone offset in minutes
    const timeZoneOffsetInMinutes = moment(datePart).utcOffset();

    // Convert the offset to hours
    const timeZoneOffsetInHours = timeZoneOffsetInMinutes / 60;

    // Add the offset hours to the date
    datePart.setHours(datePart.getHours() + timeZoneOffsetInHours - offsetHours);
    return datePart;
  }
  return null;
};

const createComment = catchAsync(async (req, res) => {
  try {
    const { body } = req;
    let newReminderDate = null;
    if (body.reminderDate) {
      newReminderDate = fixReminderdate(body.reminderDate, req);
    }
    if (newReminderDate) body.reminderDate = newReminderDate;
    const comment = await commentRepository.createComment(body, req.user);
    if (newReminderDate)
      logger.info(`reminder reminder: ${comment.reminderDate.toString()} current: ${new Date().toString()}`);
    res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(comment, req.user));
  } catch (ex) {
    logger.error(ex);
  }
});

const getComments = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['excel', 'client']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await commentRepository.queryComments(filter, options);
  // eslint-disable-next-line no-param-reassign,no-return-assign
  result.results.forEach((item, i) => {
    result.results[i] = item.toJSON();
    if (item.reminderDate) result.results[i].reminderDateFormated = new Date(item.reminderDate);
    const tempUser = { ...result.results[i].user };
    result.results[i].user = {
      firstname: tempUser.firstname,
      lastname: tempUser.lastname,
    };
  });
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportCommentTable(result.results, req.user, 'commentSettings', 'commentTable');
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  res.send(TimezoneService.LocalizeObject(result, req.user, { reminderDate: false }));
});

const getComment = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await commentRepository.getCommentById(req.params.commentId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Comment not found');
  }
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updateComment = catchAsync(async (req, res) => {
  const saveBody = { ...req.body };
  let newReminderDate = null;
  if (saveBody.reminderDate) {
    newReminderDate = fixReminderdate(saveBody.reminderDate, req);
  }
  if (newReminderDate) saveBody.reminderDate = newReminderDate;
  saveBody.updateUser = req.user._id.toString();
  const comment = await commentRepository.getCommentById(req.params.commentId);
  if (!comment) throw new ApiError(`comment not found by that id`);
  if (
    comment.reminderDate &&
    saveBody.reminderDate &&
    comment.reminderDate.getTime() !== saveBody.reminderDate.getTime() &&
    comment.sendNotification
  ) {
    saveBody.notified = false;
  }
  const channel = await commentRepository.updateCommentById(req.params.commentId, saveBody);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const commentEnableDisableAction = catchAsync(async (req, res) => {
  const item = await commentRepository.commentsActionById(req.body);
  res.send(TimezoneService.LocalizeObject(item, req.user));
});

const deleteComment = catchAsync(async (req, res) => {
  await commentRepository.deleteCommentById(req.params.commentId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createComment,
  getComments,
  getComment,
  updateComment,
  deleteComment,
  commentEnableDisableAction,
});
