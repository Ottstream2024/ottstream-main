const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { notificationRepository } = require('../../../repository');
// const notificationTypes = require('../../../config/notification_types');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createNotification = catchAsync(async (req, res) => {
  const channel = await notificationRepository.createNotification(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(channel, req.user));
});

const getNotifications = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['excel', 'client', 'comment', 'isViewed']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  filter.provider = req.user.provider._id.toString();
  filter.user = req.user.id;
  const result = await notificationRepository.queryNotifications(filter, options);
  // if (filter.excel) {
  //   const excelService = serviceCollection.getService('excelService');
  //   const report = excelService.exportNotificationTable(result.results, req.user, 'notificationSettings', 'notificationTable');
  //   res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
  //   return res.send(report);
  // }
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getNotification = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await notificationRepository.getNotificationById(req.params.notificationId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Notification not found');
  }
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updateNotification = catchAsync(async (req, res) => {
  const saveBody = { ...req.body };
  let notification = await notificationRepository.getNotificationById(req.params.notificationId);
  if (!notification) throw new ApiError(404, `notification with id ${req.params.notificationId} not found`);
  // const currentUserId = req.user._id.toString();
  // if (notification.user.toString() === currentUserId) {
  saveBody.updateUser = req.user._id.toString();
  notification = await notificationRepository.updateNotificationById(req.params.notificationId, saveBody);
  // }
  res.send(TimezoneService.LocalizeObject(notification, req.user));
});

const notificationEnableDisableAction = catchAsync(async (req, res) => {
  const item = await notificationRepository.notificationsActionById(req.body);
  res.send(TimezoneService.LocalizeObject(item, req.user));
});

const deleteNotification = catchAsync(async (req, res) => {
  await notificationRepository.deleteNotificationById(req.params.notificationId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createNotification,
  getNotifications,
  getNotification,
  updateNotification,
  deleteNotification,
  notificationEnableDisableAction,
});
