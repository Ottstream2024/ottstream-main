const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { creditRepository, ottProviderRepository, clientRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const depthExport = require('../../../services/export/depth.export');

const TimezoneService = serviceCollection.getService('timezoneService', true);

const createCredit = catchAsync(async (req, res) => {
  const credit = await creditRepository.createCredit(req.body, req.user);
  if (credit) {
    if (credit.providerId) {
      await ottProviderRepository.addBalance(credit.providerId, credit.creditAmount);
    }
    if (credit.clientId) {
      await clientRepository.addBalance(credit.clientId, credit.creditAmount);
    }
  }
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(credit, req.user));
});

const stopCredit = catchAsync(async (req, res) => {
  const credit = await creditRepository.stopCredit(req.params.ottProviderId);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(credit, req.user));
});

const stopClientCredit = catchAsync(async (req, res) => {
  const credit = await creditRepository.stopClientCredit(req.params.clientId);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(credit, req.user));
});

const getCredits = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await creditRepository.queryCredits(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getCredit = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const credit = await creditRepository.getCreditById(req.params.creditId, options);
  if (!credit) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Credit not found');
  }
  res.send(TimezoneService.LocalizeObject(credit, req.user));
});

const updateCredit = catchAsync(async (req, res) => {
  const credit = await creditRepository.updateCreditById(req.params.creditId, req.body);
  res.send(TimezoneService.LocalizeObject(credit, req.user));
});

const deleteCredit = catchAsync(async (req, res) => {
  await creditRepository.deleteCreditById(req.params.creditId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createCredit,
  stopCredit,
  stopClientCredit,
  getCredits,
  getCredit,
  updateCredit,
  deleteCredit,
});
