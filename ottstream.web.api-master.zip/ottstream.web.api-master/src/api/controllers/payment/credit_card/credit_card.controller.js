const httpStatus = require('http-status');
const pick = require('../../../../utils/helpers/pick');
const ApiError = require('../../../utils/error/ApiError');
const catchAsync = require('../../../../utils/helpers/catchAsync');
const { creditCardRepository } = require('../../../../repository');
const serviceCollection = require('../../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../../services/export/depth.export');

const createCreditCard = catchAsync(async (req, res) => {
  const creditCard = await creditCardRepository.createCreditCard(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(creditCard, req.user));
});

const getCreditCards = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await creditCardRepository.queryCreditCards(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getCreditCard = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const creditCard = await creditCardRepository.getCreditCardById(req.params.creditCardId, options);
  if (!creditCard) {
    throw new ApiError(httpStatus.NOT_FOUND, 'CreditCard not found');
  }
  res.send(TimezoneService.LocalizeObject(creditCard, req.user));
});

const updateCreditCard = catchAsync(async (req, res) => {
  const creditCard = await creditCardRepository.updateCreditCardById(req.params.creditCardId, req.body);
  res.send(TimezoneService.LocalizeObject(creditCard, req.user));
});

const deleteCreditCard = catchAsync(async (req, res) => {
  await creditCardRepository.deleteCreditCardById(req.params.creditCardId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createCreditCard,
  getCreditCards,
  getCreditCard,
  updateCreditCard,
  deleteCreditCard,
});
