/* eslint-disable no-unreachable */
/* eslint-disable no-restricted-syntax */
const httpStatus = require('http-status');
const queue = require('queue');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
// eslint-disable-next-line no-unused-vars
const {
  transactionRepository,
  invoiceRepository,
  clientRepository,
  ottProviderConversationProviderRepository,
} = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const logger = require('../../../utils/logger/logger');
const depthExport = require('../../../services/export/depth.export');

const config = require('../../../config');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const { ottProviderRepository } = require('../../../repository');
const BroadcastService = require('../../../services/socket/broadcastService.service');
const { ottProviderPrinterRepository } = require('../../../repository');
// const TransactionService = require('../../../services/payment/transaction.service');
const InvoiceService = require('../../../services/payment/invoice.service');
const PrinterService = require('../../../services/printer/printer.service');
const EmailService = require('../../../services/email/EmailService.service');
const TransactionService = require('../../../services/payment/transaction.service');
// const EmailService = require('../../../services/email/EmailService.service');
const TwilioService = require('../../../services/sms/twilio.service');

const printQueue = queue({ results: [], autostart: true, timeout: 0, concurrency: 1 });

const smsSendQueue = queue({ results: [], autostart: true, timeout: 0, concurrency: 1 });

// eslint-disable-next-line no-unused-vars
printQueue.on('timeout', async (next, job) => {
  next();
});

// get notified when jobs complete
// eslint-disable-next-line no-unused-vars
printQueue.on('success', async (result, job) => {
  // eslint-disable-next-line no-await-in-loop

  await BroadcastService.broadcastToUser(result.notifyToUser, 'transaction-info', {
    status: result.status,
    isPrint: result.isPrint,
    message: result.message,
  });
});

// eslint-disable-next-line no-unused-vars
smsSendQueue.on('timeout', async (next, job) => {
  next();
});

// get notified when jobs complete
// eslint-disable-next-line no-unused-vars
smsSendQueue.on('success', async (result, job) => {
  // eslint-disable-next-line no-await-in-loop

  await BroadcastService.broadcastToUser(result.notifyToUser, 'transaction-info', {
    status: result.status,
    message: result.message,
  });
});

const createTransaction = catchAsync(async (req, res) => {
  const transaction = await transactionRepository.createTransaction(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(transaction, req.user));
});

const getTransactionFunction = async (req, res) => {
  // Get the initial high-resolution time
  const startTime = process.hrtime();

  const filter = pick(req.query, [
    'name',
    'fee',
    'role',
    'user',
    'search',
    'transactionDateStart',
    'transactionDateEnd',
    'transactionState',
    'transactionType',
    'transactionSubType',
    'amountMin',
    'amountMax',
    'searchBillNumber',
    'billGenerationDateStart',
    'billGenerationDateEnd',
    'initiatorType',
    'participantType',
    'searchLogin',
    'paymentMethodSearch',
    'paymentMethodType',
    'executionStartDate',
    'executionEndDate',
    'excel',
    'client',
    'own',
    'v2',
    'out',
    'in',
    'toProvider',
    'autopayment',
    'merchant',
    'allResellers',
    'resellers',
    'transactionType',
    'isRefund',
  ]);
  filter.providers = [];
  filter.client = req.params.client;
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const ownProviderId = req.user.provider.id;
  filter.baseprovider = ownProviderId;
  filter.selectedResellers = [];
  if (filter.resellers) {
    const providers = await ottProviderRepository.getOttChilds([ownProviderId]); // TODO uncheck if works
    filter.selectedResellers = [];
    const incoming = filter.resellers.split(',');
    for (const incomingProvider of incoming) {
      if (providers.filter((r) => r.id === incomingProvider).length) {
        filter.selectedResellers.push(incomingProvider);
      }
    }
  }
  filter.toProviders = [];
  if (filter.toProvider) {
    // const providers = await ottProviderRepository.getOttChilds([ownProviderId]); // TODO uncheck if works
    // providers.push(req.user.parent.id);
    filter.toProviders = filter.toProvider.split(',');
    // for (const incomingProvider of incoming) {
    //   if (providers.filter((r) => r._id.toString() === incomingProvider).length) {
    //     filter.toProviders.push(incomingProvider);
    //   }
    // }
  }
  if (filter.allResellers) {
    // eslint-disable-next-line no-await-in-loop
    const currentProviders = await ottProviderRepository.getOttChilds([filter.baseprovider]); // TODO uncheck if works
    filter.selectedResellers = currentProviders.map((r) => r.id);
  }
  filter.providers = filter.selectedResellers;
  const { sum, transactions } = await transactionRepository.queryTransactions(filter, options, req.user);
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportTransactionList(
      req.user.settings?.transactionSettings?.transactionTable,
      transactions.results
    );
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  transactions.amountSum = sum.toFixed(2);
  res.send(TimezoneService.LocalizeObject(transactions, req.user));

  // Get the final high-resolution time
  const endTime = process.hrtime(startTime);

  // Calculate the execution time in milliseconds
  const executionTime = endTime[0] * 1000 + endTime[1] / 1e6;

  logger.info(`Function execution time: ${executionTime} milliseconds`);
};

const getTransactions = catchAsync(async (req, res) => {
  await getTransactionFunction(req, res);
});

const getClientTransactions = catchAsync(async (req, res) => {
  await getTransactionFunction(req, res);
});

const getTransaction = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const transaction = await transactionRepository.getTransactionById(req.params.transactionId, options);
  if (!transaction) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Transaction not found');
  }
  res.send(TimezoneService.LocalizeObject(transaction, req.user));
});

const updateTransaction = catchAsync(async (req, res) => {
  const transaction = await transactionRepository.updateTransactionById(req.params.transactionId, req.body);
  res.send(TimezoneService.LocalizeObject(transaction, req.user));
});

const voidTransaction = catchAsync(async (req, res) => {
  const { transactionId } = req.params;
  const transaction = await transactionRepository.getTransactionById(transactionId);
  if (!transaction || !transaction.voidable) {
    throw new ApiError('transaction not found or is not voidable');
  }
  const invoice = await invoiceRepository.getInvoiceById(transaction.invoice);
  let transactionVoided = transaction.state === 5;
  if (transaction.state === 1 && transaction.voidable) {
    const voidResponse = await TransactionService.cancelTransaction(transaction);
    transactionVoided = voidResponse.status;
  }
  if (transactionVoided && transaction.voidable) {
    const cancelStatus = await InvoiceService.cancelInvoice(invoice, req.user); // TODO handle exceptions her
    const invoices = await invoiceRepository.getList({
      client: invoice.client,
      shippingExecuted: false,
      payloadExecuted: true,
      canceledExecuted: { $ne: true },
    });
    const previousInvoice = invoices.length ? invoices[invoices.length - 1] : null;
    if (previousInvoice) {
      const executionStatus = await InvoiceService.executeInvoice(previousInvoice, req.user); // TODO handle exceptions here
      if (cancelStatus.status && executionStatus.status) {
        await transactionRepository.updateTransactionById(transaction._id.toString(), { voidable: false });
      }
    }
  }
  // await TransactionService.cancelTransaction(transaction);
  // const transaction = await transactionRepository.updateTransactionById(req.params.transactionId, req.body);
  res.send(TimezoneService.LocalizeObject({ status: true }, req.user));
});

const printTransactionWorker = async (req, transactionId) => {
  let ip = req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for'] || req.ip;
  ip = ip.toString().replace('::ffff:', '');
  const response = { success: true };
  const currentProvider = await ottProviderRepository.getOttProviderById(req.user.provider.id);
  let hasValidPrinter = false;
  const providerPrinters = await ottProviderPrinterRepository.getOttProviderPrinterByProviderId(currentProvider.id);
  hasValidPrinter = providerPrinters.length && providerPrinters.filter((r) => r.ip).length;
  const func = async (cb) => {
    try {
      const provider = await ottProviderRepository.getOttProviderById(req.user.provider.id);
      const printers = await ottProviderPrinterRepository.getOttProviderPrinterByProviderId(provider.id);
      hasValidPrinter = printers.length;
      let ipFound = false;
      if (printers.length) {
        if (!printers.filter((r) => r.ip === ip).length) {
          response.success = false;
          response.message = `no printer found with user ip ${ip}`;
        } else {
          ipFound = true;
        }
        if (ipFound) {
          const printer = printers.filter((r) => r.ip === ip)[0];
          const printerIp = printer.ip;
          let pagesPerSheet = 1;
          if (typeof printer.pagesPerSheet !== 'undefined' && printer.pagesPerSheet > 1)
            pagesPerSheet = printer.pagesPerSheet;
          response.status = false;
          const isPrinterAvailable = await PrinterService.checkPrinter({ ip: printerIp });
          if (isPrinterAvailable) {
            const result = await InvoiceService.exportTransaction([transactionId], true, true, currentProvider);
            const path = `${config.getConfig().file.root_path}${result}`;
            // eslint-disable-next-line no-await-in-loop
            const printerPrintStatus = await PrinterService.printImage({ path, count: pagesPerSheet }, { ip: printerIp });
            response.status = printerPrintStatus;
            response.message = 'print succesfull';
          } else {
            response.message = 'printer is not available';
          }
        }
        cb(null, {
          notifyToProvider: req.user.provider.id,
          notifyToUser: req.user.id,
          isPrint: true,
          hasValidPrinter,
          message: response.message,
          status: response.status,
        });
      } else {
        cb(null, {
          notifyToProvider: req.user.provider.id,
          notifyToUser: req.user.id,
          hasValidPrinter,
          isPrint: true,
          message: 'no printer setup',
          status: response.status,
        });
      }
    } catch (ex) {
      cb(null, {
        notifyToProvider: req.user.provider.id,
        notifyToUser: req.user.id,
        message: ex.message ?? ex,
        status: false,
      });
    }
  };
  if (hasValidPrinter) {
    if (printQueue.length) {
      logger.warn(`printing task is already running`);
      response.message = `transactions in print queue: please wait`;
    } else {
      printQueue.push(func);
      response.message = `transaction have been added to queue`;
    }
  } else {
    response.message = `no printer is setup`;
    response.noPrinter = true;
  }
  return response;
};

const printTransactionByInvoice = catchAsync(async (req, res) => {
  let response = { status: false, message: 'transaction not found in invoice' };
  const { invoiceId } = req.params;
  const invoiceTransactions = await transactionRepository.getTransactionByInvoiceId(invoiceId);
  if (invoiceTransactions.filter((r) => r.source_type === 'PAY_INVOICE').length) {
    const transaction = invoiceTransactions.filter((r) => r.source_type === 'PAY_INVOICE')[0];
    response = await printTransactionWorker(req, transaction._id.toString());
  }
  res.send(response);
});

const printTransaction = catchAsync(async (req, res) => {
  const { transactionId } = req.params;
  const response = await printTransactionWorker(req, transactionId);

  res.send(response);
});

const sendTransactionWorker = async (req, transactionId) => {
  const response = { success: true };
  const currentProvider = await ottProviderRepository.getOttProviderById(req.user.provider.id);
  let hasValidSmsProvider = false;
  const conversationApis = await ottProviderConversationProviderRepository.getOttProviderConversationProviderByProviderId(
    currentProvider.id
  );
  hasValidSmsProvider = conversationApis.length && conversationApis[0].twilio && conversationApis[0].twilio.isValid;
  const func = async (cb) => {
    const sendResponse = { status: true, message: '' };
    try {
      // cb(null, {
      //   notifyToProvider: req.user.provider.id,
      //   notifyToUser: req.user.id,
      //   hasValidSmsProvider,
      //   message: 'twilio connection error',
      //   status: false,
      // });
      const transaction = await transactionRepository.getTransactionById(transactionId);
      if (!transaction) {
        throw new ApiError('transaction not found');
      }
      // eslint-disable-next-line no-unused-vars
      const client = await clientRepository.getClientById(
        transaction.from_client ? transaction.from_client : transaction.to_client
      );
      // eslint-disable-next-line no-unused-vars
      const { type, value } = req.body;
      const sendEmail = type === 'email_phone' || type === 'email';
      const sendPhone = type === 'email_phone' || type === 'phone';
      let emailSent = false;
      // eslint-disable-next-line no-unused-vars
      if (sendEmail && client.emails.filter((r) => r.forContactInvoice).length) {
        const { email } = client.emails.filter((r) => r.forContactInvoice)[0];
        await EmailService.sendCheckEmail(email, 'check email', 'check will be here', client.provider.id);
        emailSent = true;
      }
      const providerName = client.provider.name[0].name;
      if (sendPhone && client.phones.filter((r) => r.forMessages).length) {
        // eslint-disable-next-line no-unused-vars
        const currentConfigs = conversationApis[0].twilio;
        // eslint-disable-next-line no-undef
        const twilioResponse = await TwilioService.sendSms(
          {
            fromNumber: currentConfigs.fromNumber,
            toNumber: value,
            body: `${providerName}: Thank You For Using Our Service !`,
            mediaUrl: [
              `https://panelapi.ottstream.live/v1/transactions/view/${transaction._id.toString()}?type=2&jpeg=true`,
            ],
          },
          {
            sId: currentConfigs.sId,
            authToken: currentConfigs.authToken,
          },
          {
            provider: currentProvider.id,
            user: req.user.id,
          }
        );
        sendResponse.status = twilioResponse.status;
        sendResponse.message = twilioResponse.message;
        sendResponse.data = twilioResponse.data;
      }

      cb(null, {
        notifyToProvider: req.user.provider.id,
        notifyToUser: req.user.id,
        emailSent,
        hasValidSmsProvider,
        twilioData: sendResponse.data,
        message: hasValidSmsProvider ? 'transaction sms sent' : 'no sms provider setup',
        status: sendResponse.status,
      });
    } catch (ex) {
      logger.error(ex);
      cb(null, {
        notifyToProvider: req.user.provider.id,
        notifyToUser: req.user.id,
        message: ex.message ?? ex,
        status: false,
      });
    }
  };
  if (hasValidSmsProvider) {
    if (smsSendQueue.length) {
      logger.warn(`sms sending task is already running`);
      response.message = `sms in sending queue: please wait`;
    } else {
      smsSendQueue.push(func);
      response.message = `transaction have been added to sms queue`;
    }
  } else {
    response.message = `no sms probvder is setup`;
    response.noSetup = true;
  }
  return response;
};

const sendTransactionByInvoice = catchAsync(async (req, res) => {
  let response = { status: false, message: 'transaction not found in invoice' };
  const { invoiceId } = req.params;
  const invoiceTransactions = await transactionRepository.getTransactionByInvoiceId(invoiceId);
  if (invoiceTransactions.filter((r) => r.source_type === 'PAY_INVOICE').length) {
    const transaction = invoiceTransactions.filter((r) => r.source_type === 'PAY_INVOICE')[0];
    response = await sendTransactionWorker(req, transaction._id.toString());
  }
  res.send(response);
});

const sendTransaction = catchAsync(async (req, res) => {
  const { transactionId } = req.params;
  const response = await sendTransactionWorker(req, transactionId);

  res.send(response);
});

const view = catchAsync(async (req, res) => {
  try {
    const invoice = await transactionRepository.getTransactionById(req.params.transactionId);
    if (!invoice) {
      ApiError(400, 'transaction not found');
    }
    const { provider } = req.query;
    let viewProvider = null;
    if (provider) viewProvider = await ottProviderRepository.getOttProviderById(provider);
    // eslint-disable-next-line no-await-in-loop
    const result = await InvoiceService.exportTransaction(
      [req.params.transactionId],
      req.query.jpeg,
      req.query.type === '1',
      viewProvider
    );
    res.sendFile(result, { root: config.getConfig().file.root_path });
    res.on('finish', () => {
      try {
        // eslint-disable-next-line security/detect-non-literal-fs-filename
        // fs.unlinkSync(result);
      } catch (e) {
        logger.error(`error removing file: ${result}`);
      }
    });
  } catch (e) {
    throw new ApiError(httpStatus.BAD_REQUEST, e);
  }
  // res.status(httpStatus.OK).send(TimezoneService.LocalizeObject(result, req.user));
});

const deleteTransaction = catchAsync(async (req, res) => {
  await transactionRepository.deleteTransactionById(req.params.transactionId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createTransaction,
  getTransactions,
  getClientTransactions,
  view,
  getTransaction,
  sendTransactionByInvoice,
  printTransactionByInvoice,
  printTransaction,
  updateTransaction,
  deleteTransaction,
  voidTransaction,
  sendTransaction,
});
