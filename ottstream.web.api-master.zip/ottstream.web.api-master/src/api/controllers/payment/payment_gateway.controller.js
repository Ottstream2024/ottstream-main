const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { paymentGatewayRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const depthExport = require('../../../services/export/depth.export');

const TimezoneService = serviceCollection.getService('timezoneService', true);

const createPaymentGateway = catchAsync(async (req, res) => {
  const paymentGateway = await paymentGatewayRepository.createPaymentGateway(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(paymentGateway, req.user));
});

const getPaymentGateways = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await paymentGatewayRepository.queryPaymentGateways(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getPaymentGateway = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const paymentGateway = await paymentGatewayRepository.getPaymentGatewayById(req.params.paymentGatewayId, options);
  if (!paymentGateway) {
    throw new ApiError(httpStatus.NOT_FOUND, 'PaymentGateway not found');
  }
  res.send(TimezoneService.LocalizeObject(paymentGateway, req.user));
});

const updatePaymentGateway = catchAsync(async (req, res) => {
  const paymentGateway = await paymentGatewayRepository.updatePaymentGatewayById(req.params.paymentGatewayId, req.body);
  res.send(TimezoneService.LocalizeObject(paymentGateway, req.user));
});

const deletePaymentGateway = catchAsync(async (req, res) => {
  await paymentGatewayRepository.deletePaymentGatewayById(req.params.paymentGatewayId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createPaymentGateway,
  getPaymentGateways,
  getPaymentGateway,
  updatePaymentGateway,
  deletePaymentGateway,
});
