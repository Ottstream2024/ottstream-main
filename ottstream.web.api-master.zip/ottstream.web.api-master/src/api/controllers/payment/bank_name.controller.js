const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { bankNameRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createBankName = catchAsync(async (req, res) => {
  // eslint-disable-next-line no-unused-vars
  const bankName = await bankNameRepository.createBankName(req.body, req.user);
  res.status(httpStatus.CREATED).send();
});

const getBankNames = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  filter.provider = req.user.provider.id;
  const result = await bankNameRepository.queryBankNames(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getBankName = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const bankName = await bankNameRepository.getBankNameById(req.params.bankNameId, options);
  if (!bankName) {
    throw new ApiError(httpStatus.NOT_FOUND, 'BankName not found');
  }
  res.send(TimezoneService.LocalizeObject(bankName, req.user));
});

const updateBankName = catchAsync(async (req, res) => {
  const bankName = await bankNameRepository.updateBankNameById(req.params.bankNameId, req.body);
  res.send(TimezoneService.LocalizeObject(bankName, req.user));
});

const deleteBankName = catchAsync(async (req, res) => {
  await bankNameRepository.deleteBankNameById(req.params.bankNameId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createBankName,
  getBankNames,
  getBankName,
  updateBankName,
  deleteBankName,
});
