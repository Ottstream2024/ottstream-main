const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { balanceRepository, ottProviderPaymentMethodRepository } = require('../../../repository');
// const { checKeeperService } = require('../../../services');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const TransactionService = require('../../../services/payment/transaction.service');
const depthExport = require('../../../services/export/depth.export');

const addBalance = catchAsync(async (req, res) => {
  // create transaction

  let transaction;
  // execute
  if (req.body.providerId) {
    transaction = await TransactionService.createAddBalanceTransaction(
      1,
      req.user.provider._id.toString(),
      1,
      req.body.providerId,
      req.body.balance,
      req.user
    );
  } else if (req.body.clientId) {
    transaction = await TransactionService.createAddBalanceTransaction(
      1,
      req.user.provider._id.toString(),
      2,
      req.body.clientId,
      req.body.balance,
      req.user
    );
  }
  let updated;
  if (transaction) updated = await TransactionService.executeTransaction(transaction);
  // const balance = await balanceRepository.createBalance(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(updated, req.user));
});

const pay = catchAsync(async (req, res) => {
  // create transaction
  const { action, paymentMethod, paymentMethodId, amount } = req.body;
  const from = req.user.provider._id.toString();
  const to = req.user.provider.parent;
  let _paymentMethod;
  let executed;
  let _transaction;
  let _createResponse;
  if (action === 1) {
    switch (paymentMethod) {
      case 0:
        _paymentMethod = await ottProviderPaymentMethodRepository.getOttProviderPaymentMethodById(paymentMethodId);
        if (!_paymentMethod) throw new ApiError(400, `Payment method not found ${paymentMethodId}`);
        _createResponse = await TransactionService.createPayBalanceWithCardOrTransferTransaction(
          1,
          from,
          1,
          to,
          amount,
          _paymentMethod.paymentMethod,
          _paymentMethod.paymentMethod === 0 ? _paymentMethod.creditCard : _paymentMethod.bankTransfer,
          _paymentMethod,
          req.user
        );
        if (!_createResponse.status) {
          throw new ApiError(400, _createResponse.messages.toString());
        }
        _transaction = _createResponse.transaction;
        executed = await TransactionService.executeTransaction(_transaction);
        break;
      case 1:
        _createResponse = await TransactionService.createPayBalanceWithCardOrTransferTransaction(
          1,
          from,
          1,
          to,
          amount,
          0,
          req.body.creditCard,
          null,
          req.user
        );
        if (!_createResponse.status) {
          throw new ApiError(400, _createResponse.messages.toString());
        }
        _transaction = _createResponse.transaction;
        executed = await TransactionService.executeTransaction(_transaction);
        break;
      case 2:
        _createResponse = await TransactionService.createPayBalanceWithCardOrTransferTransaction(
          1,
          from,
          1,
          to,
          amount,
          1,
          req.body.creditCard ? req.body.creditCard : req.body.bankTransfer,
          null,
          req.user
        );
        if (!_createResponse.status) {
          throw new ApiError(400, _createResponse.messages.toString());
        }
        _transaction = _createResponse.transaction;
        executed = await TransactionService.executeTransaction(_transaction);
        break;
      case 3:
        _createResponse = await TransactionService.createPayBalanceWithCheckTransaction(
          1,
          from,
          1,
          to,
          amount,
          req.body.checkNumber,
          req.user
        );
        if (!_createResponse.status) {
          throw new ApiError(400, _createResponse.messages.toString());
        }
        _transaction = _createResponse.transaction;
        executed = await TransactionService.executeTransaction(_transaction);
        break;
      default:
        break;
    }
  }
  if (!executed) {
    throw new ApiError(400, `transaction creation failed`);
  }
  if (executed.state === 0) {
    throw new ApiError(400, executed.stateMessage);
  }
  if (executed.state === 1) {
    if (paymentMethod === 1 || paymentMethod === 2) {
      const saveOrNot = paymentMethod === 1 ? req.body.creditCard?.save : req.body.bankTransfer?.save;

      if (saveOrNot) {
        const saveMethod = executed.sourcePay;
        if (saveMethod) {
          const saveObject = {
            providerId: from,
            inUse: true,
          };
          if (paymentMethod === 1) {
            saveObject.paymentMethod = 0;
            saveObject.creditCard = saveMethod;
          }
          if (paymentMethod === 2) {
            saveObject.paymentMethod = 1;
            saveObject.bankTransfer = saveMethod;
          }

          await ottProviderPaymentMethodRepository.createOttProviderPaymentMethod(saveObject);
        }
      }
    } else if (paymentMethod === 3) {
      const sendByMailKeeper = req.body.mailByCheckeeper;
      if (sendByMailKeeper) {
        // await checKeeperService.mailCheck(executed);
      }
    }
  }
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(executed, req.user));
});

const getBalances = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await balanceRepository.queryBalances(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getBalance = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const balance = await balanceRepository.getBalanceById(req.params.balanceId, options);
  if (!balance) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Balance not found');
  }
  res.send(TimezoneService.LocalizeObject(balance, req.user));
});

const updateBalance = catchAsync(async (req, res) => {
  const balance = await balanceRepository.updateBalanceById(req.params.balanceId, req.body);
  res.send(TimezoneService.LocalizeObject(balance, req.user));
});

const deleteBalance = catchAsync(async (req, res) => {
  await balanceRepository.deleteBalanceById(req.params.balanceId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  pay,
  addBalance,
  getBalances,
  getBalance,
  updateBalance,
  deleteBalance,
});
