const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { shippingProviderRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createShippingProvider = catchAsync(async (req, res) => {
  // eslint-disable-next-line no-unused-vars
  const shippingProvider = await shippingProviderRepository.createShippingProvider(req.body, req.user);
  res.status(httpStatus.CREATED).send();
});

const getShippingProviders = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await shippingProviderRepository.queryShippingProvider(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getShippingProvider = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const shippingProvider = await shippingProviderRepository.getShippingProviderById(req.params.shippingProviderId, options);
  if (!shippingProvider) {
    throw new ApiError(httpStatus.NOT_FOUND, 'ShippingProvider not found');
  }
  res.send(TimezoneService.LocalizeObject(shippingProvider, req.user));
});

const updateShippingProvider = catchAsync(async (req, res) => {
  const shippingProvider = await shippingProviderRepository.updateShippingProviderById(
    req.params.shippingProviderId,
    req.body
  );
  res.send(TimezoneService.LocalizeObject(shippingProvider, req.user));
});

const deleteShippingProvider = catchAsync(async (req, res) => {
  await shippingProviderRepository.deleteShippingProviderById(req.params.shippingProviderId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createShippingProvider,
  getShippingProviders,
  getShippingProvider,
  updateShippingProvider,
  deleteShippingProvider,
});
