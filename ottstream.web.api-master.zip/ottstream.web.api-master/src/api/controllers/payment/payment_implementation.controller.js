const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { paymentImplementationRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const { paymentImplementations } = require('../../../config/payment_implementations');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createPaymentImplementation = catchAsync(async (req, res) => {
  const paymentImplementation = await paymentImplementationRepository.createPaymentImplementation(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(paymentImplementation, req.user));
});

const getPaymentImplementations = catchAsync(async (req, res) => {
  res.send(
    TimezoneService.LocalizeObject(
      paymentImplementations.map((r) => r.name),
      req.user
    )
  );
});

const getPaymentImplementation = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const paymentImplementation = await paymentImplementationRepository.getPaymentImplementationById(
    req.params.paymentImplementationId,
    options
  );
  if (!paymentImplementation) {
    throw new ApiError(httpStatus.NOT_FOUND, 'PaymentImplementation not found');
  }
  res.send(TimezoneService.LocalizeObject(paymentImplementation, req.user));
});

const updatePaymentImplementation = catchAsync(async (req, res) => {
  const paymentImplementation = await paymentImplementationRepository.updatePaymentImplementationById(
    req.params.paymentImplementationId,
    req.body
  );
  res.send(TimezoneService.LocalizeObject(paymentImplementation, req.user));
});

const deletePaymentImplementation = catchAsync(async (req, res) => {
  await paymentImplementationRepository.deletePaymentImplementationById(req.params.paymentImplementationId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createPaymentImplementation,
  getPaymentImplementations,
  getPaymentImplementation,
  updatePaymentImplementation,
  deletePaymentImplementation,
});
