const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { paymentMethodRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const depthExport = require('../../../services/export/depth.export');

const TimezoneService = serviceCollection.getService('timezoneService', true);

const createPaymentMethod = catchAsync(async (req, res) => {
  const paymentMethod = await paymentMethodRepository.createPaymentMethod(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(paymentMethod, req.user));
});

const getPaymentMethods = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await paymentMethodRepository.queryPaymentMethods(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getPaymentMethod = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const paymentMethod = await paymentMethodRepository.getPaymentMethodById(req.params.paymentMethodId, options);
  if (!paymentMethod) {
    throw new ApiError(httpStatus.NOT_FOUND, 'PaymentMethod not found');
  }
  res.send(TimezoneService.LocalizeObject(paymentMethod, req.user));
});

const updatePaymentMethod = catchAsync(async (req, res) => {
  const paymentMethod = await paymentMethodRepository.updatePaymentMethodById(req.params.paymentMethodId, req.body);
  res.send(TimezoneService.LocalizeObject(paymentMethod, req.user));
});

const deletePaymentMethod = catchAsync(async (req, res) => {
  await paymentMethodRepository.deletePaymentMethodById(req.params.paymentMethodId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createPaymentMethod,
  getPaymentMethods,
  getPaymentMethod,
  updatePaymentMethod,
  deletePaymentMethod,
});
