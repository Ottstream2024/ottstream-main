/* eslint-disable no-await-in-loop */
const httpStatus = require('http-status');
const queue = require('queue');

const fs = require('fs').promises;
const depthExport = require('../../../services/export/depth.export');

const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const {
  invoiceRepository,
  clientRepository,
  creditRepository,
  clientPaymentMethodRepository,
  ottProviderEmailRepository,
  ottProviderOtherApiRepository,
  ottProviderAddressRepository,
  ottProviderInvoiceRepository,
  ottProviderPaymentGatewayRepository,
  transactionRepository,
  userRepository,
  ottProviderConversationProviderRepository,
} = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const EmailService = require('../../../services/email/EmailService.service');
const InvoiceService = require('../../../services/payment/invoice.service');
const BroadcastService = require('../../../services/socket/broadcastService.service');
const { ottProviderRepository } = require('../../../repository');
const config = require('../../../config');
const logger = require('../../../utils/logger/logger');
const ShippingService = require('../../../services/shiping/shipping.service');
const PostalMethodService = require('../../../services/postal/postal.service');
const StatisticService = require('../../../services/statistics/statistic.service');
const CacheService = require('../../../services/cache/CacheService');
const SubscriptionService = require('../../../services/subscription/subscription.service');
const TwilioService = require('../../../services/sms/twilio.service');

const printQueue = queue({ results: [], autostart: true, timeout: 0, concurrency: 1 });

const smsSendQueue = queue({ results: [], autostart: true, timeout: 0, concurrency: 1 });

// eslint-disable-next-line no-unused-vars
printQueue.on('timeout', async (next, job) => {
  next();
});

// get notified when jobs complete
// eslint-disable-next-line no-unused-vars
printQueue.on('success', async (result, job) => {
  // eslint-disable-next-line no-await-in-loop

  await BroadcastService.broadcastToProvider(result.notifyToProvider, 'invoice-info', {
    status: result.status,
    message: result.message,
  });
});

// eslint-disable-next-line no-unused-vars
smsSendQueue.on('timeout', async (next, job) => {
  next();
});

// get notified when jobs complete
// eslint-disable-next-line no-unused-vars
smsSendQueue.on('success', async (result, job) => {
  // eslint-disable-next-line no-await-in-loop

  let channelName = `invoice-info`;
  if (result.invoiceId) channelName += `-${result.invoiceId}`;
  await BroadcastService.broadcastToUser(result.notifyToUser, channelName, {
    status: result.status,
    message: result.message,
  });
});

const sendInvoiceWorker = async (req, invoiceId) => {
  const link = `${config.getConfig().front_url}/payment/${invoiceId}`;
  const response = { success: true };
  const invoice = await invoiceRepository.getInvoiceById(invoiceId);
  const currentProvider = await ottProviderRepository.getOttProviderById(invoice.provider);
  let hasValidSmsProvider = false;
  const conversationApis = await ottProviderConversationProviderRepository.getOttProviderConversationProviderByProviderId(
    currentProvider.id
  );
  hasValidSmsProvider = conversationApis.length && conversationApis[0].twilio && conversationApis[0].twilio.isValid;
  // eslint-disable-next-line no-unused-vars
  const { type, value } = req.body;
  const sendEmail = type === 'email_phone' || type === 'email';
  const sendPhone = type === 'email_phone' || type === 'phone';
  if (sendPhone && !hasValidSmsProvider) {
    response.message = `no sms probvder is setup`;
    response.noSetup = true;
    return response;
  }
  const func = async (cb) => {
    const sendResponse = { status: true, message: '' };
    try {
      // cb(null, {
      //   notifyToProvider: req.user.provider.id,
      //   notifyToUser: req.user.id,
      //   hasValidSmsProvider,
      //   message: 'twilio connection error',
      //   status: false,
      // });
      if (!invoice) {
        throw new ApiError('invoice not found');
      }
      // eslint-disable-next-line no-unused-vars
      const client = await clientRepository.getClientById(invoice.client);
      let emailSent = false;
      let twilioSent = false;
      // eslint-disable-next-line no-unused-vars
      if (sendEmail && client.emails.filter((r) => r.forContactInvoice).length) {
        const { email } = client.emails.filter((r) => r.forContactInvoice && r.email === value)[0];
        await EmailService.sendCheckEmail(
          email,
          `invoice ${invoice.number} email`,
          `pay by this link ${link}`,
          client.provider.id
        );
        emailSent = true;
      }
      const providerName = client.provider.name[0].name;
      if (sendPhone && client.phones.filter((r) => r.forMessages).length) {
        // eslint-disable-next-line no-unused-vars
        const currentConfigs = conversationApis[0].twilio;
        // eslint-disable-next-line no-undef
        const twilioResponse = await TwilioService.sendSms(
          {
            fromNumber: currentConfigs.fromNumber,
            toNumber: value,
            body: `${providerName}: user this link to complete checkout ${link}`,
          },
          {
            sId: currentConfigs.sId,
            authToken: currentConfigs.authToken,
          },
          {
            provider: currentProvider.id,
            user: req.user.id,
          }
        );
        sendResponse.status = twilioResponse.status;
        sendResponse.message = twilioResponse.message;
        sendResponse.data = twilioResponse.data;
        twilioSent = true;
      }
      if (twilioSent || emailSent) {
        logger.info(`invoice pay credentials set in cache...`);
        await CacheService.setex(`invoice-pay-${invoice.id}`, { expireDate: new Date() }, 10000);
      }

      cb(null, {
        notifyToProvider: req.user.provider.id,
        notifyToUser: req.user.id,
        emailSent,
        hasValidSmsProvider,
        twilioData: sendResponse.data,
        message: hasValidSmsProvider ? 'invoice sms sent' : 'no sms provider setup',
        status: sendResponse.status,
      });
    } catch (ex) {
      logger.error(ex);
      cb(null, {
        notifyToProvider: req.user.provider.id,
        notifyToUser: req.user.id,
        message: ex.message ?? ex,
        status: false,
      });
    }
  };
  if (smsSendQueue.length) {
    logger.warn(`sms sending task is already running`);
    response.message = `sms in sending queue: please wait`;
  } else {
    smsSendQueue.push(func);
    response.message = `invoice have been added to sms queue`;
  }
  return response;
};
const TimezoneService = serviceCollection.getService('timezoneService', true);

const sendCheckoutInvoice = catchAsync(async (req, res) => {
  const { invoiceId } = req.params;
  const invoice = await invoiceRepository.getInvoiceById(invoiceId);
  if (!invoice) throw new ApiError(400, `invoice with id: ${invoiceId} not found`);
  const response = await sendInvoiceWorker(req, invoiceId);
  res.send(TimezoneService.LocalizeObject(response, req.user));
});

const getPayClient = catchAsync(async (req, res) => {
  const { invoiceId } = req.params;
  const cashedKey = `invoice-pay-${invoiceId}`;
  if (!(await CacheService.hasKey(cashedKey))) throw new ApiError(404, `not payment found`);
  const invoice = await invoiceRepository.getInvoiceById(invoiceId);
  if (!invoice) throw new ApiError(400, `invoice with id: ${invoiceId} not found`);
  const response = { invoice };
  if (invoice.state === 1) {
    const invoiceTransactions = await transactionRepository.getTransactionByInvoiceId(invoice.id);
    if (invoiceTransactions.filter((r) => r.source_type === 'PAY_INVOICE').length) {
      const transaction = invoiceTransactions.filter((r) => r.source_type === 'PAY_INVOICE')[0];
      response.transaction = transaction;
    }
  }
  res.send(TimezoneService.LocalizeObject(response, req.user));
});

const createInvoice = catchAsync(async (req, res) => {
  const invoice = await invoiceRepository.createInvoice(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(invoice, req.user));
});

const view = catchAsync(async (req, res) => {
  try {
    const invoice = await invoiceRepository.getInvoiceById(req.params.invoiceId);
    if (!invoice) {
      throw new ApiError(404, 'invoice not found');
    }
    const invoiceType = req.query.type;
    let result = null;
    if (invoiceType === 2) {
      const invoiceTransactions = await transactionRepository.getTransactionByInvoiceId(req.params.invoiceId);
      if (invoiceTransactions.filter((r) => r.source_type === 'PAY_INVOICE').length) {
        const transaction = invoiceTransactions.filter((r) => r.source_type === 'PAY_INVOICE')[0];
        result = await InvoiceService.exportTransaction([transaction._id.toString()], req.query.jpeg, false);
      }
    } else {
      // eslint-disable-next-line no-await-in-loop
      result = await InvoiceService.exportPdfMulti([req.params.invoiceId], req.query.type, req.user, req.query.jpeg);
    }
    if (result) {
      res.sendFile(result, { root: config.getConfig().file.root_path });
      res.on('finish', () => {
        try {
          // eslint-disable-next-line security/detect-non-literal-fs-filename
          // fs.unlinkSync(result);
        } catch (e) {
          logger.error(`error removing file: ${result}`);
        }
      });
    } else {
      throw new ApiError('transaction not found');
    }
  } catch (e) {
    throw new ApiError(httpStatus.BAD_REQUEST, e);
  }
  // res.status(httpStatus.OK).send(TimezoneService.LocalizeObject(result, req.user));
});
const viewCheckPdf = catchAsync(async (req, res) => {
  try {
    const invoice = await invoiceRepository.getInvoiceById(req.params.invoiceId);
    if (!invoice) {
      throw new ApiError(404, 'invoice not found');
    }
    const { checkeeper } = invoice.payloadCalculated;
    if (!checkeeper) throw new ApiError(400, 'invoice has no check');

    const base64String = `${checkeeper.pdf}`;

    const binaryData = Buffer.from(base64String, 'base64');

    const savePath = `${config.getConfig().file.file_storage_path}./${invoice._id.toString()}_checkeeper_index.pdf`;
    const sendFile = savePath;
    // eslint-disable-next-line security/detect-non-literal-fs-filename
    await fs.writeFile(savePath, binaryData);
    // if (req.query.jpeg) {
    //   sendFile = `${config.getConfig().file.file_storage_path}./${invoice._id.toString()}_checkeeper_index.jpg`;
    //   const saved = await pdfToImage(savePath, sendFile);
    // }
    res.sendFile(sendFile, { root: config.getConfig().file.root_path });
  } catch (e) {
    throw new ApiError(httpStatus.BAD_REQUEST, e);
  }
  // res.status(httpStatus.OK).send(TimezoneService.LocalizeObject(result, req.user));
});

const views = catchAsync(async (req, res) => {
  try {
    const invoiceList = req.body.invoices;
    let invoiceUpdates = [];
    if (invoiceList?.length) {
      // eslint-disable-next-line no-restricted-syntax
      for (const invoiceId of invoiceList) {
        // eslint-disable-next-line no-await-in-loop
        // const invoice = await invoiceRepository.getInvoiceById(invoiceId);
        // if (!invoice) {
        //   throw new ApiError(400, 'invoice not found');
        // }
        invoiceUpdates = invoiceUpdates.concat(invoiceId);
      }
      // eslint-disable-next-line no-await-in-loop
      const result = await InvoiceService.exportPdfMulti(invoiceUpdates, 1, req.user);
      res.sendFile(result, { root: config.getConfig().file.root_path });
      res.on('finish', () => {
        try {
          // eslint-disable-next-line security/detect-non-literal-fs-filename
          // fs.unlinkSync(result);
        } catch (e) {
          logger.error(`error removing file: ${result}`);
        }
      });
    }
  } catch (e) {
    throw new ApiError(httpStatus.BAD_REQUEST, e);
  }
});

const prints = catchAsync(async (req, res) => {
  try {
    const invoiceList = req.body.invoices;
    let invoiceUpdates = [];
    if (invoiceList?.length) {
      // eslint-disable-next-line no-restricted-syntax
      for (const invoiceId of invoiceList) {
        // eslint-disable-next-line no-await-in-loop
        // const invoice = await invoiceRepository.getInvoiceById(invoiceId);
        // if (!invoice) {
        //   throw new ApiError(400, 'invoice not found');
        // }
        invoiceUpdates = invoiceUpdates.concat(invoiceId);
      }
      // eslint-disable-next-line no-await-in-loop
      const result = await InvoiceService.exportPdfMulti(invoiceUpdates, 1, req.user);
      // eslint-disable-next-line no-restricted-syntax
      for (const invoiceId of invoiceList) {
        // eslint-disable-next-line no-await-in-loop
        await invoiceRepository.updateInvoiceById(invoiceId, {
          sent: true,
          sentUser: req.user._id.toString(),
          sentType: 'print',
        });
      }
      res.on('finish', () => {
        try {
          // eslint-disable-next-line security/detect-non-literal-fs-filename
          // fs.unlinkSync(result);
        } catch (e) {
          logger.error(`error removing file: ${result}`);
        }
      });
      res.sendFile(result, { root: config.getConfig().file.root_path });
    }
  } catch (e) {
    throw new ApiError(httpStatus.BAD_REQUEST, e);
  }
});
const cancelInvoices = catchAsync(async (req, res) => {
  const response = { success: true };
  const func = async (cb) => {
    try {
      const { invoices } = req.body;
      // eslint-disable-next-line no-restricted-syntax
      for (const invoiceId of invoices) {
        const invoice = await invoiceRepository.getInvoiceById(invoiceId);
        if (invoice.sent) {
          if (invoice.sentType === 'postal') {
            const otherApis = await ottProviderOtherApiRepository.getOttProviderOtherApiByProviderId(invoice.provider);
            if (otherApis.length && otherApis[0].postal?.secretKey) {
              const secretKey = otherApis[0].postal?.secretKey;
              // eslint-disable-next-line no-unused-vars
              const postalResponse = await PostalMethodService.CancelLatter(invoice, secretKey);

              if (postalResponse.status) {
                await invoiceRepository.updateInvoiceById(invoice._id.toString(), {
                  // postalMethodId: postalResponse.response.data.result.id,
                  postalMethodStatus: postalResponse.response.data.result.message,
                  sent: false,
                  sentUser: req.user._id.toString(),
                  sentType: '',
                });
              }
            }
          } else {
            await invoiceRepository.updateInvoiceById(invoice._id.toString(), {
              sent: false,
              sentUser: req.user._id.toString(),
              sentType: '',
            });
          }
        }
      }
      cb(null, { notifyToProvider: req.user.provider.id, message: 'invoices have been canceled', status: true });
    } catch (ex) {
      cb(null, { notifyToProvider: req.user.provider.id, message: ex.message ?? ex, status: false });
    }
  };

  if (printQueue.length) {
    logger.warn(`providers sync task is already running...`);
    response.message = `invoices are beeing printed or canceled, please wait`;
  } else {
    printQueue.push(func);
    response.message = `invoices added in queue to cancel via postal, please wait`;
  }
  res.send(response);

  try {
    // TODO get ott provider postal settings
    // TODO send via postal service
    res.send(response);
  } catch (e) {
    throw new ApiError(httpStatus.BAD_REQUEST, e.message ?? e);
  }
});

const sendInvoices = catchAsync(async (req, res) => {
  const response = { success: true };
  const func = async (cb) => {
    try {
      let status = true;
      let message = 'invoice have been sent';
      const { invoices } = req.body;
      // eslint-disable-next-line no-restricted-syntax
      for (const invoiceId of invoices) {
        const invoice = await invoiceRepository.getInvoiceById(invoiceId);
        const client = await clientRepository.getClientById(invoice.client);
        const provider = await ottProviderRepository.getOttProviderById(client.provider.id);
        const otherApis = await ottProviderOtherApiRepository.getOttProviderOtherApiByProviderId(client.provider.id);
        const ottAddress = await ottProviderAddressRepository.getOttProviderAddressesByProviderId(client.provider.id);
        const invoicePdf = await InvoiceService.exportPdfMulti([invoiceId], 3, req.user);
        if (otherApis.length && otherApis[0].postal?.secretKey) {
          const invoiceSettings = await ottProviderInvoiceRepository.getOttProviderInvoiceByProviderId(client.provider.id);
          const secretKey = otherApis[0].postal?.secretKey;
          // eslint-disable-next-line no-unused-vars
          const postalResponse = await PostalMethodService.SendLatterWithAddress(
            client,
            { providerInfo: provider, addressInfo: ottAddress.length ? ottAddress[0] : {} },
            {
              invoice,
              filePath: `${config.getConfig().file.root_path}${invoicePdf}`,
              invoiceSettings: invoiceSettings.length ? invoiceSettings[0].settings : null,
            },
            secretKey
          );

          if (postalResponse.status) {
            await invoiceRepository.updateInvoiceById(invoice._id.toString(), {
              postalMethodId: postalResponse.response.data.result.id,
              postalMethodStatus: postalResponse.response.data.result.status,
              sent: true,
              sentUser: req.user._id.toString(),
              sentType: 'postal',
            });
          } else {
            status = false;
            message = postalResponse.message;
          }
        } else {
          status = false;
          message = 'Provider has no Postal Key Setup';
        }
      }
      cb(null, { notifyToProvider: req.user.provider.id, message, status });
    } catch (ex) {
      cb(null, { notifyToProvider: req.user.provider.id, message: ex.message ?? ex, status: false });
    }
  };

  if (printQueue.length) {
    logger.warn(`providers sync task is already running...`);
    response.message = `invoices are beeing printed, please wait`;
  } else {
    printQueue.push(func);
    response.message = `invoices added in queue to send via postal, please wait`;
  }
  res.send(response);
});

const payInvoice = catchAsync(async (req, res) => {
  const response = {
    message: '',
    status: true,
    transaction: null,
    invoice: null,
  };
  let invoice = await invoiceRepository.getInvoiceById(req.params.invoiceId);
  let _invoicePayResponse;
  if (!invoice) throw new ApiError(400, 'invoice not found');
  // path with balance
  if (req.body.balance) {
    const client = await clientRepository.getClientById(invoice.client);
    const clientCredit = await creditRepository.getCreditByClientId(invoice.client);
    const payResponse = await InvoiceService.payInvoiceWithBalance(req.body.balance.amount, invoice, req.user);
    invoice = payResponse.invoice;
    response.transaction = payResponse.transaction;
    // response.status = false;
    // response.error = 'asdasd 321';
    // throw ApiError(400, response);
    // return;

    // balanceCredit history
    if (invoice.generateDisplayInfo) {
      invoice.generateDisplayInfo.balanceCreditHistory = {
        initialState: client.balance ? client.balance : null,
        payed: invoice.payed,
        afterConfirmState: client?.balance - invoice.payed,
        credit: clientCredit && clientCredit.length ? clientCredit : null,
        newCredit:
          clientCredit && clientCredit.filter((r) => r.inCheckout).length
            ? clientCredit.filter((r) => r.inCheckout)[0]
            : null,
      };
    }
  }
  if (req.body.defaultMethod && invoice.state === 2) {
    const methods = await clientPaymentMethodRepository.getClientPaymentMethods(invoice.client);
    const defaultInuse = methods.filter((r) => r.default && r.inUse);
    if (defaultInuse.length) {
      const currentMethod = defaultInuse[0];
      if (currentMethod.paymentMethod === 0) {
        _invoicePayResponse = await InvoiceService.payInvoiceWithCreditCard(
          req.body.defaultMethod.amount,
          currentMethod.id,
          currentMethod,
          invoice,
          req.user
        );
        if (!_invoicePayResponse.status) throw new ApiError(400, _invoicePayResponse.messages.toString());
        invoice = _invoicePayResponse.invoice;
        response.transaction = _invoicePayResponse.transaction;
      }
    }
  }
  if (req.body.savedCard && invoice.state === 2) {
    const methods = await clientPaymentMethodRepository.getClientPaymentMethods(invoice.client);
    const defaultInuse = methods.filter((r) => r._id.toString() === req.body.savedCard);
    if (defaultInuse.length) {
      const currentMethod = defaultInuse[0];
      if (currentMethod.paymentMethod === 0) {
        _invoicePayResponse = await InvoiceService.payInvoiceWithCreditCard(
          req.body.savedCard.amount,
          currentMethod.id,
          currentMethod,
          invoice,
          req.user
        );
        if (!_invoicePayResponse.status) throw new ApiError(400, _invoicePayResponse.messages.toString());
        invoice = _invoicePayResponse.invoice;
        response.transaction = _invoicePayResponse.transaction;
      }
    }
  }
  if (req.body.creditCard) {
    const card = req.body.creditCard;
    _invoicePayResponse = await InvoiceService.payInvoiceWithCreditCard(null, null, card, invoice, req.user);
    if (!_invoicePayResponse.status) throw new ApiError(400, _invoicePayResponse.messages.toString());
    invoice = _invoicePayResponse.invoice;
    response.transaction = _invoicePayResponse.transaction;
  }
  if (req.body.bankTransfer) {
    const card = req.body.creditCard;
    _invoicePayResponse = await InvoiceService.payInvoiceWithCreditCard(null, null, card, invoice, req.user);
    if (!_invoicePayResponse.status) throw new ApiError(400, _invoicePayResponse.messages.toString());
    invoice = _invoicePayResponse.invoice;
    response.transaction = _invoicePayResponse.transaction;
  }
  if (req.body.checkNumber) {
    const check = req.body.checkNumber;
    _invoicePayResponse = await InvoiceService.payInvoiceWithCheck(null, check, invoice, req.user);
    if (!_invoicePayResponse.status) throw new ApiError(400, _invoicePayResponse.messages.toString());
    invoice = _invoicePayResponse.invoice;
    response.transaction = _invoicePayResponse.transaction;
  }
  if (req.body.moneyOrderNumber) {
    const { moneyOrderNumber, bankName } = req.body;
    _invoicePayResponse = await InvoiceService.payInvoiceWithMoneyOrder(null, moneyOrderNumber, bankName, invoice, req.user);
    if (!_invoicePayResponse.status) throw new ApiError(400, _invoicePayResponse.messages.toString());
    invoice = _invoicePayResponse.invoice;
    response.transaction = _invoicePayResponse.transaction;
  }
  if (req.body.cash) {
    _invoicePayResponse = await InvoiceService.payInvoiceWithCash(null, invoice, req.user);
    if (!_invoicePayResponse.status) throw new ApiError(400, _invoicePayResponse.messages.toString());
    invoice = _invoicePayResponse.invoice;
    response.transaction = _invoicePayResponse.transaction;
  }
  if (invoice && invoice.state === 1) {
    const executeStatus = await InvoiceService.executeInvoice(invoice, req.user); // TODO handle exceptions here
    response.invoice = executeStatus.invoice;
    response.status = executeStatus.status;
    response.message = executeStatus.message;
  }

  // if (req.body.paymentMethod === 'check' && invoice.payloadCalculated.refund) {
  // }
  response.invoice = invoice;
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(response, req.user));
});

const payClientInvoice = catchAsync(async (req, res) => {
  const response = {
    message: '',
    status: true,
    transaction: null,
    invoice: null,
  };
  const { invoiceId } = req.params;
  const cashedKey = `invoice-pay-${invoiceId}`;
  if (!(await CacheService.hasKey(cashedKey))) throw new ApiError(404, `not payment found`);
  const { creditCard } = req.body;
  let invoice = await invoiceRepository.getInvoiceById(invoiceId);
  if (!invoice) throw new ApiError(400, 'invoice not found');
  const invoiceUser = await userRepository.getUserById(invoice.user);
  const client = await clientRepository.getClientById(invoice.client);
  const address = client.addresses[0];
  creditCard.anExistingAddress = true;
  creditCard.existingAddress = address.id;
  const _invoicePayResponse = await InvoiceService.payInvoiceWithCreditCard(null, null, creditCard, invoice, invoiceUser);
  if (!_invoicePayResponse.status) throw new ApiError(400, _invoicePayResponse.messages.toString());
  invoice = _invoicePayResponse.invoice;
  response.transaction = _invoicePayResponse.transaction;
  if (invoice && invoice.state === 1) {
    const executeStatus = await InvoiceService.executeInvoice(invoice, invoiceUser); // TODO handle exceptions here
    response.invoice = executeStatus.invoice;
    response.status = executeStatus.status;
    response.message = executeStatus.message;
  }

  // if (req.body.paymentMethod === 'check' && invoice.payloadCalculated.refund) {
  // }
  response.invoice = invoice;
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(response, req.user));
});

const payClientUpdated = catchAsync(async (req, res) => {
  const { invoiceId } = req.params;
  let { day, month } = req.body;
  if (!day) day = 0;
  if (!month) month = 0;
  const cashedKey = `invoice-pay-${invoiceId}`;
  if (!(await CacheService.hasKey(cashedKey))) throw new ApiError(404, `not payment found`);
  const invoice = await invoiceRepository.getInvoiceById(invoiceId);
  if (!invoice) throw new ApiError(400, `invoice not found with id: ${invoiceId}`);
  const payload = invoice.payloadCalculated;
  const payload12Month = { ...payload };
  payload12Month.locations.forEach((item) => {
    if (item.month || item.day) {
      // eslint-disable-next-line no-param-reassign
      item.month = month;
      // eslint-disable-next-line no-param-reassign
      item.day = day;
    }
  });
  const provider = await ottProviderRepository.getOttProviderById(invoice.provider);
  const calculatedPayload = await SubscriptionService.calculateSubscription(false, payload12Month, provider);

  const paymentGateways = await ottProviderPaymentGatewayRepository.getOttProviderPaymentGatewayByProviderId(
    invoice.provider.toString()
  );
  let bankFeePercent = 0;
  let bankFeeFixed = 0;
  if (paymentGateways.length && paymentGateways[0].cardsFee && paymentGateways[0].cardsFee.percent) {
    bankFeePercent = paymentGateways[0].cardsFee.percent;
  }
  if (paymentGateways.length && paymentGateways[0].cardsFee && paymentGateways[0].cardsFee.fixed) {
    bankFeeFixed = paymentGateways[0].cardsFee.fixed;
  }
  const { price } = calculatedPayload;
  let { totalPrice } = calculatedPayload;
  let bankFee = 0;
  if (bankFeePercent) {
    bankFee = (price * bankFeePercent) / 100;
    bankFee += bankFeeFixed;
  }
  totalPrice = price + bankFee;
  calculatedPayload.totalPrice = totalPrice;
  calculatedPayload.bankFee = bankFee;
  res.send(TimezoneService.LocalizeObject(calculatedPayload, req.user));
});

const updatePaymentData = catchAsync(async (req, res) => {
  const invoiceId = req.params.invoice;
  if (req.body.shipping) {
    const prepareShippingDataWithRates = await ShippingService.prepareShippingDataWithRates(
      req.body.shipping,
      req.user.provider.id
    );
    const { createShippingData } = prepareShippingDataWithRates;
    const invoice = await invoiceRepository.getInvoiceById(invoiceId);
    if (!invoice) throw new ApiError(400, 'invoice not found');
    if (invoice.state !== 2) {
      // throw new ApiError(400, 'invoice state is not pending, cant update payload data');
      res.send(TimezoneService.LocalizeObject({ invoice }, req.user));
      return;
    }
    const updateBody = {
      totalShipping: createShippingData.totalShipping,
      isShipping: true,
      totalAmount: Math.abs(invoice.amount + createShippingData.totalShipping),
    };
    createShippingData.shipTo = createShippingData.shipTo.toJSON();
    // createShippingData.pack
    createShippingData.shipTo.email = await clientRepository.getClientEmailById(invoice.client);
    createShippingData.shipFrom = createShippingData.shipFrom.toJSON();
    const ottEmails = await ottProviderEmailRepository.getOttProviderEmails(invoice.provider);
    const providerEmailModel = ottEmails.filter((r) => r.isMain)[0];
    createShippingData.shipFrom.email = providerEmailModel?.address;

    if (!createShippingData.shipTo.email) throw new ApiError(400, 'Client Email required for shipping');
    if (!createShippingData.shipFrom.email) throw new ApiError(400, 'OttProvider Email required for shipping');

    // TODO test total amounts
    const body = {
      ...updateBody,
      payloadCalculated: {
        ...invoice.payloadCalculated,
        shippingData: createShippingData,
        totalShipping: createShippingData.totalShipping,
        totalPrice: Math.abs(invoice.payloadCalculated.totalPrice + createShippingData.totalShipping),
      },
    };
    const updatedInvoice = await invoiceRepository.updateInvoiceById(invoiceId, body);
    res.send(TimezoneService.LocalizeObject({ invoice: updatedInvoice }, req.user));
  } else if (req.body.paymentMethod) {
    const invoice = await invoiceRepository.getInvoiceById(invoiceId);
    const paymentGateways = await ottProviderPaymentGatewayRepository.getOttProviderPaymentGatewayByProviderId(
      invoice.provider.toString()
    );
    let bankFeePercent = 0;
    let bankFeeFixed = 0;
    if (paymentGateways.length && paymentGateways[0].cardsFee && paymentGateways[0].cardsFee.percent) {
      bankFeePercent = paymentGateways[0].cardsFee.percent;
    }
    if (paymentGateways.length && paymentGateways[0].cardsFee && paymentGateways[0].cardsFee.fixed) {
      bankFeeFixed = paymentGateways[0].cardsFee.fixed;
    }
    const { price, totalShipping } = invoice.payloadCalculated;
    let withoutFee = price;
    if (totalShipping) withoutFee += totalShipping;
    let { totalPrice } = invoice.payloadCalculated;
    let bankFee = 0;
    if ((req.body.paymentMethod === 'saved' || req.body.paymentMethod === 'card') && bankFeePercent) {
      bankFee = (withoutFee * bankFeePercent) / 100;
      bankFee += bankFeeFixed;
    }
    totalPrice = withoutFee + bankFee;
    // TODO test total amounts
    const body = {
      // invoice.payloadCalculated.totalPrice += bankFee;
      // invoice.payloadCalculated.bankFee = invoice.payloadCalculated.totalPrice * 0.035.toFixed(2);
      payloadCalculated: {
        ...invoice.payloadCalculated,
      },
    };
    body.payloadCalculated.totalPrice = totalPrice;
    body.payloadCalculated.bankFee = bankFee;
    body.totalAmount = totalPrice;
    // if (req.body.paymentMethod === 'check') {
    // const isRefund = invoice?.payloadCalculated?.refund;
    // if (isRefund) {
    //   if (!invoice.payloadCalculated.checkeeper || !invoice.payloadCalculated.checkeeper?.status) {
    //     const clientId = invoice.to_client ?? invoice.from_client;
    //     if (clientId) {
    //       await BroadcastService.broadcastToUser(req.user.id, 'payinvoice-info', {
    //         message: 'Checkeeper is generating please wait.',
    //         status: true,
    //       });
    //       const client = await clientRepository.getClientById(clientId);
    //       const clientProviderOtherGatewayApis = await ottProviderOtherApiRepository.getOttProviderOtherApiByProviderId(
    //         client.provider.id
    //       );
    //       if (clientProviderOtherGatewayApis.length && clientProviderOtherGatewayApis[0].checkeeper?.isValid) {
    //         const { apiToken, secret } = clientProviderOtherGatewayApis[0].checkeeper;
    //         const checkResult = await CheckeeperService.createCheck({}, apiToken, secret);
    //         if (!checkResult.status) {
    //           await BroadcastService.broadcastToUser(req.user.id, 'payinvoice-info', {
    //             message: 'check generation error, try again pls.',
    //             status: false,
    //           });
    //           throw new ApiError('Checkeeper check creation error');
    //         } else {
    //           body.payloadCalculated.checkeeper = checkResult;
    //         }
    //       }
    //     }
    //   }
    // }
    // }
    const updatedInvoice = await invoiceRepository.updateInvoiceById(invoiceId, body);
    res.send(TimezoneService.LocalizeObject({ invoice: updatedInvoice }, req.user));
  }
});

const getInvoices = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user', 'sent', 'client']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await invoiceRepository.queryInvoices(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getBillInvoices = catchAsync(async (req, res) => {
  const filter = pick(req.body, [
    'name',
    'role',
    'user',
    'search',
    'searchLogin',
    'searchCardNumber',
    'subscriptionAmountFrom',
    'subscriptionAmountTo',
    'totalAmountFrom',
    'totalAmountTo',
    'dateForPayStart',
    'dateForPayEnd',
    'dateForPaymentStart',
    'dateForPaymentEnd',
    'dateForBillSentStart',
    'dateForBillSentEnd',
    'paymentStatus',
    'paymentActonBy',
    'paymentMethod',
    'excel',
    'resellerClients',
    'providerId',
    'sent',
    'client',
    'type',
    'billSentMethod',
  ]);
  const ownProviderId = req.user.provider._id.toString();
  const options = pick(req.body, ['sortBy', 'limit', 'page', 'all', 'lang']);
  filter.providers = [];
  if (filter.resellerClients) {
    if (!filter.providerId) {
      const providers = await ottProviderRepository.getOttChilds([ownProviderId]);
      filter.providers = filter.providers.concat(providers.map((r) => r._id.toString()));
    }
  }

  if (filter.providerId) {
    filter.providers.push(filter.providerId);
  }
  if (!filter.providers.length) {
    filter.providers.push(ownProviderId);
  }
  if (!filter.type) filter.type = 2;
  // filter.provider = req.user.provider._id.toString();
  const { sent, inQueue, totalSum, invoiceResults } = await invoiceRepository.queryBillInvoicesV2(filter, options, req.user);
  invoiceResults.sent = sent;
  invoiceResults.inQueue = inQueue;
  invoiceResults.totalSum = totalSum;
  invoiceResults.postalInoviceNextSchedule = null;

  if (filter.providers.length === 1) {
    const { postalData, statisticData } = await StatisticService.getPostalScheduleInfo(filter.providers[0].toString());
    const providers = await ottProviderRepository.getList({ _id: filter.providers[0] }, []);
    const { hasValidPostalMethods } = providers[0];
    if (hasValidPostalMethods) {
      if (statisticData && typeof statisticData.postalInoviceNextSchedule !== 'undefined') {
        invoiceResults.postalInoviceNextSchedule = statisticData.postalInoviceNextSchedule;
      }
      if (postalData && typeof postalData.balance !== 'undefined') {
        invoiceResults.postalMethodsBalance = postalData.balance;
      }
    }
  }
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportClientBillList(
      invoiceResults.results,
      req.user,
      'clientBillsSettings',
      'clientBillsTable'
    );
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  res.send(TimezoneService.LocalizeObject(invoiceResults, req.user));
});

const getInvoice = catchAsync(async (req, res) => {
  const invoice = await invoiceRepository.getInvoiceById(req.params.invoiceId);
  if (!invoice) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Invoice not found');
  }
  res.send(TimezoneService.LocalizeObject(invoice, req.user));
});

const clientOrderAction = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user', 'search']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const invoice = await invoiceRepository.getInvoiceByClientId(req.params.clientId, options, filter);
  res.send(TimezoneService.LocalizeObject(invoice, req.user));
});

const updateInvoice = catchAsync(async (req, res) => {
  const invoice = await invoiceRepository.updateInvoiceById(req.params.invoiceId, req.body);
  res.send(TimezoneService.LocalizeObject(invoice, req.user));
});

const deleteInvoice = catchAsync(async (req, res) => {
  await invoiceRepository.deleteInvoiceById(req.params.invoiceId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  payInvoice,
  createInvoice,
  updatePaymentData,
  getInvoices,
  getInvoice,
  getPayClient,
  getBillInvoices,
  payClientInvoice,
  updateInvoice,
  deleteInvoice,
  payClientUpdated,
  view,
  views,
  viewCheckPdf,
  prints,
  clientOrderAction,
  sendCheckoutInvoice,
  sendInvoices,
  cancelInvoices,
});
