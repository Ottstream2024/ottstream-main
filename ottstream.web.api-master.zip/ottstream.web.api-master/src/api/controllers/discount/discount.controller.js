const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { discountRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const { priceGroupRepository, packageRepository } = require('../../../repository');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createDiscount = catchAsync(async (req, res) => {
  const item = await discountRepository.createDiscount(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(item, req.user));
});

const getDiscounts = catchAsync(async (req, res) => {
  const filter = req.body;
  const options = pick(req.body, ['sortBy', 'limit', 'page', 'all']);
  const result = await discountRepository.queryDiscounts(filter, options, req.user);

  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const pnLists = new Map();
    const pgList = new Map();
    let pkgNames = '';
    let prcGroups = '';
    // eslint-disable-next-line no-restricted-syntax
    for (const row of result.results) {
      pkgNames = '';
      prcGroups = '';
      // eslint-disable-next-line no-restricted-syntax
      for (const pgr of row.priceGroups) {
        if (pgr?.item) {
          // eslint-disable-next-line no-await-in-loop
          const pg = await priceGroupRepository.getPriceGroupById(pgr?.item);
          const pgName = pg.name.filter((i) => i.lang === 'en')[0];
          prcGroups += `${pgName.name}, `;
        } else {
          prcGroups += 'Default';
        }
      }
      // eslint-disable-next-line no-restricted-syntax
      for (const pid of row.packages) {
        // eslint-disable-next-line no-await-in-loop
        const pnList = await packageRepository.getPackageById(pid);
        const nm = pnList && pnList.name ? pnList.name.filter((i) => i.lang === 'en')[0] : null;
        if (row.packages.length - 1 === row.packages.indexOf(pid)) {
          pkgNames += `${nm?.name}`;
        } else {
          pkgNames += `${nm?.name}, `;
        }
      }
      pgList.set(row.generalInfo._id, prcGroups);
      pnLists.set(row.generalInfo._id, pkgNames);
    }
    const report = excelService.exportDiscountList(
      result.results,
      pnLists,
      pgList,
      req.user,
      'discountSettings',
      'discountTable'
    );
    res.setHeader('content-disposition', 'attachment; filename=discounts.xlsx');
    return res.send(report);
  }
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getUserDiscount = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role']);
  filter.author = req.user._id;
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await discountRepository.queryDiscounts(filter, {}, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getDiscountsByFilter = catchAsync(async (req, res) => {
  const result = await discountRepository.getDiscountsByFilter(req.body);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getDiscount = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const item = await discountRepository.getDiscountById(req.params.discountId, options);
  if (!item) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Discount not found');
  }
  res.send(TimezoneService.LocalizeObject(item, req.user));
});

const updateDiscount = catchAsync(async (req, res) => {
  const item = await discountRepository.updateDiscountById(req.params.discountId, req.body);
  res.send(TimezoneService.LocalizeObject(item, req.user));
});

const deleteDiscount = catchAsync(async (req, res) => {
  await discountRepository.deleteDiscountById(req.body);
  res.status(httpStatus.NO_CONTENT).send();
});

const sendNotificationAction = catchAsync(async (req, res) => {
  const item = await discountRepository.discountSendNotificationAction(req.body);
  // await EmailService.sendNotification(item, item.name, item.defaultSalePercent, item.dateStart, item.dateEnd);
  res.send(TimezoneService.LocalizeObject(item, req.user));
});

const discountActions = catchAsync(async (req, res) => {
  const item = await discountRepository.discountActions(req.body);
  res.send(TimezoneService.LocalizeObject(item, req.user));
});

const discountPriceGroupSettings = catchAsync(async (req, res) => {
  const item = await discountRepository.getDiscountPriceGroupList(req.params.startDate, req.params.endDate);
  res.send(TimezoneService.LocalizeObject(item, req.user));
});

module.exports = depthExport({
  createDiscount,
  getDiscounts,
  getDiscountsByFilter,
  getDiscount,
  getUserDiscount,
  updateDiscount,
  deleteDiscount,
  sendNotificationAction,
  discountActions,
  discountPriceGroupSettings,
});
