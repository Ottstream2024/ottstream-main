const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const {
  channelRepository,
  fileRepository,
  packageRepository,
  groupRepository,
  packageChannelRepository,
} = require('../../../repository');
const PackageSyncService = require('../../../services/sync/package/package_sync.service');
const depthExport = require('../../../services/export/depth.export');

const createChannel = catchAsync(async (req, res) => {
  const channel = await channelRepository.createChannel(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(channel, req.user));
});

const getChannels = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await channelRepository.queryChannels(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const syncChannelsActions = catchAsync(async (req, res) => {
  // TODO refactor smarter sync than delete add
  await PackageSyncService.syncIcons();
  await PackageSyncService.syncChannels();
  await PackageSyncService.syncPackages();
  await PackageSyncService.syncGroups();
  await PackageSyncService.syncOptions();
  res.send(TimezoneService.LocalizeObject({ success: true }, req.user));
});

const getPackageChannels = catchAsync(async (req, res) => {
  const _package = await packageRepository.getPackageById(req.params.packageId);
  if (!_package) throw new ApiError('package not found');

  const packageChannels = await packageChannelRepository.getPackageChannelsByPackageMiddlewareId(_package.middlewareId);

  const groups = await groupRepository.queryGroups({}, { limit: 1000 });
  const finalObject = {};
  // eslint-disable-next-line no-restricted-syntax
  for (const packageChannel of packageChannels) {
    if (typeof finalObject[packageChannel.channel.group_id] === 'undefined') {
      finalObject[packageChannel.channel.group_id] = {};
      finalObject[packageChannel.channel.group_id].channels = [];
      finalObject[packageChannel.channel.group_id].group = {
        group_id: packageChannel.channel.group_id,
      };
    }
    packageChannel.channel.icon_full_path = `https://iptv.ottstream.live/img/icons/52x39/${packageChannel.channel.icon_path}.gif`;
    finalObject[packageChannel.channel.group_id].channels.push(packageChannel.channel);
  }
  // eslint-disable-next-line no-restricted-syntax
  for (const group of groups.results) {
    if (typeof finalObject[group.middlewareId] !== 'undefined') {
      finalObject[group.middlewareId].group.name = group.name;
    }
  }
  const final = [];
  // eslint-disable-next-line guard-for-in,no-restricted-syntax
  for (const it in finalObject) {
    final.push(finalObject[it]);
  }
  res.send(
    TimezoneService.LocalizeObject(
      {
        page: 1,
        limit: 10000,
        results: final,
        totalPages: 1,
        totalResults: packageChannels.length,
      },
      req.user
    )
  );
});

const getChannel = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await channelRepository.getChannelById(req.params.channelId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Channel not found');
  }
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const getChannelIcon = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const filePath = await fileRepository.getChannelIcon(req.params, options);
  if (!filePath) {
    throw new ApiError(httpStatus.NOT_FOUND, 'File not found');
  }
  res.sendFile(filePath);
});

const updateChannel = catchAsync(async (req, res) => {
  const channel = await channelRepository.updateChannelById(req.params.channelId, req.body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updateChannelOrder = catchAsync(async (req, res) => {
  const channel = await channelRepository.updateChannelOrder(req.params.channelId, req.body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const deleteChannel = catchAsync(async (req, res) => {
  await channelRepository.deleteChannelById(req.params.channelId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  getPackageChannels,
  syncChannelsActions,
  createChannel,
  getChannels,
  getChannel,
  getChannelIcon,
  updateChannel,
  updateChannelOrder,
  deleteChannel,
});
