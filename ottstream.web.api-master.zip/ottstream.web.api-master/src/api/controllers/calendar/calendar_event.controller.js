/* eslint-disable no-unused-vars */
/* eslint-disable no-undef */
const httpStatus = require('http-status');
const moment = require('moment-timezone');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { calendarEventRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const BroadcastService = require('../../../services/socket/broadcastService.service');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createCalendarEvent = catchAsync(async (req, res) => {
  const { startDate, endDate } = req.body;
  const filter = {};
  // eslint-disable-next-line no-restricted-syntax
  for (const date of [
    { name: 'startDate', value: startDate },
    { name: 'endDate', value: endDate },
  ]) {
    const splited = date.value.split(' ');
    const day = splited[0];
    const time = splited[1];
    const timeHour = time.split(':')[0];
    const timeMinute = time.split(':')[1];
    // Input timezone string
    const timezoneString = req.user.provider.timezone;

    // Get the current offset in minutes
    const offsetInMinutes = moment.tz(timezoneString).utcOffset();

    // Convert offset to hours and minutes
    const offsetHours = Math.floor(offsetInMinutes / 60);
    filter[date.name] = new Date(day);
    filter[date.name] = new Date(filter[date.name].setHours(timeHour, timeMinute, 0));

    // Get the time zone offset in minutes
    const timeZoneOffsetInMinutes = moment(filter[date.name]).utcOffset();

    // Convert the offset to hours
    const timeZoneOffsetInHours = timeZoneOffsetInMinutes / 60;

    // Add the offset hours to the date
    filter[date.name].setHours(filter[date.name].getHours() + timeZoneOffsetInHours - offsetHours);
  }
  const body = { ...req.body };
  body.startDate = filter.startDate;
  body.endDate = filter.endDate;
  const channel = await calendarEventRepository.createCalendarEvent(body, req.user);
  const { calendarEvent } = channel;

  // if (calendarEvent) {
  //   await BroadcastService.broadcastToAppointment({
  //     body: {
  //       ...channel,
  //       createAppointment: true,
  //     },
  //   });
  // }
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(calendarEvent, req.user));
});

const getCalendarEvents = catchAsync(async (req, res) => {
  const filter = pick(req.query, [
    'name',
    'search',
    'startDate',
    'endDate',
    'eventType',
    'type',
    'excel',
    'state',
    'paymentType',
    'equipmentInstaller',
  ]);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  filter.provider = req.user.provider._id.toString();
  if (filter.eventType) {
    filter.title = filter.eventType;
    delete filter.eventType;
  }
  const result = await calendarEventRepository.queryCalendarEvents(filter, options, req.user);
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportCalendarEventTable(
      result.results,
      req.user,
      'calendarEventSettings',
      'calendarEventTable'
    );
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  res.send(TimezoneService.LocalizeObject(result, req.user, {}, 'DD-MM-YYYY hh:mm a'));
});

const getCalendarEvent = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await calendarEventRepository.getCalendarEventById(req.params.calendarEventId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'CalendarEvent not found');
  }
  channel.refund = channel.price;
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const createComment = catchAsync(async (req, res) => {
  const { comment, isCancel } = req.body;
  const user = req.user.id;
  const event = await calendarEventRepository.getCalendarEventById(req.params.calendarEventId);
  if (!event) throw new ApiError(400, `calendar event with id: ${event.id} not found`);
  const { comments } = event;
  const coms = comments.map((r) => r.toJSON());
  coms.push({ comment, user, userName: `${req.user.firstname} ${req.user.lastname}`, isCancel });
  const updated = await calendarEventRepository.updateCalendarEventById({ _id: event.id }, { comments: coms });
  res.send(TimezoneService.LocalizeObject(updated, req.user));
});

const updateComment = catchAsync(async (req, res) => {
  const { comment, id } = req.body;
  const user = req.user.id;
  const event = await calendarEventRepository.getCalendarEventById(req.params.calendarEventId);
  if (!event) throw new ApiError(400, `calendar event with id: ${event.id} not found`);
  const { comments } = event;
  const coms = comments.map((r) => r.toJSON());
  // eslint-disable-next-line no-restricted-syntax
  for (const currentComment of coms) {
    if (currentComment.id === id && currentComment.user.toString() === user) {
      currentComment.comment = comment;
    }
  }
  const updated = await calendarEventRepository.updateCalendarEventById({ _id: event.id }, { comments: coms });
  res.send(TimezoneService.LocalizeObject(updated, req.user));
});

const updateCalendarEvent = catchAsync(async (req, res) => {
  const { startDate, endDate, paymentType } = req.body;
  const filter = {};
  const body = { ...req.body };
  if (startDate && endDate) {
    // eslint-disable-next-line no-restricted-syntax
    for (const date of [
      { name: 'startDate', value: startDate },
      { name: 'endDate', value: endDate },
    ]) {
      const splited = date.value.split(' ');
      const day = splited[0];
      const time = splited[1];
      const timeHour = time.split(':')[0];
      const timeMinute = time.split(':')[1];
      // Input timezone string
      const timezoneString = req.user.provider.timezone;

      // Get the current offset in minutes
      const offsetInMinutes = moment.tz(timezoneString).utcOffset();

      // Convert offset to hours and minutes
      const offsetHours = Math.floor(offsetInMinutes / 60);
      filter[date.name] = new Date(day);
      filter[date.name] = new Date(filter[date.name].setHours(timeHour, timeMinute, 0));

      // Get the time zone offset in minutes
      const timeZoneOffsetInMinutes = moment(filter[date.name]).utcOffset();

      // Convert the offset to hours
      const timeZoneOffsetInHours = timeZoneOffsetInMinutes / 60;

      // Add the offset hours to the date
      filter[date.name].setHours(filter[date.name].getHours() + timeZoneOffsetInHours - offsetHours);
    }
    body.startDate = filter.startDate;
    body.endDate = filter.endDate;
  }
  if (paymentType && paymentType === 'free') {
    body.paymentPrice = null;
    body.paymentPaid = 0;
  }
  const channel = await calendarEventRepository.updateCalendarEventById(req.params.calendarEventId, body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const calendarEventEnableDisableAction = catchAsync(async (req, res) => {
  const item = await calendarEventRepository.calendarEventsActionById(req.body);
  res.send(TimezoneService.LocalizeObject(item, req.user));
});

const deleteCalendarEvent = catchAsync(async (req, res) => {
  await calendarEventRepository.deleteCalendarEventById(req.params.calendarEventId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createCalendarEvent,
  getCalendarEvents,
  getCalendarEvent,
  updateCalendarEvent,
  deleteCalendarEvent,
  calendarEventEnableDisableAction,
  createComment,
  updateComment,
});
