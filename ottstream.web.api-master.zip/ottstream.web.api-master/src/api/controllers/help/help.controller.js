const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { helpRepository } = require('../../../repository');
// const helpTypes = require('../../../config/help_types');
const serviceCollection = require('../../../services/service_collection');
const logger = require('../../../utils/logger/logger');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createHelp = catchAsync(async (req, res) => {
  try {
    const { body } = req;
    body.providerId = req.user.provider.id;
    body.user = req.user.id;
    const channel = await helpRepository.createHelp(body, req.user);
    res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(channel, req.user));
  } catch (ex) {
    logger.error(ex);
  }
});

const getHelps = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['excel', 'parent', 'type']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const queryFilter = {};
  if (filter.type) {
    if (['provider'].includes(filter.type)) {
      queryFilter.$or = [
        {
          type: filter.type,
        },
        {
          type: 'provider_cashier',
        },
      ];
    } else if (['cashier'].includes(filter.type)) {
      queryFilter.$or = [
        {
          type: filter.type,
        },
        {
          type: 'provider_cashier',
        },
      ];
    } else if (['provider_cashier'].includes(filter.type)) {
      queryFilter.$or = [
        {
          type: filter.type,
        },
        {
          type: 'provider',
        },
        {
          type: 'cashier',
        },
      ];
    } else queryFilter.type = filter.type;
  }
  const result = await helpRepository.queryHelps(queryFilter, options);
  // eslint-disable-next-line no-param-reassign,no-return-assign
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportHelpTable(result.results, req.user, 'helpSettings', 'helpTable');
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  res.send(TimezoneService.LocalizeObject(result, req.user, { reminderDate: true }));
});

const getHelp = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await helpRepository.getHelpById(req.params.helpId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Help not found');
  }
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updateHelp = catchAsync(async (req, res) => {
  const saveBody = { ...req.body };
  saveBody.updateUser = req.user._id.toString();
  const help = await helpRepository.getHelpById(req.params.helpId);
  if (!help) throw new ApiError(`help not found by that id`);
  const channel = await helpRepository.updateHelpById(req.params.helpId, saveBody);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const helpEnableDisableAction = catchAsync(async (req, res) => {
  const item = await helpRepository.helpsActionById(req.body);
  res.send(TimezoneService.LocalizeObject(item, req.user));
});

const deleteHelp = catchAsync(async (req, res) => {
  await helpRepository.deleteHelpById(req.params.helpId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createHelp,
  getHelps,
  getHelp,
  updateHelp,
  deleteHelp,
  helpEnableDisableAction,
});
