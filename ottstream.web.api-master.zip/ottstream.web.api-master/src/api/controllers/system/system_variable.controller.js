const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { systemVariableRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createSystemVariable = catchAsync(async (req, res) => {
  const systemVariable = await systemVariableRepository.createSystemVariable(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(systemVariable, req.user));
});

const getSystemVariables = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await systemVariableRepository.querySystemVariables(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getSystemVariable = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const systemVariable = await systemVariableRepository.getSystemVariableById(req.params.systemVariableId, options);
  if (!systemVariable) {
    throw new ApiError(httpStatus.NOT_FOUND, 'SystemVariable not found');
  }
  res.send(TimezoneService.LocalizeObject(systemVariable, req.user));
});

const updateSystemVariable = catchAsync(async (req, res) => {
  const systemVariable = await systemVariableRepository.updateSystemVariableById(req.params.systemVariableId, req.body);
  res.send(TimezoneService.LocalizeObject(systemVariable, req.user));
});

const deleteSystemVariable = catchAsync(async (req, res) => {
  await systemVariableRepository.deleteSystemVariableById(req.params.systemVariableId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createSystemVariable,
  getSystemVariables,
  getSystemVariable,
  updateSystemVariable,
  deleteSystemVariable,
});
