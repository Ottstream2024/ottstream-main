const catchAsync = require('../../../utils/helpers/catchAsync');
const logger = require('../../../utils/logger/logger');
const depthExport = require('../../../services/export/depth.export');
const serviceCollection = require('../../../services/service_collection');

const MessagesService = serviceCollection.getService('messagesService', true);

const createMessage = catchAsync(async (req, res) => {
  try {
    const response = await MessagesService.createMessage(req.user, req.body);
    res.send(response);
  } catch (ex) {
    logger.error(ex);
    throw ex;
  }
});

const getMessages = catchAsync(async (req, res) => {
  try {
    const response = await MessagesService.getMessages(req.user, req.query);
    res.send(response);
  } catch (ex) {
    logger.error(ex);
    throw ex;
  }
});

module.exports = depthExport({
  createMessage,
  getMessages,
});
