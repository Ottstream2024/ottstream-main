const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { currencyCountryRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const depthExport = require('../../../services/export/depth.export');

const TimezoneService = serviceCollection.getService('timezoneService', true);

const createCurrencyCountry = catchAsync(async (req, res) => {
  const channel = await currencyCountryRepository.createCurrencyCountry(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(channel, req.user));
});

const getCurrencyCountrys = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await currencyCountryRepository.queryCurrencyCountrys(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getUserCurrencyCountry = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role']);
  filter.author = req.user._id;
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await currencyCountryRepository.queryCurrencyCountrys(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getCurrencyCountry = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await currencyCountryRepository.getCurrencyCountryById(req.params.currencyCountryId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'CurrencyCountry not found');
  }
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updateCurrencyCountry = catchAsync(async (req, res) => {
  const channel = await currencyCountryRepository.updateCurrencyCountryById(req.params.currencyCountryId, req.body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const deleteCurrencyCountry = catchAsync(async (req, res) => {
  await currencyCountryRepository.deleteCurrencyCountryById(req.params.currencyCountryId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createCurrencyCountry,
  getCurrencyCountrys,
  getCurrencyCountry,
  getUserCurrencyCountry,
  updateCurrencyCountry,
  deleteCurrencyCountry,
});
