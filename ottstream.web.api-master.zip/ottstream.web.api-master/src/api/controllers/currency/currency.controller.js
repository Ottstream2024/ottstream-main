const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { currencyRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createCurrency = catchAsync(async (req, res) => {
  const channel = await currencyRepository.createCurrency(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(channel, req.user));
});

const getCurrencys = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await currencyRepository.queryCurrencys(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getUserCurrency = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role']);
  filter.author = req.user._id;
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await currencyRepository.queryCurrencys(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getCurrency = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await currencyRepository.getCurrencyById(req.params.currencyId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Currency not found');
  }
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updateCurrency = catchAsync(async (req, res) => {
  const channel = await currencyRepository.updateCurrencyById(req.params.currencyId, req.body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const deleteCurrency = catchAsync(async (req, res) => {
  await currencyRepository.deleteCurrencyById(req.params.currencyId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createCurrency,
  getCurrencys,
  getCurrency,
  getUserCurrency,
  updateCurrency,
  deleteCurrency,
});
