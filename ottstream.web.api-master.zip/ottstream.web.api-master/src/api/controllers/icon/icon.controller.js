const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { iconRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createIcon = catchAsync(async (req, res) => {
  const channel = await iconRepository.createIcon(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(channel, req.user));
});

const getIcons = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await iconRepository.queryIcons(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getIcon = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await iconRepository.getIconById(req.params.iconId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Icon not found');
  }
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updateIcon = catchAsync(async (req, res) => {
  const channel = await iconRepository.updateIconById(req.params.iconId, req.body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const disableEnableIcon = catchAsync(async (req, res) => {
  const channel = await iconRepository.disableEnableIconById(req.params.iconId, req.body.status);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const disableEnableIcons = catchAsync(async (req, res) => {
  const disableEnable = req.body.action === 1;
  // eslint-disable-next-line no-restricted-syntax
  for (const item of req.body.icons) {
    // eslint-disable-next-line no-await-in-loop
    await iconRepository.disableEnableIconById(item, disableEnable);
  }
  res.send(true);
});

const deleteIcon = catchAsync(async (req, res) => {
  await iconRepository.deleteIconById(req.params.iconId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createIcon,
  getIcons,
  getIcon,
  updateIcon,
  disableEnableIcon,
  disableEnableIcons,
  deleteIcon,
});
