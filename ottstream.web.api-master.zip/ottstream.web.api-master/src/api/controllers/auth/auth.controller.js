const httpStatus = require('http-status');
const catchAsync = require('../../../utils/helpers/catchAsync');
const ApiError = require('../../utils/error/ApiError');
const {
  ottProviderRepository,
  ottProviderEmailRepository,
  ottProviderPhoneRepository,
  authRepository,
  userRepository,
  tokenRepository,
  userActivityRepository,
} = require('../../../repository');

const serviceCollection = require('../../../services/service_collection');
const RoleService = require('../../../services/role/role.service');
const EmailService = require('../../../services/email/EmailService.service');
const AuthService = require('../../../services/auth/auth.service');
const config = require('../../../config');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');
// eslint-disable-next-line import/order, import/no-unresolved
const { OAuth2Client } = require('google-auth-library');

const CLIENT_ID = '843759782878-ims9f08e41uh8n8sr5iodl62dtd0qk75.apps.googleusercontent.com';
const client = new OAuth2Client(CLIENT_ID);

async function verifyGoogle(idToken) {
  const loginResult = {
    status: false,
  };
  const ticket = await client.verifyIdToken({
    idToken,
    audience: CLIENT_ID, // Specify the CLIENT_ID of the app that accesses the backend
  });
  const payload = ticket.getPayload();
  const { email } = payload;
  loginResult.status = true;
  loginResult.email = email;
  return loginResult;
  // If request specified a G Suite domain:
  // const domain = payload['hd'];
}
const registerUserAndProvider = catchAsync(async (req, res) => {
  if (await userRepository.isEmailTaken(req.body.email)) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'User Email already taken');
  }
  if (await ottProviderEmailRepository.ottProviderCheckEmail({ email: req.body.companyEmail })) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Company Email already taken');
  }
  if (await ottProviderPhoneRepository.ottProviderCheckPhone({ phone: req.body.phone.phoneNumber })) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Company Phone already taken');
  }
  const users = await userRepository.queryUsers({}, {});
  // eslint-disable-next-line no-unused-vars
  const role = users.results && users.results.length ? 'ottprovider' : 'superadmin'; // TODO use later when all clear with roles
  const type = users.results && users.results.length ? 1 : 0; // TODO use later when all clear with roles
  const baseOttProvider = await ottProviderRepository.getBaseOttProvider();
  // if ott fails to create, delete user in order to register again
  const createdUser = await userRepository.createUser({
    email: req.body.email,
    password: req.body.password,
    firstname: req.body.firstname,
    lastname: req.body.lastname,
    phone: req.body.phone,
    state: baseOttProvider ? 0 : 1,
    geoInfo: req.geoIpInfo,
  });
  if (!createdUser) {
    throw new ApiError(400, `unable to register user`);
  }
  let createdProvider;
  try {
    let parentId;
    if (!baseOttProvider) {
      // throw new ApiError(httpStatus.BAD_REQUEST, 'Base OttProvider');
    } else parentId = baseOttProvider.id;
    createdProvider = await ottProviderRepository.createOttProvider(
      {
        email: req.body.companyEmail,
        name: req.body.companyName,
        phone: req.body.phone,
        website: req.body.website,
        clientAmount: req.body.clientAmount,
        channelAmount: req.body.channelAmount,
        description: req.body.description,
        parent: parentId,
        type,
        state: type ? 0 : 1,
      },
      createdUser
    );
  } catch (error) {
    await userRepository.deleteUserById(createdUser._id);
    throw error;
  }
  if (createdProvider) {
    await EmailService.sendRegistrationEmail(createdUser.email, createdUser.firstname);
    res.status(httpStatus.CREATED).send();
  } else {
    throw new ApiError(400, `unable to create provider`);
  }
});

const login = catchAsync(async (req, res) => {
  const { email, password } = req.body;
  const user = await authRepository.loginUserWithEmailAndPassword(email, password);
  await userRepository.checkDisableUser(email);
  await userRepository.checkUserState(email, password);
  const updatedUser = await userRepository.updateUserById(user.id, {
    geoInfo: req.geoIpInfo,
  });
  const sendUser = updatedUser.toJSON();
  const permissionsObject = RoleService.GetUserPermissions(sendUser, true);
  sendUser.permissions = permissionsObject.permissions;
  const tokens = await AuthService.generateAuthTokens(updatedUser);
  await userActivityRepository.createUserActivity({
    provider: user.provider._id,
    data: {
      geoInfo: req.geoInfo,
      startDate: new Date(),
      endEnd: null,
    },
    state: 1,
    user: user._id,
    type: 'login',
    message: `new login detected`,
  });
  res.send(
    TimezoneService.LocalizeObject(
      {
        sendUser,
        tokens,
        redirect: permissionsObject.redirect,
        config: {
          smartyStreetPublicKey: config.getConfig().smartStreet.publicKey,
          smartyStreetAuthToken: config.getConfig().smartStreet.smartyStreetAuthToken,
          smartyStreetAuthId: config.getConfig().smartStreet.smartyStreetAuthId,
        },
      },
      req.user
    )
  );
});

const loginGoogle = catchAsync(async (req, res) => {
  const { idToken } = req.body;
  const loginResult = await verifyGoogle(idToken);
  if (!loginResult.status) return new ApiError(401);
  const { email } = loginResult;
  // Proceed with user authentication after verifying the token
  const updatedUser = await userRepository.getUserByEmail(email);
  const sendUser = updatedUser.toJSON();
  const permissionsObject = RoleService.GetUserPermissions(sendUser, true);
  sendUser.permissions = permissionsObject.permissions;
  const tokens = await AuthService.generateAuthTokens(updatedUser);
  await userActivityRepository.createUserActivity({
    provider: updatedUser.provider._id,
    data: {
      geoInfo: req.geoInfo,
      startDate: new Date(),
      endEnd: null,
    },
    state: 1,
    user: updatedUser._id,
    type: 'login',
    message: `new login detected`,
  });
  res.send(
    TimezoneService.LocalizeObject(
      {
        sendUser,
        tokens,
        redirect: permissionsObject.redirect,
        config: {
          smartyStreetPublicKey: config.getConfig().smartStreet.publicKey,
          smartyStreetAuthToken: config.getConfig().smartStreet.smartyStreetAuthToken,
          smartyStreetAuthId: config.getConfig().smartStreet.smartyStreetAuthId,
        },
      },
      req.user
    )
  );
});

const me = catchAsync(async (req, res) => {
  res.send(TimezoneService.LocalizeObject(req.user, req.user));
});

const logout = catchAsync(async (req, res) => {
  await authRepository.logout(req.body.refreshToken);
  res.status(httpStatus.NO_CONTENT).send();
});

const refreshTokens = catchAsync(async (req, res) => {
  const tokens = await AuthService.refreshAuth(req.body.refreshToken);
  res.send(TimezoneService.LocalizeObject({ ...tokens }, req.user));
});

const forgotPassword = catchAsync(async (req, res) => {
  const resetPasswordToken = await tokenRepository.generateResetPasswordToken(req.body.email);
  const user = await userRepository.getUserByEmail(req.body.email);
  await EmailService.sendResetPasswordEmail(req.body.email, resetPasswordToken, user.firstname);
  res.status(httpStatus.NO_CONTENT).send();
});

const otpCheck = catchAsync(async (req, res) => {
  const response = await authRepository.otpCheck(req.body.otp);
  res.send(TimezoneService.LocalizeObject({ ...response }, req.user));
});

const emailCheck = catchAsync(async (req, res) => {
  const found = await userRepository.UserCheckEmail(req.body);
  res.send(
    TimezoneService.LocalizeObject(
      {
        result: found,
        geoIpInfo: req.geoIpInfo,
      },
      req.user
    )
  );
});

const resetPassword = catchAsync(async (req, res) => {
  await authRepository.resetPassword(req.body.token, req.body.password);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  registerUserAndProvider,
  login,
  me,
  logout,
  refreshTokens,
  forgotPassword,
  loginGoogle,
  otpCheck,
  resetPassword,
  emailCheck,
});
