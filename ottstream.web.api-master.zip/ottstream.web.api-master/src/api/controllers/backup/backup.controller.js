const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { backupRepository } = require('../../../repository');
const config = require('../../../config');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createBackup = catchAsync(async (req, res) => {
  const channel = await backupRepository.createBackup(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(channel, req.user));
});

const getBackups = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'search', 'priceFrom', 'priceTo', 'type', 'excel']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  if (config.getConfig().global.backup_per_provider) {
    filter.provider = req.user.provider._id.toString();
  }
  const result = await backupRepository.queryBackups(filter, options);
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportBackupTable(result.results, req.user, 'backupSettings', 'backupTable');
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getBackup = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await backupRepository.getBackupById(req.params.backupId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Backup not found');
  }
  channel.refund = channel.price;
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updateBackup = catchAsync(async (req, res) => {
  const channel = await backupRepository.updateBackupById(req.params.backupId, req.body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});
const deleteBackup = catchAsync(async (req, res) => {
  await backupRepository.deleteBackupById(req.body);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createBackup,
  getBackups,
  getBackup,
  updateBackup,
  deleteBackup,
});
