const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { shippingRepository } = require('../../../repository');
// const shippingTypes = require('../../../config/shipping_types');
const serviceCollection = require('../../../services/service_collection');
const EasyshipService = require('../../../services/shiping/merchant/easyship.service');
const ShippingService = require('../../../services/shiping/shipping.service');
const CacheService = require('../../../services/cache/CacheService');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const { ottProviderRepository } = require('../../../repository');
const depthExport = require('../../../services/export/depth.export');

const getRates = catchAsync(async (req, res) => {
  const { shippingId } = req.params;
  const shipping = await shippingRepository.getShippingById(shippingId);
  const ratesState = await ShippingService.getRatesWorker(true, shipping, req.user.provider.id);
  if (ratesState.success) {
    res.send(TimezoneService.LocalizeObject(ratesState.rates, req.user));
  } else {
    throw new ApiError(400, ratesState.message);
  }
});

const cancel = catchAsync(async (req, res) => {
  const { shippingId } = req.params;
  const response = { status: true, shippingId };
  const shipping = await shippingRepository.getShippingById({ _id: shippingId });
  if (!shipping) throw new ApiError(400, `shipping not found ${shippingId}`);
  await EasyshipService.cancelShipment(shipping.easyship_shipment_id, shipping.provider.toString());
  res.send(TimezoneService.LocalizeObject(response, req.user));
});

const createShipping = catchAsync(async (req, res) => {
  const { isCheck } = req.body;
  const prepareShippingDataWithRates = await ShippingService.prepareShippingDataWithRates(req.body, req.user.provider.id);
  const { rates, createShippingData } = prepareShippingDataWithRates;

  if (!isCheck) {
    // const shipping = await shippingRepository.createShipping(createShippingData, req.user);
    res.status(httpStatus.CREATED).send(
      TimezoneService.LocalizeObject(
        {
          shipping: createShippingData,
          rates,
        },
        req.user
      )
    );
  } else {
    res.status(httpStatus.CREATED).send(
      TimezoneService.LocalizeObject(
        {
          rates,
        },
        req.user
      )
    );
  }
});

const getShippings = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['search', 'starDate', 'courier', 'endDate', 'client', 'allResellers', 'resellers']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const ownProviderId = req.user.provider._id.toString();
  filter.providers = [];
  filter.baseprovider = ownProviderId;
  filter.providers = [];
  if (filter.resellers) {
    const providers = await ottProviderRepository.getOttChilds([ownProviderId]); // TODO uncheck if works
    filter.providers = [];
    const incoming = filter.resellers.split(',');
    // eslint-disable-next-line no-restricted-syntax
    for (const incomingProvider of incoming) {
      if (providers.filter((r) => r.id === incomingProvider).length) {
        filter.providers.push(incomingProvider);
      }
    }
  }
  if (!filter.providers.length) filter.providers.push(ownProviderId);

  const result = await shippingRepository.queryShippings(filter, options);
  // if (filter.excel) {
  //   const excelService = serviceCollection.getService('excelService');
  //   const report = excelService.exportShippingTable(result.results, req.user, 'shippingSettings', 'shippingTable');
  //   res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
  //   return res.send(report);
  // }

  if (filter.providers.length === 1) {
    const providers = await ottProviderRepository.getList({ _id: filter.providers[0] }, []);
    const { hasValidShippingGateway } = providers[0];
    if (hasValidShippingGateway) {
      const cacheKey = `provider-easyship-info-${filter.providers[0]}`;
      if (await CacheService.hasKey(cacheKey)) {
        const saveData = await CacheService.get(cacheKey);
        result.shippingBalance = saveData.balance;
      }
    }
  }
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getCategories = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['excel', 'client', 'comment', 'isViewed']);
  filter.provider = req.user.provider._id.toString();
  const incoming = await EasyshipService.getItemCategories(filter.provider);
  const categories = incoming.data.item_categories;
  res.send(TimezoneService.LocalizeObject(categories, req.user));
});

const generateLabel = catchAsync(async (req, res) => {
  const shipping = await shippingRepository.getShippingById(req.params.shippingId);
  if (!shipping) throw new ApiError(400, 'shipping not found');
  if (shipping.label_state !== 'not_created')
    throw new ApiError(400, `shipping label state is ${shipping.label_state}, and can not generate label`);
  const labelResponse = await ShippingService.createLabel({
    easyship_shipment_id: shipping.easyship_shipment_id,
    selected_courier: shipping.selected_courier,
  });
  res.send(TimezoneService.LocalizeObject({ success: labelResponse.status }, req.user));
});

const getShipping = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await shippingRepository.getShippingById(req.params.shippingId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Shipping not found');
  }
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updateShipping = catchAsync(async (req, res) => {
  const saveBody = { ...req.body };
  saveBody.updateUser = req.user._id.toString();
  const channel = await shippingRepository.updateShippingById(req.params.shippingId, saveBody);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const shippingEnableDisableAction = catchAsync(async (req, res) => {
  const item = await shippingRepository.shippingsActionById(req.body);
  res.send(TimezoneService.LocalizeObject(item, req.user));
});

const deleteShipping = catchAsync(async (req, res) => {
  await shippingRepository.deleteShippingById(req.params.shippingId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createShipping,
  getShippings,
  getRates,
  generateLabel,
  getShipping,
  updateShipping,
  deleteShipping,
  getCategories,
  cancel,
  shippingEnableDisableAction,
});
