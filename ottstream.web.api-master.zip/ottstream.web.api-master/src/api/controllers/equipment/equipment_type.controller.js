const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { equipmentTypeRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createEquipmentType = catchAsync(async (req, res) => {
  const channel = await equipmentTypeRepository.createEquipmentType(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(channel, req.user));
});

const getEquipmentTypes = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'search', 'priceFrom', 'priceTo', 'type', 'excel']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  // if (config.global.equipmentType_per_provider) {
  filter.provider = req.user.provider._id.toString();
  // }
  const result = await equipmentTypeRepository.queryEquipmentTypes(filter, options);
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportEquipmentTypeTable(
      result.results,
      req.user,
      'equipmentTypeSettings',
      'equipmentTypeTable'
    );
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getEquipmentType = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await equipmentTypeRepository.getEquipmentTypeById(req.params.equipmentTypeId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'EquipmentType not found');
  }
  channel.refund = channel.price;
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updateEquipmentType = catchAsync(async (req, res) => {
  const channel = await equipmentTypeRepository.updateEquipmentTypeById(req.params.equipmentTypeId, req.body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const equipmentTypeEnableDisableAction = catchAsync(async (req, res) => {
  const item = await equipmentTypeRepository.equipmentTypesActionById(req.body);
  res.send(TimezoneService.LocalizeObject(item, req.user));
});

const deleteEquipmentType = catchAsync(async (req, res) => {
  await equipmentTypeRepository.deleteEquipmentTypeById(req.body);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createEquipmentType,
  getEquipmentTypes,
  getEquipmentType,
  updateEquipmentType,
  deleteEquipmentType,
  equipmentTypeEnableDisableAction,
});
