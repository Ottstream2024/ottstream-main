const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { equipmentInstallerRepository } = require('../../../repository');
const config = require('../../../config');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createEquipmentInstaller = catchAsync(async (req, res) => {
  const channel = await equipmentInstallerRepository.createEquipmentInstaller(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(channel, req.user));
});

const getEquipmentInstallers = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'search', 'priceFrom', 'priceTo', 'type', 'excel']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  if (config.getConfig().global.equipmentInstaller_per_provider) {
    filter.provider = req.user.provider._id.toString();
  }
  const result = await equipmentInstallerRepository.queryEquipmentInstallers(filter, options);
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportEquipmentInstallerTable(
      result.results,
      req.user,
      'equipmentInstallerSettings',
      'equipmentInstallerTable'
    );
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getEquipmentInstaller = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await equipmentInstallerRepository.getEquipmentInstallerById(req.params.equipmentInstallerId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'EquipmentInstaller not found');
  }
  channel.refund = channel.price;
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updateEquipmentInstaller = catchAsync(async (req, res) => {
  const channel = await equipmentInstallerRepository.updateEquipmentInstallerById(req.params.equipmentInstallerId, req.body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const equipmentInstallerEnableDisableAction = catchAsync(async (req, res) => {
  const item = await equipmentInstallerRepository.equipmentInstallersActionById(req.body);
  res.send(TimezoneService.LocalizeObject(item, req.user));
});

const deleteEquipmentInstaller = catchAsync(async (req, res) => {
  await equipmentInstallerRepository.deleteEquipmentInstallerById(req.body);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createEquipmentInstaller,
  getEquipmentInstallers,
  getEquipmentInstaller,
  updateEquipmentInstaller,
  deleteEquipmentInstaller,
  equipmentInstallerEnableDisableAction,
});
