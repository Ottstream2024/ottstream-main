const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { equipmentRepository, equipmentTypeRepository, equipmentSubscriptionRepository } = require('../../../repository');
// const equipmentTypes = require('../../../config/equipment_types');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createEquipment = catchAsync(async (req, res) => {
  const channel = await equipmentRepository.createEquipment(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(channel, req.user));
});

const returnEquipment = catchAsync(async (req, res) => {
  const { invoice, equipment } = req.body;
  await equipmentSubscriptionRepository.deleteEquipmentSubscription({ invoice, equipment });
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject({ success: true }, req.user));
});

const getEquipments = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'search', 'priceFrom', 'priceTo', 'type', 'excel', 'service']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  filter.provider = req.user.provider._id.toString();
  const result = await equipmentRepository.queryEquipments(filter, options);
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportEquipmentTable(result.results, req.user, 'equipmentSettings', 'equipmentTable');
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getEquipmentTypes = catchAsync(async (req, res) => {
  const result = [];
  const equipmentTypes = await equipmentTypeRepository.queryEquipmentTypes(
    { provider: req.user.provider._id.toString() },
    {}
  );
  // eslint-disable-next-line no-restricted-syntax
  for (const item of equipmentTypes.results) {
    result.push({
      name: item.name,
      provider: item.provider,
      id: item._id,
    });
  }
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getEquipment = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await equipmentRepository.getEquipmentById(req.params.equipmentId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Equipment not found');
  }
  channel.refund = channel.price;
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updateEquipment = catchAsync(async (req, res) => {
  const channel = await equipmentRepository.updateEquipmentById(req.params.equipmentId, req.body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const equipmentEnableDisableAction = catchAsync(async (req, res) => {
  const item = await equipmentRepository.equipmentsActionById(req.body);
  res.send(TimezoneService.LocalizeObject(item, req.user));
});

const deleteEquipment = catchAsync(async (req, res) => {
  await equipmentRepository.deleteEquipmentById(req.body);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createEquipment,
  returnEquipment,
  getEquipmentTypes,
  getEquipments,
  getEquipment,
  updateEquipment,
  deleteEquipment,
  equipmentEnableDisableAction,
});
