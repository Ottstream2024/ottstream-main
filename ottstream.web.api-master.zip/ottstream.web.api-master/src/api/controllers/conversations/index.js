const catchAsync = require('../../../utils/helpers/catchAsync');
const logger = require('../../../utils/logger/logger');
const depthExport = require('../../../services/export/depth.export');
const ConversationsService = require('../../../services/conversations');

const conversationsService = new ConversationsService();

const createConversation = catchAsync(async (req, res) => {
  try {
    const response = await conversationsService.createConversation(req.user, req.body);
    res.send(response);
  } catch (ex) {
    logger.error(ex);
    throw ex;
  }
});

const createClientConversation = catchAsync(async (req, res) => {
  try {
    const response = await conversationsService.createClientConversation(req.user, req.body);
    res.send(response);
  } catch (ex) {
    logger.error(ex);
    throw ex;
  }
});

const getConversations = catchAsync(async (req, res) => {
  try {
    const response = await conversationsService.getConversations(req.user, req.params.type, req.query);
    res.send(response);
  } catch (ex) {
    logger.error(ex);
    throw ex;
  }
});

const createGroupConversation = catchAsync(async (req, res) => {
  try {
    const response = await conversationsService.createGroupConversation(req.user, req.body);
    res.send(response);
  } catch (ex) {
    logger.error(ex);
    throw ex;
  }
});

const getMemberById = catchAsync(async (req, res) => {
  try {
    const response = await conversationsService.getMemberById(req.user, req.params.id);
    res.send(response);
  } catch (ex) {
    logger.error(ex);
    throw ex;
  }
});

const findConversation = catchAsync(async (req, res) => {
  try {
    const response = await conversationsService.findConversation(req.user, req.params.type, req.query.search);
    res.send(response);
  } catch (ex) {
    logger.error(ex);
    throw ex;
  }
});

module.exports = depthExport({
  createConversation,
  getConversations,
  createGroupConversation,
  createClientConversation,
  getMemberById,
  findConversation,
});
