const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { countryRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const depthExport = require('../../../services/export/depth.export');

const TimezoneService = serviceCollection.getService('timezoneService', true);

const createCountry = catchAsync(async (req, res) => {
  const country = await countryRepository.createCountry(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(country, req.user));
});

const getCountrys = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'state', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await countryRepository.queryCountrys(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getUserCountry = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role']);
  filter.author = req.user._id;
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await countryRepository.queryCountrys(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getCountry = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const country = await countryRepository.getCountryById(req.params.countryId, options);
  if (!country) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Country not found');
  }
  res.send(TimezoneService.LocalizeObject(country, req.user));
});

const updateCountry = catchAsync(async (req, res) => {
  const country = await countryRepository.updateCountryById(req.params.countryId, req.body);
  res.send(TimezoneService.LocalizeObject(country, req.user));
});

const deleteCountry = catchAsync(async (req, res) => {
  await countryRepository.deleteCountryById(req.params.countryId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createCountry,
  getCountrys,
  getCountry,
  getUserCountry,
  updateCountry,
  deleteCountry,
});
