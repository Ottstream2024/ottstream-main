const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const {
  ottProviderRepository,
  userRepository,
  ottProviderEmailRepository,
  ottProviderPhoneRepository,
  creditRepository,
  subscriptionRepository,
  clientRepository,
  clientLocationRepository,
} = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const EmailService = require('../../../services/email/EmailService.service');
const LiveSyncService = require('../../../services/sync/live/live_sync.service');
const OttSyncService = require('../../../services/sync/ott_provider/ott_sync.service');
const logger = require('../../../utils/logger/logger');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createOttProvider = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.createOttProvider(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

const syncLive = catchAsync(async (req, res) => {
  const response = await LiveSyncService.syncLive(req.user);
  res.send(TimezoneService.LocalizeObject(response, req.user));
});

const getOttProviders = catchAsync(async (req, res) => {
  const filter = pick(req.query, [
    'search',
    'state',
    'parentId',
    'country',
    'clientsFrom',
    'clientsTo',
    'resellersFrom',
    'resellersTo',
    'totalLoginsFrom',
    'totalLoginsTo',
    'activeLoginsFrom',
    'activeLoginsTo',
    'priceGroup',
    'balanceFrom',
    'balanceTo',
    'debtFrom',
    'debtTo',
    'creditAmountFrom',
    'creditAmountTo',
    'creditDateFrom',
    'creditDateTo',
    'creditAutoExtend',
    'creditDaysRemainingFrom',
    'creditDaysRemainingTo',
    'currentMonthPaymentsFrom',
    'currentMonthPaymentsTo',
    'currentMonthIncomeFrom',
    'currentMonthIncomeTo',
    'dateFrom',
    'dateTo',
    'excel',
  ]);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  filter.parentId = filter.parentId ? filter.parentId : req.user.provider._id.toString();
  const result = await ottProviderRepository.queryOttProviders(filter, options, req.user);
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportProviderList(
      result.results,
      req.user,
      'ottProviderTableSettings',
      'providerDefaultSettings'
    );
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getOttProviderForFilters = catchAsync(async (req, res) => {
  // const filter = pick(req.query, ['parents']);
  const finalList = [];
  if (req.user.provider.parent && req.query.parent) {
    const ottProvider = await ottProviderRepository.getOttProviderById(req.user.provider.parent);
    if (ottProvider) {
      finalList.push({
        name: ottProvider.name?.length ? ottProvider.name[0].name : '',
        value: ottProvider._id.toString(),
      });
    }
  }
  // const result = await ottProviderRepository.getList(filter);
  const result = await ottProviderRepository.getOttChilds([req.user.provider._id.toString()]);
  // eslint-disable-next-line no-restricted-syntax
  for (const item of result) {
    finalList.push({
      name: item.name?.length ? item.name[0].name : '',
      value: item.id,
    });
  }
  res.send(TimezoneService.LocalizeObject(finalList, req.user));
});

const getRegistrationProviders = catchAsync(async (req, res) => {
  const filter = pick(req.query, [
    'state',
    'channelMinCount',
    'channelMaxCount',
    'dateFrom',
    'dateTo',
    'clientAmount',
    'search',
    'excel',
  ]);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await ottProviderRepository.queryRegistrationOttProviders(filter, options);
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportReviewList(result.results, req.user, 'reviewSettings', 'reviewTable');
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getOttProvider = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const ottprovider = await ottProviderRepository.getOttTabs(req.params.ottproviderId, options);
  if (!ottprovider) {
    throw new ApiError(httpStatus.NOT_FOUND, 'OttProvider not found');
  }
  res.send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

const getOttProviderBalanceCredit = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const ottprovider = await ottProviderRepository.getOttProviderById(req.params.ottProviderId);
  if (!ottprovider) {
    throw new ApiError(httpStatus.NOT_FOUND, 'OttProvider not found');
  }
  let ottProvoiderCredit = null;
  const filter = {
    providerId: ottprovider._id,
    state: 1,
  };
  ottProvoiderCredit = await creditRepository.queryCredits(filter, options);
  // const credit = ottProvoiderCredit.results.reduce((prev, next) => prev + next.creditAmount, 0);

  const response = {
    balance: ottprovider.balance,
    debt: ottprovider.debt,
    credit:
      ottProvoiderCredit && ottProvoiderCredit.results && ottProvoiderCredit.results.length
        ? ottProvoiderCredit.results[0]
        : null,
  };
  res.send(TimezoneService.LocalizeObject(response, req.user));
});

const actionSettings = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.updateOttProviderAction(req.body);
  res.send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

const updateOttProvider = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.updateOttProviderById(req.params.ottproviderId, req.body, req.user);
  await OttSyncService.markToSync(ottprovider?._id?.toString(), req.user);
  res.send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

const updateOttProviderPaymentMethodOptions = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.updatePaymentOptions(req.params.ottProviderId, req.body);
  await OttSyncService.markToSync(ottprovider?._id?.toString(), req.user);
  res.send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

const getOttProviderPaymentMethodOptions = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.getPaymentOptions(req.params.ottProviderId);
  await OttSyncService.markToSync(ottprovider?._id?.toString(), req.user);
  res.send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

const updateOttProviderAddress = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.updateOttProviderAddressById(req.params.ottproviderId, req.body);
  await OttSyncService.markToSync(ottprovider?._id?.toString(), req.user);
  res.send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

const getOttProviderSettings = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const ottprovider = await ottProviderRepository.getOttProviderSettings(req.params.ottproviderId, options);
  if (!ottprovider) {
    throw new ApiError(httpStatus.NOT_FOUND, 'OttProvider not found');
  }
  res.send(TimezoneService.LocalizeObject(ottprovider.settings, req.user));
});

const getOttProviderSalesTax = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const ottprovider = await ottProviderRepository.getOttProviderSalesTax(req.params.ottproviderId, options);
  if (!ottprovider) {
    throw new ApiError(httpStatus.NOT_FOUND, 'OttProvider not found');
  }
  res.send(TimezoneService.LocalizeObject(ottprovider.salesTax ?? {}, req.user));
});

const getOttProviderAddress = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const ottprovider = await ottProviderRepository.getOttProviderAddress(req.params.ottproviderId, options);
  if (!ottprovider) {
    throw new ApiError(httpStatus.NOT_FOUND, 'OttProvider not found');
  }
  res.send(TimezoneService.LocalizeObject(ottprovider.addresses, req.user));
});

const getOttProviderPaymentGateways = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const ottprovider = await ottProviderRepository.getOttProviderPaymentGateways(req.params.ottproviderId, options);
  if (!ottprovider) {
    throw new ApiError(httpStatus.NOT_FOUND, 'OttProvider not found');
  }
  res.send(TimezoneService.LocalizeObject(ottprovider.paymentGateway, req.user));
});

const getOttProviderShippingProviders = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const ottprovider = await ottProviderRepository.getOttProviderShippingProviders(req.params.ottproviderId, options);
  if (!ottprovider) {
    throw new ApiError(httpStatus.NOT_FOUND, 'OttProvider not found');
  }
  res.send(TimezoneService.LocalizeObject(ottprovider.shippingProvider, req.user));
});

const updateOttProviderSettings = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.updateOttProviderSettingsById(req.params.ottproviderId, req.body);
  await OttSyncService.markToSync(ottprovider?._id?.toString(), req.user);
  res.send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

const updateOttProviderSalesTax = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.updateOttProviderSalesTaxById(req.params.ottproviderId, req.body);
  await OttSyncService.markToSync(ottprovider?._id?.toString(), req.user);
  res.send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

const updateOttProviderShippingProvider = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.updateOttProviderShippingProviderById(req.params.ottproviderId, req.body);
  await OttSyncService.markToSync(ottprovider?._id?.toString(), req.user);
  res.send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

const approveOttProvider = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.approveOttProviderById(req.params.ottproviderId, req.body, req.user);
  res.send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

const registrationApprove = catchAsync(async (req, res) => {
  await ottProviderRepository.approveProviders(req.body.providers, req.user);
  res.send(TimezoneService.LocalizeObject({ result: true }, req.user));
});

const deleteOtt = async (providerId) => {
  const provider = await ottProviderRepository.getOttProviderById(providerId);
  if (!provider) throw new ApiError(httpStatus.NOT_FOUND, `location not found`);
  const filter = { providers: [provider._id] };
  const providers = await ottProviderRepository.getOttChilds([providerId]); // TODO uncheck if works
  filter.providers = filter.providers.concat(providers.map((r) => r._id));

  // check if client has balance, depts or subscriptions
  const activeSubscriptions = await subscriptionRepository.getList({
    provider: { $in: filter.providers },
    state: 1,
  });
  if (activeSubscriptions.length)
    throw new ApiError(
      httpStatus.BAD_REQUEST,
      `ottprovider has client which has ${activeSubscriptions.length} active subscriptions`
    );
  logger.info(`removing provider ${providerId}`);
  await ottProviderRepository.deleteOttProviderById(providerId);
  logger.info(`removing provider clients ${providerId}`);
  await clientRepository.updateAll({ provider: providerId }, { status: 0 });
  logger.info(`removing provider client locations ${providerId}`);
  await clientLocationRepository.updateAll({ provider: providerId }, { status: 0 });
};

const deleteOttProvider = catchAsync(async (req, res) => {
  const providerId = req.params.ottproviderId;
  await deleteOtt(providerId);
  res.status(httpStatus.NO_CONTENT).send();
});

const ottProviderActionDelete = catchAsync(async (req, res) => {
  const list = req.body.ottproviderId;
  // eslint-disable-next-line no-restricted-syntax
  for (const providerId of list) {
    // eslint-disable-next-line no-await-in-loop
    await deleteOtt(providerId);
  }
  res.status(httpStatus.NO_CONTENT).send({ success: true });
});

const addByAdmin = catchAsync(async (req, res) => {
  try {
    if (await userRepository.isEmailTaken(req.body.email)) {
      throw new ApiError(httpStatus.BAD_REQUEST, 'User Email already taken');
    }
    const emails = req.body.companyEmails || [];
    for (let i = 0; i < emails.length; i += 1) {
      // eslint-disable-next-line no-await-in-loop
      if (await ottProviderEmailRepository.ottProviderCheckEmail({ email: emails[i]?.address })) {
        throw new ApiError(httpStatus.BAD_REQUEST, 'OttProvider CompanyEmail already taken');
      }
    }
    const phones = req.body.companyPhones || [];
    for (let i = 0; i < phones.length; i += 1) {
      // eslint-disable-next-line no-await-in-loop
      if (await ottProviderPhoneRepository.ottProviderCheckPhone({ phone: phones[i]?.ottprovider?._id?.toString() })) {
        throw new ApiError(httpStatus.BAD_REQUEST, 'OttProvider Phone already taken');
      }
    }
    // eslint-disable-next-line no-unused-vars
    const role = 'ottprovider'; // TODO use later when all clear with roles

    // const provider = await ottProviderRepository.createOttProviderByAdmin(req.body, user, req.user);
    // res.status(httpStatus.CREATED).send(provider);

    // if ott fails to create, delete user in order to register again
    const user = await userRepository.createUser({
      email: req.body.email,
      password: req.body.password,
      firstname: req.body.firstname,
      lastname: req.body.lastname,
      phone: req.body.phone,
      state: 1,
      geoInfo: req.geoIpInfo,
    });
    const createProvider = await ottProviderRepository.createOttProviderByAdmin(
      {
        name: req.body.companyName,
        website: req.body.website,
        clientAmount: req.body.clientAmount,
        channelAmount: req.body.channelAmount,
        description: req.body.description,
        timezone: req.body.timezone,
        comment: req.body.comment,
        priceGroup: req.body.priceGroup,
        parent: req.body.parentId,
        country: req.body.country,
        registerBy: req.user._id,
        type: 1,
        state: 1,
      },
      user,
      req.body.companyEmails,
      req.body.companyPhones
    );
    if (createProvider) {
      await EmailService.sendRegistrationEmail(user.email, user.firstname);
      res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(createProvider, req.user));
    } else {
      await userRepository.deleteUserById(user._id);
    }
  } catch (ex) {
    logger.error(ex);
    throw new ApiError(httpStatus.BAD_REQUEST, ex);
  }
});

const getCheckOttProviderKey = catchAsync(async (req, res) => {
  const result = await ottProviderRepository.getCheckOttProviderKey(req.body, req.params.ottproviderId);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const updateOttProviderCompanyAddress = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.updateCompanyAddress(req.params.ottproviderId, req.body);
  await OttSyncService.markToSync(ottprovider?._id?.toString(), req.user);
  res.send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

const updateOttProviderPaymentMethod = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.updatePaymentMethod(req.params.ottproviderId, req.body);
  await OttSyncService.markToSync(ottprovider?._id?.toString(), req.user);
  res.send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

const updateOttProviderBalanceCredit = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.updateBalanceCredit(req.params.ottproviderId, req.body);
  res.send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

const updateOttProviderPaymentGateway = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.updateOttProviderPaymentGateway(req.params.ottproviderId, req.body);
  await OttSyncService.markToSync(ottprovider?._id?.toString(), req.user);
  res.send(TimezoneService.LocalizeObject(ottprovider.paymentGateway, req.user));
});

const updateOttProviderShippingProviders = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.updateShippingProviders(req.params.ottproviderId, req.body);
  await OttSyncService.markToSync(ottprovider?._id?.toString(), req.user);
  res.send(TimezoneService.LocalizeObject(ottprovider.shippingProvider, req.user));
});

const updateOttProviderUiAndAccessCustomization = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.updateUiAndAccessCustomization(req.params.ottproviderId, req.body);
  await OttSyncService.markToSync(ottprovider?._id?.toString(), req.user);
  res.send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

const updateOttProviderInfoForClientsApp = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.updateInfoForClientsApp(req.params.ottproviderId, req.body);
  await OttSyncService.markToSync(ottprovider?._id?.toString(), req.user);
  res.send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

const updateOttProviderPermissionsAndSettings = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.updatePermissionsAndSettings(req.params.ottproviderId, req.body);
  await OttSyncService.markToSync(ottprovider?._id?.toString(), req.user);
  res.send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

const updateOttProviderBillInvoicesGeneration = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.updateBillInvoicesGeneration(req.params.ottproviderId, req.body);
  await OttSyncService.markToSync(ottprovider?._id?.toString(), req.user);
  res.send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

const updateOttProviderOtherApiIntegrations = catchAsync(async (req, res) => {
  const ottprovider = await ottProviderRepository.updateOtherApiIntegrations(req.params.ottproviderId, req.body);
  await OttSyncService.markToSync(ottprovider?._id?.toString(), req.user);
  res.send(TimezoneService.LocalizeObject(ottprovider, req.user));
});

module.exports = depthExport({
  updateOttProviderPaymentMethodOptions,
  getOttProviderPaymentMethodOptions,
  createOttProvider,
  getOttProviderForFilters,
  syncLive,
  getOttProviders,
  getOttProvider,
  actionSettings,
  updateOttProvider,
  updateOttProviderAddress,
  updateOttProviderShippingProvider,
  getOttProviderSettings,
  getOttProviderPaymentGateways,
  getOttProviderShippingProviders,
  getOttProviderSalesTax,
  getOttProviderAddress,
  updateOttProviderPaymentGateway,
  updateOttProviderSettings,
  updateOttProviderSalesTax,
  approveOttProvider,
  deleteOttProvider,
  ottProviderActionDelete,
  getRegistrationProviders,
  registrationApprove,
  addByAdmin,
  getOttProviderBalanceCredit,
  updateOttProviderCompanyAddress,
  updateOttProviderPaymentMethod,
  updateOttProviderBalanceCredit,
  updateOttProviderShippingProviders,
  updateOttProviderUiAndAccessCustomization,
  updateOttProviderInfoForClientsApp,
  updateOttProviderPermissionsAndSettings,
  updateOttProviderBillInvoicesGeneration,
  updateOttProviderOtherApiIntegrations,
  getCheckOttProviderKey,
});
