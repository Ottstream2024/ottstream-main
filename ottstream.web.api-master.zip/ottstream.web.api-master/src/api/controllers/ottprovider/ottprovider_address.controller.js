const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { ottProviderAddressRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const OttSyncService = require('../../../services/sync/ott_provider/ott_sync.service');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createOttProviderAddress = catchAsync(async (req, res) => {
  const ottProviderAddress = await ottProviderAddressRepository.createOttProviderAddress(req.body, req.user);
  await OttSyncService.markToSync(req.body.providerId, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(ottProviderAddress, req.user));
});

const getOttProviderAddresses = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'state', 'user', 'providerId']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  filter.providerId = req.user.provider._id.toString();
  const result = await ottProviderAddressRepository.queryOttProviderAddresses(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getOttProviderAddress = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const ottProviderAddress = await ottProviderAddressRepository.getOttProviderAddressById(
    req.params.ottProviderAddressId,
    options
  );
  if (!ottProviderAddress) {
    throw new ApiError(httpStatus.NOT_FOUND, 'ottProviderAddress not found');
  }
  res.send(TimezoneService.LocalizeObject(ottProviderAddress, req.user));
});

const updateOttProviderAddress = catchAsync(async (req, res) => {
  const ottProviderAddress = await ottProviderAddressRepository.updateOttProviderAddressById(
    req.params.ottProviderAddressId,
    req.body
  );
  await OttSyncService.markToSync(ottProviderAddress?.providerId, req.user);
  res.send(TimezoneService.LocalizeObject(ottProviderAddress, req.user));
});

const deleteOttProviderAddress = catchAsync(async (req, res) => {
  const ottProviderAddress = await ottProviderAddressRepository.deleteOttProviderAddressById(
    req.params.ottProviderAddressId
  );
  await OttSyncService.markToSync(ottProviderAddress?.providerId, req.user);
  res.status(httpStatus.NO_CONTENT).send();
});

const getOttProviderAddressesByProviderId = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const ottProviderAddress = await ottProviderAddressRepository.getOttProviderAddressesByProviderId(
    req.params.ottProviderId,
    options
  );
  res.send(TimezoneService.LocalizeObject(ottProviderAddress, req.user));
});
module.exports = depthExport({
  createOttProviderAddress,
  getOttProviderAddresses,
  getOttProviderAddress,
  updateOttProviderAddress,
  deleteOttProviderAddress,
  getOttProviderAddressesByProviderId,
});
