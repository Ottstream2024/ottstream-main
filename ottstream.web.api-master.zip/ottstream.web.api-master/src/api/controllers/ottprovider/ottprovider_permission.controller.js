const httpStatus = require('http-status');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { ottProviderPermissionRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const RoleService = require('../../../services/role/role.service');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createOttProviderPermission = catchAsync(async (req, res) => {
  const ottProviderPermission = await ottProviderPermissionRepository.createOttProviderPermission(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(ottProviderPermission, req.user));
});

const getOttProviderPermission = catchAsync(async (req, res) => {
  const ottProviderPermission = await ottProviderPermissionRepository.getOttProviderPermission(req.params.ottProviderId);
  if (!ottProviderPermission) {
    throw new ApiError(httpStatus.NOT_FOUND, 'ottProviderPermission not found');
  }
  ottProviderPermission.permissions = await RoleService.GetOttPermissions(
    req.params.ottProviderId,
    ottProviderPermission.permissions
  );

  res.send(TimezoneService.LocalizeObject(ottProviderPermission, req.user));
});

const updateOttProviderPermission = catchAsync(async (req, res) => {
  const ottProviderPermission = await ottProviderPermissionRepository.updateOttProviderPermission(
    req.params.ottProviderId,
    req.body
  );
  res.send(
    TimezoneService.LocalizeObject(
      await RoleService.GetOttPermissions(req.params.ottProviderId, ottProviderPermission.permissions),
      req.user
    )
  );
});

module.exports = depthExport({
  createOttProviderPermission,
  getOttProviderPermission,
  updateOttProviderPermission,
});
