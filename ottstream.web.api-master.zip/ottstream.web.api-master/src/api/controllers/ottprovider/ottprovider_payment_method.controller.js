const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { ottProviderPaymentMethodRepository, ottProviderRepository, transactionRepository } = require('../../../repository');
const logger = require('../../../utils/logger/logger');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const TransactionService = require('../../../services/payment/transaction.service');
const depthExport = require('../../../services/export/depth.export');

const ottProviderPaymentMethodValidator = async (providerId, _paymentMethod, user) => {
  const PaymentObjectValidator = serviceCollection.getService('paymentObjectValidator', true);
  const paymentMethod = _paymentMethod;
  const response = {
    status: false,
    messages: [],
  };

  const ottProvider = await ottProviderRepository.getOttProviderById(providerId);
  let _toPayOttId;
  if (ottProvider) {
    if (ottProvider.parent) {
      _toPayOttId = ottProvider.parent._id.toString();
    } else {
      _toPayOttId = ottProvider._id.toString();
    }
  }
  const oldPaymentMethods = await ottProviderPaymentMethodRepository.getOttProviderPaymentMethods(providerId);
  paymentMethod.valid = false;
  const paymentMethodType = paymentMethod.paymentMethod;
  if (paymentMethodType === 0 || paymentMethodType === 1) {
    let validCardObjectResult;
    if (paymentMethodType === 0 && paymentMethod.creditCard) {
      validCardObjectResult = await PaymentObjectValidator.validateCreditCardObject(1, providerId, paymentMethod.creditCard);
    } else if (paymentMethodType === 1 && paymentMethod.bankTransfer) {
      validCardObjectResult = await PaymentObjectValidator.validateBankTransferObject(
        1,
        providerId,
        paymentMethod.bankTransfer
      );
    } else {
      throw new ApiError(400, `payment method type and object sent does not match`);
    }

    if (validCardObjectResult && validCardObjectResult.status) {
      // validate Card
      if (paymentMethodType === 0) paymentMethod.creditCard = validCardObjectResult.card;
      else if (paymentMethodType === 1) paymentMethod.bankTransfer = validCardObjectResult.card;
      // check same or not
      const oldCardFilterList = oldPaymentMethods.filter(
        (r) => r.creditCard && r.creditCard.cardNumber === paymentMethod.creditCard.cardNumber
      );
      const oldBankFilterList = oldPaymentMethods.filter(
        (r) => r.bankTransfer && r.bankTransfer.routingNumber === paymentMethod.bankTransfer.routingNumber
      );
      const oldCardExists = paymentMethodType === 0 && oldCardFilterList.length;
      const oldBankExists = paymentMethodType === 1 && oldBankFilterList.length;
      if (oldCardExists || oldBankExists) {
        if (
          (oldCardExists && oldCardFilterList[0]?._id?.toString() !== paymentMethod.id) ||
          (oldBankExists && oldBankFilterList[0]?._id?.toString() !== paymentMethod.id)
        ) {
          throw new ApiError(400, 'Credit card or bank account with same number already exists');
        }
      }
      let executedTransaction;
      await transactionRepository.getVoidTransactionsForCreditCard(null, providerId);
      // eslint-disable-next-line no-restricted-syntax
      // for (const curVoidTransaction of existingTransactions) {
      //   if (
      //     curVoidTransaction.payload &&
      //     (paymentMethodType === 0
      //       ? curVoidTransaction.payload.cardNumber === paymentMethod.creditCard.cardNumber
      //       : curVoidTransaction.payload.routingNumber === paymentMethod.bankTransfer.routingNumber) &&
      //     (curVoidTransaction.state === 1 || curVoidTransaction.state === 4)
      //   ) {
      //     executedTransaction = curoidTransaction;
      //     // eslint-disable-next-line no-await-in-loop
      //     await paymentProcessor.cancelTransaction(executedTransaction);
      //   }
      // }
      const transactionCreateResult = await TransactionService.createVoidTransaction(
        1,
        providerId,
        1,
        _toPayOttId,
        0.5,
        paymentMethodType,
        paymentMethodType === 0 ? paymentMethod.creditCard : paymentMethod.bankTransfer,
        user
      );
      if (transactionCreateResult)
        executedTransaction = await TransactionService.executeTransaction(transactionCreateResult.transaction);
      if (!executedTransaction) throw new ApiError(400, `no executed transaction can be generate or selected from List`);
      if (executedTransaction.state === 1) {
        await TransactionService.cancelTransaction(executedTransaction);
        // if (!refundResult.status)
        //   throw new ApiError(400, `failed to refund auth only transaction ${refundResult.messages.toString()}`);
        response.status = true;
        response.paymentMethod = paymentMethod;
      } else {
        throw new ApiError(
          400,
          `credit card or bank account validation transaction failed: ${executedTransaction.stateMessage ?? null}`
        );
      }
    } else {
      throw new ApiError(400, `credit card or bank account details are not valid ${validCardObjectResult.message}`);
    }
  } else if (
    typeof paymentMethod.inUse !== 'undefined' &&
    typeof paymentMethod.default !== 'undefined' &&
    typeof paymentMethod.paymentMethod === 'undefined'
  ) {
    response.status = true;
    response.paymentMethod = paymentMethod;
  } else {
    throw new ApiError(400, `unsupported payment method type`);
  }

  return response;
};

const createOttProviderPaymentMethod = catchAsync(async (req, res) => {
  let paymentMethod = req.body;
  const { providerId } = req.body;
  let _ottProviderPaymentMethod;

  const validMethod = await ottProviderPaymentMethodValidator(providerId, paymentMethod, req.user);

  if (validMethod.status) {
    paymentMethod = validMethod.paymentMethod;
    if (
      paymentMethod.creditCard &&
      paymentMethod.creditCard.billingAddress &&
      paymentMethod.creditCard.phone &&
      paymentMethod.creditCard.number
    ) {
      paymentMethod.creditCard.billingAddress.phone = paymentMethod.creditCard.billingAddress.phone.number;
    }
    logger.info(`createOttProviderPaymentMethod() ${paymentMethod.creditCard.billingAddress.phone}`);
    _ottProviderPaymentMethod = await ottProviderPaymentMethodRepository.createOttProviderPaymentMethod(paymentMethod);
  } else {
    throw new ApiError(400, `${validMethod.messages.toString()}`);
  }

  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(_ottProviderPaymentMethod, req.user));
});

const ottProviderCheckPaymentMethod = catchAsync(async (req, res) => {
  const response = await ottProviderPaymentMethodRepository.ottProviderCheckPaymentMethod(req.body, req.user);
  res.send(TimezoneService.LocalizeObject(response, req.user));
});

const getOttProviderPaymentMethods = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'state', 'user', 'providerId']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await ottProviderPaymentMethodRepository.queryOttProviderPaymentMethods(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getUserOttProviderPaymentMethod = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role']);
  filter.author = req.user._id;
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await ottProviderPaymentMethodRepository.queryOttProviderPaymentMethods(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getOttProviderPaymentMethod = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const ottProviderPaymentMethod = await ottProviderPaymentMethodRepository.getOttProviderPaymentMethodById(
    req.params.ottProviderPaymentMethodId,
    options
  );
  if (!ottProviderPaymentMethod) {
    throw new ApiError(httpStatus.NOT_FOUND, 'OttProviderPaymentMethod not found');
  }
  res.send(TimezoneService.LocalizeObject(ottProviderPaymentMethod, req.user));
});

const updateOttProviderPaymentMethod = catchAsync(async (req, res) => {
  const paymentMethodId = req.params.ottProviderPaymentMethodId;
  const oldPaymentMethod = await ottProviderPaymentMethodRepository.getOttProviderPaymentMethodById(paymentMethodId);
  if (!oldPaymentMethod) throw new ApiError(400, `payment method not found with id: ${paymentMethodId}`);
  if (!oldPaymentMethod.providerId) throw new ApiError(400, `payment method has no providerId: ${paymentMethodId}`);
  const providerId = oldPaymentMethod.providerId.toString();
  let paymentMethod = req.body;
  paymentMethod.id = paymentMethodId;
  let _ottProviderPaymentMethod;
  const validMethod = await ottProviderPaymentMethodValidator(providerId, paymentMethod, req.user);
  if (validMethod.status) {
    paymentMethod = validMethod.paymentMethod;
    _ottProviderPaymentMethod = await ottProviderPaymentMethodRepository.updateOttProviderPaymentMethodById(
      paymentMethodId,
      paymentMethod
    );
  } else {
    throw new ApiError(400, `${validMethod.messages.toString()}`);
  }

  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(_ottProviderPaymentMethod, req.user));
});

const deleteOttProviderPaymentMethod = catchAsync(async (req, res) => {
  await ottProviderPaymentMethodRepository.deleteOttProviderPaymentMethodById(req.params.ottProviderPaymentMethodId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createOttProviderPaymentMethod,
  ottProviderCheckPaymentMethod,
  getOttProviderPaymentMethods,
  getOttProviderPaymentMethod,
  getUserOttProviderPaymentMethod,
  updateOttProviderPaymentMethod,
  deleteOttProviderPaymentMethod,
});
