const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { ottProviderConversationProviderRepository, ottProviderRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const TelegramService = require('../../../services/telegram/telegram.service');
const TwilioService = require('../../../services/sms/twilio.service');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const validateTwilio = async (twilioData) => {
  const response = { ...twilioData };
  const twilioResponse = await TwilioService.validateKey({
    sId: twilioData.sId,
    authToken: twilioData.authToken,
  });
  response.isValid = twilioResponse.status;
  return response;
};

const validateGateways = async (body) => {
  const response = {};
  // const paymentGateways = await ottProviderPaymentGatewayRepository.getOttProviderPaymentGatewayByProviderId(providerId);
  const telegramBody = body.telegram;
  const telegramArrive = !(typeof telegramBody?.authToken === 'undefined');

  if (telegramArrive) {
    const validationResponse = await TelegramService.validateToken(telegramBody?.authToken);
    telegramBody.isValid = validationResponse.status;
    telegramBody.info = validationResponse.info;
    response.telegramBody = telegramBody;
  }

  const viberBody = body.viber;
  const viberArrive = !(typeof viberBody?.authToken === 'undefined');

  if (viberArrive) {
    viberBody.isValid = true;
    response.viberBody = viberBody;
  }

  const twilioBody = body.twilio;
  const twilioArrive = !(typeof twilioBody?.authToken === 'undefined');

  if (twilioArrive) {
    const validatedTwilio = await validateTwilio(twilioBody);
    twilioBody.isValid = validatedTwilio.isValid;
    response.twilioBody = twilioBody;
  }
  return response;
};
const createOttProviderConversationProvider = catchAsync(async (req, res) => {
  const { telegramBody, viberBody, twilioBody } = await validateGateways(req.body);
  const { body } = req;
  if (telegramBody) {
    body.telegram = telegramBody;
  } else {
    delete body.telegram;
  }
  if (viberBody) {
    body.viber = viberBody;
  } else {
    delete body.viber;
  }
  if (twilioBody) {
    body.twilio = twilioBody;
  } else {
    delete body.twilio;
  }
  req.body.providerId = req.params.ottProviderId;
  const ottProviderConversationProvider =
    await ottProviderConversationProviderRepository.createOttProviderConversationProvider(body, req.user);
  await ottProviderRepository.updateOne(
    { _id: req.params.ottProviderId },
    {
      hasValidTelegramGateway: ottProviderConversationProvider?.telegram?.isValid || false,
      hasValidViberGateway: ottProviderConversationProvider?.viber?.isValid || false,
      hasValidTwilio: ottProviderConversationProvider?.twilio?.isValid || false,
    }
  );
  if (ottProviderConversationProvider?.telegram?.isValid) {
    this.eventBusService = serviceCollection.getService('publisherEventBusService');
    if (!this.eventBusService.isConnected) await this.eventBusService.connect();

    await this.eventBusService.send('telegram-bot', {
      action: 'run',
      providerId: ottProviderConversationProvider.providerId,
      credentials: ottProviderConversationProvider.telegram,
    });
  }

  if (ottProviderConversationProvider?.telegram && !ottProviderConversationProvider.telegram.isValid) {
    this.eventBusService = serviceCollection.getService('publisherEventBusService');
    if (!this.eventBusService.isConnected) await this.eventBusService.connect();

    await this.eventBusService.send('telegram-bot', {
      action: 'stop',
      providerId: ottProviderConversationProvider.providerId,
      credentials: ottProviderConversationProvider.telegram,
    });
  }
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(ottProviderConversationProvider, req.user));
});

const getOttProviderConversationProviders = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'state', 'user', 'providerId']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await ottProviderConversationProviderRepository.queryOttProviderConversationProviders(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getOttProviderConversationProvider = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  let ottProviderConversationProvider =
    await ottProviderConversationProviderRepository.getOttProviderConversationProviderByProviderId(
      req.params.ottProviderId,
      options
    );
  if (ottProviderConversationProvider && !ottProviderConversationProvider.length) {
    // throw new ApiError(httpStatus.NOT_FOUND, 'ottProviderConversationProvider not found');
    ottProviderConversationProvider = await ottProviderConversationProviderRepository.createOttProviderConversationProvider({
      providerId: req.params.ottProviderId,
    });
    res.send(TimezoneService.LocalizeObject(ottProviderConversationProvider, req.user));
  } else {
    res.send(TimezoneService.LocalizeObject(ottProviderConversationProvider[0], req.user));
  }
});

const updateOttProviderConversationProvider = catchAsync(async (req, res) => {
  const { telegramBody, viberBody, twilioBody } = await validateGateways(req.body);
  const { body } = req;
  if (telegramBody) {
    body.telegram = telegramBody;
  } else {
    delete body.telegram;
  }
  if (viberBody) {
    body.viber = viberBody;
  } else {
    delete body.viber;
  }
  if (twilioBody) {
    body.twilio = twilioBody;
  } else {
    delete body.twilio;
  }
  const oldApis = await ottProviderConversationProviderRepository.getOttProviderConversationProviderByProviderId(
    req.params.ottProviderId
  );
  if (oldApis && oldApis.length) {
    // throw new ApiError(httpStatus.NOT_FOUND, 'ottProviderConversationProvider not found');
    if (oldApis[0]?.telegram?.isValid && body?.telegram && !body.telegram.isValid) {
      this.eventBusService = serviceCollection.getService('publisherEventBusService');
      if (!this.eventBusService.isConnected) await this.eventBusService.connect();

      await this.eventBusService.send('telegram-bot', {
        action: 'stop',
        providerId: oldApis[0].providerId,
        credentials: oldApis[0].telegram,
      });
    }
  }
  const ottProviderConversationProvider =
    await ottProviderConversationProviderRepository.updateOttProviderConversationProviderById(
      req.params.ottProviderId,
      body
    );
  await ottProviderRepository.updateOne(
    { _id: req.params.ottProviderId },
    {
      hasValidTelegramGateway: ottProviderConversationProvider?.telegram?.isValid || false,
      hasValidViberGateway: ottProviderConversationProvider?.viber?.isValid || false,
      hasValidTwilio: ottProviderConversationProvider?.twilio?.isValid || false,
    }
  );
  if (ottProviderConversationProvider?.telegram?.isValid) {
    this.eventBusService = serviceCollection.getService('publisherEventBusService');
    if (!this.eventBusService.isConnected) await this.eventBusService.connect();

    await this.eventBusService.send('telegram-bot', {
      action: 'run',
      providerId: ottProviderConversationProvider.providerId,
      credentials: ottProviderConversationProvider.telegram,
    });
  }
  res.send(TimezoneService.LocalizeObject(ottProviderConversationProvider, req.user));
});

const deleteOttProviderConversationProvider = catchAsync(async (req, res) => {
  await ottProviderConversationProviderRepository.deleteOttProviderConversationProviderById(
    req.params.ottProviderConversationProviderId
  );
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createOttProviderConversationProvider,
  getOttProviderConversationProviders,
  getOttProviderConversationProvider,
  updateOttProviderConversationProvider,
  deleteOttProviderConversationProvider,
});
