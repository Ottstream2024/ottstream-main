const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
// const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { paymentImplementations } = require('../../../config/payment_implementations');
const { ottProviderPaymentGatewayRepository } = require('../../../repository');
const { ottProviderRepository } = require('../../../repository');
const ApiError = require('../../utils/error/ApiError');
const serviceCollection = require('../../../services/service_collection');
const CardService = require('../../../services/payment/card.service');
const CloverService = require('../../../services/payment/merchant/clover.service');
const SquareService = require('../../../services/payment/merchant/square.service');
const StripeService = require('../../../services/payment/merchant/stripe.service');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const validateGateways = async (body, providerId) => {
  const response = {};
  const paymentGateways = await ottProviderPaymentGatewayRepository.getOttProviderPaymentGatewayByProviderId(providerId);
  const paymentGateway = paymentGateways.length ? paymentGateways[0] : null;
  const authorizeBody = body.authorize;
  const authorizeArrive =
    !(typeof authorizeBody?.apiLoginId === 'undefined') && !(typeof authorizeBody?.transactionKey === 'undefined');
  const stripeBody = body.stripe;
  const stripeArrive = !(typeof stripeBody?.secretKey === 'undefined');
  const cloverBody = body.clover;
  const cloverArrive = !(typeof cloverBody?.secretKey === 'undefined' || typeof cloverBody?.merchantId === 'undefined');

  const squareBody = body.square;
  const squareArrive = !(typeof squareBody?.secretKey === 'undefined' || typeof squareBody?.applicationId === 'undefined');

  if (authorizeArrive) {
    let needValidation = true;
    if (
      paymentGateway &&
      paymentGateway.authorize.apiLoginId === authorizeBody.apiLoginId &&
      paymentGateway.authorize.transactionKey === authorizeBody.transactionKey
    ) {
      needValidation = false;
    }

    if (needValidation) {
      const authorizeService = serviceCollection.getService('authorizeService');
      const authorizeValidationResponse = await authorizeService.validateKey(
        authorizeBody.apiLoginId,
        authorizeBody.transactionKey
      );
      authorizeBody.isValid = authorizeValidationResponse.status;
    } else {
      authorizeBody.isValid = paymentGateway.authorize?.isValid;
    }
    response.authorizeBody = authorizeBody;
  }
  if (stripeArrive) {
    let needValidation = true;
    if (paymentGateway && paymentGateway.stripe?.isValid && paymentGateway.stripe.secretKey === stripeBody.secretKey) {
      needValidation = false;
    }

    if (needValidation) {
      const stripeValidationResponse = await StripeService.validateKey(stripeBody.secretKey);
      stripeBody.isValid = stripeValidationResponse.status;
    } else {
      stripeBody.isValid = paymentGateway.stripe?.isValid;
    }
    response.stripeBody = stripeBody;
  }
  if (cloverArrive) {
    let needValidation = true;
    if (
      paymentGateway &&
      paymentGateway.clover.secretKey === cloverBody.secretKey &&
      paymentGateway.clover.merchantId === cloverBody.merchantId
    ) {
      needValidation = false;
    }

    if (needValidation) {
      const cloverValidationResponse = await CloverService.validateKey(cloverBody.secretKey, cloverBody.merchantId);
      cloverBody.isValid = cloverValidationResponse.status;
    } else {
      cloverBody.isValid = paymentGateway.clover?.isValid;
    }
    response.cloverBody = cloverBody;
  }
  if (squareArrive) {
    let needValidation = true;
    if (
      paymentGateway &&
      paymentGateway.square.secretKey === squareBody.secretKey &&
      paymentGateway.square.applicationId === squareBody.applicationId
    ) {
      needValidation = false;
    }

    if (needValidation) {
      const squareValidationResponse = await SquareService.validateKey(squareBody.secretKey, squareBody.applicationId);
      squareBody.isValid = squareValidationResponse.status;
    } else {
      squareBody.isValid = paymentGateway.square?.isValid;
    }
    response.squareBody = squareBody;
  }
  return response;
};

const createOttProviderPaymentGateway = catchAsync(async (req, res) => {
  const { ottProviderId } = req.params;
  const { authorizeBody, stripeBody, paypalBody, cloverBody, squareBody } = await validateGateways(req.body, ottProviderId);
  const { body } = req;
  if (authorizeBody) {
    body.authorize = authorizeBody;
  } else {
    delete body.authorize;
  }
  if (stripeBody) {
    body.stripe = stripeBody;
  } else {
    delete body.stripe;
  }
  if (cloverBody) {
    body.clover = cloverBody;
  } else {
    delete body.clover;
  }
  if (squareBody) {
    body.square = squareBody;
  } else {
    delete body.square;
  }
  if (paypalBody) {
    body.paypal = paypalBody;
  } else {
    delete body.paypal;
  }
  if (
    !body?.square?.isValid &&
    !body?.clover?.isValid &&
    !body?.paypal?.isValid &&
    !body?.stripe?.isValid &&
    !body?.authorize?.isValid
  ) {
    body.cards = '';
    body.bank = '';
    body.autopay = '';
  }
  const ottProviderPaymentGateway = await ottProviderPaymentGatewayRepository.createOttProviderPaymentGateway(
    body,
    req.user
  );
  await ottProviderRepository.updateOne(
    { _id: req.params.ottProviderId },
    {
      hasValidPaymentGateway:
        ottProviderPaymentGateway?.authorize?.isValid ||
        ottProviderPaymentGateway?.clover?.isValid ||
        ottProviderPaymentGateway?.square?.isValid,
    }
  );
  res.status(httpStatus.CREATED).send(ottProviderPaymentGateway);
});

const getOttProviderPaymentGateways = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'state', 'user', 'providerId']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await ottProviderPaymentGatewayRepository.queryOttProviderPaymentGateways(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getOttProviderPaymentGatewayMethods = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['type']);
  const provider = await ottProviderRepository.getOttProviderById(req.params.providerId);
  if (!provider) throw new ApiError(400, `ottProvider not found`);
  const paymentGateWays = await ottProviderPaymentGatewayRepository.getOttProviderPaymentGatewayByProviderId(
    provider._id.toString()
  );
  const paymentGateway = paymentGateWays.length ? paymentGateWays[0] : null;
  const resultList = [];
  switch (filter) {
    case 0:
    case 1:
    case 2:
    default:
      [0, 1, 2].forEach((item) => {
        const method = {
          type: item,
          methods: [],
        };
        if (paymentGateway) {
          paymentImplementations.forEach((paymentImplementation) => {
            if (paymentImplementation.name === 'authorize' && !paymentGateway.authorize?.isValid) {
              return;
            }
            if (paymentImplementation.name === 'stripe' && !paymentGateway.stripe?.isValid) {
              return;
            }
            if (paymentImplementation.name === 'paypal' && !paymentGateway.paypal?.isValid) {
              return;
            }
            if (paymentImplementation.name === 'clover' && !paymentGateway.clover?.isValid) {
              return;
            }
            if (paymentImplementation.name === 'suqare' && !paymentGateway.square?.isValid) {
              return;
            }
            if (paymentImplementation.name === 'square' && !paymentGateway.square?.isValid) {
              return;
            }
            method.methods.push(paymentImplementation.name);
          });
        }
        resultList.push(method);
      });
      break;
  }
  // TODO send thoose implementation which key exists for ott provider
  res.send(TimezoneService.LocalizeObject(resultList, req.user));
});

const getOttProviderPaymentGateway = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  let ottProviderPaymentGateway = await ottProviderPaymentGatewayRepository.getOttProviderPaymentGatewayByProviderId(
    req.params.ottProviderId,
    options
  );
  if (ottProviderPaymentGateway && !ottProviderPaymentGateway.length) {
    // TODO validate payment gateway before create
    // throw new ApiError(httpStatus.NOT_FOUND, 'ottProviderPaymentGateway not found');
    ottProviderPaymentGateway = await ottProviderPaymentGatewayRepository.createOttProviderPaymentGateway({
      providerId: req.params.ottProviderId,
    });
    res.send(TimezoneService.LocalizeObject(ottProviderPaymentGateway, req.user));
  } else {
    res.send(TimezoneService.LocalizeObject(ottProviderPaymentGateway[0], req.user));
  }
});

const updateOttProviderPaymentGateway = catchAsync(async (req, res) => {
  const { ottProviderId } = req.params;
  const { authorizeBody, stripeBody, paypalBody, cloverBody, squareBody } = await validateGateways(req.body, ottProviderId);
  const { body } = req;
  if (authorizeBody) {
    body.authorize = authorizeBody;
  } else {
    delete body.authorize;
  }
  if (stripeBody) {
    body.stripe = stripeBody;
  } else {
    delete body.stripe;
  }
  if (cloverBody) {
    body.clover = cloverBody;
  } else {
    delete body.clover;
  }
  if (squareBody) {
    body.square = squareBody;
  } else {
    delete body.square;
  }
  if (paypalBody) {
    body.paypal = paypalBody;
  } else {
    delete body.paypal;
  }
  if (
    !body?.square?.isValid &&
    !body?.clover?.isValid &&
    !body?.paypal?.isValid &&
    !body?.stripe?.isValid &&
    !body?.authorize?.isValid
  ) {
    body.cards = '';
    body.bank = '';
    body.autopay = '';
  }
  const ottProviderPaymentGateway = await ottProviderPaymentGatewayRepository.updateOttProviderPaymentGatewayById(
    req.params.ottProviderId,
    body
  );
  await CardService.validateCards(req.params.ottProviderId);

  await ottProviderRepository.updateOne(
    { _id: req.params.ottProviderId },
    {
      hasValidPaymentGateway:
        ottProviderPaymentGateway?.authorize?.isValid ||
        ottProviderPaymentGateway?.clover?.isValid ||
        ottProviderPaymentGateway?.square?.isValid,
    }
  );
  // TODO validate payment gateway before create
  res.send(TimezoneService.LocalizeObject(ottProviderPaymentGateway, req.user));
});

const deleteOttProviderPaymentGateway = catchAsync(async (req, res) => {
  await ottProviderPaymentGatewayRepository.deleteOttProviderPaymentGatewayById(req.params.ottProviderPaymentGatewayId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createOttProviderPaymentGateway,
  getOttProviderPaymentGateways,
  getOttProviderPaymentGatewayMethods,
  getOttProviderPaymentGateway,
  updateOttProviderPaymentGateway,
  deleteOttProviderPaymentGateway,
});
