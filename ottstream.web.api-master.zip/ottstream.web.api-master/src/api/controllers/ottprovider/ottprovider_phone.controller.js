const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { ottProviderPhoneRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const OttSyncService = require('../../../services/sync/ott_provider/ott_sync.service');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createOttProviderPhone = catchAsync(async (req, res) => {
  const ottProviderPhone = await ottProviderPhoneRepository.createOttProviderPhone(req.body, req.user);
  await OttSyncService.markToSync(ottProviderPhone?.providerId, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(ottProviderPhone, req.user));
});

const ottProviderCheckPhone = catchAsync(async (req, res) => {
  const response = await ottProviderPhoneRepository.ottProviderCheckPhone(req.query, req.user);
  res.send(TimezoneService.LocalizeObject(response, req.user));
});

const getOttProviderPhones = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'state', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  filter.providerId = req.user.provider._id.toString();
  const result = await ottProviderPhoneRepository.queryOttProviderPhones(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getUserOttProviderPhone = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role']);
  filter.author = req.user._id;
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await ottProviderPhoneRepository.queryOttProviderPhones(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getOttProviderPhone = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const ottProviderPhone = await ottProviderPhoneRepository.getOttProviderPhoneById(req.params.ottProviderPhoneId, options);
  if (!ottProviderPhone) {
    throw new ApiError(httpStatus.NOT_FOUND, 'OttProviderPhone not found');
  }
  res.send(TimezoneService.LocalizeObject(ottProviderPhone, req.user));
});

const updateOttProviderPhone = catchAsync(async (req, res) => {
  const ottProviderPhone = await ottProviderPhoneRepository.updateOttProviderPhoneById(
    req.params.ottProviderPhoneId,
    req.body
  );
  await OttSyncService.markToSync(ottProviderPhone?.providerId, req.user);
  res.send(TimezoneService.LocalizeObject(ottProviderPhone, req.user));
});

const deleteOttProviderPhone = catchAsync(async (req, res) => {
  const ottProviderPhone = await ottProviderPhoneRepository.deleteOttProviderPhoneById(req.params.ottProviderPhoneId);
  await OttSyncService.markToSync(ottProviderPhone?.providerId, req.user);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createOttProviderPhone,
  ottProviderCheckPhone,
  getOttProviderPhones,
  getOttProviderPhone,
  getUserOttProviderPhone,
  updateOttProviderPhone,
  deleteOttProviderPhone,
});
