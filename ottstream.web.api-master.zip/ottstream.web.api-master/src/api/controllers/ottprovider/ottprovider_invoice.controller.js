const httpStatus = require('http-status');
// eslint-disable-next-line no-unused-vars
const nodeHtmlToImage = require('node-html-to-image'); // TODO replace with normal lib
// eslint-disable-next-line no-unused-vars
const fs = require('fs');
const pick = require('../../../utils/helpers/pick');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { paymentImplementations } = require('../../../config/shipping_implementations');
const { ottProviderInvoiceRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const logger = require('../../../utils/logger/logger');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createOttProviderInvoice = catchAsync(async (req, res) => {
  req.body.providerId = req.params.ottProviderId;
  const ottProviderInvoice = await ottProviderInvoiceRepository.createOttProviderInvoice(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(ottProviderInvoice, req.user));
});

const getOttProviderInvoices = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'state', 'user', 'providerId']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await ottProviderInvoiceRepository.queryOttProviderInvoices(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getOttProviderInvoiceMethods = catchAsync(async (req, res) => {
  res.send(TimezoneService.LocalizeObject(paymentImplementations, req.user));
});

// eslint-disable-next-line no-unused-vars
const padTo2Digits = (date, format) => {
  const mnt = (date.getMonth() + 1).toString();
  const day = date.getDate().toString();
  const formatArr = format.split('/');
  const newDate = [];
  // eslint-disable-next-line no-plusplus
  for (let f = 0; f < formatArr.length; f++) {
    switch (formatArr[f]) {
      case 'dd':
        newDate.push(day.padStart(2, '0'));
        break;
      case 'mm':
        newDate.push(mnt.padStart(2, '0'));
        break;
      case 'yyyy':
        newDate.push(date.getFullYear());
        break;
      default:
        break;
    }
  }
  return newDate.join('/');
};

const printExampleInvoice = catchAsync(async (req, res) => {
  res.send(TimezoneService.LocalizeObject({}, req.user));

  // eslint-disable-next-line security/detect-non-literal-fs-filename
  /* fs.readFile(`${__dirname}/../../../config/templates/template1.html`, async (error, data) => {
    if (error) {
      throw error;
    }
    let html = data.toString();
    const invId = '626132826094e3b3f883a8a3';
    const fileName = `./storage/invoice_sample_${req.params.ottProviderId}.${req.query.type === 1 ? 'pdf' : 'png'}`;
    const invoice = await getInvoiceById(invId);
    const ottprovider = await getOttTabs(invoice.provider.toString(), {});
    const client = await clientRepository.getClientById(invoice.client.toString(), {});
    const ottProviderInvoice = await getOttProviderInvoiceByProviderId(req.params.ottProviderId);
    const ottName = ottprovider.name.filter((i) => i.lang === 'us');
    const ottAddress = ottprovider.addresses.filter((i) => i.isMain);
    const email = ottprovider.emails.filter((i) => i.forInvoice);
    const phone = ottprovider.phones.filter((i) => i.forInvoice);
    const clientAddress = client.addresses.filter((i) => i.forContactInvoice)[0];
    const quantity = 1;
    let subtotal = 0;
    const logoPath = `http://localhost:${config.port}/v1/files/icon/${ottProviderInvoice[0].design.logo.toString()}`;
    let tblBody = '';
    // eslint-disable-next-line no-plusplus
    for (let m = 0; m < invoice.payloadCalculated.locations.length; m++) {
      // eslint-disable-next-line no-plusplus
      for (let j = 0; j < invoice.payloadCalculated.locations[m].packages.length; j++) {
        tblBody +=
          // eslint-disable-next-line no-useless-concat
          `${'<tr style="border-bottom: 1px solid;">' + '<td>' + '<p>Package '}${j + 1}</p>` +
          `<p style="font-weight: 400">${
            invoice.payloadCalculated.locations[m].packages[j].packageName.filter((f) => f.lang === 'en')[0].name
          }</p>` +
          `</td>` +
          `<td style="font-size: 8px; font-weight: 400; color: #0A3C68; margin: 0">${quantity}</td>` +
          `<td>` +
          `<p style="font-size: 8px; font-weight: 400; color: #0A3C68; margin: 0">${invoice.payloadCalculated.locations[m].packages[j].totalPrice}</p>` +
          `</td>` +
          `<td style="font-size: 8px; font-weight: 400; color: #0A3C68; margin: 0">${
            invoice.payloadCalculated.locations[m].packages[j].totalPrice * quantity
          }</td>` +
          `</tr>`;
        subtotal += invoice.payloadCalculated.locations[m].packages[j].totalPrice * quantity;
      }
    }
    html = html.replace('{{TableBody}}', tblBody);
    html = html.replace('{{logo}}', logoPath);
    html = html.replace('{{company_name}}', ottName[0].name);
    html = html.replace('{{company_address}}', ottAddress[0].address);
    html = html.replace('{{company_phone}}', phone[0].number);
    html = html.replace('{{company_email}}', email[0].address);
    html = html.replace('{{inv_number}}', invoice.number);
    html = html.replace('{{company_website}}', ottprovider.website);
    html = html.replace('{{date}}', padTo2Digits(invoice.startDate, 'mm/dd/yyyy'));
    const expDate = new Date(invoice.startDate.setMonth(invoice.startDate.getMonth() + 1));
    html = html.replace('{{dueDate}}', padTo2Digits(expDate, 'yyyy/mm/dd'));
    //
    html = html.replace('{{client_address}}', clientAddress.address);
    html = html.replace('{{client_city}}', clientAddress.city);
    html = html.replace('{{client_province}}', clientAddress.province);
    html = html.replace('{{client_country}}', clientAddress.country);
    //
    html = html.replace('{{subtotal}}', subtotal);

    // const replacerIso = new RegExp('{{currency}}', 'g');
    const replacerColor = new RegExp('{{color}}', 'g');
    html = html.replace(replacerColor, '#d1049a');
    // html = html.replace(replacerIso, invoiceData.currency);

    if (req.query.type === 1) {
      const options = {
        width: '105mm',
        height: '125mm',
      };
      pdf.create(html, options).toFile(fileName, (err, pdfStream) => {
        if (err) {
          return res.sendStatus(500);
        }
        res.sendFile(pdfStream.filename);
      });
    } else {
      nodeHtmlToImage({
        html,
        type: 'png',
        output: fileName,
        quality: 100,
      }).then(() => {
        res.sendFile(fileName, { root: './' });
      });
    }
  }); */
});

const getInvoiceHtml = catchAsync(async (req, res) => {
  // eslint-disable-next-line security/detect-non-literal-fs-filename
  const html = fs.readFileSync(`${__dirname}/../../../config/templates/invoice1.html`);
  try {
    const response = {
      html: html.toString(),
    };
    res.send(response);
  } catch (e) {
    logger.error(e);
  }
});

const getOttProviderInvoice = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  let ottProviderInvoice = await ottProviderInvoiceRepository.getOttProviderInvoiceByProviderId(
    req.params.ottProviderId,
    options
  );
  if (ottProviderInvoice && !ottProviderInvoice.length) {
    // throw new ApiError(httpStatus.NOT_FOUND, 'ottProviderInvoice not found');
    ottProviderInvoice = await ottProviderInvoiceRepository.createOttProviderInvoice({
      providerId: req.params.ottProviderId,
    });
    res.send(TimezoneService.LocalizeObject(ottProviderInvoice, req.user));
  } else {
    res.send(TimezoneService.LocalizeObject(ottProviderInvoice[0], req.user));
  }
});

const updateOttProviderInvoice = catchAsync(async (req, res) => {
  const ottProviderInvoice = await ottProviderInvoiceRepository.updateOttProviderInvoiceById(
    req.params.ottProviderId,
    req.body
  );
  res.send(TimezoneService.LocalizeObject(ottProviderInvoice, req.user));
});

const deleteOttProviderInvoice = catchAsync(async (req, res) => {
  await ottProviderInvoiceRepository.deleteOttProviderInvoiceById(req.params.ottProviderInvoiceId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createOttProviderInvoice,
  getInvoiceHtml,
  getOttProviderInvoices,
  getOttProviderInvoiceMethods,
  getOttProviderInvoice,
  updateOttProviderInvoice,
  printExampleInvoice,
  deleteOttProviderInvoice,
});
