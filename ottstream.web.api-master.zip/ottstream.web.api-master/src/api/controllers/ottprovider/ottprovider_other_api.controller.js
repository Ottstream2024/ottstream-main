const httpStatus = require('http-status');
const { ApiError } = require('square');
const queue = require('queue');
const pick = require('../../../utils/helpers/pick');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { paymentImplementations } = require('../../../config/shipping_implementations');
const {
  ottProviderOtherApiRepository,
  ottProviderRepository,
  ottProviderConversationProviderRepository,
} = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const CheckeeperService = require('../../../services/payment/merchant/checkeeper.service');
const TwilioService = require('../../../services/sms/twilio.service');
const StreetService = require('../../../services/street/street.service');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const BroadcastService = require('../../../services/socket/broadcastService.service');
const logger = require('../../../utils/logger/logger');
const PostalMethodService = require('../../../services/postal/postal.service');

const smsSendQueue = queue({ results: [], autostart: true, timeout: 0, concurrency: 1 });
const depthExport = require('../../../services/export/depth.export');

// eslint-disable-next-line no-unused-vars
smsSendQueue.on('timeout', async (next, job) => {
  next();
});

// get notified when jobs complete
// eslint-disable-next-line no-unused-vars
smsSendQueue.on('success', async (result, job) => {
  // eslint-disable-next-line no-await-in-loop

  await BroadcastService.broadcastToUser(result.notifyToUser, 'sms-info', {
    status: result.status,
    message: result.message,
  });
});

const validateCheckeeper = async (data) => {
  const response = { ...data };
  const valdationResult = await CheckeeperService.isValidKey(data.apiToken, data.secret);
  response.isValid = valdationResult.status;
  return response;
};

const validateSmarty = async (data) => {
  const response = { ...data };
  const valdationResult = await StreetService.isValidKey(data.key);
  response.isValid = valdationResult.status;
  return response;
};

const validatePostal = async (data) => {
  const response = { ...data };
  const valdationResult = await PostalMethodService.GetBalance(data.secretKey);
  response.isValid = valdationResult.status;
  response.message = valdationResult.message;
  return response;
};

const createOttProviderOtherApi = catchAsync(async (req, res) => {
  req.body.providerId = req.params.ottProviderId;
  const saveObject = {};
  // checkeeper
  const { checkeeper } = req.body;
  if (checkeeper.apiToken) {
    const validatedCheckeeper = await validateCheckeeper(checkeeper);
    saveObject.checkeeper = validatedCheckeeper;
  }

  // checkeeper
  const { smarty } = req.body;
  if (smarty.key) {
    saveObject.smarty = smarty;
  }
  // postal
  const { postal } = req.body;
  if (postal.secretKey) {
    const validatedPostal = await validatePostal(postal);
    saveObject.postal = validatedPostal;
  }

  const ottProviderOtherApi = await ottProviderOtherApiRepository.createOttProviderOtherApi(req.body, req.user);

  await ottProviderRepository.updateOne(
    { _id: ottProviderOtherApi.providerId.toString() },
    {
      hasValidCheckeeper: ottProviderOtherApi?.checkeeper?.isValid,
      hasValidPostalMethods: ottProviderOtherApi?.postal?.isValid,
    }
  );
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(ottProviderOtherApi, req.user));
});

const getOttProviderOtherApis = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'state', 'user', 'providerId']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await ottProviderOtherApiRepository.queryOttProviderOtherApis(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getOttProviderOtherApiMethods = catchAsync(async (req, res) => {
  res.send(TimezoneService.LocalizeObject(paymentImplementations, req.user));
});

const getOttProviderOtherApi = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  let ottProviderOtherApi = await ottProviderOtherApiRepository.getOttProviderOtherApiByProviderId(
    req.params.ottProviderId,
    options
  );
  if (ottProviderOtherApi && !ottProviderOtherApi.length) {
    // throw new ApiError(httpStatus.NOT_FOUND, 'ottProviderOtherApi not found');
    ottProviderOtherApi = await ottProviderOtherApiRepository.createOttProviderOtherApi({
      providerId: req.params.ottProviderId,
    });
    res.send(TimezoneService.LocalizeObject(ottProviderOtherApi, req.user));
  } else {
    res.send(TimezoneService.LocalizeObject(ottProviderOtherApi[0], req.user));
  }
});

const updateOttProviderOtherApi = catchAsync(async (req, res) => {
  const { ottProviderId } = req.params;
  const otherApiGateways = await ottProviderOtherApiRepository.getOttProviderOtherApiByProviderId(ottProviderId);
  const saveObject = {};
  if (!otherApiGateways.length) throw new ApiError('other api not found. create should be called');
  const oldOtherApi = otherApiGateways[0];
  // checkeeper
  const { checkeeper } = req.body;
  if (typeof checkeeper.apiToken !== 'undefined') {
    const validatedCheckeeper = await validateCheckeeper(checkeeper);
    saveObject.checkeeper = validatedCheckeeper;
  }
  // checkeeper
  const { smarty } = req.body;
  if (typeof smarty.key !== 'undefined') {
    saveObject.smarty = smarty;
  }
  if (typeof smarty.key !== 'undefined') {
    const validatedSmarty = await validateSmarty(smarty);
    saveObject.smarty = validatedSmarty;
  }
  // postal
  const { postal } = req.body;
  if (typeof postal.secretKey !== 'undefined') {
    const validatedPostal = await validatePostal(postal);
    saveObject.postal = validatedPostal;
  }

  // const ottProviderOtherApi = await ottProviderOtherApiRepository.updateOttProviderOtherApiById(
  //   req.params.ottProviderId,
  //   saveObject
  // );
  const ottProviderOtherApi = await ottProviderOtherApiRepository.updateOne({ _id: oldOtherApi._id.toString() }, saveObject);
  await ottProviderRepository.updateOne(
    { _id: ottProviderOtherApi.providerId.toString() },
    {
      hasValidCheckeeper: ottProviderOtherApi?.checkeeper?.isValid,
      hasValidPostalMethods: ottProviderOtherApi?.postal?.isValid,
    }
  );
  res.send(TimezoneService.LocalizeObject(ottProviderOtherApi, req.user));
});

const sendSignatureLinkWorker = async (req, phone, link) => {
  const response = { status: true };
  const interesetedProvider = req.user.provider.id;
  const currentProvider = await ottProviderRepository.getOttProviderById(interesetedProvider);
  let hasValidSmsProvider = false;
  const conversationApis = await ottProviderConversationProviderRepository.getOttProviderConversationProviderByProviderId(
    currentProvider.id
  );
  hasValidSmsProvider = conversationApis.length && conversationApis[0].twilio && conversationApis[0].twilio.isValid;
  const func = async (cb) => {
    const sendResponse = { status: true, message: '' };
    try {
      const currentConfigs = conversationApis[0].twilio;
      // eslint-disable-next-line no-undef
      const twilioResponse = await TwilioService.sendSms(
        {
          fromNumber: currentConfigs.fromNumber,
          toNumber: phone,
          body: `use this link to sign doc ${link}`,
        },
        {
          sId: currentConfigs.sId,
          authToken: currentConfigs.authToken,
        },
        {
          provider: currentProvider.id,
          user: req.user.id,
        }
      );
      sendResponse.status = twilioResponse.status;
      sendResponse.message = twilioResponse.message;
      sendResponse.data = twilioResponse.data;

      cb(null, {
        notifyToProvider: req.user.provider.id,
        notifyToUser: req.user.id,
        hasValidSmsProvider,
        twilioData: sendResponse.data,
        message: hasValidSmsProvider ? 'signature sms sent' : 'no sms provider setup',
        status: sendResponse.status,
      });
    } catch (ex) {
      cb(null, {
        notifyToProvider: req.user.provider.id,
        notifyToUser: req.user.id,
        message: ex.message ?? ex,
        status: false,
      });
    }
  };
  if (hasValidSmsProvider) {
    if (smsSendQueue.length) {
      logger.warn(`sms sending task is already running`);
      response.message = `sms in sending queue: please wait`;
    } else {
      smsSendQueue.push(func);
      response.message = `transaction have been added to sms queue`;
    }
  } else {
    response.message = `no sms probvder is setup`;
    response.noSetup = true;
  }
  return response;
};

const smsCheckeeperSignature = catchAsync(async (req, res) => {
  const response = await sendSignatureLinkWorker(req, req.body.phone, 'https://panel.ottstream.live/sign?as3232knsd');
  res.send(TimezoneService.LocalizeObject(response, req.user));
});

const deleteOttProviderOtherApi = catchAsync(async (req, res) => {
  await ottProviderOtherApiRepository.deleteOttProviderOtherApiById(req.params.ottProviderOtherApiId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  smsCheckeeperSignature,
  createOttProviderOtherApi,
  getOttProviderOtherApis,
  getOttProviderOtherApiMethods,
  getOttProviderOtherApi,
  updateOttProviderOtherApi,
  deleteOttProviderOtherApi,
});
