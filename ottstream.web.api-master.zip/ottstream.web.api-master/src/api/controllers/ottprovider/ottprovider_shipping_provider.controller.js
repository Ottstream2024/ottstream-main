const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { paymentImplementations } = require('../../../config/shipping_implementations');
const { ottProviderShippingProviderRepository, ottProviderRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const EasyshipService = require('../../../services/shiping/merchant/easyship.service');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const validateGateways = async (body) => {
  const response = {};
  // const paymentGateways = await ottProviderPaymentGatewayRepository.getOttProviderPaymentGatewayByProviderId(providerId);
  const easyshipBody = body.easyship;
  const easyshipArrive = !(typeof easyshipBody?.productionToken === 'undefined');

  if (easyshipArrive) {
    const balanceResponse = await EasyshipService.getBalance(easyshipBody?.productionToken);
    easyshipBody.isValid = balanceResponse.status;
    response.easyshipBody = easyshipBody;
  }
  return response;
};
const createOttProviderShippingProvider = catchAsync(async (req, res) => {
  const { easyshipBody } = await validateGateways(req.body);
  const { body } = req;
  if (easyshipBody) {
    body.easyship = easyshipBody;
  } else {
    delete body.easyship;
  }
  req.body.providerId = req.params.ottProviderId;
  const ottProviderShippingProvider = await ottProviderShippingProviderRepository.createOttProviderShippingProvider(
    body,
    req.user
  );
  await ottProviderRepository.updateOne(
    { _id: req.params.ottProviderId },
    { hasValidShippingGateway: ottProviderShippingProvider?.easyship?.isValid || false }
  );
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(ottProviderShippingProvider, req.user));
});

const getOttProviderShippingProviders = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'state', 'user', 'providerId']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await ottProviderShippingProviderRepository.queryOttProviderShippingProviders(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getOttProviderShippingProviderMethods = catchAsync(async (req, res) => {
  res.send(TimezoneService.LocalizeObject(paymentImplementations, req.user));
});

const getOttProviderShippingProvider = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  let ottProviderShippingProvider = await ottProviderShippingProviderRepository.getOttProviderShippingProviderByProviderId(
    req.params.ottProviderId,
    options
  );
  if (ottProviderShippingProvider && !ottProviderShippingProvider.length) {
    // throw new ApiError(httpStatus.NOT_FOUND, 'ottProviderShippingProvider not found');
    ottProviderShippingProvider = await ottProviderShippingProviderRepository.createOttProviderShippingProvider({
      providerId: req.params.ottProviderId,
    });
    res.send(TimezoneService.LocalizeObject(ottProviderShippingProvider, req.user));
  } else {
    res.send(TimezoneService.LocalizeObject(ottProviderShippingProvider[0], req.user));
  }
});

const updateOttProviderShippingProvider = catchAsync(async (req, res) => {
  const { easyshipBody } = await validateGateways(req.body);
  const { body } = req;
  if (easyshipBody) {
    body.easyship = easyshipBody;
  } else {
    delete body.easyship;
  }
  const ottProviderShippingProvider = await ottProviderShippingProviderRepository.updateOttProviderShippingProviderById(
    req.params.ottProviderId,
    body
  );
  await ottProviderRepository.updateOne(
    { _id: req.params.ottProviderId },
    { hasValidShippingGateway: ottProviderShippingProvider?.easyship?.isValid || false }
  );
  res.send(TimezoneService.LocalizeObject(ottProviderShippingProvider, req.user));
});

const deleteOttProviderShippingProvider = catchAsync(async (req, res) => {
  await ottProviderShippingProviderRepository.deleteOttProviderShippingProviderById(
    req.params.ottProviderShippingProviderId
  );
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createOttProviderShippingProvider,
  getOttProviderShippingProviders,
  getOttProviderShippingProviderMethods,
  getOttProviderShippingProvider,
  updateOttProviderShippingProvider,
  deleteOttProviderShippingProvider,
});
