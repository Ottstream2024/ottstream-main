const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { paymentImplementations } = require('../../../config/shipping_implementations');
const { ottProviderInfoRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const depthExport = require('../../../services/export/depth.export');

const TimezoneService = serviceCollection.getService('timezoneService', true);

const createOttProviderInfo = catchAsync(async (req, res) => {
  req.body.providerId = req.params.ottProviderId;
  const ottProviderInfo = await ottProviderInfoRepository.createOttProviderInfo(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(ottProviderInfo, req.user));
});

const getOttProviderInfos = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'state', 'user', 'providerId']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await ottProviderInfoRepository.queryOttProviderInfos(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getOttProviderInfoMethods = catchAsync(async (req, res) => {
  res.send(TimezoneService.LocalizeObject(paymentImplementations, req.user));
});

const getOttProviderInfo = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  let ottProviderInfo = await ottProviderInfoRepository.getOttProviderInfoByProviderId(req.params.ottProviderId, options);
  if (ottProviderInfo && !ottProviderInfo.length) {
    // throw new ApiError(httpStatus.NOT_FOUND, 'ottProviderInfo not found');
    ottProviderInfo = await ottProviderInfoRepository.createOttProviderInfo({
      providerId: req.params.ottProviderId,
    });
    res.send(TimezoneService.LocalizeObject(ottProviderInfo, req.user));
  } else {
    res.send(TimezoneService.LocalizeObject(ottProviderInfo[0], req.user));
  }
});

const updateOttProviderInfo = catchAsync(async (req, res) => {
  const ottProviderInfo = await ottProviderInfoRepository.updateOttProviderInfoById(req.params.ottProviderId, req.body);
  res.send(TimezoneService.LocalizeObject(ottProviderInfo, req.user));
});

const deleteOttProviderInfo = catchAsync(async (req, res) => {
  await ottProviderInfoRepository.deleteOttProviderInfoById(req.params.ottProviderInfoId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createOttProviderInfo,
  getOttProviderInfos,
  getOttProviderInfoMethods,
  getOttProviderInfo,
  updateOttProviderInfo,
  deleteOttProviderInfo,
});
