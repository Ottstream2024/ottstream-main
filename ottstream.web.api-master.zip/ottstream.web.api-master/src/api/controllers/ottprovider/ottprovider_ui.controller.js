const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { paymentImplementations } = require('../../../config/shipping_implementations');
const { ottProviderUiRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createOttProviderUi = catchAsync(async (req, res) => {
  req.body.providerId = req.params.ottProviderId;
  const ottProviderUi = await ottProviderUiRepository.createOttProviderUi(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(ottProviderUi, req.user));
});

const getOttProviderUis = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'state', 'user', 'providerId']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await ottProviderUiRepository.queryOttProviderUis(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getOttProviderUiMethods = catchAsync(async (req, res) => {
  res.send(TimezoneService.LocalizeObject(paymentImplementations, req.user));
});

const getOttProviderUi = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  let ottProviderUi = await ottProviderUiRepository.getOttProviderUiByProviderId(req.params.ottProviderId, options);
  if (ottProviderUi && !ottProviderUi.length) {
    // throw new ApiError(httpStatus.NOT_FOUND, 'ottProviderUi not found');
    ottProviderUi = await ottProviderUiRepository.createOttProviderUi({
      providerId: req.params.ottProviderId,
    });
    res.send(TimezoneService.LocalizeObject(ottProviderUi, req.user));
  } else {
    res.send(TimezoneService.LocalizeObject(ottProviderUi[0], req.user));
  }
});

const updateOttProviderUi = catchAsync(async (req, res) => {
  const ottProviderUi = await ottProviderUiRepository.updateOttProviderUiById(req.params.ottProviderId, req.body);
  res.send(TimezoneService.LocalizeObject(ottProviderUi, req.user));
});

const deleteOttProviderUi = catchAsync(async (req, res) => {
  await ottProviderUiRepository.deleteOttProviderUiById(req.params.ottProviderUiId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createOttProviderUi,
  getOttProviderUis,
  getOttProviderUiMethods,
  getOttProviderUi,
  updateOttProviderUi,
  deleteOttProviderUi,
});
