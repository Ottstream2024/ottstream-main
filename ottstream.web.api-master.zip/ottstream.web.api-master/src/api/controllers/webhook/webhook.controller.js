const httpStatus = require('http-status');
const catchAsync = require('../../../utils/helpers/catchAsync');
const logger = require('../../../utils/logger/logger');
const { shippingRepository } = require('../../../repository');
const ShippingService = require('../../../services/shiping/shipping.service');
const serviceCollection = require('../../../services/service_collection');

const twilio = catchAsync(async (req, res) => {
  try {
    this.eventBusService = serviceCollection.getService('publisherEventBusService');
    if (!this.eventBusService.isConnected) await this.eventBusService.connect();
    const contentType = req.get('Content-Type');
    logger.info(`twilioarrived ${contentType} ${JSON.stringify(req.body)}`);
    await this.eventBusService.send('twilio', {
      body: req.body,
    });
    res.type('text/html');
  } catch (ex) {
    logger.error(ex);
  }
  res.status(httpStatus.OK).send();
});

const telegram = catchAsync(async (req, res) => {
  try {
    this.eventBusService = serviceCollection.getService('publisherEventBusService');
    if (!this.eventBusService.isConnected) await this.eventBusService.connect();
    const contentType = req.get('Content-Type');
    logger.info(`webhookcontroller:telegram() time: ${new Date().getTime()} ms ${contentType} ${JSON.stringify(req.body)}`);
    // const telegramBotService = new TelegramBotService();
    // await telegramBotService.runBot();
    await this.eventBusService.send('telegram-bot', {
      body: {
        ...req.body,
        token: req.query.token,
      },
    });
    res.send({});
  } catch (ex) {
    logger.error(ex);
  }
  res.status(httpStatus.OK).send();
});

const messenger = catchAsync(async (req, res) => {
  logger.info(`messengerwebhook: ${JSON.stringify(req.body)}`);
  res.status(httpStatus.OK).send('EVENT_RECEIVED');
});

const messengerVerify = catchAsync(async (req, res) => {
  logger.info(`messengerwebhook: verify ${JSON.stringify(req.query)}`);

  // Parse the query params
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  // Check if a token and mode is in the query string of the request
  if (mode && token) {
    // Check the mode and token sent is correct
    if (mode === 'subscribe' && token === 'otttoken') {
      // Respond with the challenge token from the request
      res.status(200).send(challenge);
    } else {
      // Respond with '403 Forbidden' if verify tokens do not match
      res.sendStatus(403);
    }
  }
  res.status(httpStatus.OK).send();
});

const whatsapp = catchAsync(async (req, res) => {
  logger.info(`whatsappwebhook: ${JSON.stringify(req.body)}`);
  res.status(httpStatus.OK).send('EVENT_RECEIVED');
});

const whatsappVerify = catchAsync(async (req, res) => {
  logger.info(`whatsappwebhook: verify ${JSON.stringify(req.query)}`);

  // Parse the query params
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  // Check if a token and mode is in the query string of the request
  if (mode && token) {
    // Check the mode and token sent is correct
    if (mode === 'subscribe' && token === 'otttoken') {
      // Respond with the challenge token from the request
      res.status(200).send(challenge);
    } else {
      // Respond with '403 Forbidden' if verify tokens do not match
      res.sendStatus(403);
    }
  }
  res.status(httpStatus.OK).send();
});

const instagram = catchAsync(async (req, res) => {
  logger.info(`instagramwebhook: ${JSON.stringify(req.body)}`);
  res.status(httpStatus.OK).send('EVENT_RECEIVED');
});

const instagramVerify = catchAsync(async (req, res) => {
  logger.info(`instagramwebhook: verify ${JSON.stringify(req.query)}`);

  // Parse the query params
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  // Check if a token and mode is in the query string of the request
  if (mode && token) {
    // Check the mode and token sent is correct
    if (mode === 'subscribe' && token === 'otttoken') {
      // Respond with the challenge token from the request
      res.status(200).send(challenge);
    } else {
      // Respond with '403 Forbidden' if verify tokens do not match
      res.sendStatus(403);
    }
  }
  res.status(httpStatus.OK).send();
});

const testHook = catchAsync(async (req, res) => {
  logger.info(`testhookarrived ${JSON.stringify(req.body)}`);
  res.type('application/json');
  res.send({ status: true });
});

const easyship = catchAsync(async (req, res) => {
  logger.info(`webhook arrived easyship ${JSON.stringify(req.body)}`);
  logger.info(req.body);
  if (req.body.event_type) {
    const resourceId = req.body.resource_id;
    if (resourceId) {
      const shippings = await shippingRepository.getAll({ easyship_shipment_id: resourceId });
      if (shippings.length === 1) {
        await ShippingService.syncEasyshipShippings(shippings[0].providerId.toString());
      } else {
        logger.info(`shipping not found easyship shipment.label.created webhook ${resourceId}`);
      }
    }
  }
  // await twilioProcess(req.body);
  res.status(httpStatus.OK);
});

module.exports = {
  testHook,
  twilio,
  telegram,
  messenger,
  messengerVerify,
  easyship,
  whatsapp,
  whatsappVerify,
  instagram,
  instagramVerify,
};
