const httpStatus = require('http-status');
const queue = require('queue');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { clientUsedDeviceRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const { deviceOptionRepository } = require('../../../repository');
const LocationSyncService = require('../../../services/sync/location/location_sync.service');
const { clientLocationRepository } = require('../../../repository');
const logger = require('../../../utils/logger/logger');
const BroadcastService = require('../../../services/socket/broadcastService.service');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

// eslint-disable-next-line camelcase
const locationSyncQueue = queue({ results: [], autostart: true, timeout: 0, concurrency: 1 });

locationSyncQueue.on('timeout', function (next, job) {
  logger.warn('task timed out:', job.toString().replace(/\n/g, ''));
  next();
});

// get notified when jobs complete
locationSyncQueue.on('success', async (result, job) => {
  logger.info('location sync task finished processing:', job.toString().replace(/\n/g, ''));
  // logger.info('The result is:', result);

  if (result.clientId) {
    // notifiction
    await BroadcastService.broadcastToGroup(
      `client-useddevice-info-${result.clientId}`,
      `client-useddevice-info-${result.clientId}`,
      {
        action: 'getUsedDevice',
      }
    );
  }
});

const prettifyUsedDevice = (current) => {
  return {
    information: {
      _id: current._id,
      lastActiveTime: current.lastActiveTime,
      type: current.type,
      model: current.model,
      modelCode: current.modelCode,
      providerName: current.providerName,
      manufacturer: current.manufacturer,
      ipAddress: current.ipAddress,
      geoIpInfo: current.geoIpInfo,
      macAddress: current.macAddress,
      serialN: current.serialN,
      appVersion: current.appVersion,
      userAgent: current.userAgent,
      lastUpdate: current.lastUpdate,
      clientId: current.clientId,
      locationId: current.locationId,
    },
    settings: {
      timeShift: current.timeShift,
      language: current.language,
      remoteControl: current.remoteControl,
      audioTrackDefault: current.audioTrackDefault,
      httpCaching: current.httpCaching,
      streamQuality: current.streamQuality,
      isSD: current.isSD,
      isHD: current.isHD,
      isFHD: current.isFHD,
      isUHD: current.isUHD,
      isBackgroundPlayer: current.isBackgroundPlayer,
      uiFontSize: current.uiFontSize,
    },
    statistics: current.cdn_sessions || [],
  };
};

const createClientUsedDevice = catchAsync(async (req, res) => {
  const { body } = req;
  body.locationId = req.params.locationId;
  const clientUsedDevice = await clientUsedDeviceRepository.createClientUsedDevice(body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(clientUsedDevice, req.user));
});

const getClientUsedDevices = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  options.sortBy = '_id:desc';
  const result = await clientUsedDeviceRepository.queryClientUsedDevices(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const syncUsedDeviceCdn = catchAsync(async (req, res) => {
  const { usedDeviceId } = req.body;
  const clientUsedDevices = await clientUsedDeviceRepository.getClientUsedDevicesByLocationId(req.params.locationId, {});
  const results = [];
  const currentUsedDevice = clientUsedDevices.filter((r) => r.id === usedDeviceId)[0];
  if (!currentUsedDevice) {
    throw new ApiError(400, `used device ${usedDeviceId} not found`);
  }
  const { locationId } = req.params;
  const func = async (cb) => {
    try {
      const location = await clientLocationRepository.getClientLocationById(locationId);
      if (!location) throw new ApiError(404, `location not found`);
      await LocationSyncService.syncCdnSessions(location.login, currentUsedDevice.roomN);

      cb(null, {
        clientId: location.clientId?.id,
        notifyToProvider: location.clientId?.provider?.toString(),
        status: true,
      });
    } catch (ex) {
      cb(null, {
        status: true,
      });
    }
  };
  locationSyncQueue.push(func);
  res.send(TimezoneService.LocalizeObject(results, req.user));
});

const getClientUsedDevice = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang', 'sortBy', 'syncCdn']);
  const clientUsedDevice = await clientUsedDeviceRepository.getClientUsedDevicesByLocationId(req.params.locationId, options);
  const results = [];
  clientUsedDevice.forEach((current) => {
    results.push(prettifyUsedDevice(current));
  });
  if (!results) {
    throw new ApiError(httpStatus.NOT_FOUND, 'ClientUsedDevices not found');
  }

  if (options.syncCdn) {
    const { locationId } = req.params;
    const func = async (cb) => {
      try {
        const location = await clientLocationRepository.getClientLocationById(locationId);
        if (!location) throw new ApiError(404, `location not found`);
        await LocationSyncService.syncLocation(location.login, false);

        cb(null, {
          clientId: location.clientId?.id,
          notifyToProvider: location.clientId?.provider?.toString(),
          status: true,
        });
      } catch (ex) {
        cb(null, {
          status: true,
        });
      }
    };
    // if (locationSyncQueue.length) {
    //   logger.warn(`location sync task is already running`);
    // } else {
    //   locationSyncQueue.push(func);
    // }
    locationSyncQueue.push(func);
  }
  res.send(TimezoneService.LocalizeObject(results, req.user));
});

const updateClientUsedDevice = catchAsync(async (req, res) => {
  const saveBody = { ...req.body };
  if (saveBody.settings) {
    saveBody.settings.lastUpdate = new Date().getTime() / 1000;
  }
  const clientUsedDevice = await clientUsedDeviceRepository.updateClientUsedDeviceById(
    req.body.id,
    saveBody.settings ? saveBody.settings : {}
  );

  const { locationId } = clientUsedDevice;
  const func = async (cb) => {
    try {
      const location = await clientLocationRepository.getClientLocationById(locationId);
      if (!location) throw new ApiError(404, `location not found`);
      await LocationSyncService.syncLocation(location.login, false);

      cb(null, {
        clientId: location.clientId?.id,
        notifyToProvider: location.clientId?.provider?.toString(),
        status: true,
      });
    } catch (ex) {
      cb(null, {
        status: true,
      });
    }
  };
  if (locationSyncQueue.length) {
    logger.warn(`location sync task is already running`);
  } else {
    locationSyncQueue.push(func);
  }

  res.send(TimezoneService.LocalizeObject(prettifyUsedDevice(clientUsedDevice), req.user));
});

const updateClientAllUsedDevice = catchAsync(async (req, res) => {
  // eslint-disable-next-line no-restricted-syntax
  for (const item of req.body) {
    // eslint-disable-next-line no-restricted-syntax
    for (let device of item.usedDevices) {
      device.lastUpdate = new Date().getTime() / 1000;
      // eslint-disable-next-line no-await-in-loop
      device = await clientUsedDeviceRepository.updateClientUsedDeviceById(device.id, device);
    }
  }
  res.send(TimezoneService.LocalizeObject(req.body, req.user));
});

const deleteClientUsedDevice = catchAsync(async (req, res) => {
  await clientUsedDeviceRepository.deleteClientUsedDeviceById(req.params.clientUsedDeviceId);
  res.status(httpStatus.NO_CONTENT).send();
});

const getOptions = catchAsync(async (req, res) => {
  const options = await deviceOptionRepository.getDeviceOptions();
  const returnOptions = {
    http_caching: options?.http_caching.map((r) => ({
      value: r.id.toString(),
      name: r.value,
    })),
    bitrate: options?.bitrate.map((r) => ({
      value: r.id.toString(),
      name: `${r.name} - ${r.value}`,
    })),
    servers: options?.servers.map((r) => ({
      value: r.id.toString(),
      name: `${r.name}`,
    })),
    audiotrack_default: options?.audiotrack_default.map((r) => ({
      value: r.id.toString(),
      name: `${r.name}`,
    })),
    definition_filter: options?.definition_filter.map((r) => ({
      value: r.val.toString(),
      name: `${r.name}`,
    })),
    stream_quality: options?.stream_quality.map((r) => ({
      value: r.val.toString(),
      name: `${r.name}`,
    })),
    background_player: options?.background_player.map((r) => ({
      value: r.val.toString(),
      name: `${r.name}`,
    })),
    ui_font_size: options?.ui_font_size.map((r) => ({
      value: r.val.toString(),
      name: `${r.name}`,
    })),
    box_models: options?.box_models.map((r) => ({
      value: r.id.toString(),
      name: `${r.name}`,
    })),
    lang: options?.lang.map((r) => ({
      value: r.id.toString(),
      name: `${r.value}`,
    })),
  };
  res.send(returnOptions);
});

module.exports = depthExport({
  getOptions,
  createClientUsedDevice,
  getClientUsedDevices,
  getClientUsedDevice,
  updateClientUsedDevice,
  syncUsedDeviceCdn,
  updateClientAllUsedDevice,
  deleteClientUsedDevice,
});
