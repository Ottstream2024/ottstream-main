const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { clientPaymentMethodRepository, clientRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const TransactionService = require('../../../services/payment/transaction.service');

const CardService = require('../../../services/payment/card.service');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const updateRecurringFinance = async (clientId) => {
  const client = await clientRepository.getClientById(clientId);
  if (client && client.finance && client.finance.forPackages && !client.finance.forPackages._id) {
    const finance = { ...client.finance.toJSON() };
    finance.forPackages = null;
    await clientRepository.updateOne({ _id: client.id }, { finance });
  }
};

const createClientPaymentMethod = catchAsync(async (req, res) => {
  let paymentMethod = req.body;
  const { clientId } = req.body;
  let _clientPaymentMethod;

  const validMethod = await CardService.clientPaymentMethodValidator(clientId, paymentMethod, req.user);

  if (validMethod.status) {
    paymentMethod = validMethod.paymentMethod;
    if (
      paymentMethod.creditCard &&
      paymentMethod.creditCard.billingAddress &&
      paymentMethod.creditCard.phone &&
      paymentMethod.creditCard.number
    ) {
      paymentMethod.creditCard.billingAddress.phone = paymentMethod.creditCard.billingAddress.phone.number;
    }

    const syncResult = await CardService.syncCard(clientId, paymentMethod);
    if (!syncResult.status) {
      throw new ApiError(400, syncResult.messages.toString());
    }
    syncResult.paymentObject.isValid = syncResult.isValid;
    syncResult.paymentObject.validationMessage = syncResult.messages.toString();
    syncResult.paymentObject.creditCard = TransactionService.hideCard(syncResult.paymentObject.creditCard);
    _clientPaymentMethod = await clientPaymentMethodRepository.createClientPaymentMethod(syncResult.paymentObject, req.user);
    _clientPaymentMethod = _clientPaymentMethod.toJSON();
    await updateRecurringFinance();
  } else {
    throw new ApiError(400, `${validMethod.messages.toString()}`);
  }

  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(_clientPaymentMethod, req.user));
});

const getClientPaymentMethods = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'state', 'user', 'providerId']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await clientPaymentMethodRepository.queryClientPaymentMethods(filter, options);
  const response = [];
  result.results.forEach((item) => {
    const current = item.toJSON();
    if (current?.creditCard?.cardNumber) {
      current.creditCard.cardNumber = TransactionService.hideCardNumber(current.creditCard.cardNumber);
    }
    if (current?.creditCard?.cvc) {
      current.creditCard.cvc = TransactionService.hideCVC(current.creditCard.cardNumber);
    }
    response.push(current);
  });
  result.results = response;
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getClientPaymentMethod = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const clientPaymentMethod = await clientPaymentMethodRepository.getClientPaymentMethodById(
    req.params.clientPaymentMethodId,
    options
  );
  if (!clientPaymentMethod) {
    throw new ApiError(httpStatus.NOT_FOUND, 'ClientPaymentMethod not found');
  }
  const current = clientPaymentMethod.toJSON();
  if (current?.creditCard?.cardNumber) {
    current.creditCard.cardNumber = TransactionService.hideCardNumber(current.creditCard.cardNumber);
  }
  if (current?.creditCard?.cvc) {
    current.creditCard.cvc = TransactionService.hideCVC(current.creditCard.cvc);
  }
  res.send(TimezoneService.LocalizeObject(current, req.user));
});

const getClientPaymentMethodByClient = catchAsync(async (req, res) => {
  const options = pick(req.query, ['sortBy', 'lang']);
  const clientPaymentMethods = await clientPaymentMethodRepository.getClientPaymentMethodByClientId(
    req.params.clientId,
    options
  );
  if (!clientPaymentMethods) {
    throw new ApiError(httpStatus.NOT_FOUND, 'ClientPaymentMethod not found');
  }
  const response = [];
  clientPaymentMethods.forEach((item) => {
    const current = item.toJSON();
    if (current?.creditCard?.cardNumber) {
      current.creditCard.cardNumber = TransactionService.hideCardNumber(current.creditCard.cardNumber);
    }
    if (current?.creditCard?.cvc) {
      current.creditCard.cvc = TransactionService.hideCVC(current.creditCard.cvc);
    }
    response.push(current);
  });
  res.send(TimezoneService.LocalizeObject(response, req.user));
});

const updateClientPaymentMethod = catchAsync(async (req, res) => {
  let paymentMethod = req.body;
  let _clientPaymentMethod;

  const { clientPaymentMethodId } = req.params;
  const pamentMethod = await clientPaymentMethodRepository.getClientPaymentMethodById(clientPaymentMethodId);
  if (!pamentMethod) throw new ApiError(`client payment method not found ${clientPaymentMethodId}`);
  const validMethod = await CardService.clientPaymentMethodValidator(pamentMethod.clientId, paymentMethod, req.user);

  if (validMethod.status) {
    paymentMethod = validMethod.paymentMethod;
    if (
      paymentMethod.creditCard &&
      paymentMethod.creditCard.billingAddress &&
      paymentMethod.creditCard.phone &&
      paymentMethod.creditCard.number
    ) {
      paymentMethod.creditCard.billingAddress.phone = paymentMethod.creditCard.billingAddress.phone.number;
    }

    if (paymentMethod.cardNumber && paymentMethod.cvc) {
      const syncResult = await CardService.syncCard(pamentMethod.clientId, paymentMethod);
      if (!syncResult.status) {
        throw new ApiError(400, syncResult.messages.toString());
      }
      syncResult.paymentObject.isValid = syncResult.isValid;
      syncResult.paymentObject.validationMessage = syncResult.messages.toString();
      syncResult.paymentObject.creditCard = TransactionService.hideCard(syncResult.paymentObject.creditCard);
      _clientPaymentMethod = await clientPaymentMethodRepository.updateClientPaymentMethodById(
        req.params.clientPaymentMethodId,
        syncResult.paymentObject
      );
    } else {
      _clientPaymentMethod = await clientPaymentMethodRepository.updateClientPaymentMethodById(
        req.params.clientPaymentMethodId,
        { default: paymentMethod.default, inUse: paymentMethod.inUse }
      );
    }
    _clientPaymentMethod = _clientPaymentMethod.toJSON();
    await updateRecurringFinance();
  } else {
    throw new ApiError(400, `${validMethod.messages.toString()}`);
  }
  res.send(TimezoneService.LocalizeObject(_clientPaymentMethod, req.user));
});

const deleteClientPaymentMethod = catchAsync(async (req, res) => {
  const { clientPaymentMethodId } = req.params;
  const clientPaymentMethod = await clientPaymentMethodRepository.getClientPaymentMethodById(clientPaymentMethodId);
  if (!clientPaymentMethod) throw new ApiError(400, `payment method ${clientPaymentMethodId} not found`);
  const deleteResult = await CardService.deleteCard(clientPaymentMethod.clientId, clientPaymentMethod);
  if (!deleteResult.status) {
    throw new ApiError(400, deleteResult.messages.toString());
  }
  await clientPaymentMethodRepository.deleteClientPaymentMethodById(req.params.clientPaymentMethodId);
  await updateRecurringFinance();
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createClientPaymentMethod,
  getClientPaymentMethods,
  getClientPaymentMethod,
  getClientPaymentMethodByClient,
  updateClientPaymentMethod,
  deleteClientPaymentMethod,
});
