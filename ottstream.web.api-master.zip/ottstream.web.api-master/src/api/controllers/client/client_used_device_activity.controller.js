const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { clientUsedDeviceActivityRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const { deviceOptionRepository } = require('../../../repository');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const prettifyUsedDevice = (current) => {
  return {
    information: {
      _id: current._id,
      lastActiveTime: current.lastActiveTime,
      type: current.type,
      model: current.model,
      modelCode: current.modelCode,
      providerName: current.providerName,
      manufacturer: current.manufacturer,
      ipAddress: current.ipAddress,
      geoIpInfo: current.geoIpInfo,
      macAddress: current.macAddress,
      serialN: current.serialN,
      userAgent: current.userAgent,
      lastUpdate: current.lastUpdate,
      clientId: current.clientId,
      locationId: current.locationId,
    },
    settings: {
      timeShift: current.timeShift,
      language: current.language,
      remoteControl: current.remoteControl,
      audioTrackDefault: current.audioTrackDefault,
      httpCaching: current.httpCaching,
      streamQuality: current.streamQuality,
      isSD: current.isSD,
      isHD: current.isHD,
      isFHD: current.isFHD,
      isUHD: current.isUHD,
      isBackgroundPlayer: current.isBackgroundPlayer,
      uiFontSize: current.uiFontSize,
    },
  };
};

const createClientUsedDeviceActivity = catchAsync(async (req, res) => {
  const { body } = req;
  body.locationId = req.params.locationId;
  const clientUsedDeviceActivity = await clientUsedDeviceActivityRepository.createClientUsedDeviceActivity(body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(clientUsedDeviceActivity, req.user));
});

const getClientUsedDeviceActivitys = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  options.sortBy = '_id:desc';
  const result = await clientUsedDeviceActivityRepository.queryClientUsedDeviceActivitys(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getClientUsedDeviceActivityGraphData = catchAsync(async (req, res) => {
  // const filter = pick(req.query, ['name', 'role', 'user']);
  // const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const statisticsResponse = [];
  const date = new Date();
  // eslint-disable-next-line no-plusplus
  for (let i = 0; i < 30; i++) {
    const from = new Date(date);
    const to = new Date(date);
    from.setDate(date.getDay() + i);
    to.setDate(date.getDay() + i + 1);
    statisticsResponse.push({
      from,
      to,
      secondsActive: 300 + 10 * i,
    });
  }
  res.send(TimezoneService.LocalizeObject(statisticsResponse, req.user));
});

const getClientUsedDeviceActivity = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang', 'sortBy']);
  const clientUsedDeviceActivity = await clientUsedDeviceActivityRepository.getClientUsedDeviceActivitysByLocationId(
    req.params.locationId,
    options
  );
  const results = [];
  clientUsedDeviceActivity.forEach((current) => {
    results.push(prettifyUsedDevice(current));
  });
  if (!results) {
    throw new ApiError(httpStatus.NOT_FOUND, 'ClientUsedDeviceActivitys not found');
  }
  res.send(TimezoneService.LocalizeObject(results, req.user));
});

const updateClientUsedDeviceActivity = catchAsync(async (req, res) => {
  const saveBody = { ...req.body };
  saveBody.lastUpdate = new Date().getTime() / 1000;
  const clientUsedDeviceActivity = await clientUsedDeviceActivityRepository.updateClientUsedDeviceActivityById(
    req.body.id,
    saveBody.settings ? saveBody.settings : {}
  );
  res.send(TimezoneService.LocalizeObject(prettifyUsedDevice(clientUsedDeviceActivity), req.user));
});

const updateClientAllUsedDevice = catchAsync(async (req, res) => {
  // eslint-disable-next-line no-restricted-syntax
  for (const item of req.body) {
    // eslint-disable-next-line no-restricted-syntax
    for (let device of item.usedDevices) {
      device.lastUpdate = new Date().getTime() / 1000;
      // eslint-disable-next-line no-await-in-loop
      device = await clientUsedDeviceActivityRepository.updateClientUsedDeviceActivityById(device.id, device);
    }
  }
  res.send(TimezoneService.LocalizeObject(req.body, req.user));
});

const deleteClientUsedDeviceActivity = catchAsync(async (req, res) => {
  await clientUsedDeviceActivityRepository.deleteClientUsedDeviceActivityById(req.params.clientUsedDeviceActivityId);
  res.status(httpStatus.NO_CONTENT).send();
});

const getOptions = catchAsync(async (req, res) => {
  const options = await deviceOptionRepository.getDeviceOptions();
  const returnOptions = {
    http_caching: options?.http_caching.map((r) => ({
      value: r.id.toString(),
      name: r.value,
    })),
    bitrate: options?.bitrate.map((r) => ({
      value: r.id.toString(),
      name: `${r.name} - ${r.value}`,
    })),
    servers: options?.servers.map((r) => ({
      value: r.id.toString(),
      name: `${r.name}`,
    })),
    audiotrack_default: options?.audiotrack_default.map((r) => ({
      value: r.id.toString(),
      name: `${r.name}`,
    })),
    definition_filter: options?.definition_filter.map((r) => ({
      value: r.val.toString(),
      name: `${r.name}`,
    })),
    stream_quality: options?.stream_quality.map((r) => ({
      value: r.val.toString(),
      name: `${r.name}`,
    })),
    background_player: options?.background_player.map((r) => ({
      value: r.val.toString(),
      name: `${r.name}`,
    })),
    ui_font_size: options?.ui_font_size.map((r) => ({
      value: r.val.toString(),
      name: `${r.name}`,
    })),
    box_models: options?.box_models.map((r) => ({
      value: r.id.toString(),
      name: `${r.name}`,
    })),
    lang: options?.lang.map((r) => ({
      value: r.id.toString(),
      name: `${r.value}`,
    })),
  };
  res.send(returnOptions);
});

module.exports = depthExport({
  getOptions,
  createClientUsedDeviceActivity,
  getClientUsedDeviceActivitys,
  getClientUsedDeviceActivityGraphData,
  getClientUsedDeviceActivity,
  updateClientUsedDeviceActivity,
  updateClientAllUsedDevice,
  deleteClientUsedDeviceActivity,
});
