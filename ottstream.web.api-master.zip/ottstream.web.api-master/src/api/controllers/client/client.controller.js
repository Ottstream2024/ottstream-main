/* eslint-disable no-await-in-loop */
const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { paymentMethodTypes } = require('../../../config/payment_methods');
const {
  creditRepository,
  clientPaymentMethodRepository,
  clientRepository,
  clientLocationRepository,
  ottProviderRepository,
  subscriptionRepository,
} = require('../../../repository');

const serviceCollection = require('../../../services/service_collection');
const LocationService = require('../../../services/location/LocationService.service');
const logger = require('../../../utils/logger/logger');
const CardService = require('../../../services/payment/card.service');
const StreetService = require('../../../services/street/street.service');
const BroadcastService = require('../../../services/socket/broadcastService.service');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const validateClientAddress = async (incomingAddresses) => {
  const addresses = incomingAddresses;

  const authData = {
    authId: '5b8ebc83-788c-d791-203e-a3ed479549ae',
    authToken: 'C40Fx0tmrPO39mIxNjQg',
    license: 'us-core-cloud',
  };
  const googleCred = { key: 'AIzaSyAij3x_iuPKGdiX7kOJT0oThOxuv9lOGJI' };

  // eslint-disable-next-line no-restricted-syntax
  for (const address of addresses) {
    if (address.country && address.country.toLowerCase() === 'us') {
      const validtaionResult = await StreetService.validateClientAddress(address, authData);
      if (validtaionResult.status === true) {
        address.isValid = validtaionResult.isValid;
        if (!validtaionResult.isValid) address.validationMessage = validtaionResult.validationMessages.toString();
        address.validationObject = {
          newaddress: validtaionResult.newAddress,
          oldAddress: validtaionResult.oldAddress,
        };
        if (address.validationObject.newaddress) {
          const imageResult = await StreetService.getMapImage(
            {
              lat: address.validationObject.newaddress.lat,
              long: address.validationObject.newaddress.long,
              address: `${address.validationObject?.newaddress?.address} ${
                address.validationObject?.newaddress?.suite || ''
              } ${address.validationObject?.newaddress?.city || ''} ${
                address.validationObject?.newaddress?.province || ''
              } ${address.validationObject?.newaddress?.zip || ''}`,
            },
            {},
            googleCred
          );
          if (imageResult.status) {
            address.image = imageResult.image;
          }
        }
      } else {
        logger.error(validtaionResult.messages.toString());
        if (address.address && address.city && address.province && address.zip) {
          address.isValid = true;
        } else {
          address.isValid = false;
          address.validationMessage = `missing required filed (US client but no smartstreet validation)`;
        }
      }
    } else if (address.address && address.city && address.province && address.zip) {
      address.isValid = true;
    } else {
      address.isValid = false;
      address.validationMessage = `missing required filed`;
    }
  }
  return addresses;
};

const getAddressImage = catchAsync(async (req, res) => {
  const response = { status: false, message: `` };
  const googleCred = { key: 'AIzaSyAij3x_iuPKGdiX7kOJT0oThOxuv9lOGJI' };

  const { lat, long, address } = req.body;
  const imageResult = await StreetService.getMapImage(
    {
      lat,
      long,
      address,
    },
    {},
    googleCred
  );
  if (imageResult.status) {
    response.status = true;
    response.image = imageResult.image;
  } else {
    response.message = imageResult.message;
  }
  res.status(httpStatus.OK).send(TimezoneService.LocalizeObject(response, req.user));
});

const createClient = catchAsync(async (req, res) => {
  if (req.body.addresses) req.body.addresses = await validateClientAddress(req.body.addresses);
  const channel = await clientRepository.createClient(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(channel, req.user));
});

const getClients = catchAsync(async (req, res) => {
  const filter = pick(req.query, [
    'excel',
    'search',
    'extendedType',
    'providerId',
    'parent',
    'paymentMethod',
    'balanceFrom',
    'balanceTo',
    'debtFrom',
    'debtTo',
    'subscriptionState',
    'creditAmountFrom',
    'creditAmountTo',
    'creditDateFrom',
    'creditDateTo',
    'creditAutoExtend',
    'creditDaysRemainingFrom',
    'creditDaysRemainingTo',
    'resellerId',
    'priceGroup',
    'currency',
    'isBlocked',
    'inPaused',
    'server',
    'timezone',
    'expireDate',
    'roomsCount',
    'login',
    'packageExpireDateFrom',
    'packageExpireDateTo',
    'activePackagesFrom',
    'activePackagesTo',
    'packageExpired', // sets the start date of the previous filter to -5 years
    'creditExpired', // sets the start date of the previous filter to -5 years
    'resellerClients',
    'ownClients',
    'autopayment',
    'statusFilterType',
  ]);
  const ownProviderId = req.user.provider.id;
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  filter.providers = [];
  if (req.query.providers) {
    const providers = await ottProviderRepository.getOttChilds([ownProviderId]); // TODO uncheck if works
    filter.providers = [];
    const incoming = req.query.providers.split(',');
    // eslint-disable-next-line no-restricted-syntax
    for (const incomingProvider of incoming) {
      if (providers.filter((r) => r.id === incomingProvider).length) {
        filter.providers.push(incomingProvider);
      }
    }
  }
  // if (filter.resellerClients) {
  // if (!filter.providerId) {
  //   const providers = await ottProviderRepository.getOttChilds([ownProviderId]); // TODO uncheck if works
  //   filter.providers = filter.providers.concat(providers.map((r) => r._id.toString()));
  //   // }
  // }

  // if (filter.providerId) {
  //   filter.providers.push(filter.providerId);
  // }
  if (!filter.providers.length) {
    filter.providers.push(ownProviderId);
  }

  let result = {};
  if (filter.extendedType) {
    result = await clientLocationRepository.queryLocations(filter, options, req.user);
  } else {
    result = await clientRepository.queryClients(filter, options, req.user);
  }
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportClientList(result.results, req.user, 'clientSettings', 'settingsExtended');
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  const start = new Date();
  res.send(TimezoneService.LocalizeObject(result, req.user));
  const end = new Date();
  logger.info(`localization duration ${end.getTime() - start.getTime()}`);
});

const getClientBySearch = catchAsync(async (req, res) => {
  // eslint-disable-next-line no-console
  console.time(`Execution Time`);
  const filter = pick(req.query, ['search', 'provider', 'login']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  filter.providers = [req.user.provider._id];
  const providers = await ottProviderRepository.getOttChilds([req.user.provider._id.toString()], null); // TODO uncheck if works
  filter.providers = filter.providers.concat(providers.map((r) => r.id));

  const result = await clientRepository.getClientsByName(filter, options, req.user);
  // eslint-disable-next-line no-console
  console.timeEnd(`Execution Time`);

  res.send(TimezoneService.LocalizeObject(result.results, req.user));
});

const getUserClient = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role']);
  filter.author = req.user._id;
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await clientRepository.queryClients(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getClient = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const client = await clientRepository.getClientById(req.params.clientId, options);
  if (!client) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Client not found');
  }
  const clientJson = client.toJSON();
  const pauseCount = client.locations.filter((r) => r.isPauseSubscriptions).length;
  const blockCount = client.locations.filter((r) => r.isBlockLocation).length;
  let inPause = 0;
  if (pauseCount !== 0) {
    if (pauseCount === client.locations.length) {
      inPause = 1;
    } else {
      inPause = 2;
    }
  }
  // eslint-disable-next-line no-param-reassign
  clientJson.inPause = inPause;
  let inBlock = 0;
  if (blockCount !== 0) {
    if (blockCount === client.locations.length) {
      inBlock = 1;
    } else {
      inBlock = 2;
    }
  }
  // eslint-disable-next-line no-param-reassign
  clientJson.inBlock = inBlock;
  res.send(TimezoneService.LocalizeObject(clientJson, req.user));
});

const getClientSettings = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await clientRepository.getClientSettingsById(req.params.clientId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Client not found');
  }
  res.send(TimezoneService.LocalizeObject(channel.settings, req.user));
});

const getClientBalanceCredit = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const client = await clientRepository.getClientById(req.params.clientId, options);
  if (!client) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Client not found');
  }
  let clientCredit = null;
  const filter = {
    clientId: client._id,
    state: 1,
  };
  clientCredit = await creditRepository.queryCredits(filter, options);
  // const credit = clientCredit.results.reduce((prev, next) => prev + next.creditAmount, 0);

  const response = {
    balance: client.balance,
    debt: client.debt,
    comment: client.comment,
    credit: clientCredit && clientCredit.results && clientCredit.results.length ? clientCredit.results[0] : null,
  };
  res.send(TimezoneService.LocalizeObject(response, req.user));
});

const updateClient = catchAsync(async (req, res) => {
  const client = await clientRepository.getClientById(req.params.clientId);
  if (!client) throw new ApiError(`client with id ${req.params.clientId} not found`);

  const { body } = req;
  if (body.addresses) body.addresses = await validateClientAddress(body.addresses);
  // address part
  if (body?.finance?.forPackages) {
    try {
      const paymentMethods = await clientPaymentMethodRepository.getClientPaymentMethodById(body.finance.forPackages);
      logger.info(`client: ${client.id} paymentmethods`);
      if (!paymentMethods) {
        throw new ApiError(`trying to save wrong card on finance recurring ${client.id}`);
      }
    } catch (ex) {
      throw new ApiError(`trying to save wrong card on finance recurring ${client.id}`);
    }
  }
  if (body.phones && body.phones.length) {
    const updatedPhones = client.phones.filter(
      (r) => body.phones.filter((a) => a.id === r.id && r.phone !== a.phone).length
    );
    if (updatedPhones.length) {
      // eslint-disable-next-line no-restricted-syntax
      for (const updatedPhone of updatedPhones) {
        const checkAddresses = client.addresses.map((r) => r.toJSON());
        let phoneUpdated = false;
        // eslint-disable-next-line no-restricted-syntax
        for (let i = 0; i < checkAddresses.length; i += 1) {
          const address = checkAddresses[i];
          if (address.phone === updatedPhone.phone) {
            phoneUpdated = true;
            // eslint-disable-next-line no-unused-expressions
            checkAddresses[i].phone = body.phones.filter((r) => r.id === updatedPhone.id)[0].phone;
          }
        }
        if (phoneUpdated) body.addresses = checkAddresses;
      }
    }
  }
  const updatedClient = await clientRepository.updateClientById(req.params.clientId, body);
  if (req.body?.personalInfo?.provider && req.body?.personalInfo?.provider !== client.provider.id.toString()) {
    // case when client parent updated. update its cards.
    await CardService.validateCards(updatedClient.provider.id.toString(), updatedClient.id.toString());
    // broadcast info
    await BroadcastService.broadcastToUser(req.user.id, 'card-info', {
      status: true,
      message: `client provider updated. updaing card validity`,
    });
  }
  res.send(TimezoneService.LocalizeObject(updatedClient, req.user));
});

// get types for finance tab recurring payments
const paymentMethodsTypes = catchAsync(async (req, res) => {
  res.send(TimezoneService.LocalizeObject(paymentMethodTypes, req.user));
});

const updateClientSettings = catchAsync(async (req, res) => {
  const channel = await clientRepository.updateClientSettingsById(req.params.clientId, req.body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updateClientEmail = catchAsync(async (req, res) => {
  const clientEmail = await clientRepository.updateClientEmailById(req.params.clientId, req.body);
  res.send(TimezoneService.LocalizeObject(clientEmail, req.user));
});

const clientActionSettings = catchAsync(async (req, res) => {
  const locationsToUpdate = req.body.locations;
  const clientsToUpdate = req.body.clients;
  const { inPaused, isBlocked, server } = req.body;

  let locationUpdates = [];
  if (clientsToUpdate?.length) {
    // eslint-disable-next-line no-restricted-syntax
    for (const clientid of clientsToUpdate) {
      // eslint-disable-next-line no-await-in-loop
      const clientLocations = await clientLocationRepository.getClientLocationByClientId(clientid);
      locationUpdates = locationUpdates.concat(clientLocations);
    }
  }
  if (locationsToUpdate?.length) {
    // eslint-disable-next-line no-restricted-syntax
    for (const locationId of locationsToUpdate) {
      // eslint-disable-next-line no-await-in-loop
      const clientLocation = await clientLocationRepository.getClientLocationById(locationId);
      locationUpdates.push(clientLocation);
    }
  }
  // eslint-disable-next-line no-restricted-syntax,no-unused-vars
  for (const location of locationUpdates) {
    // update isBlocked
    if (typeof isBlocked !== 'undefined') {
      if (isBlocked !== location.isBlockLocation) {
        // do updates
        // eslint-disable-next-line no-await-in-loop
        await clientLocationRepository.updateClientLocationById(location._id.toString(), {
          isBlockLocation: isBlocked,
        });
      }
    }
    // update inPause
    if (typeof inPaused !== 'undefined') {
      if (inPaused !== location.isPauseSubscriptions) {
        // do updates
        // eslint-disable-next-line no-await-in-loop
        await LocationService.UpdateLocationPause(location._id.toString(), inPaused);
      }
    }
    // update server
    if (typeof server !== 'undefined') {
      if (server !== location.server) {
        // do updates
        // eslint-disable-next-line no-await-in-loop
        await clientLocationRepository.updateClientLocationById(location._id.toString(), {
          server,
        });
      }
    }
  }

  res.send(TimezoneService.LocalizeObject({}, req.user));
});

const clientCheckEmailPhone = catchAsync(async (req, res) => {
  const response = await clientRepository.clientCheckEmailPhone(req.body);
  res.send(TimezoneService.LocalizeObject(response, req.user));
});

const deleteClient = catchAsync(async (req, res) => {
  const { clientId } = req.params;
  const client = await clientRepository.getClientById(clientId);
  if (!client) throw new ApiError(httpStatus.NOT_FOUND, 'Client not found');
  // check if client has balance, depts or subscriptions
  const activeSubscriptions = await subscriptionRepository.getList({
    client: clientId,
    state: 1,
  });
  if (activeSubscriptions.length)
    throw new ApiError(httpStatus.BAD_REQUEST, `Client has ${activeSubscriptions.length} active subscriptions`);
  if (client.balance !== 0 || client.debt !== 0)
    throw new ApiError(httpStatus.BAD_REQUEST, `Client has balance: ${client.balance} or debt: ${client.dept} problems`);
  await clientRepository.deleteClientById(req.params.clientId);
  res.status(httpStatus.NO_CONTENT).send();
});

const clientActionDelete = catchAsync(async (req, res) => {
  await clientRepository.clientActionDeleteById(req.body);
  res.status(httpStatus.NO_CONTENT).send();
});

const getDeletedClients = catchAsync(async (req, res) => {
  const data = await clientRepository.getDeletedList(req.query, req.user.provider._id);
  res.status(200).send(data);
});

module.exports = depthExport({
  createClient,
  getClients,
  getClientBySearch,
  getDeletedClients,
  getClient,
  getClientSettings,
  getClientBalanceCredit,
  getUserClient,
  clientActionSettings,
  updateClient,
  updateClientEmail,
  updateClientSettings,
  clientCheckEmailPhone,
  deleteClient,
  clientActionDelete,
  paymentMethodsTypes,
  getAddressImage,
});
