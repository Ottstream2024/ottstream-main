const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { ageGroupRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createAgeGroup = catchAsync(async (req, res) => {
  const channel = await ageGroupRepository.createAgeGroup(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(channel, req.user));
});

const getAgeGroups = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await ageGroupRepository.queryAgeGroups(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getUserAgeGroup = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role']);
  filter.author = req.user._id;
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  const result = await ageGroupRepository.queryAgeGroups(filter, options);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getAgeGroup = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await ageGroupRepository.getAgeGroupById(req.params.ageGroupId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'AgeGroup not found');
  }
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updateAgeGroup = catchAsync(async (req, res) => {
  const channel = await ageGroupRepository.updateAgeGroupById(req.params.ageGroupId, req.body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const deleteAgeGroup = catchAsync(async (req, res) => {
  await ageGroupRepository.deleteAgeGroupById(req.params.ageGroupId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createAgeGroup,
  getAgeGroups,
  getAgeGroup,
  getUserAgeGroup,
  updateAgeGroup,
  deleteAgeGroup,
});
