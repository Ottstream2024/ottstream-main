const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const {
  clientRepository,
  clientLocationRepository,
  subscriptionRepository,
  serverRepository,
  // packageRepository,
  // serverRepository,
  // subscriptionRepository,
} = require('../../../repository');
const { backupRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const LocationService = require('../../../services/location/LocationService.service');
const EmailService = require('../../../services/email/EmailService.service');
const LocationSyncService = require('../../../services/sync/location/location_sync.service');
const config = require('../../../config');
const logger = require('../../../utils/logger/logger');
const depthExport = require('../../../services/export/depth.export');

const TimezoneService = serviceCollection.getService('timezoneService', true);

const syncCdn = catchAsync(async (req, res) => {
  const { locationId } = req.params;
  const location = await clientLocationRepository.getClientLocationById(locationId);
  if (!location) throw new ApiError(404, `location not found`);
  await LocationSyncService.syncLocation(location.login);
  res.send({ success: true });
});

const changeServer = catchAsync(async (req, res) => {
  const servers = await serverRepository.getList({ status: 1 });
  const { hasServer, server } = req.body;
  const serverDict = servers.reduce((obj, item) => {
    // eslint-disable-next-line no-param-reassign
    obj[item._id.toString()] = item;
    return obj;
  }, {});
  // eslint-disable-next-line guard-for-in,no-restricted-syntax
  for (const clientId of req.body.clients) {
    // eslint-disable-next-line no-await-in-loop
    const clientLocations = await clientLocationRepository.getClientLocationByClientId(clientId);
    // eslint-disable-next-line no-restricted-syntax
    for (const clientLocation of clientLocations) {
      if (clientLocation.server && clientLocation.server.toString() === hasServer) {
        // eslint-disable-next-line no-await-in-loop
        await clientLocationRepository.updateClientLocationById(clientLocation._id.toString(), {
          syncState: 2,
          server: serverDict[server]._id.toString(),
        });
      }
    }
  }
  // await backupRepository.createBackup(
  //   {
  //     table: 'client_locations',
  //     state: 1,
  //     changes: [],
  //   },
  //   req.user
  // );
  res.send({ success: true });
});

const restoreServer = catchAsync(async (req, res) => {
  res.send({ success: true });
});

const getServerBackups = catchAsync(async (req, res) => {
  const response = [];
  const backup = await backupRepository.getBackups({
    table: 'client_locations',
    state: 1,
    provider: req.user.provider._id.toString(),
  });
  backup.forEach((item) => {
    response.push({
      name: `location backup - ${TimezoneService.LocalizeObject(item, req.user).updatedAt}`,
      value: `${item._id.toString()}`,
    });
  });
  res.send(TimezoneService.LocalizeObject(response, req.user));
});

const createClientLocation = catchAsync(async (req, res) => {
  const client = await clientRepository.getClientById(req.body.clientId);
  if (!client) {
    throw new ApiError(404, `api not found`);
  }
  const { body } = req;
  if (!client.provider) {
    throw new ApiError(400, `client has no provider`);
  }
  body.syncState = 1;
  body.provider = client.provider._id;
  let clientLocation = null;
  const clientLocationBody = req.body;
  if (config.getConfig().sync.generate_login) {
    const syncedData = await LocationSyncService.GenerateLocationLogin();
    if (syncedData && syncedData.login) {
      clientLocationBody.login = syncedData.login;
      clientLocationBody.password = syncedData.password;
      clientLocationBody.parentalCode = syncedData.pin_code;
      clientLocation = await clientLocationRepository.createClientLocation(clientLocationBody, req.geoIpInfo, req.user);
    } else {
      logger.warn(`error generating location login password through middleware`);
    }
  } else {
    clientLocationBody.parentalCode = clientLocationBody.password;
    clientLocation = await clientLocationRepository.createClientLocation(clientLocationBody, req.geoIpInfo, req.user);
    // create base demo subscription for location
  }
  // mark to sync
  if (clientLocation) {
    if (client.emails && client.emails.length) {
      await EmailService.sendEmail(
        client.emails[0].email,
        `location login pw: ${clientLocation.login} ${clientLocation.password}`
      );
    }
    await LocationSyncService.markToSync(clientLocation._id.toString(), true);

    // get base demo package
    // const basePackage = await packageRepository.getPackageByMiddlewareId(1);
    // const server = await serverRepository.getServerByMiddlewareId(1);
    // if (basePackage && server) {
    //   const locationWithClient = await clientLocationRepository.getClientLocationById(clientLocation._id);
    //   // subscribe location to package
    //   await subscriptionRepository.subscribeLocationToPackage(locationWithClient, basePackage, {
    //     day: 1,
    //     month: 0,
    //   });
    // }
  }
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(clientLocation, req.user));
});

const getClientLocations = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'lang']);
  const result = await clientLocationRepository.queryClientLocations(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getClientLocation = catchAsync(async (req, res) => {
  const clientLocation = await clientLocationRepository.getClientLocationById(req.params.clientLocationId);
  if (!clientLocation) {
    throw new ApiError(httpStatus.NOT_FOUND, 'ClientLocation not found');
  }
  res.send(TimezoneService.LocalizeObject(clientLocation, req.user));
});

const getClientLocationByClient = catchAsync(async (req, res) => {
  const clientLocation = await clientLocationRepository.getClientLocationByClientId(req.params.clientId);
  if (!clientLocation) {
    throw new ApiError(httpStatus.NOT_FOUND, 'ClientLocation not found');
  }
  res.send(TimezoneService.LocalizeObject(clientLocation, req.user));
});

const getClientLocationRandomLoginPassword = catchAsync(async (req, res) => {
  const clientLocation = await clientLocationRepository.getClientLocationLoginPassword(req.body);
  const email = await clientRepository.getClientEmailById(req.params.clientId);
  const name = await clientRepository.getClientFirstname(req.params.clientId);
  const client = await clientRepository.getClientById(req.params.clientId);
  if (email && name) {
    await EmailService.sendGenerateLoginPassword(
      email,
      clientLocation.password,
      clientLocation.login,
      name,
      client.provider.id
    );
  }
  res.send(clientLocation);
});

const updateClientLocation = catchAsync(async (req, res) => {
  const locationId = req.params.clientLocationId;
  let clientLocation = await clientLocationRepository.getClientLocationById(locationId);
  if (req.body.isPauseSubscriptions && clientLocation.isPauseSubscriptions !== req.body.isPauseSubscriptions) {
    await LocationService.UpdateLocationPause(locationId, req.body.isPauseSubscriptions);
  }
  const updateBody = req.body;
  if (updateBody.comment) {
    updateBody.commentUser = req.user._id.toString();
  }
  clientLocation = await clientLocationRepository.updateClientLocationById(locationId, req.body);
  // mark to sync
  await LocationSyncService.markToSync(clientLocation._id.toString(), true);
  res.send(TimezoneService.LocalizeObject(clientLocation, req.user));
});

const pauseClientLocation = catchAsync(async (req, res) => {
  const { locationId } = req.params;
  let clientLocation = await clientLocationRepository.getClientLocationById(locationId);
  if (clientLocation.isPauseSubscriptions !== req.body.pause) {
    clientLocation = await LocationService.UpdateLocationPause(locationId, req.body.pause);
  }
  // mark to sync
  await LocationSyncService.markToSync(clientLocation._id.toString(), true);
  res.send(TimezoneService.LocalizeObject(clientLocation, req.user));
});

const resetPassword = catchAsync(async (req, res) => {
  const location = await clientLocationRepository.getClientLocationById(req.params.clientLocationId);
  if (!location) {
    throw new ApiError(404, `location not found`);
  }
  const email = await clientRepository.getClientEmailById(req.body.clientId);
  const name = await clientRepository.getClientFirstname(req.body.clientId);
  await clientLocationRepository.updateClientLocationById(location._id.toString(), {
    password: req.body.password,
    parentalCode: req.body.password,
    lastChangePassword: new Date(),
  });
  if (email) {
    const client = await clientLocationRepository.getClientLocationById(req.params.clientLocationId);
    await EmailService.sendGenerateLoginPassword(email, req.body.password, req.body.login, name, client.clientId.provider);
  } else {
    logger.warn(`client has no email clientId: ${req.body.clientId}`);
  }
  // mark to sync
  await LocationSyncService.markToSync(location._id.toString(), true);
  res.send(TimezoneService.LocalizeObject({ success: true }, req.user));
});

const getClientLocationPackagesByRoom = catchAsync(async (req, res) => {
  const clientLocation = await clientLocationRepository.getClientLocationPackagesByRoom(
    req.params.clientLocationId,
    req.params.roomsCount,
    req.params.expireNew
  );
  res.send(TimezoneService.LocalizeObject(clientLocation, req.user));
});

const deleteClientLocation = catchAsync(async (req, res) => {
  const location = await clientLocationRepository.getClientLocationById(req.params.clientLocationId);
  if (!location) throw new ApiError(httpStatus.NOT_FOUND, `location not found`);
  // check if client has balance, depts or subscriptions
  const activeSubscriptions = await subscriptionRepository.getList({
    location: location._id.toString(),
    state: 1,
  });
  if (activeSubscriptions.length)
    throw new ApiError(httpStatus.BAD_REQUEST, `location has ${activeSubscriptions.length} active subscriptions`);
  await clientLocationRepository.deleteClientLocationById(req.params.clientLocationId);
  // mark to sync
  await LocationSyncService.markToSync(location._id.toString(), true);
  res.status(httpStatus.NO_CONTENT).send({ success: true });
});

module.exports = depthExport({
  syncCdn,
  changeServer,
  createClientLocation,
  getClientLocations,
  getClientLocationRandomLoginPassword,
  getClientLocation,
  getClientLocationPackagesByRoom,
  getClientLocationByClient,
  updateClientLocation,
  resetPassword,
  deleteClientLocation,
  pauseClientLocation,
  restoreServer,
  getServerBackups,
});
