const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { clientProfileRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');
const depthExport = require('../../../services/export/depth.export');

const TimezoneService = serviceCollection.getService('timezoneService', true);

const createClientProfile = catchAsync(async (req, res) => {
  const clientProfile = await clientProfileRepository.createClientProfile(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(clientProfile, req.user));
});

const getClientProfiles = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await clientProfileRepository.queryClientProfiles(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getClientProfile = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const clientProfile = await clientProfileRepository.getClientProfileById(req.params.clientProfileId, options);
  if (!clientProfile) {
    throw new ApiError(httpStatus.NOT_FOUND, 'ClientProfile not found');
  }
  res.send(TimezoneService.LocalizeObject(clientProfile, req.user));
});

const updateClientProfile = catchAsync(async (req, res) => {
  const clientProfile = await clientProfileRepository.updateClientProfileById(req.params.clientProfileId, req.body);
  res.send(TimezoneService.LocalizeObject(clientProfile, req.user));
});

const deleteClientProfile = catchAsync(async (req, res) => {
  await clientProfileRepository.deleteClientProfileById(req.params.clientProfileId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createClientProfile,
  getClientProfiles,
  getClientProfile,
  updateClientProfile,
  deleteClientProfile,
});
