const httpStatus = require('http-status');
const pick = require('../../../utils/helpers/pick');
const ApiError = require('../../utils/error/ApiError');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { clientPackageRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');

const TimezoneService = serviceCollection.getService('timezoneService', true);
const depthExport = require('../../../services/export/depth.export');

const createClientPackage = catchAsync(async (req, res) => {
  const channel = await clientPackageRepository.createClientPackage(req.body, req.user);
  res.status(httpStatus.CREATED).send(TimezoneService.LocalizeObject(channel, req.user));
});

const getClientPackages = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['name', 'role', 'user']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all', 'lang']);
  const result = await clientPackageRepository.queryClientPackages(filter, options, req.user);
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

const getClientPackage = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await clientPackageRepository.getClientPackageById(req.params.clientPackageId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'ClientPackage not found');
  }
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});
const getClientPackageByClient = catchAsync(async (req, res) => {
  const options = pick(req.query, ['lang']);
  const channel = await clientPackageRepository.getClientPackageByClientId(req.params.clientId, options);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'ClientPackage not found');
  }
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const updateClientPackage = catchAsync(async (req, res) => {
  const channel = await clientPackageRepository.updateClientPackageId(req.params.clientPackageId, req.body);
  res.send(TimezoneService.LocalizeObject(channel, req.user));
});

const deleteClientPackage = catchAsync(async (req, res) => {
  await clientPackageRepository.deleteClientPackageById(req.params.clientPackageId);
  res.status(httpStatus.NO_CONTENT).send();
});

module.exports = depthExport({
  createClientPackage,
  getClientPackages,
  getClientPackage,
  getClientPackageByClient,
  updateClientPackage,
  deleteClientPackage,
});
