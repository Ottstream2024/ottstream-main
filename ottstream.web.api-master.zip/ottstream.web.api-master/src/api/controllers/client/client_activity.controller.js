const pick = require('../../../utils/helpers/pick');
const catchAsync = require('../../../utils/helpers/catchAsync');
const { clientActivityRepository } = require('../../../repository');
const serviceCollection = require('../../../services/service_collection');

const { ottProviderRepository } = require('../../../repository');
const depthExport = require('../../../services/export/depth.export');

const TimezoneService = serviceCollection.getService('timezoneService', true);

const getClientActivitys = catchAsync(async (req, res) => {
  const filter = pick(req.query, ['type', 'search', 'excel', 'user', 'client', 'own', 'resellers', 'startDate', 'endDate']);
  const options = pick(req.query, ['sortBy', 'limit', 'page', 'all']);
  if (!req.params.user) filter.provider = req.user.provider._id.toString();
  else filter.user = req.params.user;

  const ownProviderId = req.user.provider.id;
  filter.baseprovider = ownProviderId;
  filter.providers = [];
  if (filter.resellers || filter.allResellers) {
    const providers = await ottProviderRepository.getOttChilds([ownProviderId]); // TODO uncheck if works
    if (filter.allResellers) {
      filter.providers = filter.providers.concat(providers.map((r) => r._id.toString()));
    } else {
      filter.providers = [];
      const incoming = filter.resellers.split(',');
      // eslint-disable-next-line no-restricted-syntax
      for (const incomingProvider of incoming) {
        if (providers.filter((r) => r._id.toString() === incomingProvider).length) {
          filter.providers.push(incomingProvider);
        }
      }
    }
  }
  if (filter.own || filter.allResellers || !filter.providers.length) {
    filter.providers.push(ownProviderId);
  }

  const result = await clientActivityRepository.queryClientActivitys(filter, options, req.user);
  if (filter.excel) {
    const excelService = serviceCollection.getService('excelService');
    const report = excelService.exportUserListTable(result.results, req.user, 'defaultSettings', 'defaultSettingsColumns');
    res.setHeader('content-disposition', 'attachment; filename=report.xlsx');
    return res.send(report);
  }
  res.send(TimezoneService.LocalizeObject(result, req.user));
});

module.exports = depthExport({
  getClientActivitys,
});
