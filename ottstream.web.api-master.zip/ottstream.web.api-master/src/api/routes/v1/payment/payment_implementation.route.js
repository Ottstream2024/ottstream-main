const express = require('express');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');
const paymentImplementationValidation = require('../../../validations/payment/payment_implementation.validation');
const paymentImplementationController = require('../../../controllers/payment/payment_implementation.controller');

const router = express.Router();

router
  .route('/')
  .post(
    auth({ roles: [], permissions: ['createPaymentImplementation'] }),
    validate(paymentImplementationValidation.createPaymentImplementation),
    paymentImplementationController.createPaymentImplementation
  )
  .get(
    validate(paymentImplementationValidation.getPaymentImplementations),
    paymentImplementationController.getPaymentImplementations
  );

router
  .route('/:paymentImplementationId')
  .get(
    auth({ roles: [], permissions: ['getPaymentImplementation'] }),
    validate(paymentImplementationValidation.getPaymentImplementation),
    paymentImplementationController.getPaymentImplementation
  )
  .patch(
    auth({ roles: [], permissions: ['updatePaymentImplementation'] }),
    validate(paymentImplementationValidation.updatePaymentImplementation),
    paymentImplementationController.updatePaymentImplementation
  )
  .delete(
    auth({ roles: [], permissions: ['deletePaymentImplementation'] }),
    validate(paymentImplementationValidation.deletePaymentImplementation),
    paymentImplementationController.deletePaymentImplementation
  );

// router
//   .route('/user')
//   .get(auth('getPaymentImplementations'), validate(paymentImplementationValidation.getPaymentImplementation), paymentImplementationController.getUserPaymentImplementation)

module.exports = router;

/**
 * @swagger
 * tags:
 *   name: PaymentImplementations
 *   description: PaymentImplementation management and retrieval
 */

/**
 * @swagger
 * path:
 *  /paymentImplementations:
 *    post:
 *      summary: Create a paymentImplementation
 *      description: Only admins can create other paymentImplementations.
 *      tags: [PaymentImplementations]
 *      security:
 *        - bearerAuth: []
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              required:
 *                - name
 *                - email
 *                - password
 *                - role
 *              properties:
 *                name:
 *                  type: string
 *                email:
 *                  type: string
 *                  format: email
 *                  description: must be unique
 *                password:
 *                  type: string
 *                  format: password
 *                  minLength: 8
 *                  description: At least one number and one letter
 *                role:
 *                   type: string
 *                   enum: [paymentImplementation, admin]
 *              example:
 *                name: fake name
 *                email: fake@example.com
 *                password: password1
 *                role: paymentImplementation
 *      responses:
 *        "201":
 *          description: Created
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/PaymentImplementation'
 *        "400":
 *          $ref: '#/components/responses/DuplicateEmail'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *
 *    get:
 *      summary: Get all paymentImplementations
 *      description: Only admins can retrieve all paymentImplementations.
 *      tags: [PaymentImplementations]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: query
 *          name: name
 *          schema:
 *            type: string
 *          description: PaymentImplementation name
 *        - in: query
 *          name: role
 *          schema:
 *            type: string
 *          description: PaymentImplementation role
 *        - in: query
 *          name: sortBy
 *          schema:
 *            type: string
 *          description: sort by query in the form of field:desc/asc (ex. name:asc)
 *        - in: query
 *          name: limit
 *          schema:
 *            type: integer
 *            minimum: 1
 *          default: 10
 *          description: Maximum number of paymentImplementations
 *        - in: query
 *          name: page
 *          schema:
 *            type: integer
 *            minimum: 1
 *            default: 1
 *          description: Page number
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                  results:
 *                    type: array
 *                    items:
 *                      $ref: '#/components/schemas/PaymentImplementation'
 *                  page:
 *                    type: integer
 *                    example: 1
 *                  limit:
 *                    type: integer
 *                    example: 10
 *                  totalPages:
 *                    type: integer
 *                    example: 1
 *                  totalResults:
 *                    type: integer
 *                    example: 1
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 */

/**
 * @swagger
 * path:
 *  /paymentImplementations/{id}:
 *    get:
 *      summary: Get a paymentImplementation
 *      description: Logged in paymentImplementations can fetch only their own paymentImplementation information. Only admins can fetch other paymentImplementations.
 *      tags: [PaymentImplementations]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: PaymentImplementation id
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/PaymentImplementation'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 *
 *    patch:
 *      summary: Update a paymentImplementation
 *      description: Logged in paymentImplementations can only update their own information. Only admins can update other paymentImplementations.
 *      tags: [PaymentImplementations]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: PaymentImplementation id
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                name:
 *                  type: string
 *                email:
 *                  type: string
 *                  format: email
 *                  description: must be unique
 *                password:
 *                  type: string
 *                  format: password
 *                  minLength: 8
 *                  description: At least one number and one letter
 *              example:
 *                name: fake name
 *                email: fake@example.com
 *                password: password1
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/PaymentImplementation'
 *        "400":
 *          $ref: '#/components/responses/DuplicateEmail'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 *
 *    delete:
 *      summary: Delete a paymentImplementation
 *      description: Logged in paymentImplementations can delete only themselves. Only admins can delete other paymentImplementations.
 *      tags: [PaymentImplementations]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: PaymentImplementation id
 *      responses:
 *        "200":
 *          description: No content
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 */
