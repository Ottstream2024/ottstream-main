const express = require('express');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');
const balanceValidation = require('../../../validations/payment/balance.validation');
const balanceController = require('../../../controllers/payment/balance.controller');

const router = express.Router();

router
  .route('/')
  .post(
    auth({ roles: [], permissions: ['addBalance'] }),
    validate(balanceValidation.addBalance),
    balanceController.addBalance
  );
router
  .route('/clients')
  .post(
    auth({ roles: [], permissions: ['addBalance'] }),
    validate(balanceValidation.addBalance),
    balanceController.addBalance
  );
router
  .route('/pay')
  .post(auth({ roles: [], permissions: ['payBalance'] }), validate(balanceValidation.pay), balanceController.pay);
// .get(
//   auth({ roles: ['superadmin'], permissions: ['getBalances'] }),
//   validate(balanceValidation.getBalance),
//   balanceController.getBalances
// );
//
// router
//   .route('/stop/:balanceId')
//   .get(
//     auth({ roles: ['superadmin'], permissions: ['getBalances'] }),
//     validate(balanceValidation.getBalance),
//     balanceController.getBalance
//   )
//   .patch(
//     auth({ roles: ['superadmin'], permissions: ['manageBalances'] }),
//     validate(balanceValidation.stopBalanceJoi),
//     balanceController.updateBalance
//   );

// router
//   .route('/user')
//   .get(auth('getBalances'), validate(balanceValidation.getBalance), balanceController.getUserBalance)

module.exports = router;
/**
 * @swagger
 * tags:
 *   name: Balances
 *   description: Balance management and retrieval
 */

/**
 * @swagger
 * path:
 *  /balances:
 *    post:
 *      summary: Create a balance
 *      description: Only admins can create other balances.
 *      tags: [Balances]
 *      security:
 *        - bearerAuth: []
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              required:
 *                - name
 *                - email
 *                - password
 *                - role
 *              properties:
 *                name:
 *                  type: string
 *                email:
 *                  type: string
 *                  format: email
 *                  description: must be unique
 *                password:
 *                  type: string
 *                  format: password
 *                  minLength: 8
 *                  description: At least one number and one letter
 *                role:
 *                   type: string
 *                   enum: [balance, admin]
 *              example:
 *                name: fake name
 *                email: fake@example.com
 *                password: password1
 *                role: balance
 *      responses:
 *        "201":
 *          description: Created
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/Balance'
 *        "400":
 *          $ref: '#/components/responses/DuplicateEmail'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *
 *    get:
 *      summary: Get all balances
 *      description: Only admins can retrieve all balances.
 *      tags: [Balances]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: query
 *          name: name
 *          schema:
 *            type: string
 *          description: Balance name
 *        - in: query
 *          name: role
 *          schema:
 *            type: string
 *          description: Balance role
 *        - in: query
 *          name: sortBy
 *          schema:
 *            type: string
 *          description: sort by query in the form of field:desc/asc (ex. name:asc)
 *        - in: query
 *          name: limit
 *          schema:
 *            type: integer
 *            minimum: 1
 *          default: 10
 *          description: Maximum number of balances
 *        - in: query
 *          name: page
 *          schema:
 *            type: integer
 *            minimum: 1
 *            default: 1
 *          description: Page number
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                  results:
 *                    type: array
 *                    items:
 *                      $ref: '#/components/schemas/Balance'
 *                  page:
 *                    type: integer
 *                    example: 1
 *                  limit:
 *                    type: integer
 *                    example: 10
 *                  totalPages:
 *                    type: integer
 *                    example: 1
 *                  totalResults:
 *                    type: integer
 *                    example: 1
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 */

/**
 * @swagger
 * path:
 *  /balances/{id}:
 *    get:
 *      summary: Get a balance
 *      description: Logged in balances can fetch only their own balance information. Only admins can fetch other balances.
 *      tags: [Balances]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: Balance id
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/Balance'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 *
 *    patch:
 *      summary: Update a balance
 *      description: Logged in balances can only update their own information. Only admins can update other balances.
 *      tags: [Balances]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: Balance id
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                name:
 *                  type: string
 *                email:
 *                  type: string
 *                  format: email
 *                  description: must be unique
 *                password:
 *                  type: string
 *                  format: password
 *                  minLength: 8
 *                  description: At least one number and one letter
 *              example:
 *                name: fake name
 *                email: fake@example.com
 *                password: password1
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/Balance'
 *        "400":
 *          $ref: '#/components/responses/DuplicateEmail'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 *
 *    delete:
 *      summary: Delete a balance
 *      description: Logged in balances can delete only themselves. Only admins can delete other balances.
 *      tags: [Balances]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: Balance id
 *      responses:
 *        "200":
 *          description: No content
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 */
