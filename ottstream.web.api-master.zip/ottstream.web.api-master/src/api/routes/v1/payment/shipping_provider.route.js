const express = require('express');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');
const shippingProviderValidation = require('../../../validations/payment/shipping_provider.validation');
const shippingProviderController = require('../../../controllers/payment/shipping_provider.controller');

const router = express.Router();

router
  .route('/')
  .post(
    auth({ roles: [], permissions: ['createShippingProvider'] }),
    validate(shippingProviderValidation.createShippingProvider),
    shippingProviderController.createShippingProvider
  )
  .get(
    auth({ roles: [], permissions: ['getShippingProviders'] }),
    validate(shippingProviderValidation.getShippingProviders),
    shippingProviderController.getShippingProviders
  );

router
  .route('/:paymentMethodId')
  .get(
    auth({ roles: [], permissions: ['getShippingProvider'] }),
    validate(shippingProviderValidation.getShippingProvider),
    shippingProviderController.getShippingProvider
  )
  .patch(
    auth({ roles: [], permissions: ['updateShippingProvider'] }),
    validate(shippingProviderValidation.updateShippingProvider),
    shippingProviderController.updateShippingProvider
  )
  .delete(
    auth({ roles: [], permissions: ['deleteShippingProvider'] }),
    validate(shippingProviderValidation.deleteShippingProvider),
    shippingProviderController.deleteShippingProvider
  );
