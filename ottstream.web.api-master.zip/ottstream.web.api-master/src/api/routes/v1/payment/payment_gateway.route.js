const express = require('express');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');
const paymentGatewayValidation = require('../../../validations/payment/payment_gateway.validation');
const paymentGatewayController = require('../../../controllers/payment/payment_gateway.controller');

const router = express.Router();

router
  .route('/')
  .post(
    auth({ roles: [], permissions: ['createPaymentGateway'] }),
    validate(paymentGatewayValidation.createPaymentGateway),
    paymentGatewayController.createPaymentGateway
  )
  .get(
    auth({ roles: [], permissions: ['getPaymentGateways'] }),
    validate(paymentGatewayValidation.getPaymentGateways),
    paymentGatewayController.getPaymentGateways
  );

router
  .route('/:paymentGatewayId')
  .get(
    auth({ roles: [], permissions: ['getPaymentGateway'] }),
    validate(paymentGatewayValidation.getPaymentGateway),
    paymentGatewayController.getPaymentGateway
  )
  .patch(
    auth({ roles: [], permissions: ['updatePaymentGateway'] }),
    validate(paymentGatewayValidation.updatePaymentGateway),
    paymentGatewayController.updatePaymentGateway
  )
  .delete(
    auth({ roles: [], permissions: ['deletePaymentGateway'] }),
    validate(paymentGatewayValidation.deletePaymentGateway),
    paymentGatewayController.deletePaymentGateway
  );

// router
//   .route('/user')
//   .get(auth('getPaymentGateways'), validate(paymentGatewayValidation.getPaymentGateway), paymentGatewayController.getUserPaymentGateway)

module.exports = router;
/**
 * @swagger
 * tags:
 *   name: PaymentGateways
 *   description: PaymentGateway management and retrieval
 */

/**
 * @swagger
 * path:
 *  /paymentGateways:
 *    post:
 *      summary: Create a paymentGateway
 *      description: Only admins can create other paymentGateways.
 *      tags: [PaymentGateways]
 *      security:
 *        - bearerAuth: []
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              required:
 *                - name
 *                - email
 *                - password
 *                - role
 *              properties:
 *                name:
 *                  type: string
 *                email:
 *                  type: string
 *                  format: email
 *                  description: must be unique
 *                password:
 *                  type: string
 *                  format: password
 *                  minLength: 8
 *                  description: At least one number and one letter
 *                role:
 *                   type: string
 *                   enum: [paymentGateway, admin]
 *              example:
 *                name: fake name
 *                email: fake@example.com
 *                password: password1
 *                role: paymentGateway
 *      responses:
 *        "201":
 *          description: Created
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/PaymentGateway'
 *        "400":
 *          $ref: '#/components/responses/DuplicateEmail'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *
 *    get:
 *      summary: Get all paymentGateways
 *      description: Only admins can retrieve all paymentGateways.
 *      tags: [PaymentGateways]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: query
 *          name: name
 *          schema:
 *            type: string
 *          description: PaymentGateway name
 *        - in: query
 *          name: role
 *          schema:
 *            type: string
 *          description: PaymentGateway role
 *        - in: query
 *          name: sortBy
 *          schema:
 *            type: string
 *          description: sort by query in the form of field:desc/asc (ex. name:asc)
 *        - in: query
 *          name: limit
 *          schema:
 *            type: integer
 *            minimum: 1
 *          default: 10
 *          description: Maximum number of paymentGateways
 *        - in: query
 *          name: page
 *          schema:
 *            type: integer
 *            minimum: 1
 *            default: 1
 *          description: Page number
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                  results:
 *                    type: array
 *                    items:
 *                      $ref: '#/components/schemas/PaymentGateway'
 *                  page:
 *                    type: integer
 *                    example: 1
 *                  limit:
 *                    type: integer
 *                    example: 10
 *                  totalPages:
 *                    type: integer
 *                    example: 1
 *                  totalResults:
 *                    type: integer
 *                    example: 1
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 */

/**
 * @swagger
 * path:
 *  /paymentGateways/{id}:
 *    get:
 *      summary: Get a paymentGateway
 *      description: Logged in paymentGateways can fetch only their own paymentGateway information. Only admins can fetch other paymentGateways.
 *      tags: [PaymentGateways]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: PaymentGateway id
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/PaymentGateway'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 *
 *    patch:
 *      summary: Update a paymentGateway
 *      description: Logged in paymentGateways can only update their own information. Only admins can update other paymentGateways.
 *      tags: [PaymentGateways]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: PaymentGateway id
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                name:
 *                  type: string
 *                email:
 *                  type: string
 *                  format: email
 *                  description: must be unique
 *                password:
 *                  type: string
 *                  format: password
 *                  minLength: 8
 *                  description: At least one number and one letter
 *              example:
 *                name: fake name
 *                email: fake@example.com
 *                password: password1
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/PaymentGateway'
 *        "400":
 *          $ref: '#/components/responses/DuplicateEmail'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 *
 *    delete:
 *      summary: Delete a paymentGateway
 *      description: Logged in paymentGateways can delete only themselves. Only admins can delete other paymentGateways.
 *      tags: [PaymentGateways]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: PaymentGateway id
 *      responses:
 *        "200":
 *          description: No content
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 */
