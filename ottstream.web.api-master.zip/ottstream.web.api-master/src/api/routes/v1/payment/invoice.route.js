const express = require('express');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');
const invoiceValidation = require('../../../validations/payment/invoice.validation');
const invoiceController = require('../../../controllers/payment/invoice.controller');

const router = express.Router();

router
  .route('/')
  .post(
    auth({ roles: [], permissions: ['createInvoice'] }),
    validate(invoiceValidation.createInvoiceJoi),
    invoiceController.createInvoice
  )
  .get(
    auth({ roles: [], permissions: ['getInvoices'] }),
    validate(invoiceValidation.getInvoices),
    invoiceController.getInvoices
  );

router
  .route('/pay/:invoiceId')
  .post(
    auth({ roles: [], permissions: ['payInvoice'] }),
    validate(invoiceValidation.payInvoice),
    invoiceController.payInvoice
  );

router
  .route('/sendCheckoutToClient/:invoiceId')
  .patch(
    auth({ roles: [], permissions: ['payInvoice'] }),
    validate(invoiceValidation.sendCheckoutInvoice),
    invoiceController.sendCheckoutInvoice
  );

router
  .route('/payClientUpdated/:invoiceId')
  .patch(validate(invoiceValidation.payClientUpdated), invoiceController.payClientUpdated);

router
  .route('/payClientInvoice/:invoiceId')
  .patch(validate(invoiceValidation.payClientInvoice), invoiceController.payClientInvoice);

router.route('/payClient/:invoiceId').get(validate(invoiceValidation.getPayClient), invoiceController.getPayClient);

router
  .route('/updatePayData/:invoice')
  .patch(
    auth({ roles: [], permissions: ['updateShippingInfo'] }),
    validate(invoiceValidation.updatePaymentData),
    invoiceController.updatePaymentData
  );

router
  .route('/invoiceFilter')
  .post(
    auth({ roles: [], permissions: ['getBillInvoices'] }),
    validate(invoiceValidation.getBillInvoices),
    invoiceController.getBillInvoices
  );

router
  .route('/:invoiceId')
  .get(
    auth({ roles: [], permissions: ['getInvoice'] }),
    validate(invoiceValidation.getInvoice),
    invoiceController.getInvoice
  );

router.route('/view/:invoiceId').get(validate(invoiceValidation.view), invoiceController.view);

router.route('/viewCheckPdf/:invoiceId').get(validate(invoiceValidation.view), invoiceController.viewCheckPdf);

router
  .route('/views')
  .post(auth({ roles: [], permissions: ['getInvoice'] }), validate(invoiceValidation.views), invoiceController.views);

router
  .route('/prints')
  .post(auth({ roles: [], permissions: ['getInvoice'] }), validate(invoiceValidation.views), invoiceController.prints);

router
  .route('/sendInvoices')
  .post(
    auth({ roles: [], permissions: ['getInvoice'] }),
    validate(invoiceValidation.sendInvoices),
    invoiceController.sendInvoices
  );

router
  .route('/cancelInvoices')
  .post(
    auth({ roles: [], permissions: ['getInvoice'] }),
    validate(invoiceValidation.sendInvoices),
    invoiceController.cancelInvoices
  );

router
  .route('/clientOrder/:clientId')
  .get(
    auth({ roles: [], permissions: ['clientOrderAction'] }),
    validate(invoiceValidation.clientOrderAction),
    invoiceController.clientOrderAction
  );
// router
//   .route('/stop/:invoiceId')
//   .get(
//     auth({ roles: ['superadmin'], permissions: ['getInvoices'] }),
//     validate(invoiceValidation.getInvoice),
//     invoiceController.getInvoice
//   )
//   .patch(
//     auth({ roles: ['superadmin'], permissions: ['manageInvoices'] }),
//     validate(invoiceValidation.stopInvoiceJoi),
//     invoiceController.updateInvoice
//   );

// router
//   .route('/user')
//   .get(auth('getInvoices'), validate(invoiceValidation.getInvoice), invoiceController.getUserInvoice)

module.exports = router;
/**
 * @swagger
 * tags:
 *   name: Invoices
 *   description: Invoice management and retrieval
 */

/**
 * @swagger
 * path:
 *  /invoices:
 *    post:
 *      summary: Create a invoice
 *      description: Only admins can create other invoices.
 *      tags: [Invoices]
 *      security:
 *        - bearerAuth: []
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              required:
 *                - name
 *                - email
 *                - password
 *                - role
 *              properties:
 *                name:
 *                  type: string
 *                email:
 *                  type: string
 *                  format: email
 *                  description: must be unique
 *                password:
 *                  type: string
 *                  format: password
 *                  minLength: 8
 *                  description: At least one number and one letter
 *                role:
 *                   type: string
 *                   enum: [invoice, admin]
 *              example:
 *                name: fake name
 *                email: fake@example.com
 *                password: password1
 *                role: invoice
 *      responses:
 *        "201":
 *          description: Created
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/Invoice'
 *        "400":
 *          $ref: '#/components/responses/DuplicateEmail'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *
 *    get:
 *      summary: Get all invoices
 *      description: Only admins can retrieve all invoices.
 *      tags: [Invoices]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: query
 *          name: name
 *          schema:
 *            type: string
 *          description: Invoice name
 *        - in: query
 *          name: role
 *          schema:
 *            type: string
 *          description: Invoice role
 *        - in: query
 *          name: sortBy
 *          schema:
 *            type: string
 *          description: sort by query in the form of field:desc/asc (ex. name:asc)
 *        - in: query
 *          name: limit
 *          schema:
 *            type: integer
 *            minimum: 1
 *          default: 10
 *          description: Maximum number of invoices
 *        - in: query
 *          name: page
 *          schema:
 *            type: integer
 *            minimum: 1
 *            default: 1
 *          description: Page number
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                  results:
 *                    type: array
 *                    items:
 *                      $ref: '#/components/schemas/Invoice'
 *                  page:
 *                    type: integer
 *                    example: 1
 *                  limit:
 *                    type: integer
 *                    example: 10
 *                  totalPages:
 *                    type: integer
 *                    example: 1
 *                  totalResults:
 *                    type: integer
 *                    example: 1
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 */

/**
 * @swagger
 * path:
 *  /invoices/{id}:
 *    get:
 *      summary: Get a invoice
 *      description: Logged in invoices can fetch only their own invoice information. Only admins can fetch other invoices.
 *      tags: [Invoices]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: Invoice id
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/Invoice'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 *
 *    patch:
 *      summary: Update a invoice
 *      description: Logged in invoices can only update their own information. Only admins can update other invoices.
 *      tags: [Invoices]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: Invoice id
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                name:
 *                  type: string
 *                email:
 *                  type: string
 *                  format: email
 *                  description: must be unique
 *                password:
 *                  type: string
 *                  format: password
 *                  minLength: 8
 *                  description: At least one number and one letter
 *              example:
 *                name: fake name
 *                email: fake@example.com
 *                password: password1
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/Invoice'
 *        "400":
 *          $ref: '#/components/responses/DuplicateEmail'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 *
 *    delete:
 *      summary: Delete a invoice
 *      description: Logged in invoices can delete only themselves. Only admins can delete other invoices.
 *      tags: [Invoices]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: Invoice id
 *      responses:
 *        "200":
 *          description: No content
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 */
