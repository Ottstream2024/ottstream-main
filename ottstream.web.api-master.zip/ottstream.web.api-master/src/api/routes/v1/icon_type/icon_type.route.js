const express = require('express');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');
const iconTypeValidation = require('../../../validations/icon_type/icon_type.validation');
const iconTypeController = require('../../../controllers/icon_type/icon_type.controller');

const router = express.Router();

router
  .route('/')
  .post(
    auth({ roles: [], permissions: ['createIconType'] }),
    validate(iconTypeValidation.createIconType),
    iconTypeController.createIconType
  )
  .get(
    auth({ roles: [], permissions: ['getIconTypes'] }),
    validate(iconTypeValidation.getIconTypes),
    iconTypeController.getIconTypes
  );

router
  .route('/:iconTypeId')
  .get(
    auth({ roles: [], permissions: ['getIconType'] }),
    validate(iconTypeValidation.getIconType),
    iconTypeController.getIconType
  )
  .patch(
    auth({ roles: [], permissions: ['updateIconType'] }),
    validate(iconTypeValidation.updateIconType),
    iconTypeController.updateIconType
  )
  .delete(
    auth({ roles: [], permissions: ['deleteIconType'] }),
    validate(iconTypeValidation.deleteIconType),
    iconTypeController.deleteIconType
  );

// router
//   .route('/user')
//   .get(auth('getIconTypes'), validate(iconTypeValidation.getIconType), iconTypeController.getUserIconType)

module.exports = router;

/**
 * @swagger
 * tags:
 *   name: IconTypes
 *   description: IconType management and retrieval
 */

/**
 * @swagger
 * path:
 *  /iconTypes:
 *    post:
 *      summary: Create a iconType
 *      description: Only admins can create other iconTypes.
 *      tags: [IconTypes]
 *      security:
 *        - bearerAuth: []
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              required:
 *                - name
 *                - email
 *                - password
 *                - role
 *              properties:
 *                name:
 *                  type: string
 *                email:
 *                  type: string
 *                  format: email
 *                  description: must be unique
 *                password:
 *                  type: string
 *                  format: password
 *                  minLength: 8
 *                  description: At least one number and one letter
 *                role:
 *                   type: string
 *                   enum: [iconType, admin]
 *              example:
 *                name: fake name
 *                email: fake@example.com
 *                password: password1
 *                role: iconType
 *      responses:
 *        "201":
 *          description: Created
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/IconType'
 *        "400":
 *          $ref: '#/components/responses/DuplicateEmail'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *
 *    get:
 *      summary: Get all iconTypes
 *      description: Only admins can retrieve all iconTypes.
 *      tags: [IconTypes]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: query
 *          name: name
 *          schema:
 *            type: string
 *          description: IconType name
 *        - in: query
 *          name: role
 *          schema:
 *            type: string
 *          description: IconType role
 *        - in: query
 *          name: sortBy
 *          schema:
 *            type: string
 *          description: sort by query in the form of field:desc/asc (ex. name:asc)
 *        - in: query
 *          name: limit
 *          schema:
 *            type: integer
 *            minimum: 1
 *          default: 10
 *          description: Maximum number of iconTypes
 *        - in: query
 *          name: page
 *          schema:
 *            type: integer
 *            minimum: 1
 *            default: 1
 *          description: Page number
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                  results:
 *                    type: array
 *                    items:
 *                      $ref: '#/components/schemas/IconType'
 *                  page:
 *                    type: integer
 *                    example: 1
 *                  limit:
 *                    type: integer
 *                    example: 10
 *                  totalPages:
 *                    type: integer
 *                    example: 1
 *                  totalResults:
 *                    type: integer
 *                    example: 1
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 */

/**
 * @swagger
 * path:
 *  /iconTypes/{id}:
 *    get:
 *      summary: Get a iconType
 *      description: Logged in iconTypes can fetch only their own iconType information. Only admins can fetch other iconTypes.
 *      tags: [IconTypes]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: IconType id
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/IconType'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 *
 *    patch:
 *      summary: Update a iconType
 *      description: Logged in iconTypes can only update their own information. Only admins can update other iconTypes.
 *      tags: [IconTypes]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: IconType id
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                name:
 *                  type: string
 *                email:
 *                  type: string
 *                  format: email
 *                  description: must be unique
 *                password:
 *                  type: string
 *                  format: password
 *                  minLength: 8
 *                  description: At least one number and one letter
 *              example:
 *                name: fake name
 *                email: fake@example.com
 *                password: password1
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/IconType'
 *        "400":
 *          $ref: '#/components/responses/DuplicateEmail'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 *
 *    delete:
 *      summary: Delete a iconType
 *      description: Logged in iconTypes can delete only themselves. Only admins can delete other iconTypes.
 *      tags: [IconTypes]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: IconType id
 *      responses:
 *        "200":
 *          description: No content
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 */
