const express = require('express');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');
const clientValidation = require('../../../validations/client/client.validation');
const clientController = require('../../../controllers/client/client.controller');
const clientLocationValidation = require('../../../validations/client/client_location.validation');
const clientLocationController = require('../../../controllers/client/client_location.controller');
const clientProfileValidation = require('../../../validations/client/client_profile.validation');
const clientProfileController = require('../../../controllers/client/client_profile.controller');
const clientUsedDeviceValidation = require('../../../validations/client/client_used_device.validation');
const clientUsedDeviceController = require('../../../controllers/client/client_used_device.controller');
const clientPackageValidation = require('../../../validations/client/client_package.validation');
const clientPackageController = require('../../../controllers/client/client_package.controller');
const clientPaymentMethodValidation = require('../../../validations/client/client_payment_method.validation');
const clientPaymentMethodController = require('../../../controllers/client/client_payment_method.controller');
const clientActivityValidation = require('../../../validations/client/client_activity.validation');
const clientActivityController = require('../../../controllers/client/client_activity.controller');
const { clientUsedDeviceActivityController } = require('../../../controllers');

const router = express.Router();

router
  .route('/')
  .post(
    auth({ roles: [], permissions: ['createClient'] }),
    validate(clientValidation.createClient),
    clientController.createClient
  )
  .get(auth({ roles: [], permissions: ['getClients'] }), validate(clientValidation.getClients), clientController.getClients);

router
  .route('/edit/:clientId')
  .get(auth({ roles: [], permissions: ['getClient'] }), validate(clientValidation.getClient), clientController.getClient)
  .patch(
    auth({ roles: [], permissions: ['updateClient'] }),
    validate(clientValidation.updateClient),
    clientController.updateClient
  );

router
  .route('/globalSearch')
  .get(
    auth({ roles: [], permissions: ['getClients'] }),
    validate(clientValidation.getClientBySearch),
    clientController.getClientBySearch
  );

router
  .route('/delete/:clientId')
  .patch(
    auth({ roles: [], permissions: ['deleteClient'] }),
    validate(clientValidation.deleteClient),
    clientController.deleteClient
  );

router.post(
  '/getAddressImage',
  auth({ roles: [], permissions: ['updateClient'] }),
  validate(clientValidation.getAddressImage),
  clientController.getAddressImage
);

router.patch(
  '/actionSettings/edit',
  auth({ roles: [], permissions: ['clientActionSettings'] }),
  validate(clientValidation.clientActionSettings),
  clientController.clientActionSettings
);

router.patch(
  '/locations/pause/:locationId',
  auth({ roles: [], permissions: ['clientActionSettings'] }),
  validate(clientLocationValidation.pauseClientLocation),
  clientLocationController.pauseClientLocation
);

router.patch(
  '/locations/changeServer',
  auth({ roles: [], permissions: ['clientActionSettings'] }),
  validate(clientLocationValidation.changeServer),
  clientLocationController.changeServer
);

router.patch(
  '/locations/restoreServer',
  auth({ roles: [], permissions: ['clientActionSettings'] }),
  validate(clientLocationValidation.restoreServer),
  clientLocationController.restoreServer
);

router.get(
  '/locations/serverBackups',
  auth({ roles: [], permissions: ['clientActionSettings'] }),
  validate(clientLocationValidation.getServerBackups),
  clientLocationController.getServerBackups
);

router.patch(
  '/actionSettings/delete',
  auth({ roles: [], permissions: ['clientActionDelete'] }),
  validate(clientValidation.clientActionDelete),
  clientController.clientActionDelete
);

// client table settings
router
  .route('/edit/settings/:clientId')
  .get(
    auth({ roles: [], permissions: ['getClientSettings'] }),
    validate(clientValidation.getClient),
    clientController.getClientSettings
  )
  .patch(
    auth({ roles: [], permissions: ['updateClientSettings'] }),
    validate(clientValidation.clientSettings),
    clientController.updateClientSettings
  );

router
  .route('/check-email-phone')
  .post(
    auth({ roles: [], permissions: ['clientCheckEmailPhone'] }),
    validate(clientValidation.clientCheckEmailPhone),
    clientController.clientCheckEmailPhone
  );

router
  .route('/paymentMethods/')
  .post(
    auth({ roles: [], permissions: ['createClientPaymentMethod'] }),
    validate(clientPaymentMethodValidation.createClientPaymentMethod),
    clientPaymentMethodController.createClientPaymentMethod
  )
  .get(
    auth({ roles: [], permissions: ['getClientPaymentMethods'] }),
    validate(clientPaymentMethodValidation.getClientPaymentMethods),
    clientPaymentMethodController.getClientPaymentMethods
  );

router
  .route('/paymentMethods/edit/:clientPaymentMethodId')
  .get(
    auth({ roles: [], permissions: ['getClientPaymentMethod'] }),
    validate(clientPaymentMethodValidation.getClientPaymentMethod),
    clientPaymentMethodController.getClientPaymentMethod
  )
  .patch(
    auth({ roles: [], permissions: ['updateClientPaymentMethod'] }),
    validate(clientPaymentMethodValidation.updateClientPaymentMethod),
    clientPaymentMethodController.updateClientPaymentMethod
  )
  .delete(
    auth({ roles: [], permissions: ['deleteClientPaymentMethod'] }),
    validate(clientPaymentMethodValidation.deleteClientPaymentMethod),
    clientPaymentMethodController.deleteClientPaymentMethod
  );

// get paymentMethod by client Id
router
  .route('/paymentMethods/:clientId')
  .get(
    auth({ roles: [], permissions: ['getClientPaymentMethodByClient'] }),
    validate(clientPaymentMethodValidation.getClientPaymentMethodByClient),
    clientPaymentMethodController.getClientPaymentMethodByClient
  );

// get paymentMethod types for finance tab
router
  .route('/payment_method_types')
  .get(
    auth({ roles: [], permissions: ['paymentMethodsTypes'] }),
    validate(clientValidation.paymentMethodsTypes),
    clientController.paymentMethodsTypes
  );

router
  .route('/locations/')
  .post(
    auth({ roles: [], permissions: ['createClientLocation'] }),
    validate(clientLocationValidation.createClientLocation),
    clientLocationController.createClientLocation
  )
  .get(
    auth({ roles: [], permissions: ['getClientLocations'] }),
    validate(clientLocationValidation.getClientLocations),
    clientLocationController.getClientLocations
  );

router
  .route('/locations/randomLoginPassword/:clientId')
  .get(
    auth({ roles: [], permissions: ['getClientLocationRandomLoginPassword'] }),
    validate(clientLocationValidation.getClientLocationRandomLoginPassword),
    clientLocationController.getClientLocationRandomLoginPassword
  );

router
  .route('/locations/edit/:clientLocationId')
  .get(
    auth({ roles: [], permissions: ['getClientLocation'] }),
    validate(clientLocationValidation.getClientLocation),
    clientLocationController.getClientLocation
  )
  .patch(
    auth({ roles: [], permissions: ['updateClientLocation'] }),
    validate(clientLocationValidation.updateClientLocation),
    clientLocationController.updateClientLocation
  )
  .delete(
    auth({ roles: [], permissions: ['deleteClientLocation'] }),
    validate(clientLocationValidation.deleteClientLocation),
    clientLocationController.deleteClientLocation
  );

router
  .route('/locations/edit/packagesByRoom/:clientLocationId/:roomsCount/:expireNew')
  .get(
    auth({ roles: [], permissions: ['getClientLocationPackagesByRoom'] }),
    validate(clientLocationValidation.getClientLocationPackagesByRoom),
    clientLocationController.getClientLocationPackagesByRoom
  );

router
  .route('/locations/edit/reset-password/:clientLocationId')
  .patch(
    auth({ roles: [], permissions: ['resetPassword'] }),
    validate(clientLocationValidation.resetPassword),
    clientLocationController.resetPassword
  );

// get locations by client Id
router
  .route('/locations/:clientId')
  .get(
    auth({ roles: [], permissions: ['getClientLocationByClient'] }),
    validate(clientLocationValidation.getClientLocationByClient),
    clientLocationController.getClientLocationByClient
  );

router
  .route('/profiles/')
  .post(
    auth({ roles: [], permissions: ['createClientProfile'] }),
    validate(clientProfileValidation.createClientProfile),
    clientProfileController.createClientProfile
  )
  .get(
    auth({ roles: [], permissions: ['getClientProfiles'] }),
    validate(clientProfileValidation.getClientProfiles),
    clientProfileController.getClientProfiles
  );

router
  .route('/profiles/edit/:clientProfileId')
  .get(
    auth({ roles: [], permissions: ['getClientProfile'] }),
    validate(clientProfileValidation.getClientProfile),
    clientProfileController.getClientProfile
  )
  .patch(
    auth({ roles: [], permissions: ['updateClientProfile'] }),
    validate(clientProfileValidation.updateClientProfile),
    clientProfileController.updateClientProfile
  )
  .delete(
    auth({ roles: [], permissions: ['deleteClientProfile'] }),
    validate(clientProfileValidation.deleteClientProfile),
    clientProfileController.deleteClientProfile
  );

router
  .route('/locations/syncCdn/:locationId')
  .get(
    auth({ roles: [], permissions: ['createClientProfile'] }),
    validate(clientLocationValidation.syncCdn),
    clientLocationController.syncCdn
  );

router
  .route('/locations/usedDevices/edit/:locationId')
  .get(
    auth({ roles: [], permissions: ['getClientUsedDevice'] }),
    validate(clientUsedDeviceValidation.getClientUsedDevice),
    clientUsedDeviceController.getClientUsedDevice
  )
  .patch(
    auth({ roles: [], permissions: ['updateClientUsedDevice'] }),
    validate(clientUsedDeviceValidation.updateClientUsedDevice),
    clientUsedDeviceController.updateClientUsedDevice
  )
  .delete(
    auth({ roles: [], permissions: ['deleteClientUsedDevice'] }),
    validate(clientUsedDeviceValidation.deleteClientUsedDevice),
    clientUsedDeviceController.deleteClientUsedDevice
  );
router
  .route('/locations/usedDevices/syncCdn/:locationId')
  .patch(
    auth({ roles: [], permissions: ['getClientUsedDevice'] }),
    validate(clientUsedDeviceValidation.syncUsedDeviceCdn),
    clientUsedDeviceController.syncUsedDeviceCdn
  );

router
  .route('/locations/usedDevices/activityStatistics/:usedDevice')
  .get(
    auth({ roles: [], permissions: ['getClientUsedDevice'] }),
    validate(clientUsedDeviceActivityController.getClientUsedDeviceActivityStatistics),
    clientUsedDeviceActivityController.getClientUsedDeviceActivityGraphData
  );

router
  .route('/locations/usedDevices/options')
  .get(
    auth({ roles: [], permissions: ['getClientUsedDevice'] }),
    validate(clientUsedDeviceValidation.getOptions),
    clientUsedDeviceController.getOptions
  );

router
  .route('/locations/usedDevices/multiple')
  .patch(
    auth({ roles: [], permissions: ['updateClientUsedDevice'] }),
    validate(clientUsedDeviceValidation.updateClientAllUsedDevice),
    clientUsedDeviceController.updateClientAllUsedDevice
  );

router
  .route('/packages/')
  .post(
    auth({ roles: [], permissions: ['createClientPackage'] }),
    validate(clientPackageValidation.createClientPackage),
    clientPackageController.createClientPackage
  )
  .get(
    auth({ roles: [], permissions: ['getClientPackages'] }),
    validate(clientPackageValidation.getClientPackages),
    clientPackageController.getClientPackages
  );

router
  .route('/packages/edit/:clientPackageId')
  .get(
    auth({ roles: [], permissions: ['getClientPackage'] }),
    validate(clientPackageValidation.getClientPackage),
    clientPackageController.getClientPackage
  )
  .patch(
    auth({ roles: [], permissions: ['updateClientPackage'] }),
    validate(clientPackageValidation.updateClientPackage),
    clientPackageController.updateClientPackage
  )
  .delete(
    auth({ roles: [], permissions: ['deleteClientPackage'] }),
    validate(clientPackageValidation.deleteClientPackage),
    clientPackageController.deleteClientPackage
  );

// get packages by client Id
router
  .route('/packages/:clientId')
  .get(
    auth({ roles: [], permissions: ['getClientPackageByClient'] }),
    validate(clientPackageValidation.getClientPackageByClient),
    clientPackageController.getClientPackageByClient
  );

router
  .route('/emails/edit/:clientId')
  .get(auth({ roles: [], permissions: ['getClient'] }), validate(clientValidation.getClient), clientController.getClient)
  .patch(
    auth({ roles: [], permissions: ['updateClientEmail'] }),
    validate(clientValidation.updateClientEmail),
    clientController.updateClientEmail
  );

// balance credit
router
  .route('/balanceCredit/edit/:clientId')
  .get(
    auth({ roles: [], permissions: ['getClientBalanceCredit'] }),
    validate(clientValidation.getClientBalanceCredit),
    clientController.getClientBalanceCredit
  );

router.get(
  '/activity',
  auth({ roles: [], permissions: ['getUserActivitys'] }),
  validate(clientActivityValidation.getClientActivitys),
  clientActivityController.getClientActivitys
);

router.get(
  '/deleted',
  auth({ roles: [], permissions: [] }),
  validate(clientValidation.getDeletedClients),
  clientController.getDeletedClients
);
// router
//   .route('/user')
//   .get(auth('getChannels'), validate(channelValidation.getChannel), channelController.getUserChannel)

module.exports = router;

/**
 * @swagger
 * tags:
 *   name: Channels
 *   description: Channel management and retrieval
 */

/**
 * @swagger
 * path:
 *  /channels:
 *    post:
 *      summary: Create a channel
 *      description: Only admins can create other channels.
 *      tags: [Channels]
 *      security:
 *        - bearerAuth: []
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              required:
 *                - name
 *                - email
 *                - password
 *                - role
 *              properties:
 *                name:
 *                  type: string
 *                email:
 *                  type: string
 *                  format: email
 *                  description: must be unique
 *                password:
 *                  type: string
 *                  format: password
 *                  minLength: 8
 *                  description: At least one number and one letter
 *                role:
 *                   type: string
 *                   enum: [channel, admin]
 *              example:
 *                name: fake name
 *                email: fake@example.com
 *                password: password1
 *                role: channel
 *      responses:
 *        "201":
 *          description: Created
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/Channel'
 *        "400":
 *          $ref: '#/components/responses/DuplicateEmail'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *
 *    get:
 *      summary: Get all channels
 *      description: Only admins can retrieve all channels.
 *      tags: [Channels]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: query
 *          name: name
 *          schema:
 *            type: string
 *          description: Channel name
 *        - in: query
 *          name: role
 *          schema:
 *            type: string
 *          description: Channel role
 *        - in: query
 *          name: sortBy
 *          schema:
 *            type: string
 *          description: sort by query in the form of field:desc/asc (ex. name:asc)
 *        - in: query
 *          name: limit
 *          schema:
 *            type: integer
 *            minimum: 1
 *          default: 10
 *          description: Maximum number of channels
 *        - in: query
 *          name: page
 *          schema:
 *            type: integer
 *            minimum: 1
 *            default: 1
 *          description: Page number
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                  results:
 *                    type: array
 *                    items:
 *                      $ref: '#/components/schemas/Channel'
 *                  page:
 *                    type: integer
 *                    example: 1
 *                  limit:
 *                    type: integer
 *                    example: 10
 *                  totalPages:
 *                    type: integer
 *                    example: 1
 *                  totalResults:
 *                    type: integer
 *                    example: 1
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 */

/**
 * @swagger
 * path:
 *  /channels/{id}:
 *    get:
 *      summary: Get a channel
 *      description: Logged in channels can fetch only their own channel information. Only admins can fetch other channels.
 *      tags: [Channels]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: Channel id
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/Channel'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 *
 *    patch:
 *      summary: Update a channel
 *      description: Logged in channels can only update their own information. Only admins can update other channels.
 *      tags: [Channels]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: Channel id
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                name:
 *                  type: string
 *                email:
 *                  type: string
 *                  format: email
 *                  description: must be unique
 *                password:
 *                  type: string
 *                  format: password
 *                  minLength: 8
 *                  description: At least one number and one letter
 *              example:
 *                name: fake name
 *                email: fake@example.com
 *                password: password1
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/Channel'
 *        "400":
 *          $ref: '#/components/responses/DuplicateEmail'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 *
 *    delete:
 *      summary: Delete a channel
 *      description: Logged in channels can delete only themselves. Only admins can delete other channels.
 *      tags: [Channels]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: Channel id
 *      responses:
 *        "200":
 *          description: No content
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 */
