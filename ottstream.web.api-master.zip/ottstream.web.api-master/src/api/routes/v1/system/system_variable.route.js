const express = require('express');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');
const systemVariableValidation = require('../../../validations/system/system_variable.validation');
const systemVariableController = require('../../../controllers/system/system_variable.controller');

const router = express.Router();

router
  .route('/')
  .post(
    auth({ roles: [], permissions: ['createSystemVariable'] }),
    validate(systemVariableValidation.createSystemVariable),
    systemVariableController.createSystemVariable
  )
  .get(
    auth({ roles: [], permissions: ['getSystemVariables'] }),
    validate(systemVariableValidation.getSystemVariables),
    systemVariableController.getSystemVariables
  );

router
  .route('/:systemVariableId')
  .get(
    auth({ roles: [], permissions: ['getSystemVariable'] }),
    validate(systemVariableValidation.getSystemVariable),
    systemVariableController.getSystemVariable
  )
  .patch(
    auth({ roles: [], permissions: ['updateSystemVariable'] }),
    validate(systemVariableValidation.updateSystemVariable),
    systemVariableController.updateSystemVariable
  )
  .delete(
    auth({ roles: [], permissions: ['deleteSystemVariable'] }),
    validate(systemVariableValidation.deleteSystemVariable),
    systemVariableController.deleteSystemVariable
  );

// router
//   .route('/user')
//   .get(auth('getSystemVariables'), validate(systemVariableValidation.getSystemVariable), systemVariableController.getUserSystemVariable)

module.exports = router;

/**
 * @swagger
 * tags:
 *   name: SystemVariables
 *   description: SystemVariable management and retrieval
 */

/**
 * @swagger
 * path:
 *  /systemVariables:
 *    post:
 *      summary: Create a systemVariable
 *      description: Only admins can create other systemVariables.
 *      tags: [SystemVariables]
 *      security:
 *        - bearerAuth: []
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              required:
 *                - name
 *                - email
 *                - password
 *                - role
 *              properties:
 *                name:
 *                  type: string
 *                email:
 *                  type: string
 *                  format: email
 *                  description: must be unique
 *                password:
 *                  type: string
 *                  format: password
 *                  minLength: 8
 *                  description: At least one number and one letter
 *                role:
 *                   type: string
 *                   enum: [systemVariable, admin]
 *              example:
 *                name: fake name
 *                email: fake@example.com
 *                password: password1
 *                role: systemVariable
 *      responses:
 *        "201":
 *          description: Created
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/SystemVariable'
 *        "400":
 *          $ref: '#/components/responses/DuplicateEmail'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *
 *    get:
 *      summary: Get all systemVariables
 *      description: Only admins can retrieve all systemVariables.
 *      tags: [SystemVariables]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: query
 *          name: name
 *          schema:
 *            type: string
 *          description: SystemVariable name
 *        - in: query
 *          name: role
 *          schema:
 *            type: string
 *          description: SystemVariable role
 *        - in: query
 *          name: sortBy
 *          schema:
 *            type: string
 *          description: sort by query in the form of field:desc/asc (ex. name:asc)
 *        - in: query
 *          name: limit
 *          schema:
 *            type: integer
 *            minimum: 1
 *          default: 10
 *          description: Maximum number of systemVariables
 *        - in: query
 *          name: page
 *          schema:
 *            type: integer
 *            minimum: 1
 *            default: 1
 *          description: Page number
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                  results:
 *                    type: array
 *                    items:
 *                      $ref: '#/components/schemas/SystemVariable'
 *                  page:
 *                    type: integer
 *                    example: 1
 *                  limit:
 *                    type: integer
 *                    example: 10
 *                  totalPages:
 *                    type: integer
 *                    example: 1
 *                  totalResults:
 *                    type: integer
 *                    example: 1
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 */

/**
 * @swagger
 * path:
 *  /systemVariables/{id}:
 *    get:
 *      summary: Get a systemVariable
 *      description: Logged in systemVariables can fetch only their own systemVariable information. Only admins can fetch other systemVariables.
 *      tags: [SystemVariables]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: SystemVariable id
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/SystemVariable'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 *
 *    patch:
 *      summary: Update a systemVariable
 *      description: Logged in systemVariables can only update their own information. Only admins can update other systemVariables.
 *      tags: [SystemVariables]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: SystemVariable id
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                name:
 *                  type: string
 *                email:
 *                  type: string
 *                  format: email
 *                  description: must be unique
 *                password:
 *                  type: string
 *                  format: password
 *                  minLength: 8
 *                  description: At least one number and one letter
 *              example:
 *                name: fake name
 *                email: fake@example.com
 *                password: password1
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/SystemVariable'
 *        "400":
 *          $ref: '#/components/responses/DuplicateEmail'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 *
 *    delete:
 *      summary: Delete a systemVariable
 *      description: Logged in systemVariables can delete only themselves. Only admins can delete other systemVariables.
 *      tags: [SystemVariables]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: SystemVariable id
 *      responses:
 *        "200":
 *          description: No content
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 */
