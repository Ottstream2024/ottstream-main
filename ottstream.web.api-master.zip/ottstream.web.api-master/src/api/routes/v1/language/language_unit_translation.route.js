const express = require('express');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');
const languageUnitTranslationValidation = require('../../../validations/language/language_unit_translation.validation');
const languageUnitTranslationController = require('../../../controllers/language/language_unit_translation.controller');

const router = express.Router();

router
  .route('/')
  .post(
    auth({ roles: [], permissions: ['createLanguageUnitTranslation'] }),
    validate(languageUnitTranslationValidation.createLanguageUnitTranslation),
    languageUnitTranslationController.createLanguageUnitTranslation
  )
  .get(
    auth({ roles: [], permissions: ['getLanguageUnitTranslations'] }),
    validate(languageUnitTranslationValidation.getLanguageUnitTranslations),
    languageUnitTranslationController.getLanguageUnitTranslations
  );

router
  .route('/:languageUnitTranslationId')
  .patch(
    auth({ roles: [], permissions: ['updateLanguageUnitTranslation'] }),
    validate(languageUnitTranslationValidation.updateLanguageUnitTranslation),
    languageUnitTranslationController.updateLanguageUnitTranslation
  )
  .delete(
    auth({ roles: [], permissions: ['deleteLanguageUnitTranslation'] }),
    validate(languageUnitTranslationValidation.deleteLanguageUnitTranslation),
    languageUnitTranslationController.deleteLanguageUnitTranslation
  );

module.exports = router;
