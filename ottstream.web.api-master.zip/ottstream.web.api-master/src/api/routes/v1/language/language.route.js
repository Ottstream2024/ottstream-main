const express = require('express');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');
const languageValidation = require('../../../validations/language/language.validation');
const languageController = require('../../../controllers/language/language.controller');

const router = express.Router();

router
  .route('/')
  .post(
    auth({ roles: [], permissions: ['createLanguage'] }),
    validate(languageValidation.createLanguage),
    languageController.createLanguage
  )
  .get(
    auth({ roles: [], permissions: ['getLanguages'] }),
    validate(languageValidation.getLanguages),
    languageController.getLanguages
  );

router.route('/system').get(languageController.getSystemLanguages);

router
  .route('/edit/:languageId')
  .get(
    auth({ roles: [], permissions: ['getLanguage'] }),
    validate(languageValidation.getLanguage),
    languageController.getLanguage
  )
  .patch(
    auth({ roles: [], permissions: ['updateLanguage'] }),
    validate(languageValidation.updateLanguage),
    languageController.updateLanguage
  )
  .delete(
    auth({ roles: [], permissions: ['deleteLanguage'] }),
    validate(languageValidation.deleteLanguage),
    languageController.deleteLanguage
  );

// router
//   .route('/user')
//   .get(auth('getLanguages'), validate(languageValidation.getLanguage), languageController.getUserLanguage)

module.exports = router;
