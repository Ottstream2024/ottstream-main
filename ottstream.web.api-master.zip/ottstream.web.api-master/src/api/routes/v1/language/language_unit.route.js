const express = require('express');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');
const languageUnitValidation = require('../../../validations/language/language_unit.validation');
const languageUnitController = require('../../../controllers/language/language_unit.controller');

const router = express.Router();

router
  .route('/')
  .post(
    auth({ roles: [], permissions: ['createLanguageUnit'] }),
    validate(languageUnitValidation.createLanguageUnit),
    languageUnitController.createLanguageUnit
  )
  .get(
    auth({ roles: [], permissions: ['getLanguageUnits'] }),
    validate(languageUnitValidation.getLanguageUnits),
    languageUnitController.getLanguageUnits
  );

router
  .route('/:languageUnitId')
  .get(
    auth({ roles: [], permissions: ['getLanguageUnit'] }),
    validate(languageUnitValidation.getLanguageUnit),
    languageUnitController.getLanguageUnit
  )
  .patch(
    auth({ roles: [], permissions: ['updateLanguageUnit'] }),
    validate(languageUnitValidation.updateLanguageUnit),
    languageUnitController.updateLanguageUnit
  )
  .delete(
    auth({ roles: [], permissions: ['deleteLanguageUnit'] }),
    validate(languageUnitValidation.deleteLanguageUnit),
    languageUnitController.deleteLanguageUnit
  );

module.exports = router;
