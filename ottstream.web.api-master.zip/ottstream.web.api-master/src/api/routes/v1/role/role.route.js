const express = require('express');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');
const roleValidation = require('../../../validations/role/role.validation');
const roleController = require('../../../controllers/role/role.controller');

const router = express.Router();

router
  .route('/')
  .post(auth({ roles: [], permissions: ['createRole'] }), validate(roleValidation.createRole), roleController.createRole)
  .get(auth({ roles: [], permissions: ['getRoles'] }), validate(roleValidation.getRoles), roleController.getRoles);
router
  .route('/ott')
  .get(auth({ roles: [], permissions: ['getOttRoles'] }), validate(roleValidation.getOttRoles), roleController.getOttRoles);

router
  .route('/edit/:roleId')
  .get(auth({ roles: [], permissions: ['getRole'] }), validate(roleValidation.getRole), roleController.getRole)
  .patch(auth({ roles: [], permissions: ['updateRole'] }), validate(roleValidation.updateRole), roleController.updateRole)
  .delete(auth({ roles: [], permissions: ['deleteRole'] }), validate(roleValidation.deleteRole), roleController.deleteRole);

// router
//   .route('/user')
//   .get(auth('getRoles'), validate(roleValidation.getRole), roleController.getUserRole)

module.exports = router;
