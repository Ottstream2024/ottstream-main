const express = require('express');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');
const permissionValidation = require('../../../validations/role/permission.validation');
const permissionController = require('../../../controllers/role/permission.controller');

const router = express.Router();

router
  .route('/')
  .post(
    auth({ roles: [], permissions: ['createPermission'] }),
    validate(permissionValidation.createPermission),
    permissionController.createPermission
  )
  .get(
    auth({ roles: [], permissions: ['getPermissions'] }),
    validate(permissionValidation.getPermissions),
    permissionController.getPermissions
  );

router
  .route('/:permissionId')
  .get(
    auth({ roles: [], permissions: ['getPermission'] }),
    validate(permissionValidation.getPermission),
    permissionController.getPermission
  )
  .patch(
    auth({ roles: [], permissions: ['updatePermission'] }),
    validate(permissionValidation.updatePermission),
    permissionController.updatePermission
  )
  .delete(
    auth({ roles: [], permissions: ['deletePermission'] }),
    validate(permissionValidation.deletePermission),
    permissionController.deletePermission
  );

// router
//   .route('/user')
//   .get(auth('getPermissions'), validate(permissionValidation.getPermission), permissionController.getUserPermission)

module.exports = router;
