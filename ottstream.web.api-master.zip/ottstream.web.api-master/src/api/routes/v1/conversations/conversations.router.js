const router = require('express').Router();
const conversationController = require('../../../controllers/conversations');
const conversationValidations = require('../../../validations/conversations');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');

router.get(
  '/:type',
  auth({ roles: [], permissions: [] }),
  validate(conversationValidations.getConversations),
  conversationController.getConversations
);
// router.post('/client', auth({ roles: [], permissions: [] }), validate(conversationValidations.createClientConversation), conversationController.createClientConversation)
// router.post('/team', auth({ roles: [], permissions: [] }), validate(conversationValidations.createConversation), conversationController.createConversation)
// router.route('/group').post(auth({ roles: [], permissions: [] }), validate(conversationValidations.createGroupConversation), conversationController.createGroupConversation)

router.get(
  '/member/:id',
  auth({ roles: [], permissions: [] }),
  validate(conversationValidations.getMemberById),
  conversationController.getMemberById
);
router.get(
  '/find/:type',
  auth({ roles: [], permissions: [] }),
  validate(conversationValidations.findConversation),
  conversationController.findConversation
);

module.exports = router;
