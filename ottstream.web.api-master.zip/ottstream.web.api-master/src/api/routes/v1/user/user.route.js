const express = require('express');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');
const { generateTelegramAccess } = require('../../../../middlewares/helperMiddlewares');
const userValidation = require('../../../validations/user/user.validation');
const userController = require('../../../controllers/user/user.controller');
const userActivityValidation = require('../../../validations/user/user_activity.validation');
const userActivityController = require('../../../controllers/user/user_activity.controller');
const geoipInfo = require('../../../../middlewares/geoip');

const router = express.Router();

router.get(
  '/activity/:user',
  auth({ roles: [], permissions: ['getUserActivitys'] }),
  validate(userActivityValidation.getUserActivitys),
  userActivityController.getUserActivitys
);

router
  .route('/')
  .post(
    geoipInfo,
    auth({ roles: [], permissions: ['createUser'] }),
    validate(userValidation.createUser),
    generateTelegramAccess,
    userController.createUser
  )
  .get(auth({ roles: [], permissions: ['getUsers'] }), validate(userValidation.getUsers), userController.getUsers);

router.get(
  '/reset-login-count/:userId',
  auth({ roles: [], permissions: ['resetLoginCount'] }),
  validate(userValidation.resetLoginCount),
  userController.resetLoginCount
);

router.post(
  '/email/reset-password',
  auth({ roles: [], permissions: ['emailResetPassword'] }),
  validate(userValidation.emailResetPassword),
  userController.emailResetPassword
);

router.patch(
  '/telegram-generate-password/:userId',
  auth({ roles: [], permissions: ['generateTelegramPassword'] }),
  validate(userValidation.generateTelegramPassword),
  userController.generateTelegramPassword
);

router.post(
  '/telegram-send-password/:userId',
  auth({ roles: [], permissions: ['generateTelegramPassword'] }),
  validate(userValidation.sendTelegramPassword),
  userController.sendTelegramPassword
);

router.post(
  '/reset-password',
  auth({ roles: [], permissions: ['resetPassword'] }),
  validate(userValidation.resetPassword),
  userController.resetPassword
);

router.get(
  '/registration',
  auth({ roles: [], permissions: ['getRegistrationUsers'] }),
  validate(userValidation.getRegistrationUsers),
  userController.getRegistrationUsers
);

router.get(
  '/calendar',
  auth({ roles: [], permissions: ['getCalendarUsers'] }),
  validate(userValidation.getRegistrationUsers),
  userController.getCalendarUsers
);

router.get(
  '/active',
  auth({ roles: [], permissions: ['getActiveUsers'] }),
  validate(userValidation.getActiveUsers),
  userController.getActiveUsers
);

router.get('/settings', auth({ roles: [], permissions: ['getUserSettings'] }), userController.getUserSettings);

router.patch(
  '/settings',
  auth({ roles: [], permissions: ['setUserSettings'] }),
  validate(userValidation.setUserSettings),
  userController.setUserSettings
);

router.route('/email/check-mail').get(validate(userValidation.UserCheckEmail), userController.UserCheckEmail);

router
  .route('/phone/check-phone')
  .get(
    auth({ roles: [], permissions: ['UserCheckPhone'] }),
    validate(userValidation.UserCheckPhone),
    userController.UserCheckPhone
  );

router
  .route('/edit/:userId')
  .get(auth({ roles: [], permissions: ['getUser'] }), validate(userValidation.getUser), userController.getUser)
  .patch(
    auth({ roles: [], permissions: ['updateUser'] }),
    validate(userValidation.updateUser),
    generateTelegramAccess,
    userController.updateUser
  ) //
  .delete(auth({ roles: [], permissions: ['deleteUser'] }), validate(userValidation.deleteUser), userController.deleteUser);

router
  .route('/permissions/:userId')
  .get(
    auth({ roles: [], permissions: ['getPermissionUser'] }),
    validate(userValidation.getUser),
    userController.getPermissionUser
  );

router
  .route('/delete/:userId')
  .delete(auth({ roles: [], permissions: ['deleteUser'] }), validate(userValidation.deleteUser), userController.deleteUser);

router
  .route('/deleteMultiply')
  .patch(
    auth({ roles: [], permissions: ['deleteMultiply'] }),
    validate(userValidation.deleteMultiply),
    userController.deleteMultiply
  );

router
  .route('/enableDisable')
  .patch(
    auth({ roles: [], permissions: ['userEnableDisableAction'] }),
    validate(userValidation.userEnableDisableAction),
    userController.userEnableDisableAction
  );

module.exports = router;
