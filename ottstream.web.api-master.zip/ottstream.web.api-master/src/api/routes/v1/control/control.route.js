const express = require('express');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');
const controlValidation = require('../../../validations/control/control.validation');
const controlController = require('../../../controllers/control/control.controller');

const router = express.Router();

router
  .route('/syncLocations')
  .get(auth({ roles: [], permissions: [] }), validate(controlValidation.syncLocations), controlController.syncLocations);

module.exports = router;
