const express = require('express');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');
const geoipInfo = require('../../../../middlewares/geoip');
const ottproviderValidation = require('../../../validations/ottprovider/ottprovider.validation');
const ottproviderController = require('../../../controllers/ottprovider/ottprovider.controller');
const ottProviderEmailValidation = require('../../../validations/ottprovider/ottprovider_email.validation');
const ottProviderEmailController = require('../../../controllers/ottprovider/ottprovider_email.controller');
const ottProviderPhoneValidation = require('../../../validations/ottprovider/ottprovider_phone.validation');
const ottProviderPhoneController = require('../../../controllers/ottprovider/ottprovider_phone.controller');
const ottProviderAddressValidation = require('../../../validations/ottprovider/ottprovider_address.validation');
const ottProviderAddressController = require('../../../controllers/ottprovider/ottprovider_address.controller');
const ottProviderShippingProviderValidation = require('../../../validations/ottprovider/ottprovider_shipping_provider.validation');
const ottProviderConversationProviderValidation = require('../../../validations/ottprovider/ottprovider_conversation_provider.validation');
const ottProviderShippingProviderController = require('../../../controllers/ottprovider/ottprovider_shipping_provider.controller');
const ottProviderConversationProviderController = require('../../../controllers/ottprovider/ottprovider_conversation_provider.controller');
const ottProviderPaymentGatewayValidation = require('../../../validations/ottprovider/ottprovider_payment_gateway.validation');
const ottProviderPaymentGatewayController = require('../../../controllers/ottprovider/ottprovider_payment_gateway.controller');
const ottProviderOtherApiValidation = require('../../../validations/ottprovider/ottprovider_other_api.validation');
const ottProviderOtherApiController = require('../../../controllers/ottprovider/ottprovider_other_api.controller');
const ottProviderInvoiceValidation = require('../../../validations/ottprovider/ottprovider_invoice.validation');
const ottProviderInvoiceController = require('../../../controllers/ottprovider/ottprovider_invoice.controller');
const ottProviderPrinterValidation = require('../../../validations/ottprovider/ottprovider_printer.validation');
const ottProviderPrinterController = require('../../../controllers/ottprovider/ottprovider_printer.controller');
const ottProviderUiValidation = require('../../../validations/ottprovider/ottprovider_ui.validation');
const ottProviderUiController = require('../../../controllers/ottprovider/ottprovider_ui.controller');
const ottProviderInfoValidation = require('../../../validations/ottprovider/ottprovider_info.validation');
const ottProviderInfoController = require('../../../controllers/ottprovider/ottprovider_info.controller');
const ottProviderPaymentMethodValidation = require('../../../validations/ottprovider/ottprovider_payment_method.validation');
const ottProviderPaymentMethodController = require('../../../controllers/ottprovider/ottprovider_payment_method.controller');
const { ottProviderPermissionValidation } = require('../../../validations');
const { ottProviderPermissionController } = require('../../../controllers');

const router = express.Router();

router
  .route('/syncLive')
  .get(
    auth({ roles: [], permissions: ['syncLive'] }),
    validate(ottproviderValidation.syncLive),
    ottproviderController.syncLive
  );

router
  .route('/')
  .post(
    auth({ roles: [], permissions: ['createOttProvider'] }),
    validate(ottproviderValidation.createOttProvider),
    ottproviderController.createOttProvider
  )
  .get(
    auth({ roles: [], permissions: ['getOttProviders'] }),
    validate(ottproviderValidation.getOttProviders),
    ottproviderController.getOttProviders
  );

router
  .route('/filterValues')
  .get(
    auth({ roles: [], permissions: [] }),
    validate(ottproviderValidation.getOttProviderForFilters),
    ottproviderController.getOttProviderForFilters
  );

router.get(
  '/registration',
  auth({ roles: [], permissions: ['getRegistrationProviders'], baseOnly: true }),
  validate(ottproviderValidation.getRegistrationProviders),
  ottproviderController.getRegistrationProviders
);

router.post(
  '/addByAdmin',
  geoipInfo,
  auth({ roles: [], permissions: ['addByAdmin'] }),
  validate(ottproviderValidation.addByAdmin),
  ottproviderController.addByAdmin
);
router
  .route('/registration/approve')
  .patch(
    auth({ roles: [], permissions: ['registrationApprove'] }),
    validate(ottproviderValidation.registrationApprove),
    ottproviderController.registrationApprove
  );

router
  .route('/approve/:ottproviderId')
  .patch(
    auth({ roles: [], permissions: ['approveOttProvider'] }),
    validate(ottproviderValidation.approveOttProvider),
    ottproviderController.approveOttProvider
  );

router
  .route('/edit/:ottproviderId')
  .get(
    auth({ roles: [], permissions: ['getOttProvider'] }),
    validate(ottproviderValidation.getOttProvider),
    ottproviderController.getOttProvider
  )
  .patch(
    auth({ roles: [], permissions: ['updateOttProvider'] }),
    validate(ottproviderValidation.updateOttProvider),
    ottproviderController.updateOttProvider
  )
  .delete(
    auth({ roles: [], permissions: ['deleteOttProvider'] }),
    validate(ottproviderValidation.deleteOttProvider),
    ottproviderController.deleteOttProvider
  );

router
  .route('/delete/:ottproviderId')
  .patch(
    auth({ roles: [], permissions: ['deleteOttProvider'] }),
    validate(ottproviderValidation.deleteOttProvider),
    ottproviderController.deleteOttProvider
  );

router
  .route('/checkKey/:ottproviderId')
  .get(
    auth({ roles: [], permissions: ['getCheckOttProviderKey'] }),
    validate(ottproviderValidation.getCheckOttProviderKey),
    ottproviderController.getCheckOttProviderKey
  );

router
  .route('/edit/salesTax/:ottproviderId')
  .get(
    auth({ roles: [], permissions: ['getOttProviderSalesTax'] }),
    validate(ottproviderValidation.getOttProvider),
    ottproviderController.getOttProviderSalesTax
  )
  .patch(
    auth({ roles: [], permissions: ['updateOttProviderSalesTax'] }),
    validate(ottproviderValidation.updateOttProviderSalesTaxJoi),
    ottproviderController.updateOttProviderSalesTax
  );

router
  .route('/edit/settings/:ottproviderId')
  .get(
    auth({ roles: [], permissions: ['getOttProviderSettings'] }),
    validate(ottproviderValidation.getOttProvider),
    ottproviderController.getOttProviderSettings
  )
  .patch(
    auth({ roles: [], permissions: ['updateOttProviderSettings'] }),
    validate(ottproviderValidation.updateOttProviderSettingsJoi),
    ottproviderController.updateOttProviderSettings
  );

// Email section

router
  .route('/emails/')
  .post(
    auth({ roles: [], permissions: ['createOttProviderEmail'] }),
    validate(ottProviderEmailValidation.createOttProviderEmail),
    ottProviderEmailController.createOttProviderEmail
  )
  .get(
    auth({ roles: [], permissions: ['getOttProviderEmails'] }),
    validate(ottProviderEmailValidation.getOttProviderEmails),
    ottProviderEmailController.getOttProviderEmails
  );

router
  .route('/emails/check-mail')
  .get(validate(ottProviderEmailValidation.ottProviderCheckEmail), ottProviderEmailController.ottProviderCheckEmail);

router
  .route('/emails/edit/:ottProviderEmailId')
  .get(
    auth({ roles: [], permissions: ['getOttProviderEmail'] }),
    validate(ottProviderEmailValidation.getOttProviderEmail),
    ottProviderEmailController.getOttProviderEmail
  )
  .patch(
    auth({ roles: [], permissions: ['updateOttProviderEmail'] }),
    validate(ottProviderEmailValidation.updateOttProviderEmail),
    ottProviderEmailController.updateOttProviderEmail
  )
  .delete(
    auth({ roles: [], permissions: ['deleteOttProviderEmail'] }),
    validate(ottProviderEmailValidation.deleteOttProviderEmail),
    ottProviderEmailController.deleteOttProviderEmail
  );
// Printer section

router
  .route('/printers/')
  .post(
    auth({ roles: [], permissions: ['createOttProviderPrinter'] }),
    validate(ottProviderPrinterValidation.createOttProviderPrinter),
    ottProviderPrinterController.createOttProviderPrinter
  )
  .get(
    auth({ roles: [], permissions: ['getOttProviderPrinters'] }),
    validate(ottProviderPrinterValidation.getOttProviderPrinters),
    ottProviderPrinterController.getOttProviderPrinters
  );

router
  .route('/paymentMethodOptions/:ottProviderId')
  .patch(
    auth({ roles: [], permissions: ['updateOttProviderPaymentMethodOptions'] }),
    validate(ottproviderValidation.updateOttProviderPaymentMethodOptions),
    ottproviderController.updateOttProviderPaymentMethodOptions
  )
  .get(
    auth({ roles: [], permissions: ['getOttProviderPaymentMethodOptions'] }),
    validate(ottproviderValidation.getOttProviderPaymentMethodOptions),
    ottproviderController.getOttProviderPaymentMethodOptions
  );

router
  .route('/paymentMethods/')
  .post(
    auth({ roles: [], permissions: ['createOttProviderPaymentMethod'] }),
    validate(ottProviderPaymentMethodValidation.createOttProviderPaymentMethod),
    ottProviderPaymentMethodController.createOttProviderPaymentMethod
  )
  .get(
    auth({ roles: [], permissions: ['getOttProviderPaymentMethods'] }),
    validate(ottProviderPaymentMethodValidation.getOttProviderPaymentMethods),
    ottProviderPaymentMethodController.getOttProviderPaymentMethods
  );

router
  .route('/paymentMethods/edit/:ottProviderPaymentMethodId')
  .get(
    auth({ roles: [], permissions: ['getOttProviderPaymentMethod'] }),
    validate(ottProviderPaymentMethodValidation.getOttProviderPaymentMethod),
    ottProviderPaymentMethodController.getOttProviderPaymentMethod
  )
  .patch(
    auth({ roles: [], permissions: ['updateOttProviderPaymentMethod'] }),
    validate(ottProviderPaymentMethodValidation.updateOttProviderPaymentMethod),
    ottProviderPaymentMethodController.updateOttProviderPaymentMethod
  )
  .delete(
    auth({ roles: [], permissions: ['deleteOttProviderPaymentMethod'] }),
    validate(ottProviderPaymentMethodValidation.deleteOttProviderPaymentMethod),
    ottProviderPaymentMethodController.deleteOttProviderPaymentMethod
  );

router
  .route('/printers/edit/:ottProviderPrinterId')
  .get(
    auth({ roles: [], permissions: ['getOttProviderPrinter'] }),
    validate(ottProviderPrinterValidation.getOttProviderPrinter),
    ottProviderPrinterController.getOttProviderPrinter
  )
  .patch(
    auth({ roles: [], permissions: ['updateOttProviderPrinter'] }),
    validate(ottProviderPrinterValidation.updateOttProviderPrinter),
    ottProviderPrinterController.updateOttProviderPrinter
  )
  .delete(
    auth({ roles: [], permissions: ['deleteOttProviderPrinter'] }),
    validate(ottProviderPrinterValidation.deleteOttProviderPrinter),
    ottProviderPrinterController.deleteOttProviderPrinter
  );

// Phone section

router
  .route('/phones/')
  .post(
    auth({ roles: [], permissions: ['createOttProviderPhone'] }),
    validate(ottProviderPhoneValidation.createOttProviderPhone),
    ottProviderPhoneController.createOttProviderPhone
  )
  .get(
    auth({ roles: [], permissions: ['getOttProviderPhones'] }),
    validate(ottProviderPhoneValidation.getOttProviderPhones),
    ottProviderPhoneController.getOttProviderPhones
  );

router
  .route('/phones/check-phone')
  .get(validate(ottProviderPhoneValidation.ottProviderCheckPhone), ottProviderPhoneController.ottProviderCheckPhone);

router
  .route('/phones/edit/:ottProviderPhoneId')
  .get(
    auth({ roles: [], permissions: ['getOttProviderPhone'] }),
    validate(ottProviderPhoneValidation.getOttProviderPhone),
    ottProviderPhoneController.getOttProviderPhone
  )
  .patch(
    auth({ roles: [], permissions: ['updateOttProviderPhone'] }),
    validate(ottProviderPhoneValidation.updateOttProviderPhone),
    ottProviderPhoneController.updateOttProviderPhone
  )
  .delete(
    auth({ roles: [], permissions: ['deleteOttProviderPhone'] }),
    validate(ottProviderPhoneValidation.deleteOttProviderPhone),
    ottProviderPhoneController.deleteOttProviderPhone
  );

// Addresses section
router
  .route('/addresses/')
  .post(
    auth({ roles: [], permissions: ['createOttProviderAddress'] }),
    validate(ottProviderAddressValidation.createOttProviderAddress),
    ottProviderAddressController.createOttProviderAddress
  )
  .get(
    auth({ roles: [], permissions: ['getOttProviderAddresses'] }),
    validate(ottProviderAddressValidation.getOttProviderAddresses),
    ottProviderAddressController.getOttProviderAddresses
  );

router
  .route('/addresses/:ottProviderId')
  .get(
    auth({ roles: [], permissions: ['getOttProviderAddressesByProviderId'] }),
    validate(ottProviderAddressValidation.getOttProviderAddressesByProviderId),
    ottProviderAddressController.getOttProviderAddressesByProviderId
  );

router
  .route('/addresses/edit/:ottProviderAddressId')
  .get(
    auth({ roles: [], permissions: ['getOttProviderAddress'] }),
    validate(ottProviderAddressValidation.getOttProviderAddress),
    ottProviderAddressController.getOttProviderAddress
  )
  .patch(
    auth({ roles: [], permissions: ['updateOttProviderAddress'] }),
    validate(ottProviderAddressValidation.updateOttProviderAddress),
    ottProviderAddressController.updateOttProviderAddress
  )
  .delete(
    auth({ roles: [], permissions: ['deleteOttProviderAddress'] }),
    validate(ottProviderAddressValidation.deleteOttProviderAddress),
    ottProviderAddressController.deleteOttProviderAddress
  );

router
  .route('/infos/edit/:ottProviderId')
  .get(
    auth({ roles: [], permissions: ['getOttProviderInfo'] }),
    validate(ottProviderInfoValidation.getOttProviderInfo),
    ottProviderInfoController.getOttProviderInfo
  )
  .patch(
    auth({ roles: [], permissions: ['updateOttProviderInfo'] }),
    validate(ottProviderInfoValidation.updateOttProviderInfo),
    ottProviderInfoController.updateOttProviderInfo
  );

router
  .route('/uis/edit/:ottProviderId')
  .get(
    auth({ roles: [], permissions: ['getOttProviderUi'] }),
    validate(ottProviderUiValidation.getOttProviderUi),
    ottProviderUiController.getOttProviderUi
  )
  .patch(
    auth({ roles: [], permissions: ['updateOttProviderUi'] }),
    validate(ottProviderUiValidation.updateOttProviderUi),
    ottProviderUiController.updateOttProviderUi
  );

router
  .route('/shippingProviders/edit/:ottProviderId')
  .get(
    auth({ roles: [], permissions: ['getOttProviderShippingProvider'] }),
    validate(ottProviderShippingProviderValidation.getOttProviderShippingProvider),
    ottProviderShippingProviderController.getOttProviderShippingProvider
  )
  .patch(
    auth({ roles: [], permissions: ['updateOttProviderShippingProvider'] }),
    validate(ottProviderShippingProviderValidation.updateOttProviderShippingProvider),
    ottProviderShippingProviderController.updateOttProviderShippingProvider
  );

router
  .route('/conversationProviders/edit/:ottProviderId')
  .get(
    auth({ roles: [], permissions: ['getOttProviderConversationProvider'] }),
    validate(ottProviderConversationProviderValidation.getOttProviderConversationProvider),
    ottProviderConversationProviderController.getOttProviderConversationProvider
  )
  .patch(
    auth({ roles: [], permissions: ['updateOttProviderConversationProvider'] }),
    validate(ottProviderConversationProviderValidation.updateOttProviderConversationProvider),
    ottProviderConversationProviderController.updateOttProviderConversationProvider
  );

router
  .route('/shippingProviders/methods')
  .get(
    auth({ roles: [], permissions: ['getOttProviderShippingProviderMethods'] }),
    ottProviderShippingProviderController.getOttProviderShippingProviderMethods
  );

// payment method
router
  .route('/paymentGateways/edit/:ottProviderId')
  .get(
    auth({ roles: [], permissions: ['getOttProviderPaymentGateway'] }),
    validate(ottProviderPaymentGatewayValidation.getOttProviderPaymentGateway),
    ottProviderPaymentGatewayController.getOttProviderPaymentGateway
  )
  .patch(
    auth({ roles: [], permissions: ['updateOttProviderPaymentGateway'] }),
    validate(ottProviderPaymentGatewayValidation.updateOttProviderPaymentGateway),
    ottProviderPaymentGatewayController.updateOttProviderPaymentGateway
  );

router
  .route('/paymentGateways/methods/:providerId')
  .get(
    auth({ roles: [], permissions: ['getOttProviderPaymentGatewayMethods'] }),
    validate(ottProviderPaymentGatewayValidation.getOttProviderPaymentGatewayMethods),
    ottProviderPaymentGatewayController.getOttProviderPaymentGatewayMethods
  );

// invoice
router
  .route('/invoices/edit/:ottProviderId')
  .get(
    auth({ roles: [], permissions: ['getOttProviderInvoice'] }),
    validate(ottProviderInvoiceValidation.getOttProviderInvoice),
    ottProviderInvoiceController.getOttProviderInvoice
  )
  .patch(
    auth({ roles: [], permissions: ['updateOttProviderInvoice'] }),
    validate(ottProviderInvoiceValidation.updateOttProviderInvoice),
    ottProviderInvoiceController.updateOttProviderInvoice
  );

router
  .route('/invoices/print/:ottProviderId')
  .get(
    auth({ roles: [], permissions: ['printExampleInvoice'] }),
    validate(ottProviderInvoiceValidation.printExampleInvoice),
    ottProviderInvoiceController.printExampleInvoice
  );

router
  .route('/invoices/html/:ottProviderId')
  .get(
    auth({ roles: [], permissions: ['printExampleInvoice'] }),
    validate(ottProviderInvoiceValidation.getInvoiceHtml),
    ottProviderInvoiceController.getInvoiceHtml
  );

// other apis
router
  .route('/otherApis/edit/:ottProviderId')
  .get(
    auth({ roles: [], permissions: ['getOttProviderOtherApi'] }),
    validate(ottProviderOtherApiValidation.getOttProviderOtherApi),
    ottProviderOtherApiController.getOttProviderOtherApi
  )
  .patch(
    auth({ roles: [], permissions: ['updateOttProviderOtherApi'] }),
    validate(ottProviderOtherApiValidation.updateOttProviderOtherApi),
    ottProviderOtherApiController.updateOttProviderOtherApi
  );

router
  .route('/otherApis/smsCheckeeperSignature/:ottProviderId')
  .patch(
    auth({ roles: [], permissions: ['updateOttProviderOtherApi'] }),
    validate(ottProviderOtherApiValidation.smsCheckeeperSignature),
    ottProviderOtherApiController.smsCheckeeperSignature
  );

// other apis
router
  .route('/permission/edit/:ottProviderId')
  .get(
    auth({ roles: [], permissions: ['getOttProviderPermission'] }),
    validate(ottProviderPermissionValidation.getOttProviderPermission),
    ottProviderPermissionController.getOttProviderPermission
  )
  .patch(
    auth({ roles: [], permissions: ['updateOttProviderPermission'] }),
    validate(ottProviderPermissionValidation.updateOttProviderPermission),
    ottProviderPermissionController.updateOttProviderPermission
  );

router
  .route('/otherApis/methods')
  .get(
    auth({ roles: [], permissions: ['getOttProviderOtherApiMethods'] }),
    ottProviderOtherApiController.getOttProviderOtherApiMethods
  );

// balance credit
router
  .route('/balanceCredit/edit/:ottProviderId')
  .get(
    auth({ roles: [], permissions: ['getOttProviderBalanceCredit'] }),
    validate(ottproviderValidation.getOttProviderBalanceCredit),
    ottproviderController.getOttProviderBalanceCredit
  );

// provider actions
router.patch(
  '/actionSettings/edit',
  auth({ roles: [], permissions: ['actionSettings'] }),
  validate(ottproviderValidation.actionSettings),
  ottproviderController.actionSettings
);
router.patch(
  '/actionSettings/delete',
  auth({ roles: [], permissions: ['ottProviderActionDelete'] }),
  validate(ottproviderValidation.ottProvderActionDelete),
  ottproviderController.ottProviderActionDelete
);

module.exports = router;
