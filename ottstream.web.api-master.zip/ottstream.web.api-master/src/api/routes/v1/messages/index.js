const router = require('express').Router();
const messagesController = require('../../../controllers/messages');
const messagesValidation = require('../../../validations/conversations');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');

router
  .route('/')
  .post(auth({ roles: [], permissions: [] }), validate(messagesValidation.createMessage), messagesController.createMessage)
  .get(auth({ roles: [], permissions: [] }), validate(messagesValidation.getMessages), messagesController.getMessages);

module.exports = router;
