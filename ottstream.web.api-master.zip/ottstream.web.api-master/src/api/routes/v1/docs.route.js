const express = require('express');
const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');
const swaggerDefinition = require('../../docs/swaggerDef');
// const swaggerFile = require('./swagger-output.json');

const router = express.Router();

// eslint-disable-next-line no-unused-vars
const specs = swaggerJsdoc({
  swaggerDefinition,
  apis: ['src/api/docs/*.yml', 'src/api/routes/v1/*/*.js'],
});

router.use('/', swaggerUi.serve);
router.get('/', swaggerUi.setup(specs));

module.exports = router;
