const router = require('express').Router();
const {
  rates,
  createShipment,
  labels,
  updateShipment,
  getShipment,
  getShipments,
  deleteShipment,
  warehouseState,
  pickupSlots,
  requestPickup,
  getCheckpoints,
  getStatus,
  getItemCategories,
  getBoxes,
} = require('../../../controllers').easyshipController;
const auth = require('../../../../middlewares/auth');

router.route('/rates').post(rates);

router.route('/shipments').get(getShipments).post(createShipment).patch(warehouseState);

router.route('/shipment/:id').patch(updateShipment).get(getShipment).delete(deleteShipment);

router.route('/labels').post(labels);

router.route('/pickup_slots/:id').get(pickupSlots);

router.route('/pickups').post(requestPickup);

router.route('/checkpoints/:id').get(getCheckpoints);

router.route('/status/:id').get(getStatus);

router.route('/item-categories').get(getItemCategories);

router.route('/boxes').get(auth({ roles: [], permissions: ['getDiscounts'] }), getBoxes);

module.exports = router;
