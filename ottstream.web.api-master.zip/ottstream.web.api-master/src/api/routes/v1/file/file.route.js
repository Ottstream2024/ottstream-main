const express = require('express');
const auth = require('../../../../middlewares/auth');
const validate = require('../../../../middlewares/validate');
const validateFile = require('../../../../middlewares/validate_file');
const fileValidation = require('../../../validations/file/file.validation');
const fileController = require('../../../controllers/file/file.controller');
const { fileMulterService, channelSetTypeImageMulterService } = require('../../../utils/file/multerFileUpload');

const router = express.Router();

router
  .route('/')
  .post(
    auth({ roles: [], permissions: ['manageFiles'] }),
    validate(fileValidation.createFile),
    fileMulterService.getInstance().single('file'),
    validateFile('file'),
    fileController.createFile
  )
  .get(auth({ roles: [], permissions: ['getFiles'] }), validate(fileValidation.getFiles), fileController.getFiles);

router
  .route('/channelIconSetTypeIcon')
  .post(
    auth({ roles: [], permissions: ['manageChannels'] }),
    validate(fileValidation.createFile),
    channelSetTypeImageMulterService.getInstance().single('file'),
    validateFile('file'),
    fileController.createChannelIconFile
  );

router.route('/icon/:fileId').get(validate(fileValidation.getFile), fileController.getFile);

// router.route('/icon/:fileId').get(validate(fileValidation.getFile), fileController.getFile);

router
  .route('/edit/:fileId')
  // .get(validate(fileValidation.getFile), fileController.getFile)
  .patch(auth({ roles: [], permissions: ['updateFile'] }), validate(fileValidation.updateFile), fileController.updateFile)
  .delete(auth({ roles: [], permissions: ['deleteFile'] }), validate(fileValidation.deleteFile), fileController.deleteFile);

// router
//   .route('/user')
//   .get(auth('getFiles'), validate(fileValidation.getFile), fileController.getUserFile)

module.exports = router;

/**
 * @swagger
 * tags:
 *   name: Files
 *   description: File management and retrieval
 */

/**
 * @swagger
 * path:
 *  /files:
 *    post:
 *      summary: Create a file
 *      description: Only admins can create other files.
 *      tags: [Files]
 *      security:
 *        - bearerAuth: []
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              required:
 *                - name
 *                - email
 *                - password
 *                - role
 *              properties:
 *                name:
 *                  type: string
 *                email:
 *                  type: string
 *                  format: email
 *                  description: must be unique
 *                password:
 *                  type: string
 *                  format: password
 *                  minLength: 8
 *                  description: At least one number and one letter
 *                role:
 *                   type: string
 *                   enum: [file, admin]
 *              example:
 *                name: fake name
 *                email: fake@example.com
 *                password: password1
 *                role: file
 *      responses:
 *        "201":
 *          description: Created
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/File'
 *        "400":
 *          $ref: '#/components/responses/DuplicateEmail'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *
 *    get:
 *      summary: Get all files
 *      description: Only admins can retrieve all files.
 *      tags: [Files]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: query
 *          name: name
 *          schema:
 *            type: string
 *          description: File name
 *        - in: query
 *          name: role
 *          schema:
 *            type: string
 *          description: File role
 *        - in: query
 *          name: sortBy
 *          schema:
 *            type: string
 *          description: sort by query in the form of field:desc/asc (ex. name:asc)
 *        - in: query
 *          name: limit
 *          schema:
 *            type: integer
 *            minimum: 1
 *          default: 10
 *          description: Maximum number of files
 *        - in: query
 *          name: page
 *          schema:
 *            type: integer
 *            minimum: 1
 *            default: 1
 *          description: Page number
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                  results:
 *                    type: array
 *                    items:
 *                      $ref: '#/components/schemas/File'
 *                  page:
 *                    type: integer
 *                    example: 1
 *                  limit:
 *                    type: integer
 *                    example: 10
 *                  totalPages:
 *                    type: integer
 *                    example: 1
 *                  totalResults:
 *                    type: integer
 *                    example: 1
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 */

/**
 * @swagger
 * path:
 *  /files/{id}:
 *    get:
 *      summary: Get a file
 *      description: Logged in files can fetch only their own file information. Only admins can fetch other files.
 *      tags: [Files]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: File id
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/File'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 *
 *    patch:
 *      summary: Update a file
 *      description: Logged in files can only update their own information. Only admins can update other files.
 *      tags: [Files]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: File id
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                name:
 *                  type: string
 *                email:
 *                  type: string
 *                  format: email
 *                  description: must be unique
 *                password:
 *                  type: string
 *                  format: password
 *                  minLength: 8
 *                  description: At least one number and one letter
 *              example:
 *                name: fake name
 *                email: fake@example.com
 *                password: password1
 *      responses:
 *        "200":
 *          description: OK
 *          content:
 *            application/json:
 *              schema:
 *                 $ref: '#/components/schemas/File'
 *        "400":
 *          $ref: '#/components/responses/DuplicateEmail'
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 *
 *    delete:
 *      summary: Delete a file
 *      description: Logged in files can delete only themselves. Only admins can delete other files.
 *      tags: [Files]
 *      security:
 *        - bearerAuth: []
 *      parameters:
 *        - in: path
 *          name: id
 *          required: true
 *          schema:
 *            type: string
 *          description: File id
 *      responses:
 *        "200":
 *          description: No content
 *        "401":
 *          $ref: '#/components/responses/Unauthorized'
 *        "403":
 *          $ref: '#/components/responses/Forbidden'
 *        "404":
 *          $ref: '#/components/responses/NotFound'
 */
