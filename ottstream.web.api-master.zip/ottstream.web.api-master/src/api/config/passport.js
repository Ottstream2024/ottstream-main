const GoogleStrategy = require('passport-google-oauth2').Strategy;
const GoogleAuthCodeStrategy = require('passport-google-authcode').Strategy;
const { Strategy: JwtStrategy, ExtractJwt } = require('passport-jwt');
const config = require('../../config');
// eslint-disable-next-line no-unused-vars
const { userRepository } = require('../../repository');
const logger = require('../../utils/logger/logger');

const jwtOptions = {
  secretOrKey: config.getConfig().jwt.secret,
  jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
};

const jwtVerify = async (payload, done) => {
  const paylod = {
    userId: payload?.sub,
    token: payload?.id,
  };
  return done(null, paylod, false);
};

const jwtStrategy = new JwtStrategy(jwtOptions, jwtVerify);

// const googleStrategy = new GoogleStrategy(
//   {
//     clientID: config.getConfig().google.clientId,
//     clientSecret: config.getConfig().google.secret,
//     callbackURL: config.getConfig().google.callbackUrl,
//     passReqToCallback: true,
//   },
//   // eslint-disable-next-line no-unused-vars

//   async (accessToken, refreshToken, profile, done) => {
//     const newUser = {
//       googleId: profile.id,
//       firstname: profile.name.givenName,
//       lastname: profile.name.familyName,
//       email: profile.emails[0].value,
//     };

//     try {
//       let user = await userRepository.getUserByGoogleId(profile.id);
//       if (user) {
//         done(null, user);
//       } else {
//         // if user is not preset in our database save user data to database.
//         user = await userRepository.getUserByGoogleId(profile.id);
//         user = await userRepository.createUser(newUser, 'ottprovider');
//         done(null, user);
//       }
//     } catch (err) {
//       logger.error(err);
//     }
//   }
// );

const googleStrategy = new GoogleStrategy(
  {
    clientID: '843759782878-ims9f08e41uh8n8sr5iodl62dtd0qk75.apps.googleusercontent.com',
    clientSecret: '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',
    callbackURL: 'http://localhost:3000/v1/auth/google/callback',
  },
  (_accessToken, _refreshToken, profile, done) => {
    // Handle user authentication or registration here
    // For example, you might save the user to a database
    // In this example, we're just passing the profile to the done callback
    logger.info(profile);
    done(null, profile);
  }
);

const googleAuthCodeStrategy = new GoogleAuthCodeStrategy(
  {
    clientID: '843759782878-ims9f08e41uh8n8sr5iodl62dtd0qk75.apps.googleusercontent.com',
    clientSecret: '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',
  },
  function (_accessToken, _refreshToken, profile, done) {
    const newUser = {
      googleId: profile.id,
      firstname: profile.name.givenName,
      lastname: profile.name.familyName,
      email: profile.emails[0].value,
    };
    done(null, newUser);

    // try {
    //   let user = await userRepository.getUserByGoogleId(profile.id);
    //   if (user) {
    //     done(null, user);
    //   } else {
    //     // if user is not preset in our database save user data to database.
    //     user = await userRepository.getUserByGoogleId(profile.id);
    //     user = await userRepository.createUser(newUser, 'ottprovider');
    //     done(null, user);
    //   }
    // } catch (err) {
    //   logger.error(err);
    // }
  }
);

module.exports = {
  jwtStrategy,
  googleStrategy,
  googleAuthCodeStrategy,
};
