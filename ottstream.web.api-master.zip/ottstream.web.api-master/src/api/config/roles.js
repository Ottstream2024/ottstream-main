const roles = ['user', 'admin', 'ottprovider'];

const admin = [
  'getUsers',
  'manageUsers',
  'getPackets',
  'managePackets',
  'getPackages',
  'managePackages',
  'getChannels',
  'manageChannels',
  'getCategorys',
  'manageCategorys',
  'getChannelPackages',
  'manageChannelPackages',
  'getChannelPackagePrices',
  'manageChannelPackagePrices',
  'getFiles',
  'manageFiles',
  'getCreditCards',
  'manageCreditCards',
  'getPaymentGateways',
  'managePaymentGateways',
  'getPaymentImplementations',
  'managePaymentImplementations',
  'getLanguageUnits',
  'manageLanguageUnits',
  'getLanguageUnitTranslations',
  'manageLanguageUnitTranslations',
  'getLanguages',
  'manageLanguages',
  'getCountrys',
  'manageCountrys',
  'applyForOttProvider',
  'getOttProviders',
  'manageOttProviders',
  'getPermissions',
  'managePermissions',
  'getRoles',
  'manageRoles',
];
const ott = ['applyForOttProvider'];
const roleRights = new Map();
roleRights.set(roles[0], []);
roleRights.set(roles[1], admin);
roleRights.set(roles[2], ott);

module.exports = {
  roles,
  roleRights,
};
