const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createNotification = {
  body: Joi.object()
    .keys({
      note: Joi.string().allow(''),
      client: Joi.string().custom(objectId),
      comment: Joi.string().custom(objectId),
    })
    .min(1),
};

const getNotifications = {
  query: Joi.object().keys({
    search: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    client: Joi.string().custom(objectId),
    comment: Joi.string().custom(objectId),
    isViewed: Joi.bool(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    name: Joi.string(),
    description: Joi.string(),
    excel: Joi.boolean(),
  }),
};

const getNotification = {
  params: Joi.object().keys({
    notificationId: Joi.string().custom(objectId),
  }),
};

const updateNotification = {
  params: Joi.object().keys({
    notificationId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      note: Joi.string().allow(''),
      isViewed: Joi.bool(),
      client: Joi.string().custom(objectId),
      comment: Joi.string().custom(objectId),
    })
    .min(1),
};

const notificationEnableDisableAction = {
  body: Joi.object().keys({
    enableForSale: Joi.bool(),
    notificationId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const deleteNotification = {
  params: Joi.object().keys({
    notificationId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createNotification,
  getNotifications,
  getNotification,
  updateNotification,
  deleteNotification,
  notificationEnableDisableAction,
};
