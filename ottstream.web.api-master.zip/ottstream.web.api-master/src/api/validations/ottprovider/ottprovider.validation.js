const Joi = require('joi');
const { objectId } = require('../custom.validation');
const { password } = require('../custom.validation');
const { addBalance } = require('../payment/balance.validation');
const { createCreditCardJoi } = require('../payment/credit_card/credit_card.validation');
const { createBankTransferJoi } = require('../payment/bank_transfer/bank_transfer.validation');

const ottproviderSettingsJoi = {
  companyName: Joi.string().allow(null),
  channelMinCount: Joi.number().allow(null),
  channelMaxCount: Joi.number().allow(null),
  clientAmount: Joi.number().allow(null),
  dateFrom: Joi.date().allow(null),
  dateTo: Joi.date().allow(null),
  state: Joi.number().allow(null),
};

const ottproviderSalesTaxJoi = {
  serviceTaxByApi: Joi.bool(),
  serviceTaxPercent: Joi.number().when('serviceTaxByApi', {
    is: false,
    then: Joi.number().integer().min(0).max(100),
  }),
  productTaxByApi: Joi.bool(),
  productTaxPercent: Joi.number().when('productTaxByApi', {
    is: false,
    then: Joi.number().integer().min(0).max(100),
  }),
  countryTax: Joi.array().items({
    id: Joi.string().custom(objectId),
    country: Joi.string().required().allow(''),
    countryState: Joi.string(),
    serviceTaxPercent: Joi.number().min(0).max(100),
    productTaxPercent: Joi.number().required().min(0).max(100).allow(null),
  }),
};

const updateOttProviderSettingsJoi = Joi.object().keys({
  id: Joi.string().custom(objectId),
  ...ottproviderSettingsJoi,
});
const updateOttProviderSalesTaxJoi = Joi.object().keys({
  params: Joi.object().keys({
    ottproviderId: Joi.string().custom(objectId),
  }),
  ...ottproviderSalesTaxJoi,
});

const createOttProvider = {
  body: Joi.object().keys({
    name: Joi.array()
      .items({
        lang: Joi.string().required(),
        name: Joi.string().required(),
      })
      .min(1),
    phone: Joi.string().trim().required(),
    description: Joi.string(),
    website: Joi.string(),
    clientAmount: Joi.number().integer().required(),
    channelAmount: Joi.string(),
    email: Joi.string().email(),
    payment: Joi.object().keys({
      balance: addBalance,
      methods: Joi.array().items({
        paymentMethod: Joi.string().required(),
        creditCard: createCreditCardJoi,
        default: Joi.boolean(),
        bankTransfer: createBankTransferJoi,
        billingAddress: Joi.object().keys({
          id: Joi.string().custom(objectId),
          // ...ottproviderAddressJoi,
        }),
      }),
    }),
  }),
};

const addByAdmin = {
  body: Joi.object().keys({
    email: Joi.string().required().email(),
    password: Joi.string().required().custom(password),
    firstname: Joi.string().required(),
    lastname: Joi.string().required(),
    companyName: Joi.array()
      .items({
        lang: Joi.string().required(),
        name: Joi.string().required(),
      })
      .required()
      .min(1),
    companyEmails: Joi.array()
      .items({
        inUse: Joi.bool(),
        isMain: Joi.bool(),
        isInfo: Joi.bool(),
        isSupport: Joi.bool(),
        forInvoice: Joi.bool(),
        forSend: Joi.bool(),
        smtp: Joi.alternatives().conditional('forSend', {
          is: true,
          then: Joi.object().keys({
            server: Joi.string().allow(null).regex(/^\S*$/),
            ssl: Joi.bool(),
            port: Joi.number().integer().min(1).max(65534),
            username: Joi.string().allow(null).regex(/^\S*$/),
            password: Joi.string().allow(null).regex(/^\S*$/),
          }),
        }),
        address: Joi.string().required(),
      })
      .required(),
    companyPhones: Joi.array()
      .items({
        inUse: Joi.bool(),
        isMain: Joi.bool(),
        isSupport: Joi.bool(),
        isMobile: Joi.bool(),
        forInvoice: Joi.bool(),
        number: Joi.string().trim().required(),
      })
      .required(),
    website: Joi.string(),
    phone: Joi.object()
      .keys({
        phoneNumber: Joi.string(),
        countryCode: Joi.string(),
      })
      .required(),
    comment: Joi.string().allow(null, ''),
    priceGroup: Joi.string().allow(null),
    country: Joi.string().required(),
    description: Joi.string(),
    timezone: Joi.string(),
    channelAmount: Joi.number().required(),
    clientAmount: Joi.number().integer().required(),
    parentId: Joi.required().custom(objectId),
  }),
};

const checkEmailOnOthers = {
  body: Joi.object().keys({
    email: Joi.string().required().email(),
    providerId: Joi.custom(objectId),
  }),
};

const getOttProviders = {
  query: Joi.object().keys({
    excel: Joi.boolean(),
    search: Joi.string().trim(),
    country: Joi.string(),
    clientsFrom: Joi.number(),
    clientsTo: Joi.number(),
    resellersFrom: Joi.number(),
    resellersTo: Joi.number(),
    totalLoginsFrom: Joi.number(),
    totalLoginsTo: Joi.number(),
    activeLoginsFrom: Joi.number(),
    activeLoginsTo: Joi.number(),
    priceGroup: Joi.string().custom(objectId).allow(null),
    balanceFrom: Joi.number(),
    balanceTo: Joi.number(),
    debtFrom: Joi.number(),
    debtTo: Joi.number(),
    creditAmountFrom: Joi.number(),
    creditAmountTo: Joi.number(),
    creditDateFrom: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    creditDateTo: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    creditAutoExtend: Joi.boolean(),
    creditDaysRemainingFrom: Joi.number(),
    creditDaysRemainingTo: Joi.number(),
    currentMonthPaymentsFrom: Joi.number(),
    currentMonthPaymentsTo: Joi.number(),
    currentMonthIncomeFrom: Joi.number(),
    currentMonthIncomeTo: Joi.number(),
    dateFrom: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    dateTo: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    sortBy: Joi.string(),
    state: Joi.string().trim(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    parentId: Joi.string().custom(objectId),
    // user: Joi.string().custom(objectId),
    // lang: Joi.string(),
  }),
};

const getOttProviderForFilters = {
  query: Joi.object().keys({
    parent: Joi.boolean().default(false),
    parents: Joi.string(),
    providers: Joi.string(),
  }),
};

const getOttProviderBalanceCredit = {
  params: Joi.object().keys({
    ottProviderId: Joi.string().custom(objectId),
  }),
};

const updateOttProviderPaymentMethodOptions = {
  params: Joi.object().keys({
    ottProviderId: Joi.string().custom(objectId),
  }),
  body: Joi.object().keys({
    cardsFee: Joi.object().keys({
      cardsCollectFeeProvider: Joi.boolean(),
      enabled: Joi.boolean(),
      fixed: Joi.number(),
      percent: Joi.number(),
    }),
    bankFee: Joi.object().keys({
      bankCollectFeeProvider: Joi.boolean(),
      enabled: Joi.boolean(),
      fixed: Joi.number(),
      percent: Joi.number(),
    }),
  }),
};

const getOttProviderPaymentMethodOptions = {
  params: Joi.object().keys({
    ottProviderId: Joi.string().custom(objectId),
  }),
};

const getRegistrationProviders = {
  query: Joi.object().keys({
    state: Joi.number().integer(),
    channelMinCount: Joi.number().integer(),
    channelMaxCount: Joi.number().integer(),
    clientAmount: Joi.number().integer(),
    search: Joi.string(),
    dateFrom: Joi.date(),
    dateTo: Joi.date(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    excel: Joi.boolean(),
  }),
};

const getOttProvider = {
  params: Joi.object().keys({
    ottproviderId: Joi.string().custom(objectId),
  }),
};

const updateOttProvider = {
  params: Joi.object().keys({
    ottproviderId: Joi.custom(objectId),
  }),
  body: Joi.object().keys({
    user: Joi.object().keys({
      firstname: Joi.string().allow(''),
      email: Joi.string().email(),
      id: Joi.custom(objectId),
      password: Joi.string(),
      lastname: Joi.string(),
      phone: Joi.object().keys({
        phoneNumber: Joi.string(),
        countryCode: Joi.string(),
      }),
    }),
    companyName: Joi.array()
      .items({
        id: Joi.string().custom(objectId),
        lang: Joi.string(),
        name: Joi.string(),
      })
      .min(1),
    companyEmails: Joi.array().items(Joi.string().custom(objectId)),
    companyPhones: Joi.array().items(Joi.string().custom(objectId)),
    website: Joi.string(),
    comment: Joi.string(),
    priceGroup: Joi.string().custom(objectId).allow(null),
    country: Joi.string(),
    description: Joi.string(),
    timezone: Joi.string(),
    channelAmount: Joi.number(),
    clientAmount: Joi.number().integer(),
  }),
};

const actionSettings = {
  body: Joi.object().keys({
    actionStatus: Joi.string().valid('blockAccess', 'enableAccess', 'blockAll', 'pauseClient', 'blockClient'),
    ottproviderId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const approveOttProvider = {
  params: Joi.object().keys({
    ottproviderId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      state: Joi.number(),
    })
    .min(1),
};

const registrationApprove = {
  body: Joi.object().keys({
    providers: Joi.array().items({ id: Joi.required().custom(objectId), state: Joi.number() }),
  }),
};

const deleteOttProvider = {
  params: Joi.object().keys({
    ottproviderId: Joi.string().custom(objectId),
  }),
};

const ottProvderActionDelete = {
  body: Joi.object().keys({
    ottproviderId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const getCheckOttProviderKey = {
  params: Joi.object().keys({
    ottproviderId: Joi.string().custom(objectId),
  }),
  // address: Joi.string().custom(objectId).allow(null),
  // email: Joi.string().custom(objectId).allow(null),
  phone: Joi.string().custom(objectId).allow(null),
};

const updateOttProviderPaymentMethod = {
  params: Joi.object().keys({
    ottproviderId: Joi.string().custom(objectId),
  }),
};
const updateOttProviderBalanceCredit = {
  params: Joi.object().keys({
    ottproviderId: Joi.string().custom(objectId),
  }),
};
const updateOttProviderPaymentGateway = {
  params: Joi.object().keys({
    ottproviderId: Joi.string().custom(objectId),
  }),
};
const updateOttProviderLabelReceiptPrinters = {
  params: Joi.object().keys({
    ottproviderId: Joi.string().custom(objectId),
  }),
};
const updateOttProviderUiAndAccessCustomization = {
  params: Joi.object().keys({
    ottproviderId: Joi.string().custom(objectId),
  }),
};
const updateOttProviderInfoForClientsApp = {
  params: Joi.object().keys({
    ottproviderId: Joi.string().custom(objectId),
  }),
};
const updateOttProviderPermissionsAndSettings = {
  params: Joi.object().keys({
    ottproviderId: Joi.string().custom(objectId),
  }),
};
const updateOttProviderSaleTaxes = {
  params: Joi.object().keys({
    ottproviderId: Joi.string().custom(objectId),
  }),
};
const updateOttProviderBillInvoicesGeneration = {
  params: Joi.object().keys({
    ottproviderId: Joi.string().custom(objectId),
  }),
};
const updateOttProviderOtherApiIntegrations = {
  params: Joi.object().keys({
    ottproviderId: Joi.string().custom(objectId),
  }),
};
const syncLive = {};

module.exports = {
  updateOttProviderPaymentMethodOptions,
  getOttProviderPaymentMethodOptions,
  createOttProvider,
  syncLive,
  getOttProviders,
  getOttProvider,
  updateOttProvider,
  deleteOttProvider,
  ottProvderActionDelete,
  getCheckOttProviderKey,
  approveOttProvider,
  getRegistrationProviders,
  registrationApprove,
  updateOttProviderSettingsJoi,
  updateOttProviderSalesTaxJoi,
  addByAdmin,
  getOttProviderBalanceCredit,
  checkEmailOnOthers,
  actionSettings,
  updateOttProviderPaymentMethod,
  updateOttProviderBalanceCredit,
  updateOttProviderPaymentGateway,
  updateOttProviderLabelReceiptPrinters,
  updateOttProviderUiAndAccessCustomization,
  updateOttProviderInfoForClientsApp,
  updateOttProviderPermissionsAndSettings,
  updateOttProviderSaleTaxes,
  updateOttProviderBillInvoicesGeneration,
  updateOttProviderOtherApiIntegrations,
  getOttProviderForFilters,
};
