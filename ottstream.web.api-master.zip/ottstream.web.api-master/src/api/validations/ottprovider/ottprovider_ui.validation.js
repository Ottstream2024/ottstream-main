const Joi = require('joi');
const { objectId } = require('../custom.validation');

const ottprovidersUiJoi = {
  domain: Joi.string().allow(''),
  dns: Joi.string().allow(''),
  providerId: Joi.string().custom(objectId),
};

const createOttProviderUi = {
  body: Joi.object().keys(ottprovidersUiJoi),
};

const getOttProviderUis = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    providerId: Joi.string().custom(objectId),
  }),
};

const getOttProviderUi = {
  params: Joi.object().keys({
    ottProviderId: Joi.string().custom(objectId),
  }),
};

const updateOttProviderUi = {
  params: Joi.object().keys({
    ottProviderId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      ...ottprovidersUiJoi,
    })
    .min(1),
};

const deleteOttProviderUi = {
  params: Joi.object().keys({
    ottProviderUiId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createOttProviderUi,
  getOttProviderUis,
  getOttProviderUi,
  updateOttProviderUi,
  deleteOttProviderUi,
};
