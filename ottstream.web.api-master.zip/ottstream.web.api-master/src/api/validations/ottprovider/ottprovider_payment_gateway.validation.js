const Joi = require('joi');
const { objectId } = require('../custom.validation');

const ottprovidersPaymentGatewayJoi = {
  autopay: Joi.string().allow(null, ''),
  autopayInterval: Joi.number(),
  autopayRetryCount: Joi.number(),
  autopayCollectFeeClient: Joi.bool(),
  cards: Joi.string().allow(null, ''),
  cardsCollectFeeClient: Joi.bool(),
  bank: Joi.string().allow(null, ''),
  bankCollectFeeClient: Joi.bool(),
  collectClientFee: Joi.array().items(
    Joi.object().keys({
      type: Joi.number().valid(1, 2, 3),
      fixed: Joi.string(),
      percent: Joi.string(),
    })
  ),
  autoPayFee: Joi.object().keys({
    enabled: Joi.boolean(),
    fixed: Joi.number(),
    percent: Joi.number(),
  }),
  cardsFee: Joi.object().keys({
    enabled: Joi.boolean(),
    fixed: Joi.number(),
    percent: Joi.number(),
  }),
  bankFee: Joi.object().keys({
    enabled: Joi.boolean(),
    fixed: Joi.number(),
    percent: Joi.number(),
  }),
  authorize: Joi.object().keys({
    apiLoginId: Joi.string().allow(null, ''),
    transactionKey: Joi.string().allow(null, ''),
    currentSignatureKey: Joi.string().allow(null, ''),
  }),
  paypal: Joi.object().keys({
    username: Joi.string().allow(null, ''),
    password: Joi.string().allow(null, ''),
    signature: Joi.string().allow(''),
  }),
  stripe: Joi.object().keys({
    secretKey: Joi.string().allow(null, ''),
    publicKey: Joi.string().allow(null, ''),
  }),
  clover: Joi.object().keys({
    merchantId: Joi.string().allow(null, ''), // .regex(/^\S+$/),
    secretKey: Joi.string().allow(null, ''), // .regex(/^\S+$/),
  }),
  square: Joi.object().keys({
    applicationId: Joi.string().allow(null, ''), // .regex(/^\S+$/),
    locationId: Joi.string().allow(null, ''), // .regex(/^\S+$/),
    isValidApplicationId: Joi.bool(), // .regex(/^\S+$/),
    secretKey: Joi.string().allow(null, ''), // .regex(/^\S+$/),
    isProduction: Joi.boolean(),
  }),
  providerId: Joi.string().custom(objectId),
};

const createOttProviderPaymentGateway = {
  body: Joi.object().keys(ottprovidersPaymentGatewayJoi),
};

const getOttProviderPaymentGateways = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    providerId: Joi.string().custom(objectId),
  }),
};

const getOttProviderPaymentGatewayMethods = {
  params: Joi.object().keys({
    providerId: Joi.string().custom(objectId).required(),
  }),
};

const getOttProviderPaymentGateway = {
  params: Joi.object().keys({
    ottProviderId: Joi.string().custom(objectId),
  }),
};

const updateOttProviderPaymentGateway = {
  params: Joi.object().keys({
    ottProviderId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      autopay: Joi.string().allow(null, ''),
      autopayInterval: Joi.number().allow(null, ''),
      autopayRetryCount: Joi.number().allow(null, ''),
      autopayCollectFeeClient: Joi.bool(),
      cards: Joi.string().allow(null, ''),
      cardsCollectFeeClient: Joi.bool(),
      bank: Joi.string().allow(null, ''),
      bankCollectFeeClient: Joi.bool(),
      autoPayFee: Joi.object().keys({
        enabled: Joi.boolean(),
        fixed: Joi.number(),
        percent: Joi.number(),
      }),
      cardsFee: Joi.object().keys({
        enabled: Joi.boolean(),
        fixed: Joi.number(),
        percent: Joi.number(),
      }),
      bankFee: Joi.object().keys({
        enabled: Joi.boolean(),
        fixed: Joi.number(),
        percent: Joi.number(),
      }),
      authorize: Joi.object().keys({
        apiLoginId: Joi.string().allow(null, ''), // regex(/^\S+$/),
        transactionKey: Joi.string().allow(null, ''), // regex(/^\S+$/),
        currentSignatureKey: Joi.string().allow(null, ''), // regex(/^\S+$/).allow(''),
      }),
      paypal: Joi.object().keys({
        username: Joi.string().allow(null, ''),
        password: Joi.string().allow(null, ''),
        signature: Joi.string().allow(null, ''), // regex(/^\S+$/).allow(''),
      }),
      stripe: Joi.object().keys({
        secretKey: Joi.string().allow(null, ''), // .regex(/^\S+$/),
        publicKey: Joi.string().allow(null, ''), // .regex(/^\S+$/),
      }),
      clover: Joi.object().keys({
        merchantId: Joi.string().allow(null, ''), // .regex(/^\S+$/),
        secretKey: Joi.string().allow(null, ''), // .regex(/^\S+$/),
      }),
      square: Joi.object().keys({
        applicationId: Joi.string().allow(null, ''), // .regex(/^\S+$/),
        locationId: Joi.string().allow(null, ''), // .regex(/^\S+$/),
        isValidApplicationId: Joi.bool(), // .regex(/^\S+$/),
        secretKey: Joi.string().allow(null, ''), // .regex(/^\S+$/),
        isProduction: Joi.boolean(),
      }),
      providerId: Joi.string().custom(objectId),
    })
    .min(1),
};

const deleteOttProviderPaymentGateway = {
  params: Joi.object().keys({
    ottProviderPaymentGatewayId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  getOttProviderPaymentGatewayMethods,
  createOttProviderPaymentGateway,
  getOttProviderPaymentGateways,
  getOttProviderPaymentGateway,
  updateOttProviderPaymentGateway,
  deleteOttProviderPaymentGateway,
};
