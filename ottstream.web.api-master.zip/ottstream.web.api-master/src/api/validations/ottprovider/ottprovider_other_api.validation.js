const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createOttProviderOtherApi = {
  ivr: Joi.object().keys({
    apiToken: Joi.string().required().allow('', null),
  }),
  ring: Joi.object().keys({
    apiToken: Joi.string().required().allow('', null),
  }),
  checkeeper: Joi.object().keys({
    apiToken: Joi.string().required().allow('', null),
    secret: Joi.string().required().allow('', null),
  }),
  smarty: Joi.object().keys({
    key: Joi.string().required().allow('', null),
  }),
  postal: Joi.object().keys({
    secretKey: Joi.string().required().allow('', null),
  }),
  taxJar: Joi.object().keys({
    apiToken: Joi.string().required().allow('', null),
  }),
  providerId: Joi.string().custom(objectId).allow('', null),
};

const getOttProviderOtherApis = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    providerId: Joi.string().custom(objectId),
  }),
};

const getOttProviderOtherApi = {
  params: Joi.object().keys({
    ottProviderId: Joi.string().custom(objectId),
  }),
};

const smsCheckeeperSignature = {
  params: Joi.object().keys({
    ottProviderId: Joi.required().custom(objectId),
  }),
  body: Joi.object().keys({
    phone: Joi.string().required(),
  }),
};

const updateOttProviderOtherApi = {
  params: Joi.object().keys({
    ottProviderId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      ivr: Joi.object().keys({
        apiToken: Joi.string().trim().regex(/^\S+$/).allow('', null),
      }),
      // .messages({
      //   'string.pattern.base': `No white space allowed`,
      // }),
      ring: Joi.object().keys({
        apiToken: Joi.string().regex(/^\S+$/).allow('', null),
      }),
      checkeeper: Joi.object().keys({
        apiToken: Joi.string().regex(/^\S+$/).allow('', null),
        secret: Joi.string().regex(/^\S+$/).allow('', null),
        bankAccount: Joi.string().allow('', null),
        templateName: Joi.string().allow('', null),
        companyAddress: Joi.string().custom(objectId).allow(null, ''),
        companyName: Joi.string().allow('', null),
        routingNumber: Joi.string().allow('', null),
        signatureImage: Joi.string().allow('', null),
      }),
      smarty: Joi.object().keys({
        key: Joi.string().regex(/^\S+$/).allow('', null),
      }),
      postal: Joi.object().keys({
        secretKey: Joi.string().regex(/^\S+$/).allow('', null),
      }),
      taxJar: Joi.object().keys({
        apiToken: Joi.string().regex(/^\S+$/).allow('', null),
      }),
      providerId: Joi.string().custom(objectId).allow('', null),
    })
    .min(1),
};

const deleteOttProviderOtherApi = {
  params: Joi.object().keys({
    ottProviderOtherApiId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createOttProviderOtherApi,
  getOttProviderOtherApis,
  getOttProviderOtherApi,
  smsCheckeeperSignature,
  updateOttProviderOtherApi,
  deleteOttProviderOtherApi,
};
