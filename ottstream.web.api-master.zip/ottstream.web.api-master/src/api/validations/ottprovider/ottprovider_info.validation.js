const Joi = require('joi');
const { objectId } = require('../custom.validation');

const ottprovidersInfoJoi = {
  providerId: Joi.string().custom(objectId),
  address: Joi.string().custom(objectId).allow(null),
  email: Joi.string().custom(objectId).allow(null),
  phone: Joi.string().custom(objectId).allow(null),
  comment: Joi.string().allow(null),
};

const createOttProviderInfo = {
  body: Joi.object().keys(ottprovidersInfoJoi),
};

const getOttProviderInfos = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    providerId: Joi.string().custom(objectId),
  }),
};

const getOttProviderInfo = {
  params: Joi.object().keys({
    ottProviderId: Joi.string().custom(objectId),
  }),
};

const updateOttProviderInfo = {
  params: Joi.object().keys({
    ottProviderId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      ...ottprovidersInfoJoi,
    })
    .min(1),
};

const deleteOttProviderInfo = {
  params: Joi.object().keys({
    ottProviderInfoId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createOttProviderInfo,
  getOttProviderInfos,
  getOttProviderInfo,
  updateOttProviderInfo,
  deleteOttProviderInfo,
};
