const Joi = require('joi');
const { objectId } = require('../custom.validation');

const permissionObjectValidation = Joi.object().keys({
  permissions: Joi.object().keys({
    permission: Joi.string().required(),
    name: Joi.array()
      .items({
        lang: Joi.string().required(),
        name: Joi.string().required(),
      })
      .min(1),
    onOff: Joi.bool(),
    onOffChild: Joi.bool(),
  }),
});

const createOttProviderPermission = {
  body: permissionObjectValidation,
};

const getOttProviderPermission = {
  params: Joi.object().keys({
    ottProviderId: Joi.string().custom(objectId),
  }),
};

const updateOttProviderPermission = {
  params: Joi.object().keys({
    ottProviderId: Joi.required().custom(objectId),
  }),
  body: permissionObjectValidation,
};

module.exports = {
  createOttProviderPermission,
  getOttProviderPermission,
  updateOttProviderPermission,
};
