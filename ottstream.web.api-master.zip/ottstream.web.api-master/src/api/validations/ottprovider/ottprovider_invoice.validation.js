const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createOttProviderInvoice = {};

const printExampleInvoice = {
  query: Joi.object().keys({
    type: Joi.number().default(1),
  }),
  params: Joi.object().keys({
    ottProviderId: Joi.string().custom(objectId),
  }),
};

const getInvoiceHtml = {
  params: Joi.object().keys({
    ottProviderId: Joi.string().custom(objectId),
  }),
};

const getOttProviderInvoices = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    providerId: Joi.string().custom(objectId),
  }),
};

const getOttProviderInvoice = {
  params: Joi.object().keys({
    ottProviderId: Joi.string().custom(objectId),
  }),
};

const designUpdateJoi = Joi.object().keys({
  color: Joi.string(),
  template: Joi.string(),
  invoiceTitle: Joi.string(),
  quoteTitle: Joi.string(),
  creditNoteTitle: Joi.string(),
  logo: Joi.string().custom(objectId),
});

const settingsUpdateJoi = Joi.object().keys({
  dateFormat: Joi.string(),
  string: Joi.number(),
  currency: Joi.string(),
  website: Joi.string(),
  timezone: Joi.string(),
  autosend: Joi.number(),
  language: Joi.string(),
  paperFormat: Joi.string(),
  postalMethod: Joi.string(),
  returnEnvelope: Joi.bool(),
  comment: Joi.string().allow(''),
  invoiceGenerateDay: Joi.number(),

  phone: Joi.string().custom(objectId),
  email: Joi.string().custom(objectId),
  address: Joi.string().custom(objectId),
});

const updateOttProviderInvoice = {
  params: Joi.object().keys({
    ottProviderId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      settings: settingsUpdateJoi,
      design: designUpdateJoi,
    })
    .min(1),
};

const deleteOttProviderInvoice = {
  params: Joi.object().keys({
    ottProviderInvoiceId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  getInvoiceHtml,
  createOttProviderInvoice,
  getOttProviderInvoices,
  printExampleInvoice,
  getOttProviderInvoice,
  updateOttProviderInvoice,
  deleteOttProviderInvoice,
};
