const Joi = require('joi');
const { objectId } = require('../custom.validation');

const ottprovidersShippingProviderJoi = {
  provider_default: Joi.string().allow(null),
  client_default: Joi.string().allow(null),
  easyship: Joi.object()
    .keys({
      productionToken: Joi.string().required(),
    })
    .allow({}),
  shiprocket: Joi.object().keys({
    email: Joi.string().required().email(),
    password: Joi.string().required(),
  }),
  shipstation: Joi.object().keys({
    apiKey: Joi.string().required(),
    apiSecret: Joi.string().required(),
  }),
  goshippo: Joi.object().keys({
    apiToken: Joi.string().required(),
  }),
  providerId: Joi.string().custom(objectId),
};

const createOttProviderShippingProvider = {
  body: Joi.object().keys(ottprovidersShippingProviderJoi),
};

const getOttProviderShippingProviders = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    providerId: Joi.string().custom(objectId),
  }),
};

const getOttProviderShippingProvider = {
  params: Joi.object().keys({
    ottProviderId: Joi.string().custom(objectId),
  }),
};

const updateOttProviderShippingProvider = {
  params: Joi.object().keys({
    ottProviderId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      provider_default: Joi.string().allow(null),
      client_default: Joi.string().allow(null),
      easyship: Joi.object().keys({
        productionToken: Joi.string().regex(/^\S+$/).allow('', null),
      }),
      shiprocket: Joi.object().keys({
        email: Joi.string().email().allow('', null),
        password: Joi.string().allow('', null),
      }),
      shipstation: Joi.object().keys({
        apiKey: Joi.string().regex(/^\S+$/).allow('', null),
        apiSecret: Joi.string().regex(/^\S+$/).allow('', null),
      }),
      goshippo: Joi.object().keys({
        apiToken: Joi.string().regex(/^\S+$/).allow('', null),
      }),
      providerId: Joi.string().custom(objectId),
    })
    .min(1),
};

const deleteOttProviderShippingProvider = {
  params: Joi.object().keys({
    ottProviderShippingProviderId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createOttProviderShippingProvider,
  getOttProviderShippingProviders,
  getOttProviderShippingProvider,
  updateOttProviderShippingProvider,
  deleteOttProviderShippingProvider,
};
