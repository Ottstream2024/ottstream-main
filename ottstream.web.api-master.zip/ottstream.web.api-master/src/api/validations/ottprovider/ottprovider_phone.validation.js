const Joi = require('joi');
const { objectId } = require('../custom.validation');
const myCustomJoi = Joi.extend(require('joi-phone-number'));

myCustomJoi.string().phoneNumber();

const createOttProviderPhone = {
  body: Joi.object().keys({
    inUse: Joi.bool(),
    isMain: Joi.bool(),
    isSupport: Joi.bool(),
    isMobile: Joi.bool(),
    providerId: Joi.string().required().custom(objectId),
    forInvoice: Joi.bool(),
    number: myCustomJoi.string().phoneNumber().strict().required(),
  }),
};

const ottProviderCheckPhone = {
  query: Joi.object().keys({
    providerId: Joi.string().custom(objectId),
    phone: Joi.string().required(),
  }),
};

const getOttProviderPhones = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getOttProviderPhone = {
  params: Joi.object().keys({
    ottProviderPhoneId: Joi.string().custom(objectId),
  }),
};

const updateOttProviderPhone = {
  params: Joi.object().keys({
    ottProviderPhoneId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      inUse: Joi.bool(),
      isMain: Joi.bool(),
      isSupport: Joi.bool(),
      isMobile: Joi.bool(),
      forInvoice: Joi.bool(),
      number: myCustomJoi.string().phoneNumber().strict(),
    })
    .min(1),
};

const deleteOttProviderPhone = {
  params: Joi.object().keys({
    ottProviderPhoneId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createOttProviderPhone,
  ottProviderCheckPhone,
  getOttProviderPhones,
  getOttProviderPhone,
  updateOttProviderPhone,
  deleteOttProviderPhone,
};
