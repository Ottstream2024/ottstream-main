const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createOttProviderEmail = {
  body: Joi.object().keys({
    inUse: Joi.bool(),
    providerId: Joi.string().required().custom(objectId),
    isMain: Joi.bool(),
    isInfo: Joi.bool(),
    isSupport: Joi.bool(),
    forInvoice: Joi.bool(),
    forSend: Joi.bool(),
    smtp: Joi.alternatives().conditional('forSend', {
      is: true,
      then: Joi.object().keys({
        server: Joi.string().allow(null).regex(/^\S*$/),
        ssl: Joi.bool(),
        port: Joi.number().integer().min(1).max(65534),
        username: Joi.string().allow(null).regex(/^\S*$/),
        password: Joi.string().allow(null).regex(/^\S*$/),
      }),
    }),
    // .required(),
    address: Joi.string().required(),
  }),
};

const ottProviderCheckEmail = {
  query: Joi.object().keys({
    providerId: Joi.string().custom(objectId),
    email: Joi.string().email().required(),
  }),
};

const getOttProviderEmails = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getOttProviderEmail = {
  params: Joi.object().keys({
    ottProviderEmailId: Joi.string().custom(objectId),
  }),
};

const updateOttProviderEmail = {
  params: Joi.object().keys({
    ottProviderEmailId: Joi.custom(objectId),
  }),
  body: Joi.object()
    .keys({
      inUse: Joi.bool(),
      isMain: Joi.bool(),
      isInfo: Joi.bool(),
      isSupport: Joi.bool(),
      forInvoice: Joi.bool(),
      forSend: Joi.bool(),
      smtp: Joi.alternatives().conditional('forSend', {
        is: true,
        then: Joi.object().keys({
          server: Joi.string().allow(null).regex(/^\S*$/),
          ssl: Joi.bool(),
          port: Joi.number().integer().min(1).max(65534),
          username: Joi.string().allow(null).regex(/^\S*$/),
          password: Joi.string().allow(null).regex(/^\S*$/),
        }),
      }),
      address: Joi.string(),
    })
    .min(1),
};

const deleteOttProviderEmail = {
  params: Joi.object().keys({
    ottProviderEmailId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createOttProviderEmail,
  ottProviderCheckEmail,
  getOttProviderEmails,
  getOttProviderEmail,
  updateOttProviderEmail,
  deleteOttProviderEmail,
};
