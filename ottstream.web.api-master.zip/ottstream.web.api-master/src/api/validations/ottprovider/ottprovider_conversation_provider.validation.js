const Joi = require('joi');
const { objectId } = require('../custom.validation');

const ottprovidersConversationProviderJoi = {
  viber: Joi.object().keys({
    authToken: Joi.string().regex(/^\S+$/).allow('', null),
  }),
  telegram: Joi.object().keys({
    authToken: Joi.string().regex(/^\S+$/).allow('', null),
  }),
  twilio: Joi.object().keys({
    sId: Joi.string().regex(/^\S+$/).allow('', null),
    authToken: Joi.string().regex(/^\S+$/).allow('', null),
    fromNumber: Joi.string().regex(/^\S+$/).allow('', null),
  }),
  providerId: Joi.string().custom(objectId),
};

const createOttProviderConversationProvider = {
  body: Joi.object().keys(ottprovidersConversationProviderJoi),
};

const getOttProviderConversationProviders = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    providerId: Joi.string().custom(objectId),
  }),
};

const getOttProviderConversationProvider = {
  params: Joi.object().keys({
    ottProviderId: Joi.string().custom(objectId),
  }),
};

const updateOttProviderConversationProvider = {
  params: Joi.object().keys({
    ottProviderId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      viber: Joi.object().keys({
        authToken: Joi.string().regex(/^\S+$/).allow('', null),
      }),
      telegram: Joi.object().keys({
        authToken: Joi.string().regex(/^\S+$/).allow('', null),
      }),
      twilio: Joi.object().keys({
        sId: Joi.string().regex(/^\S+$/).allow('', null),
        authToken: Joi.string().regex(/^\S+$/).allow('', null),
        fromNumber: Joi.string().regex(/^\S+$/).allow('', null),
      }),
      providerId: Joi.string().custom(objectId),
    })
    .min(1),
};

const deleteOttProviderConversationProvider = {
  params: Joi.object().keys({
    ottProviderConversationProviderId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createOttProviderConversationProvider,
  getOttProviderConversationProviders,
  getOttProviderConversationProvider,
  updateOttProviderConversationProvider,
  deleteOttProviderConversationProvider,
};
