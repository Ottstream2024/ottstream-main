const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createOttProviderPrinter = {
  isShipping: Joi.bool().required(),
  ip: Joi.string().required(),
  model: Joi.string().allow(null, ''),
  pagesPerSheet: Joi.number(),
  port: Joi.number().integer().min(1).max(65534).required(),
  address: Joi.string().required().custom(objectId),
};

const getOttProviderPrinters = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    providerId: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getOttProviderPrinter = {
  params: Joi.object().keys({
    ottProviderPrinterId: Joi.string().custom(objectId),
  }),
};

const updateOttProviderPrinter = {
  params: Joi.object().keys({
    ottProviderPrinterId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      isShipping: Joi.bool(),
      ip: Joi.string(),
      model: Joi.string().allow(null, ''),
      port: Joi.number().integer().min(1).max(65534),
      pagesPerSheet: Joi.number(),
      address: Joi.string().required().custom(objectId),
    })
    .min(1),
};

const deleteOttProviderPrinter = {
  params: Joi.object().keys({
    ottProviderPrinterId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createOttProviderPrinter,
  getOttProviderPrinters,
  getOttProviderPrinter,
  updateOttProviderPrinter,
  deleteOttProviderPrinter,
};
