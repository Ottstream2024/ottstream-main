const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createOttProviderAddress = {
  body: Joi.object().keys({
    company: Joi.bool(),
    companyName: Joi.string(),
    firstname: Joi.alternatives().conditional('company', { is: false, then: Joi.string().required() }),
    lastname: Joi.alternatives().conditional('company', { is: false, then: Joi.string().required() }),
    providerId: Joi.string().required().custom(objectId),
    officeName: Joi.string(),
    phone: Joi.object().keys({
      id: Joi.string().custom(objectId),
      number: Joi.string().required(),
      countryCode: Joi.string(),
    }),
    unit: Joi.string().allow(null, ''),
    state: Joi.string().allow(null, ''),
    address: Joi.string().required(),
    country: Joi.string().required(),
    city: Joi.string().required(),
    zip: Joi.string().required(),
    isBilling: Joi.boolean(),
    isMain: Joi.boolean(),
    inUse: Joi.boolean(),
    isForShipping: Joi.boolean(),
    forInvoice: Joi.boolean(),
    isWarehouse: Joi.boolean(),
    acceptSelfPickup: Joi.bool().when('isWarehouse', {
      is: true,
      then: Joi.bool(),
    }),
    acceptCurrierPickup: Joi.bool().when('isWarehouse', {
      is: true,
      then: Joi.bool(),
    }),
  }),
};

const getOttProviderAddresses = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    providerId: Joi.string().custom(objectId),
  }),
};

const getOttProviderAddress = {
  params: Joi.object().keys({
    ottProviderAddressId: Joi.string().custom(objectId),
  }),
};

const updateOttProviderAddress = {
  params: Joi.object().keys({
    ottProviderAddressId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      company: Joi.bool(),
      companyName: Joi.string(),
      firstname: Joi.alternatives().conditional('company', { is: false, then: Joi.string() }),
      lastname: Joi.alternatives().conditional('company', { is: false, then: Joi.string() }),
      officeName: Joi.string(),
      phone: Joi.object().keys({
        id: Joi.string().custom(objectId),
        number: Joi.string(),
        countryCode: Joi.string(),
      }),
      unit: Joi.string().allow(null, ''),
      state: Joi.string().allow(null, ''),
      address: Joi.string(),
      country: Joi.string(),
      city: Joi.string(),
      zip: Joi.string(),
      isBilling: Joi.boolean(),
      isMain: Joi.boolean(),
      inUse: Joi.boolean(),
      isForShipping: Joi.boolean(),
      forInvoice: Joi.boolean(),
      isWarehouse: Joi.boolean(),
      acceptSelfPickup: Joi.bool().when('isWarehouse', {
        is: true,
        then: Joi.bool(),
      }),
      acceptCurrierPickup: Joi.bool().when('isWarehouse', {
        is: true,
        then: Joi.bool(),
      }),
    })
    .min(1),
};

const deleteOttProviderAddress = {
  params: Joi.object().keys({
    ottProviderAddressId: Joi.string().custom(objectId),
  }),
};

const getOttProviderAddressesByProviderId = {
  params: Joi.object().keys({
    ottProviderId: Joi.string().custom(objectId),
  }),
};
module.exports = {
  createOttProviderAddress,
  getOttProviderAddresses,
  getOttProviderAddress,
  updateOttProviderAddress,
  deleteOttProviderAddress,
  getOttProviderAddressesByProviderId,
};
