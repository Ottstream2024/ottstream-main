const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createCalendarEvent = {
  body: Joi.object()
    .keys({
      description: Joi.string().allow(''),
      title: Joi.string().allow(''),
      lat: Joi.number().allow(null),
      long: Joi.number().allow(null),
      client: Joi.string().custom(objectId),
      paymentType: Joi.string().required(),
      paymentPrice: Joi.number(),
      location: Joi.string().custom(objectId),
      customerAddress: Joi.object(),
      officeAddress: Joi.object(),
      startDate: Joi.string(),
      endDate: Joi.string(),
      state: Joi.string().allow('', null),
      allDay: Joi.boolean(),
      equipmentInstaller: Joi.string().custom(objectId),
    })
    .min(1),
};

const getCalendarEvents = {
  query: Joi.object().keys({
    search: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    type: Joi.number(),
    eventType: Joi.string(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    paymentType: Joi.string(),
    state: Joi.string(),
    equipmentInstaller: Joi.string().custom(objectId),
    startDate: Joi.string(),
    endDate: Joi.string(),
    name: Joi.string(),
    excel: Joi.boolean(),
  }),
};

const getCalendarEvent = {
  params: Joi.object().keys({
    calendarEventId: Joi.string().custom(objectId),
  }),
};

const updateCalendarEvent = {
  params: Joi.object().keys({
    calendarEventId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      description: Joi.string().allow(''),
      title: Joi.string().allow(''),
      lat: Joi.number().allow(null),
      long: Joi.number().allow(null),
      client: Joi.string().custom(objectId),
      paymentType: Joi.string(),
      paymentPrice: Joi.number(),
      state: Joi.string().allow('', null),
      location: Joi.string().custom(objectId),
      customerAddress: Joi.object(),
      officeAddress: Joi.object(),
      startDate: Joi.string(),
      color: Joi.string(),
      endDate: Joi.string(),
      allDay: Joi.boolean(),
      equipmentInstaller: Joi.string().custom(objectId),
    })
    .min(1),
};

const createComment = {
  params: Joi.object().keys({
    calendarEventId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      comment: Joi.string().allow('').required(),
      isCancel: Joi.bool(),
    })
    .min(1),
};

const updateComment = {
  params: Joi.object().keys({
    calendarEventId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      comment: Joi.string().allow('').required(),
      id: Joi.string().custom(objectId).required(),
    })
    .min(2),
};

const calendarEventEnableDisableAction = {
  body: Joi.object().keys({
    enableForSale: Joi.bool(),
    calendarEventId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const deleteCalendarEvent = {
  params: Joi.object().keys({
    calendarEventId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createCalendarEvent,
  getCalendarEvents,
  getCalendarEvent,
  updateCalendarEvent,
  deleteCalendarEvent,
  createComment,
  updateComment,
  calendarEventEnableDisableAction,
};
