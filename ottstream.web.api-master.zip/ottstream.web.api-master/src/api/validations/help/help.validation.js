const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createHelp = {
  body: Joi.object()
    .keys({
      video: Joi.string(),
      videoDescription: Joi.string().allow(''),
      categoryName: Joi.string().allow(''),
      type: Joi.string().valid('provider', 'cashier', 'provider_cashier'),
      name: Joi.string().allow(''),
      number: Joi.number(),
      parent: Joi.string().custom(objectId),
    })
    .min(1),
};

const getHelps = {
  query: Joi.object().keys({
    search: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    type: Joi.string(),
    parent: Joi.string().custom(objectId),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    name: Joi.string(),
    excel: Joi.boolean(),
  }),
};

const getHelp = {
  params: Joi.object().keys({
    helpId: Joi.string().custom(objectId),
  }),
};

const updateHelp = {
  params: Joi.object().keys({
    helpId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      video: Joi.string().allow(''),
      videoDescription: Joi.string().allow(''),
      categoryName: Joi.string().allow(''),
      type: Joi.string().valid('provider', 'cashier', 'provider_cashier'),
      name: Joi.string().allow(''),
      number: Joi.number(),
      parent: Joi.string().custom(objectId),
    })
    .min(1),
};

const helpEnableDisableAction = {
  body: Joi.object().keys({
    enableForSale: Joi.bool(),
    helpId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const deleteHelp = {
  params: Joi.object().keys({
    helpId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createHelp,
  getHelps,
  getHelp,
  updateHelp,
  deleteHelp,
  helpEnableDisableAction,
};
