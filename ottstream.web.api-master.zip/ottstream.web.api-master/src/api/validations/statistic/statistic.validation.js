const Joi = require('joi');

const getBillStatisticInfo = {
  query: Joi.object().keys({}),
};

const getServiceSubscriptionInfo = {
  query: Joi.object().keys({}),
};
const getServiceTelegramInfo = {
  query: Joi.object().keys({}),
};

const getTransactions = {
  query: Joi.object().keys({}),
};
const recalculateInvoice = {};

module.exports = {
  getBillStatisticInfo,
  recalculateInvoice,
  getServiceSubscriptionInfo,
  getServiceTelegramInfo,
  getTransactions,
};
