const Joi = require('joi');
const _ = require('lodash');
const cardValidator = require('card-validator');

module.exports = {
  type: 'creditCard',
  base: Joi.string(),
  messages: {
    'creditCard.number': '{{#label}} must be a valid credit card number',
    'creditCard.expirationMonth': '{{#label}} must be a valid expiration month',
    'creditCard.expirationYear': '{{#label}} must be a valid expiration year',
    'creditCard.cvv': '{{#label}} must be a valid cvv',
    'creditCard.postalCode': '{{#label}} must be a valid postal code',
    'creditCard.type': "{{#label}} can't get credit card type with given number",
  },
  rules: {
    number: {
      validate(value, helpers) {
        const result = cardValidator.number(value);
        if (!result.isValid) {
          return helpers.error('creditCard.number', { v: value });
        }
        return _(value).replace(/\s/g, '').toString();
      },
    },
    expirationMonth: {
      validate(value, helpers) {
        const result = cardValidator.expirationMonth(value);
        if (!result.isValid) {
          return helpers.error('creditCard.expirationMonth', { v: value });
        }
        return value;
      },
    },
    expirationYear: {
      validate(value, helpers) {
        const result = cardValidator.expirationYear(value);
        if (!result.isValid) {
          return helpers.error('creditCard.expirationYear', { v: value });
        }
        return value;
      },
    },
    cvv: {
      validate(value, helpers) {
        const result = cardValidator.cvv(value);
        if (!result.isValid) {
          return helpers.error('creditCard.cvv', { v: value });
        }
        return value;
      },
    },
    postalCode: {
      validate(value, helpers) {
        const result = cardValidator.postalCode(value);
        if (!result.isValid) {
          return helpers.error('creditCard.postalCode', { v: value });
        }
        return value;
      },
    },
  },
};
