const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createIconType = {
  body: Joi.object().keys({
    name: Joi.string().required(),
    contour: Joi.string().required(),
    ratiox: Joi.number(),
    ratioy: Joi.number(),
    widths: Joi.array().items(Joi.number()).required(),
    formats: Joi.array().items(Joi.string()).required(),
    state: Joi.number().valid(0, 1, 2),
    order: Joi.number(),
  }),
};

const getIconTypes = {
  query: Joi.object().keys({
    name: Joi.string(),
    country: Joi.string(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getIconType = {
  params: Joi.object().keys({
    iconTypeId: Joi.string().custom(objectId),
  }),
};

const updateIconType = {
  params: Joi.object().keys({
    iconTypeId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.string(),
      contour: Joi.string(),
      ratiox: Joi.number(),
      ratioy: Joi.number(),
      order: Joi.number(),
      widths: Joi.array().items(Joi.number()),
      formats: Joi.array().items(Joi.string()),
      state: Joi.number().valid(0, 1, 2),
    })
    .min(1),
};

const deleteIconType = {
  params: Joi.object().keys({
    iconTypeId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createIconType,
  getIconTypes,
  getIconType,
  updateIconType,
  deleteIconType,
};
