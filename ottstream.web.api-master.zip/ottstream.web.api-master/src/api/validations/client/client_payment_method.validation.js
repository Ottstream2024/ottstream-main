const Joi = require('joi');
const { objectId } = require('../custom.validation'); // , hideCardNumber, hideCVC

const createClientPaymentMethodJoi = {
  paymentMethod: Joi.number().valid(0, 1),
  clientId: Joi.string().custom(objectId),
  default: Joi.bool(),
  inUse: Joi.bool(),
  creditCard: Joi.alternatives().conditional('paymentMethod', {
    is: 0,
    then: Joi.object().keys({
      id: Joi.string().custom(objectId),
      token: Joi.string(),
      // cardNumber: Joi.string().min(1).max(20).required(),
      cardNumber: Joi.string(),
      cardholderName: Joi.string().required(),
      cvc: Joi.string(),
      // cvc: Joi.string().required().min(3),
      month: Joi.string(),
      year: Joi.string(),
      brand: Joi.string().allow(''),
      anExistingAddress: Joi.bool(),
      existingAddress: Joi.alternatives().conditional('anExistingAddress', {
        is: true,
        then: Joi.string().custom(objectId).required(),
      }),
      billingAddress: Joi.alternatives()
        .conditional('anExistingAddress', {
          is: false,
          then: Joi.object().keys({
            phone: Joi.string().required(),
            address: Joi.string().required(),
            country: Joi.string().required(),
            city: Joi.string().required(),
            suite: Joi.string().allow(''),
            zip: Joi.string().required(),
            state: Joi.string().allow(''),
          }),
        })
        .allow(''),
    }),
  }),
  bankTransfer: Joi.alternatives().conditional('paymentMethod', {
    is: 1,
    then: Joi.object().keys({
      id: Joi.string().custom(objectId),
      bankName: Joi.string().required(),
      routingNumber: Joi.number().required(),
      accountNumber: Joi.string().min(1).required(),
      account: Joi.string().valid('personalAccount', 'businessAccount'),
      personalData: Joi.alternatives()
        .conditional('account', {
          is: 'personalAccount',
          then: Joi.object().keys({
            firstname: Joi.string().required(),
            lastname: Joi.string().required(),
            nickname: Joi.string().required(),
          }),
        })
        .allow(''),
      companyName: Joi.alternatives()
        .conditional('account', {
          is: 'businessAccount',
          then: Joi.string().required(),
        })
        .allow(''),
    }),
  }),
};

const createClientPaymentMethod = {
  body: Joi.object().keys({
    clientId: Joi.string().required().custom(objectId),
    ...createClientPaymentMethodJoi,
  }),
};

const getClientPaymentMethods = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    providerId: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getClientPaymentMethod = {
  params: Joi.object().keys({
    clientPaymentMethodId: Joi.string().custom(objectId),
  }),
};

const getClientPaymentMethodByClient = {
  params: Joi.object().keys({
    clientId: Joi.string().custom(objectId),
  }),
};

const updateClientPaymentMethod = {
  params: Joi.object().keys({
    clientPaymentMethodId: Joi.custom(objectId),
  }),
  body: Joi.object().keys({
    paymentMethod: Joi.number().valid(0, 1),
    default: Joi.bool(),
    inUse: Joi.bool(),
    creditCard: Joi.alternatives().conditional('paymentMethod', {
      is: 0,
      then: Joi.object().keys({
        id: Joi.string().custom(objectId),
        cardNumber: Joi.string().min(1).max(20),
        cardholderName: Joi.string(),
        cvc: Joi.string().min(3),
        brand: Joi.string().allow(''),
        month: Joi.string(),
        year: Joi.string(),
        anExistingAddress: Joi.bool(),
        existingAddress: Joi.alternatives()
          .conditional('anExistingAddress', {
            is: true,
            then: Joi.string().custom(objectId).required(),
          })
          .allow(''),
        billingAddress: Joi.alternatives()
          .conditional('anExistingAddress', {
            is: false,
            then: Joi.object().keys({
              phone: Joi.string(),
              address: Joi.string(),
              country: Joi.string(),
              city: Joi.string(),
              suite: Joi.string().allow(''),
              zip: Joi.string(),
              state: Joi.string().allow(''),
            }),
          })
          .allow(''),
      }),
    }),
    bankTransfer: Joi.alternatives().conditional('paymentMethod', {
      is: 1,
      then: Joi.object().keys({
        id: Joi.string().custom(objectId),
        bankName: Joi.string(),
        routingNumber: Joi.number(),
        accountNumber: Joi.string().min(1),
        account: Joi.string().valid('personalAccount', 'businessAccount'),
        personalData: Joi.alternatives()
          .conditional('account', {
            is: 'personalAccount',
            then: Joi.object().keys({
              firstname: Joi.string(),
              lastname: Joi.string(),
              nickname: Joi.string(),
            }),
          })
          .allow(''),
        companyName: Joi.alternatives()
          .conditional('account', {
            is: 'businessAccount',
            then: Joi.string(),
          })
          .allow(''),
      }),
    }),
  }),
};

const deleteClientPaymentMethod = {
  params: Joi.object().keys({
    clientPaymentMethodId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createClientPaymentMethod,
  getClientPaymentMethods,
  getClientPaymentMethod,
  getClientPaymentMethodByClient,
  updateClientPaymentMethod,
  deleteClientPaymentMethod,
};
