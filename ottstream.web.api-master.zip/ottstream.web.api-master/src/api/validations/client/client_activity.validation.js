const Joi = require('joi');
const { objectId } = require('../custom.validation');

const getClientActivitys = {
  query: Joi.object().keys({
    type: Joi.string(),
    from: Joi.date(),
    to: Joi.date(),
    search: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    own: Joi.boolean(),
    resellers: Joi.string(),
    startDate: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    endDate: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    excel: Joi.bool(),
    sortBy: Joi.string(),
    user: Joi.string().custom(objectId),
    client: Joi.string().custom(objectId),
  }),
};

module.exports = {
  getClientActivitys,
};
