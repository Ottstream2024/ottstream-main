const Joi = require('joi');
const { objectId } = require('../custom.validation');
const { createClientPackage } = require('./client_package.validation');

const updateClientAddressesJoi = Joi.array().items({
  id: Joi.custom(objectId),
  existingName: Joi.bool(),
  firstname: Joi.alternatives().conditional('existingName', {
    is: false,
    then: Joi.string(),
    otherwise: Joi.string().required(),
  }),
  lastname: Joi.alternatives().conditional('existingName', {
    is: false,
    then: Joi.string(),
    otherwise: Joi.string().required(),
  }),
  phone: Joi.string().allow(''),
  lat: Joi.number().allow(null, ''),
  long: Joi.number().allow(null, ''),
  address: Joi.string(),
  companyName: Joi.string().allow(''),
  country: Joi.string(),
  city: Joi.string(),
  suite: Joi.string().allow(''),
  province: Joi.string().allow(''),
  zip: Joi.string().allow(''),
  isShipping: Joi.boolean(),
  isBilling: Joi.boolean(),
  isResident: Joi.boolean(),
  forContactInvoice: Joi.boolean(),
});

const createClient = {
  body: Joi.object().keys({
    personalInfo: Joi.object().keys({
      firstname: Joi.string().required(),
      lastname: Joi.string().required(),
      sex: Joi.string().required().valid('male', 'female', 'other'),
      comment: Joi.string().allow(''),
      dateOfBirth: Joi.date().allow(''),
      provider: Joi.string().custom(objectId),
      // isBlocked: Joi.bool().required(),
      // inPaused: Joi.bool().required(),
    }),
  }),
};

const getDeletedClients = {
  query: Joi.object().keys({
    search: Joi.string().optional(),
    page: Joi.number().optional(),
    limit: Joi.number().optional(),
    sortBy: Joi.string().optional(),
    sort: Joi.string().optional(),
  }),
};

const getClients = {
  query: Joi.object().keys({
    ownClients: Joi.boolean(),
    resellerClients: Joi.boolean(),
    providerId: Joi.string().custom(objectId),
    providers: Joi.string(),
    excel: Joi.bool(),
    extendedType: Joi.number().valid(0, 1),
    name: Joi.string().trim(),
    user: Joi.string().custom(objectId),
    autopayment: Joi.bool(),
    lang: Joi.string(),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    subscriptionState: Joi.number(),
    statusFilterType: Joi.string(),
    search: Joi.string().trim(),
    paymentMethod: Joi.string().trim(),
    balanceFrom: Joi.number(),
    balanceTo: Joi.number(),
    creditDateFrom: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    creditDateTo: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    creditAmountFrom: Joi.number(),
    creditAmountTo: Joi.number(),
    creditAutoExtend: Joi.boolean(),
    creditDaysRemainingFrom: Joi.number(),
    creditDaysRemainingTo: Joi.number(),
    debtFrom: Joi.number(),
    debtTo: Joi.number(),
    priceGroup: Joi.string().allow(null),
    currency: Joi.string().custom(objectId).allow(null),
    server: Joi.string(),
    timezone: Joi.string(),
    room: Joi.number(),
    login: Joi.string().trim(),
    packageExpired: Joi.bool(),
    creditExpired: Joi.bool(),
    roomsCount: Joi.number(),
    expireDate: Joi.date(),
    isBlocked: Joi.bool(),
    inPaused: Joi.bool(),
    packageExpireDateFrom: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    packageExpireDateTo: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    activePackagesFrom: Joi.date(),
    activePackagesTo: Joi.date(),
  }),
};

const getClientBySearch = {
  query: Joi.object().keys({
    user: Joi.string().custom(objectId),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    search: Joi.string().trim(),
    login: Joi.string().trim(),
    provider: Joi.string().custom(objectId).allow(null),
  }),
};

const getClientBalanceCredit = {
  params: Joi.object().keys({
    clientId: Joi.string().custom(objectId),
  }),
};

const getClient = {
  params: Joi.object().keys({
    clientId: Joi.string().custom(objectId),
  }),
};

const updateClient = {
  params: Joi.object().keys({
    clientId: Joi.custom(objectId),
  }),
  body: Joi.object()
    .keys({
      personalInfo: Joi.object().keys({
        firstname: Joi.string(),
        lastname: Joi.string(),
        sex: Joi.string().required(),
        comment: Joi.string().allow(''),
        dateOfBirth: Joi.date().allow(''),
        provider: Joi.string().custom(objectId),
      }),
      emails: Joi.array().items({
        email: Joi.string(),
        isMain: Joi.bool(),
        forContactInvoice: Joi.bool(),
      }),
      phones: Joi.array().items({
        phone: Joi.string(),
        id: Joi.string().custom(objectId),
        code: Joi.string().allow(null, ''),
        name: Joi.string().allow(null, ''),
        forCall: Joi.bool(),
        forMessages: Joi.bool(),
      }),
      rentDevices: Joi.array().items({
        product: Joi.string().required(),
        interval: Joi.string(),
        count: Joi.number().required(),
        expireDate: Joi.date().required(),
      }),
      addresses: updateClientAddressesJoi,
      usedDevices: Joi.custom(objectId),
      finance: Joi.object().keys({
        currency: Joi.string().custom(objectId).allow(null),
        priceGroup: Joi.string().custom(objectId).allow(null),
        forPackages: Joi.string().custom(objectId),
        forDevicesRent: Joi.string(),
        paperlessBilling: Joi.bool(),
      }),
      packages: createClientPackage,
      // settings: clientSettingsJoi,
    })
    .min(1),
};

const updateClientEmail = {
  email: Joi.string(),
  isMain: Joi.bool(),
  forContactInvoice: Joi.bool(),
};

const deleteClient = {
  params: Joi.object().keys({
    clientId: Joi.string().custom(objectId),
  }),
};
const clientSettings = {
  id: Joi.string().custom(objectId),
  location: Joi.string(),
  roomsCount: Joi.number(),
  server: Joi.string(),
  login: Joi.string(),
  expireDate: Joi.date(),
  isBlockLocation: Joi.bool(),
  isPauseSubscriptions: Joi.bool(),
  timezone: Joi.string(),
};

const clientActionSettings = {
  body: Joi.object().keys({
    // actionStatus: Joi.string().valid('activityLog', 'sendNotifications'),
    clients: Joi.array().items(Joi.string().custom(objectId)),
    locations: Joi.array().items(Joi.string().custom(objectId)),
    inPaused: Joi.bool(),
    isBlocked: Joi.bool(),
    server: Joi.string(),
  }),
};

const getAddressImage = {
  body: Joi.object().keys({
    // actionStatus: Joi.string().valid('activityLog', 'sendNotifications'),
    long: Joi.number().required(),
    lat: Joi.number().required(),
    address: Joi.string().required(),
  }),
};

const clientActionDelete = {
  body: Joi.object().keys({
    clientId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const clientCheckEmailPhone = {
  body: Joi.object().keys({
    email: Joi.string().email(),
    phone: Joi.string(),
    client: Joi.string().custom(objectId),
  }),
};

const paymentMethodsTypes = {};

module.exports = {
  createClient,
  getDeletedClients,
  getClients,
  getClientBySearch,
  getClient,
  getClientBalanceCredit,
  updateClient,
  updateClientEmail,
  deleteClient,
  clientSettings,
  clientActionSettings,
  clientActionDelete,
  clientCheckEmailPhone,
  getAddressImage,
  paymentMethodsTypes,
};
