const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createClientProfile = {
  body: Joi.object().keys({
    clientId: Joi.string().custom(objectId).required(),
    photo: Joi.string().custom(objectId),
    nickname: Joi.string().required(),
    protectCode: Joi.number().required().min(0).max(6),
    timeshift: Joi.number().min(0).max(12),
    inactivityTimeout: Joi.number(),
    language: Joi.string(),
    audiotrackDefault: Joi.string(),
    channelsOrderMode: Joi.string(),
    ageGroup: Joi.string().custom(objectId),
    locations: Joi.string().custom(objectId).required(),
    enableProfile: Joi.bool(),
    isAdmin: Joi.bool(),
    protectBoot: Joi.bool(),
    protectSetting: Joi.bool(),
    hideMediaByAge: Joi.bool(),
    protectMediaByAge: Joi.bool(),
    vodEnable: Joi.bool(),
    blood: Joi.alternatives().conditional('vodEnable', {
      is: true,
      then: Joi.object().keys({
        hide: Joi.bool(),
        protect: Joi.bool(),
      }),
    }),
    violence: Joi.alternatives().conditional('vodEnable', {
      is: true,
      then: Joi.object().keys({
        hide: Joi.bool(),
        protect: Joi.bool(),
      }),
    }),
    obscene: Joi.alternatives().conditional('vodEnable', {
      is: true,
      then: Joi.object().keys({
        hide: Joi.bool(),
        protect: Joi.bool(),
      }),
    }),
    porn: Joi.alternatives().conditional('vodEnable', {
      is: true,
      then: Joi.object().keys({
        hide: Joi.bool(),
        protect: Joi.bool(),
      }),
    }),
    horror: Joi.alternatives().conditional('vodEnable', {
      is: true,
      then: Joi.object().keys({
        hide: Joi.bool(),
        protect: Joi.bool(),
      }),
    }),
  }),
};

const getClientProfiles = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    lang: Joi.string(),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getClientProfile = {
  params: Joi.object().keys({
    clientProfileId: Joi.string().custom(objectId),
  }),
};

const updateClientProfile = {
  params: Joi.object().keys({
    clientProfileId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      photo: Joi.string().custom(objectId),
      nickname: Joi.string(),
      protectCode: Joi.number().min(0).max(6),
      timeshift: Joi.number().min(0).max(12),
      inactivityTimeout: Joi.number(),
      language: Joi.string(),
      audiotrackDefault: Joi.string(),
      channelsOrderMode: Joi.string(),
      ageGroup: Joi.string().custom(objectId),
      locations: Joi.string().custom(objectId),
      enableProfile: Joi.bool(),
      isAdmin: Joi.bool(),
      protectBoot: Joi.bool(),
      protectSetting: Joi.bool(),
      hideMediaByAge: Joi.bool(),
      protectMediaByAge: Joi.bool(),
      vodEnable: Joi.bool(),
      blood: Joi.alternatives().conditional('vodEnable', {
        is: true,
        then: Joi.object().keys({
          hide: Joi.bool(),
          protect: Joi.bool(),
        }),
      }),
      violence: Joi.alternatives().conditional('vodEnable', {
        is: true,
        then: Joi.object().keys({
          hide: Joi.bool(),
          protect: Joi.bool(),
        }),
      }),
      obscene: Joi.alternatives().conditional('vodEnable', {
        is: true,
        then: Joi.object().keys({
          hide: Joi.bool(),
          protect: Joi.bool(),
        }),
      }),
      porn: Joi.alternatives().conditional('vodEnable', {
        is: true,
        then: Joi.object().keys({
          hide: Joi.bool(),
          protect: Joi.bool(),
        }),
      }),
      horror: Joi.alternatives().conditional('vodEnable', {
        is: true,
        then: Joi.object().keys({
          hide: Joi.bool(),
          protect: Joi.bool(),
        }),
      }),
    })
    .min(1),
};

const deleteClientProfile = {
  params: Joi.object().keys({
    clientProfileId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createClientProfile,
  getClientProfiles,
  getClientProfile,
  updateClientProfile,
  deleteClientProfile,
};
