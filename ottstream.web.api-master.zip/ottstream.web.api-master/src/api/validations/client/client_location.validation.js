const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createClientLocation = {
  body: Joi.object().keys({
    locationName: Joi.string().required(),
    roomsCount: Joi.number(),
    server: Joi.string().custom(objectId).required(),
    maxDevice: Joi.number().required().valid(5, 10, 20, 50),
    parentalCode: Joi.string().required(),
    isBlockLocation: Joi.bool().required(),
    isPauseSubscriptions: Joi.bool().required(),
    VODEnable: Joi.bool().required(),
    archiveEnable: Joi.bool().required(),
    timeShiftEnable: Joi.bool().required(),
    password: Joi.string().required(),
    login: Joi.string().required(),
    comment: Joi.string(),
    lastChangedPassword: Joi.date(),
    timezone: Joi.string(),
    clientId: Joi.string().required().custom(objectId),
  }),
};

const getClientLocations = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    lang: Joi.string(),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
  }),
};

const getClientLocation = {
  params: Joi.object().keys({
    clientLocationId: Joi.string().custom(objectId),
  }),
};

const getClientLocationByClient = {
  params: Joi.object().keys({
    clientId: Joi.string().custom(objectId),
  }),
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    lang: Joi.string(),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    isPackageActive: Joi.bool(),
    lastActiveTime: Joi.date(),
    search: Joi.string(),
  }),
};

const getClientLocationRandomLoginPassword = {
  params: Joi.object().keys({
    clientId: Joi.string().custom(objectId),
  }),
};

const updateClientLocation = {
  params: Joi.object().keys({
    clientLocationId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      locationName: Joi.string(),
      // roomsCount: Joi.number(),
      // roomsCountNew: Joi.number(),
      server: Joi.string().custom(objectId),
      maxDevice: Joi.number().valid(5, 10, 20, 50),
      parentalCode: Joi.string(),
      isBlockLocation: Joi.bool(),
      isPauseSubscriptions: Joi.bool(),
      VODEnable: Joi.bool(),
      archiveEnable: Joi.bool(),
      timeShiftEnable: Joi.bool(),
      password: Joi.string(),
      login: Joi.string(),
      comment: Joi.string(),
      lastChangedPassword: Joi.date(),
      timezone: Joi.string(),
      profiles: Joi.array().items(Joi.string().custom(objectId)).allow(''),
      usedDevices: Joi.array().items({
        language: Joi.string(),
        timeShift: Joi.number().min(0).max(12),
        remoteControl: Joi.string(),
        audioTrackDefault: Joi.string(),
        httpCaching: Joi.number().valid(500, 1500, 3000, 5000),
        streamQuality: Joi.string().valid('auto', 'low', 'normal', 'high'),
        isSD: Joi.bool(),
        isHD: Joi.bool(),
        isFHD: Joi.bool(),
        isUHD: Joi.bool(),
        isBackgroundPlayer: Joi.bool(),
        uiFontSize: Joi.string().valid('normal', 'medium', 'large').default('normal'),
      }),
      // packagesInfo: Joi.object().keys({
      //   globalAction: Joi.number().valid(1, 2, 3, 4),
      //   name: Joi.alternatives().conditional('globalAction', {
      //     switch: [
      //       {
      //         is: 1,
      //         then: Joi.string().valid('subscribeFromEndMaxExpire'),
      //       },
      //       {
      //         is: 2,
      //         then: Joi.string().valid('subscribeToEndMaxExpire'),
      //       },
      //       {
      //         is: 3,
      //         then: Joi.string().valid('subscribeToDate'),
      //       },
      //       {
      //         is: 4,
      //         then: Joi.string().valid('stop'),
      //       },
      //     ],
      //   }),
      //   dayMonth: Joi.alternatives().conditional('name', {
      //     is: 'subscribeFromEndMaxExpire',
      //     then: Joi.number(),
      //   }),
      //   subscribeToDate: Joi.alternatives().conditional('name', {
      //     is: 'subscribeToDate',
      //     then: Joi.date(),
      //   }),
      // }),
    })
    .min(1),
};

const resetPassword = {
  body: Joi.object().keys({
    password: Joi.string().required(),
    login: Joi.string().required(),
    lastChangedPassword: Joi.date().required(),
    clientId: Joi.string().required().custom(objectId),
  }),
};

const pauseClientLocation = {
  params: Joi.object().keys({
    locationId: Joi.string().custom(objectId),
  }),
  body: Joi.object().keys({
    pause: Joi.bool().required(),
  }),
};

const changeServer = {
  body: Joi.object().keys({
    locations: Joi.array().items(Joi.string().custom(objectId)),
    clients: Joi.array().items(Joi.string().custom(objectId)),
    server: Joi.string().custom(objectId).required(),
    mode: Joi.number().required().allow(1, 2, 3, 4),
    hasServer: Joi.string().custom(objectId),
    filter: Joi.alternatives().conditional('mode', { is: 2, then: Joi.object().keys() }),
  }),
};

const restoreServer = {
  body: Joi.object().keys({
    backup: Joi.string().custom(objectId).required(),
    commend: Joi.string(),
  }),
};

const syncCdn = {
  params: Joi.object().keys({
    locationId: Joi.string().custom(objectId),
  }),
};

const getServerBackups = {};

const getClientLocationPackagesByRoom = {
  params: Joi.object().keys({
    clientLocationId: Joi.string().custom(objectId),
    roomsCount: Joi.number(),
    expireNew: Joi.date(),
  }),
};

const deleteClientLocation = {
  params: Joi.object().keys({
    clientLocationId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createClientLocation,
  getClientLocations,
  getClientLocation,
  getClientLocationPackagesByRoom,
  updateClientLocation,
  deleteClientLocation,
  getClientLocationRandomLoginPassword,
  resetPassword,
  pauseClientLocation,
  getClientLocationByClient,
  changeServer,
  getServerBackups,
  restoreServer,
  syncCdn,
};
