const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createAgeGroup = {
  body: Joi.object().keys({
    name: Joi.string(),
    to: Joi.number().required(),
    from: Joi.number().required(),
  }),
};

const getAgeGroups = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    lang: Joi.string(),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getAgeGroup = {
  params: Joi.object().keys({
    ageGroupId: Joi.string().custom(objectId),
  }),
};

const updateAgeGroup = {
  params: Joi.object().keys({
    ageGroupId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.string(),
      from: Joi.number().required(),
      to: Joi.number().required(),
    })
    .min(1),
};

const deleteAgeGroup = {
  params: Joi.object().keys({
    ageGroupId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createAgeGroup,
  getAgeGroups,
  getAgeGroup,
  updateAgeGroup,
  deleteAgeGroup,
};
