const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createClientUsedDevice = {
  params: Joi.object().keys({
    locationId: Joi.string().custom(objectId),
  }),
  body: Joi.object().keys({
    type: Joi.string().required(),
    model: Joi.string().required(),
    modelCode: Joi.string().required(),
    manufacturer: Joi.string().required(),
    ipAddress: Joi.string().required(),
    macAddress: Joi.string().required(),
    serialN: Joi.string().required(),
    uiFontSize: Joi.string(),
    userAgent: Joi.string().required(),
    language: Joi.string().required(),
    timeShift: Joi.number().min(0).max(12),
    remoteControl: Joi.string().allow('', null),
    audioTrackDefault: Joi.string(),
    httpCaching: Joi.number(),
    streamQuality: Joi.string(),
    isSD: Joi.bool(),
    isHD: Joi.bool(),
    isFHD: Joi.bool(),
    isUHD: Joi.bool(),
    isBackgroundPlayer: Joi.bool(),
  }),
};

const getClientUsedDevices = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    lang: Joi.string(),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const syncUsedDeviceCdn = {
  params: Joi.object().keys({
    locationId: Joi.string().custom(objectId).required(),
  }),
  body: Joi.object().keys({
    usedDeviceId: Joi.string().custom(objectId).required(),
  }),
};

const getClientUsedDevice = {
  query: Joi.object().keys({
    sortBy: Joi.string().default('lastActiveTime:desc'),
    limit: Joi.number().integer(),
    syncCdn: Joi.boolean(),
    page: Joi.number().integer(),
    statisticsFrom: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    statisticsTo: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    all: Joi.boolean(),
  }),
  params: Joi.object().keys({
    locationId: Joi.string().custom(objectId),
  }),
};

const getClientUsedDeviceActivityStatistics = {
  query: Joi.object().keys({
    sortBy: Joi.string().default('lastActiveTime:desc'),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    from: Joi.date(),
    to: Joi.date(),
  }),
};

const getOptions = {};

const updateBody = {
  id: Joi.string().custom(objectId).required(),
  settings: Joi.object().keys({
    uiFontSize: Joi.string(),
    language: Joi.string(),
    timeShift: Joi.number().min(0).max(12),
    remoteControl: Joi.string().allow('', null),
    audioTrackDefault: Joi.string(),
    httpCaching: Joi.number(),
    streamQuality: Joi.string(),
    isSD: Joi.bool(),
    isHD: Joi.bool(),
    isFHD: Joi.bool(),
    isUHD: Joi.bool(),
    isBackgroundPlayer: Joi.bool(),
  }),
};

const updateClientUsedDevice = {
  params: Joi.object().keys({
    locationId: Joi.required().custom(objectId),
  }),
  body: Joi.object().keys(updateBody).min(1),
};

const updateClientAllUsedDevice = {
  body: Joi.array().items(
    Joi.object()
      .keys({
        locationId: Joi.string().custom(objectId),
        updateDevices: Joi.array().items(updateBody),
      })
      .min(1)
  ),
};

const deleteClientUsedDevice = {
  params: Joi.object().keys({
    clientUsedDeviceId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  getOptions,
  createClientUsedDevice,
  getClientUsedDevices,
  syncUsedDeviceCdn,
  getClientUsedDevice,
  getClientUsedDeviceActivityStatistics,
  updateClientUsedDevice,
  updateClientAllUsedDevice,
  deleteClientUsedDevice,
};
