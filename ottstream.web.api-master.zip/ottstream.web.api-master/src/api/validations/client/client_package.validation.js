const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createClientPackage = {
  body: Joi.object().keys({
    state: Joi.number().valid(0, 1),
    packageName: Joi.string(),
    packageType: Joi.string().valid('Base', 'Additional'),
    expireDate: Joi.date(),
    expireNew: Joi.string().allow(''),
    recurringPayment: Joi.bool(),
    currentPrice: Joi.number(),
    totalPrice: Joi.number(),
    clientId: Joi.string().custom(objectId),
  }),
};

const getClientPackages = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    lang: Joi.string(),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getClientPackage = {
  params: Joi.object().keys({
    clientPackageId: Joi.string().custom(objectId),
  }),
};
const getClientPackageByClient = {
  params: Joi.object().keys({
    clientId: Joi.string().custom(objectId),
  }),
};

const updateClientPackage = {
  params: Joi.object().keys({
    clientPackageId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      state: Joi.number().valid(0, 1),
      packageName: Joi.string(),
      packageType: Joi.string().valid('Base', 'Additional'),
      expireDate: Joi.date(),
      expireNew: Joi.string().allow(''),
      recurringPayment: Joi.bool(),
      currentPrice: Joi.number(),
      totalPrice: Joi.number(),
    })
    .min(1),
};

const deleteClientPackage = {
  params: Joi.object().keys({
    clientPackageId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createClientPackage,
  getClientPackages,
  getClientPackage,
  getClientPackageByClient,
  updateClientPackage,
  deleteClientPackage,
};
