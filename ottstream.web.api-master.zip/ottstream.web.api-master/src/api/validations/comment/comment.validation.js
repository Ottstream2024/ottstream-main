const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createComment = {
  body: Joi.object()
    .keys({
      comment: Joi.string().allow(''),
      isPrivate: Joi.bool(),
      sendNotification: Joi.bool(),
      reminderDate: Joi.string(),
      client: Joi.string().custom(objectId),
    })
    .min(1),
};

const getComments = {
  query: Joi.object().keys({
    search: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    client: Joi.string().custom(objectId),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    name: Joi.string(),
    sendNotification: Joi.bool(),
    description: Joi.string(),
    excel: Joi.boolean(),
  }),
};

const getComment = {
  params: Joi.object().keys({
    commentId: Joi.string().custom(objectId),
  }),
};

const updateComment = {
  params: Joi.object().keys({
    commentId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      comment: Joi.string().allow(''),
      isPrivate: Joi.bool(),
      sendNotification: Joi.bool(),
      reminderDate: Joi.string(),
      client: Joi.string().custom(objectId),
    })
    .min(1),
};

const commentEnableDisableAction = {
  body: Joi.object().keys({
    enableForSale: Joi.bool(),
    commentId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const deleteComment = {
  params: Joi.object().keys({
    commentId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createComment,
  getComments,
  getComment,
  updateComment,
  deleteComment,
  commentEnableDisableAction,
};
