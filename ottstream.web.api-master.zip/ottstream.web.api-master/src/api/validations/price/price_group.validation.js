const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createPriceGroup = {
  body: Joi.object().keys({
    name: Joi.array()
      .required()
      .items({
        lang: Joi.string().required(),
        name: Joi.string().required(),
      })
      .min(1),
    default: Joi.boolean(),
    type: Joi.number().valid(1, 2),
    percent: Joi.number(),
    round: Joi.number(),
    digits: Joi.number(),
  }),
};

const getPriceGroups = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    lang: Joi.string(),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    type: Joi.number().integer().default(1),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    provider: Joi.string().custom(objectId),
  }),
};

const getPriceGroup = {
  params: Joi.object().keys({
    priceGroupId: Joi.string().custom(objectId),
  }),
};

const updatePriceGroup = {
  params: Joi.object().keys({
    priceGroupId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.array()
        .required()
        .items({
          lang: Joi.string(),
          name: Joi.string(),
        })
        .min(0),
      default: Joi.boolean(),
      type: Joi.number(),
      percent: Joi.number(),
      round: Joi.number(),
      digits: Joi.number(),
    })
    .min(1),
};

const deletePriceGroup = {
  params: Joi.object().keys({
    priceGroupId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createPriceGroup,
  getPriceGroups,
  getPriceGroup,
  updatePriceGroup,
  deletePriceGroup,
};
