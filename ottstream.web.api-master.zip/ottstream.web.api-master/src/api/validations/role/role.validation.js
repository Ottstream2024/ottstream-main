const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createRole = {
  body: Joi.object().keys({
    name: Joi.string().required(),
    keyword: Joi.string(),
    type: Joi.number(),
    permissions: Joi.array().items(Joi.string().custom(objectId)),
    state: Joi.number().valid(0, 1, 2),
  }),
};

const getRoles = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getOttRoles = {
  query: Joi.object().keys({
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getRole = {
  params: Joi.object().keys({
    roleId: Joi.string().custom(objectId),
  }),
};

const updateRole = {
  params: Joi.object().keys({
    roleId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.string(),
      keyword: Joi.string(),
      permissions: Joi.array().items(Joi.string().custom(objectId)),
      state: Joi.number(),
    })
    .min(1),
};

const deleteRole = {
  params: Joi.object().keys({
    roleId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createRole,
  getRoles,
  getOttRoles,
  getRole,
  updateRole,
  deleteRole,
};
