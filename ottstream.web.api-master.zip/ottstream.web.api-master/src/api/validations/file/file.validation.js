const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createFile = {
  // file: Joi.object({
  //   // pipe: Joi.func().required(),
  // }).required(),
  body: Joi.object().keys({}),
};

const createChannelIconFile = {
  // file: Joi.object({
  //   // pipe: Joi.func().required(),
  // }).required(),
  body: Joi.object().keys({
    iconSet: Joi.string().required().custom(objectId),
    iconType: Joi.string().required().custom(objectId),
    channel: Joi.string().required().custom(objectId),
  }),
};

const getFiles = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getFile = {
  params: Joi.object().keys({
    fileId: Joi.string().custom(objectId),
  }),
};

const updateFile = {
  params: Joi.object().keys({
    fileId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.string(),
      state: Joi.number(),
    })
    .min(1),
};

const deleteFile = {
  params: Joi.object().keys({
    fileId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createFile,
  createChannelIconFile,
  getFiles,
  getFile,
  updateFile,
  deleteFile,
};
