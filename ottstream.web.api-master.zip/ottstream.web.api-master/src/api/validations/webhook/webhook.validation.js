const Joi = require('joi');

const testHook = {
  body: Joi.object(),
};

const easyship = {
  body: Joi.object(),
};

const twilio = {
  body: Joi.object(),
};

const telegram = {
  query: Joi.object().keys({
    token: Joi.string(),
  }),
  body: Joi.object(),
};

const messenger = {
  query: Joi.object().keys({
    'hub.mode': Joi.string(),
    'hub.challenge': Joi.string(),
    'hub.verify_token': Joi.string(),
  }),
  body: Joi.object(),
};

const whatsapp = {
  query: Joi.object().keys({
    'hub.mode': Joi.string(),
    'hub.challenge': Joi.string(),
    'hub.verify_token': Joi.string(),
  }),
  body: Joi.object(),
};

const instagram = {
  query: Joi.object().keys({
    'hub.mode': Joi.string(),
    'hub.challenge': Joi.string(),
    'hub.verify_token': Joi.string(),
  }),
  body: Joi.object(),
};

const run = {
  query: Joi.object().keys({
    job: Joi.string(),
  }),
};

module.exports = {
  testHook,
  easyship,
  messenger,
  instagram,
  whatsapp,
  twilio,
  telegram,
  run,
};
