const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createDiscountNotification = {
  body: Joi.object().keys({
    beforeDays: Joi.string(),
    repeatDays: Joi.string().required(),
    notificationTextForUpcoming: Joi.string().required(),
    notificationTextForCurrent: Joi.string().required(),
    discount: Joi.string().custom(objectId),
  }),
};

const getDiscountNotifications = {
  params: Joi.object().keys({}),
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    lang: Joi.string(),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getDiscountNotification = {
  params: Joi.object().keys({
    discountNotificationId: Joi.string().custom(objectId),
  }),
};

const updateDiscountNotification = {
  params: Joi.object().keys({
    discountNotificationId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      beforeDays: Joi.string(),
      repeatDays: Joi.string(),
      notificationTextForUpcoming: Joi.string(),
      notificationTextForCurrent: Joi.string(),
    })
    .min(1),
};

const deleteDiscountNotification = {
  params: Joi.object().keys({
    discountNotificationId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createDiscountNotification,
  getDiscountNotifications,
  getDiscountNotification,
  updateDiscountNotification,
  deleteDiscountNotification,
};
