const Joi = require('joi');
const { objectId } = require('../custom.validation');

const generalInfoJoi = {
  description: Joi.string().allow(''),
  name: Joi.string(),
  type: Joi.number().valid(1, 2, 3),
  client: Joi.alternatives().conditional('type', {
    is: 2,
    then: Joi.string().custom(objectId),
  }),
  provider: Joi.alternatives().conditional('type', {
    is: 3,
    then: Joi.string().custom(objectId),
  }),
  startDate: Joi.date(),
  endDate: Joi.date(),
  defaultSalePercent: Joi.number(),
  rounding: Joi.string().valid('off', 'up', 'down'),
  status: Joi.number(),
  digits: Joi.number(),
  sendNotifications: Joi.bool(),
  // countriesAccepted: Joi.array().items(Joi.string()),
  // countriesDenied: Joi.array().items(Joi.string()),
};

const notificationJoi = {
  notificationsMode: Joi.string().valid('manualOnly', 'immediately', 'beforeStart'),
  beforeDays: Joi.alternatives().conditional('notificationsMode', {
    switch: [
      {
        is: 'manualOnly',
        then: Joi.allow(null),
      },
      {
        is: 'beforeStart',
        then: Joi.number().required(),
      },
      {
        is: 'immediately',
        then: Joi.allow(null),
      },
    ],
  }),
  repeatDays: Joi.alternatives().conditional('notificationsMode', {
    switch: [
      {
        is: 'manualOnly',
        then: Joi.allow(null),
      },
      {
        is: 'immediately',
        then: Joi.number().required(),
      },
      {
        is: 'beforeStart',
        then: Joi.number().required(),
      },
    ],
  }),
  notificationTextForUpcoming: Joi.string(),
  notificationTextForCurrent: Joi.string(),
};

const createDiscount = {
  body: Joi.object().keys({
    generalInfo: generalInfoJoi,
    priceGroups: Joi.array().items(
      Joi.object().keys({
        item: Joi.string().custom(objectId).allow(''),
      })
    ),
    packages: Joi.array().items(Joi.string().custom(objectId)).required(),
    equipments: Joi.array().items(Joi.string().custom(objectId)),
    provider: Joi.string().custom(objectId),
    notifications: notificationJoi,
    current: Joi.bool(),
    forDefaultPriceGroup: Joi.bool().required().default(false),
    upcoming: Joi.bool(),
    past: Joi.bool(),
  }),
};

const getDiscounts = {
  body: Joi.object().keys({
    excel: Joi.bool(),
    search: Joi.string(),
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    lang: Joi.string(),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    startDate: Joi.date(),
    endDate: Joi.date(),
    status: Joi.number(),
    type: Joi.number(),
    // current: Joi.bool(),
    // upcoming: Joi.bool(),
    // past: Joi.bool(),
    timeLineStatus: Joi.number(),
    priceGroups: Joi.array().items(Joi.string().allow('')),
    packages: Joi.array().items(Joi.string()),
    currencyCountry: Joi.string().custom(objectId),
    parent: Joi.boolean().default(false),
  }),
};

const getDiscountsByFilter = {
  body: Joi.object().keys({
    priceGroups: Joi.array().items(Joi.string().allow('')),
    packages: Joi.array().items(Joi.string()),
  }),
};

const getDiscount = {
  params: Joi.object().keys({
    discountId: Joi.string().custom(objectId),
  }),
};

const updateDiscount = {
  params: Joi.object().keys({
    discountId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      generalInfo: generalInfoJoi,
      timelineStatus: Joi.string().valid('past', 'current', 'upcoming'),
      priceGroups: Joi.array().items(
        Joi.object().keys({
          item: Joi.string().custom(objectId),
        })
      ),
      packages: Joi.array().items(Joi.string().custom(objectId)),
      equipments: Joi.array().items(Joi.string().custom(objectId)),
      notifications: notificationJoi,
      current: Joi.bool(),
      upcoming: Joi.bool(),
      forDefaultPriceGroup: Joi.bool(),
      past: Joi.bool(),
      currency: Joi.string().custom(objectId),
      currencyCountry: Joi.string().custom(objectId),
    })
    .min(1),
};

const deleteDiscount = {
  body: Joi.object().keys({
    discountId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const sendNotificationAction = {
  body: Joi.object().keys({
    discountId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const discountActions = {
  body: Joi.object().keys({
    status: Joi.number(),
    discountId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const discountPriceGroupSettings = {
  params: Joi.object().keys({
    startDate: Joi.date(),
    endDate: Joi.date(),
    // provider: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createDiscount,
  getDiscounts,
  getDiscountsByFilter,
  getDiscount,
  updateDiscount,
  deleteDiscount,
  sendNotificationAction,
  discountActions,
  discountPriceGroupSettings,
};
