const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createChat = {
  params: Joi.object().keys({
    clientId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      message: Joi.string(),
      type: Joi.string(),
      phone: Joi.string().allow('', null),
    })
    .min(1),
};

const getChats = {
  query: Joi.object().keys({
    search: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    client: Joi.string().custom(objectId),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    name: Joi.string(),
    sendNotification: Joi.bool(),
    description: Joi.string(),
    excel: Joi.boolean(),
  }),
};

const getClientChats = {
  params: Joi.object().keys({
    clientId: Joi.required().custom(objectId),
  }),
  query: Joi.object().keys({
    search: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
  }),
};

const getProviderChats = {
  query: Joi.object().keys({
    type: Joi.string().valid('client', 'provider'),
    unread: Joi.boolean(),
  }),
};

const getChat = {
  params: Joi.object().keys({
    chatId: Joi.string().custom(objectId),
  }),
};

const updateChat = {
  params: Joi.object().keys({
    chatId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      chat: Joi.string().allow(''),
      isPrivate: Joi.bool(),
      sendNotification: Joi.bool(),
      reminderDate: Joi.date(),
      client: Joi.string().custom(objectId),
    })
    .min(1),
};

const chatEnableDisableAction = {
  body: Joi.object().keys({
    enableForSale: Joi.bool(),
    chatId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const deleteChat = {
  params: Joi.object().keys({
    chatId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createChat,
  getChats,
  getChat,
  updateChat,
  getProviderChats,
  deleteChat,
  getClientChats,
  chatEnableDisableAction,
};
