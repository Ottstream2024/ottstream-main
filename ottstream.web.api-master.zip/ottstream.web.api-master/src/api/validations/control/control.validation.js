const Joi = require('joi');

const syncLocations = {
  query: Joi.object().keys({}),
};

module.exports = {
  syncLocations,
};
