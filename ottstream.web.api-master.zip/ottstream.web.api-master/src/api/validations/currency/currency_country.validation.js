const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createCurrencyCountry = {
  body: Joi.object().keys({
    name: Joi.array()
      .items({
        lang: Joi.string().required(),
        name: Joi.string().required(),
      })
      .min(1),
    country: Joi.string().custom(objectId).required(),
    currency: Joi.string().custom(objectId).required(),
  }),
};

const getCurrencyCountrys = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    lang: Joi.string(),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getCurrencyCountry = {
  params: Joi.object().keys({
    currencyCountryId: Joi.string().custom(objectId),
  }),
};

const updateCurrencyCountry = {
  params: Joi.object().keys({
    currencyCountryId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.array()
        .items({
          lang: Joi.string(),
          name: Joi.string(),
          id: Joi.string(),
        })
        .min(1),
      country: Joi.string().custom(objectId),
      currency: Joi.string().custom(objectId),
      state: Joi.number().valid(0, 1, 2),
    })
    .min(1),
};

const deleteCurrencyCountry = {
  params: Joi.object().keys({
    currencyCountryId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createCurrencyCountry,
  getCurrencyCountrys,
  getCurrencyCountry,
  updateCurrencyCountry,
  deleteCurrencyCountry,
};
