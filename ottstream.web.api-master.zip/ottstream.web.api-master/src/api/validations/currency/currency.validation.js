const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createCurrency = {
  body: Joi.object().keys({
    name: Joi.array()
      .items({
        lang: Joi.string().required(),
        name: Joi.string().required(),
      })
      .min(1),
    code: Joi.string().required(),
    client: Joi.string().custom(objectId),
  }),
};

const getCurrencys = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    lang: Joi.string(),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getCurrency = {
  params: Joi.object().keys({
    currencyId: Joi.string().custom(objectId),
  }),
};

const updateCurrency = {
  params: Joi.object().keys({
    currencyId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.array()
        .items({
          lang: Joi.string(),
          name: Joi.string(),
          id: Joi.string(),
        })
        .min(1),
      code: Joi.string(),
      state: Joi.number().valid(0, 1, 2),
    })
    .min(1),
};

const deleteCurrency = {
  params: Joi.object().keys({
    currencyId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createCurrency,
  getCurrencys,
  getCurrency,
  updateCurrency,
  deleteCurrency,
};
