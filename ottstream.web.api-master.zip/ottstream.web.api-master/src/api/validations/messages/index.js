const Joi = require('joi');

const createMessage = {
  body: Joi.object().keys({
    conversation: Joi.number().required(),
    files: Joi.array().items(Joi.string()),
    reply_from: Joi.number().optional(),
    message: Joi.string().optional(),
  }),
};

const getMessages = {
  query: Joi.object().keys({
    conversation: Joi.number().required(),
    page: Joi.number().required(),
    limit: Joi.number().required(),
  }),
};

module.exports = {
  createMessage,
  getMessages,
};
