const Joi = require('joi');
const { objectId } = require('../custom.validation');

const subscriptionPayload = Joi.object().keys({
  selectedLocation: Joi.string().custom(objectId),
  locations: Joi.array()
    .items(
      Joi.object().keys({
        locationId: Joi.string().custom(objectId).required(),
        room: Joi.number(),
        packageInfos: Joi.array().items(Joi.string().custom(objectId)),
        packageRemoves: Joi.array().items(Joi.string().custom(objectId)),
        globalAction: Joi.number().allow(0, 1, 2, 3, 4, null).default(-1),
        subscribeToDate: Joi.alternatives().conditional('globalAction', { is: 3, then: Joi.date().required() }),
        day: Joi.alternatives().conditional('globalAction', { is: 1, then: Joi.number() }),
        month: Joi.alternatives().conditional('globalAction', { is: 1, then: Joi.number() }),
        recurringPaymentInfos: Joi.array().items(
          Joi.object().keys({
            packageId: Joi.string().custom(objectId),
            recurringPayment: Joi.boolean().default(true),
          })
        ),
      })
    )
    .min(0),
  equipments: Joi.array().items(
    Joi.object().keys({
      equipment: Joi.string().custom(objectId).required(),
      macAddress: Joi.string().allow(''),
      serialN: Joi.string().allow(''),
      price: Joi.number().required(),
      piece: Joi.number(),
      totalPrice: Joi.number(),
      comment: Joi.string().allow(''),
      description: Joi.string().allow(''),
    })
  ),
  returnEquipments: Joi.array().items(
    Joi.object().keys({
      equipment: Joi.string().custom(objectId),
      price: Joi.number().required(),
      piece: Joi.number(),
      totalPrice: Joi.number(),
    })
  ),
  equipment: Joi.object().keys({}),
  client: Joi.string().custom(objectId).required(),
});

const getLocationSubscriptions = {
  body: subscriptionPayload,
};

const subscribeLocationToPackage = {
  body: Joi.object()
    .keys({
      locationId: Joi.string().custom(objectId).required(),
      packageId: Joi.string().custom(objectId).required(),
      recurringPayment: Joi.boolean().default(true),
      day: Joi.number(),
      month: Joi.number(),
      subscribeToDate: Joi.date(),
      action: Joi.array().items(Joi.string().custom(objectId)),
      packages: Joi.array().items(Joi.string().custom(objectId)),
    })
    .min(1),
};

const checkout = {
  body: subscriptionPayload,
};

const createPackage = {
  body: Joi.object()
    .keys({
      name: Joi.array()
        .items({
          lang: Joi.string().allow(''),
          name: Joi.string(),
          id: Joi.string(),
        })
        .min(1),
      description: Joi.array()
        .required()
        .items({
          lang: Joi.string().allow(''),
          name: Joi.string(),
        })
        .min(0),
      type: Joi.number().allow(1, 2),
      vEnable: Joi.boolean(),
      tEnable: Joi.boolean(),
      aEnable: Joi.boolean(),
      forClients: Joi.boolean(),
      forResale: Joi.boolean(),
      status: Joi.number().allow(0, 1, 2),
      prices: Joi.array()
        .items({
          priceGroup: Joi.string().custom(objectId).allow(null),
          discount: Joi.string().custom(objectId).allow(null),
          priceItems: Joi.array()
            .required()
            .items({
              room: Joi.number(),
              interval: Joi.number(),
              intervalType: Joi.string().allow('m', 'd'),
              price: Joi.number(),
            })
            .min(0),
        })
        .min(0),
    })
    .min(1),
};

const getPackages = {
  query: Joi.object().keys({
    search: Joi.string(),
    parentDiscounts: Joi.array().items(Joi.string().custom(objectId).required()).min(0),
    clientPriceGroup: Joi.string().custom(objectId),
    clientDiscounts: Joi.array().items(Joi.string().custom(objectId).required()).min(0),
    providerPriceGroup: Joi.string().custom(objectId),
    providerDiscounts: Joi.array().items(Joi.string().custom(objectId).required()).min(0),
    clients: Joi.array().items(Joi.number()).min(2).max(2),
    clientsTotal: Joi.array().items(Joi.number()).min(2).max(2),
    services: Joi.array().items(Joi.number().valid(1, 2, 3)).min(0).max(3),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getPackage = {
  params: Joi.object().keys({
    packageId: Joi.string().custom(objectId),
  }),
};

const getSubscriptions = {
  query: Joi.object().keys({
    client: Joi.string().custom(objectId),
    isActive: Joi.boolean(),
    location: Joi.string().custom(objectId),
  }),
};

const updatePackage = {
  params: Joi.object().keys({
    packageId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.array()
        .items({
          lang: Joi.string(),
          name: Joi.string(),
          id: Joi.string(),
        })
        .min(1),
      description: Joi.array()
        .items({
          lang: Joi.string(),
          name: Joi.string(),
          id: Joi.string(),
        })
        .min(0),
      type: Joi.number().allow(1, 2),
      vEnable: Joi.boolean(),
      tEnable: Joi.boolean(),
      aEnable: Joi.boolean(),
      forClients: Joi.boolean(),
      forResale: Joi.boolean(),
      status: Joi.number().allow(0, 1, 2),
      prices: Joi.array()
        .items({
          id: Joi.string(),
          priceGroup: Joi.string().custom(objectId).allow(null),
          discount: Joi.string().custom(objectId).allow(null),
          priceItems: Joi.array()
            .required()
            .items({
              id: Joi.string(),
              room: Joi.number(),
              interval: Joi.number(),
              intervalType: Joi.string().allow('m', 'd'),
              price: Joi.number(),
            })
            .min(0),
        })
        .min(0),
    })
    .min(1),
};

const unsubscribeLocationFromPackage = {
  body: Joi.object()
    .keys({
      packageId: Joi.string().custom(objectId),
      locationId: Joi.required().custom(objectId),
    })
    .min(1),
};

const updateLocationSubscriptions = {
  params: Joi.object().keys({
    locationId: Joi.string().custom(objectId),
  }),
  body: Joi.object().keys({}).min(1),
};

const deletePackage = {
  params: Joi.object().keys({
    packageId: Joi.string().custom(objectId),
  }),
};

const generateLocationInvoice = {
  params: Joi.object().keys({
    locationId: Joi.string().custom(objectId),
  }),
};

const disableEnablePackage = {
  params: Joi.object().keys({
    packageId: Joi.string().custom(objectId),
  }),
  body: Joi.object().keys({
    status: Joi.boolean().required(),
  }),
};

module.exports = {
  checkout,
  getLocationSubscriptions,
  subscribeLocationToPackage,
  unsubscribeLocationFromPackage,
  updateLocationSubscriptions,
  generateLocationInvoice,
  createPackage,
  getPackages,
  disableEnablePackage,
  getPackage,
  updatePackage,
  deletePackage,
  getSubscriptions,
};
