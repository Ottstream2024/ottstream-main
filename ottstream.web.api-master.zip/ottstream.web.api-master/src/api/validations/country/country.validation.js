const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createCountry = {
  body: Joi.object().keys({
    name: Joi.string().required(),
    code: Joi.string().required(),
    state: Joi.number().valid(0, 1, 2),
  }),
};

const getCountrys = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getCountry = {
  params: Joi.object().keys({
    countryId: Joi.string().custom(objectId),
  }),
};

const updateCountry = {
  params: Joi.object().keys({
    countryId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.string(),
      code: Joi.string(),
      state: Joi.number(),
    })
    .min(1),
};

const deleteCountry = {
  params: Joi.object().keys({
    countryId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createCountry,
  getCountrys,
  getCountry,
  updateCountry,
  deleteCountry,
};
