const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createLanguageUnitTranslation = {
  // params: Joi.object().keys({
  //   languageUnitTranslationId: Joi.string().custom(objectId),
  // }),
  body: Joi.object().keys({
    translation: Joi.string().required(),
    unit: Joi.string().custom(objectId).required(),
    language: Joi.string().custom(objectId).required(),
  }),
};

const getLanguageUnitTranslations = {
  query: Joi.object().keys({
    // id: Joi.string().custom(objectId).required(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getLanguageUnitTranslation = {
  params: Joi.object().keys({
    languageUnitTranslationId: Joi.string().custom(objectId),
  }),
};

const updateLanguageUnitTranslation = {
  // params: Joi.object().keys({
  //   languageUnitTranslationId: Joi.required().custom(objectId),
  // }),
  body: Joi.object()
    .keys({
      translation: Joi.string().required(),
      unit: Joi.required().custom(objectId).required(),
      language: Joi.string().custom(objectId).required(),
    })
    .min(1),
};

const deleteLanguageUnitTranslation = {
  params: Joi.object().keys({
    languageUnitTranslationId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createLanguageUnitTranslation,
  getLanguageUnitTranslations,
  getLanguageUnitTranslation,
  updateLanguageUnitTranslation,
  deleteLanguageUnitTranslation,
};
