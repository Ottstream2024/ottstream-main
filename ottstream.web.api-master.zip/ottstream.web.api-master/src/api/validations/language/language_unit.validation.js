const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createLanguageUnit = {
  body: Joi.object().keys({
    keyword: Joi.string().required(),
    state: Joi.number().valid(0, 1, 2),
  }),
};

const getLanguageUnits = {
  query: Joi.object().keys({
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getLanguageUnit = {
  params: Joi.object().keys({
    languageUnitId: Joi.string().custom(objectId),
  }),
};

const updateLanguageUnit = {
  params: Joi.object().keys({
    languageUnitId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      keyword: Joi.string(),
      state: Joi.number(),
    })
    .min(1),
};

const deleteLanguageUnit = {
  params: Joi.object().keys({
    languageUnitId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createLanguageUnit,
  getLanguageUnits,
  getLanguageUnit,
  updateLanguageUnit,
  deleteLanguageUnit,
};
