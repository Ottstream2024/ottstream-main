const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createLanguage = {
  body: Joi.object().keys({
    name: Joi.string().required(),
    code: Joi.string().required(),
    selected: Joi.boolean(),
    country: Joi.string().required(),
    state: Joi.number().valid(0, 1, 2),
  }),
};

const getLanguages = {
  query: Joi.object().keys({
    name: Joi.string(),
    country: Joi.string(),
    user: Joi.string().custom(objectId),
    lang: Joi.string(),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getLanguage = {
  params: Joi.object().keys({
    languageId: Joi.string().custom(objectId),
  }),
};

const updateLanguage = {
  params: Joi.object().keys({
    languageId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.string(),
      code: Joi.string(),
      selected: Joi.boolean(),
      country: Joi.string(),
      state: Joi.number(),
    })
    .min(1),
};

const deleteLanguage = {
  params: Joi.object().keys({
    languageId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createLanguage,
  getLanguages,
  getLanguage,
  updateLanguage,
  deleteLanguage,
};
