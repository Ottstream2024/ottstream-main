const Joi = require('joi');
const { password, objectId } = require('../custom.validation');

const createUser = {
  body: Joi.object().keys({
    email: Joi.string().required().email(),
    password: Joi.string().required().custom(password),
    confirmPassword: Joi.string().required().valid(Joi.ref('password')),
    firstname: Joi.string().required(),
    lastname: Joi.string().required(),
    color: Joi.string(),
    phone: Joi.object()
      .keys({
        id: Joi.string().custom(objectId),
        phoneNumber: Joi.string().required(),
        countryCode: Joi.string(),
      })
      .required(),
    avatar: Joi.string(),
    accessEnable: Joi.bool(),
    timezone: Joi.string(),
    accessAnEnable: Joi.bool(),
    address: Joi.string().custom(objectId),
    showUnsuccessfulTransactions: Joi.bool(),
    rolesInfo: Joi.object().keys({
      cashier: Joi.bool(),
      support: Joi.bool(),
      admin: Joi.bool(),
      advancedCashier: Joi.bool(),
      equipmentInstaller: Joi.bool(),
    }),
    provider: Joi.string().custom(objectId),
    roles: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const setUserSettings = {
  body: Joi.object().keys({
    saveHeader: Joi.array().items(Joi.string()),
    defaultSettings: Joi.object(),
    ottProviderTableSettings: Joi.object(),
    reviewSettings: Joi.object(),
    generalSearch: Joi.object().keys({
      lockDrags: Joi.bool(),
      tabsWidth: Joi.number(),
    }),
    manuSettings: Joi.object().keys({
      isMinimize: Joi.bool(),
      isFullHide: Joi.bool(),
      themeDark: Joi.bool(),
      notificationVolume: Joi.number(),
      isMuted: Joi.boolean(),
    }),
    clientSettings: Joi.object().keys({
      extendedType: Joi.number().valid(0, 1),
      isDefault: Joi.bool(),
      limit: Joi.number(),
      settingsExtended: Joi.array().items(),
      settingsAnExtended: Joi.array().items(),
    }),
    discountSettings: Joi.object().keys({
      isDefault: Joi.bool(),
      limit: Joi.number(),
      discountTable: Joi.array().items(),
    }),
    clientBillsSettings: Joi.object().keys({
      isDefault: Joi.bool(),
      limit: Joi.number(),
      searchLimit: Joi.number(),
      clientBillsTable: Joi.array().items(),
    }),
    packagesSettings: Joi.object().keys({
      isDefault: Joi.bool(),
      limit: Joi.number(),
      packagesTable: Joi.array().items(),
    }),
    transactionSettings: Joi.object().keys({
      isDefault: Joi.bool(),
      limit: Joi.number(),
      searchLimit: Joi.number(),
      transactionTable: Joi.array().items(),
    }),
    userActivitySettings: Joi.object().keys({
      isDefault: Joi.bool(),
      limit: Joi.number(),
      userActivityTable: Joi.array().items(),
    }),
    equipmentSettings: Joi.object().keys({
      isDefault: Joi.bool(),
      limit: Joi.number(),
      equipmentTable: Joi.array().items(),
    }),
    equipmentTypeSettings: Joi.object().keys({
      isDefault: Joi.bool(),
      limit: Joi.number(),
      equipmentTypeTable: Joi.array().items(),
    }),
    invoiceSettings: Joi.object().keys({
      isDefault: Joi.bool(),
      limit: Joi.number(),
      invoiceTable: Joi.array().items(),
    }),
    clientActivitySettings: Joi.object().keys({
      isDefault: Joi.bool(),
      limit: Joi.number(),
      searchLimit: Joi.number(),
      clientActivityTable: Joi.array().items(),
    }),
    shippingSettings: Joi.object().keys({
      isDefault: Joi.bool(),
      limit: Joi.number(),
      searchLimit: Joi.number(),
      shippingTable: Joi.array().items(),
    }),
    clientDragComponents: Joi.array(),
  }),
};

const getUsers = {
  query: Joi.object().keys({
    state: Joi.string(),
    role: Joi.string(),
    lang: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    search: Joi.string().trim(),
  }),
};

const UserCheckEmail = {
  query: Joi.object().keys({
    userId: Joi.string().custom(objectId),
    email: Joi.string().email().required(),
  }),
};

const UserCheckPhone = {
  query: Joi.object().keys({
    userId: Joi.string().custom(objectId),
    phone: Joi.string().required(),
  }),
};

const getRegistrationUsers = {
  query: Joi.object().keys({
    sortBy: Joi.string(),
    firstname: Joi.string(),
    lastname: Joi.string(),
    accessEnable: Joi.bool(),
    // roles: Joi.string(),
    admin: Joi.boolean().allow(''),
    cashier: Joi.boolean().allow(''),
    advancedCashier: Joi.boolean().allow(''),
    equipmentInstaller: Joi.boolean().allow(''),
    support: Joi.boolean().allow(''),
    email: Joi.string(),
    search: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    excel: Joi.bool(),
  }),
};

const getActiveUsers = {
  query: Joi.object().keys({
    sortBy: Joi.string(),
    search: Joi.string().trim(),
    loginStartDate: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    loginEndDate: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    loginStatus: Joi.number(),
    userStatus: Joi.bool(),
    id: Joi.number(), // number
    ipAddressesSearch: Joi.string().trim(),
    role: Joi.array().items(Joi.bool()),
    city: Joi.string().trim(),
    country: Joi.string().trim(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    excel: Joi.bool(),
  }),
};

const getUser = {
  params: Joi.object().keys({
    userId: Joi.string().custom(objectId),
  }),
};

const updateUser = {
  params: Joi.object().keys({
    userId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      email: Joi.string().email(),
      password: Joi.string().custom(password),
      confirmPassword: Joi.string().valid(Joi.ref('password')),
      firstname: Joi.string(),
      lastname: Joi.string(),
      color: Joi.string(),
      state: Joi.string(),
      address: Joi.string().custom(objectId),
      phone: Joi.object().keys({
        id: Joi.string().custom(objectId),
        phoneNumber: Joi.string(),
        countryCode: Joi.string(),
      }),
      darkMode: Joi.boolean(),
      lang: Joi.string(),
      timezone: Joi.string(),
      avatar: Joi.string().custom(objectId),
      accessEnable: Joi.bool(),
      showUnsuccessfulTransactions: Joi.bool(),
      rolesInfo: Joi.object().keys({
        cashier: Joi.bool(),
        support: Joi.bool(),
        admin: Joi.bool(),
        advancedCashier: Joi.bool(),
        equipmentInstaller: Joi.bool(),
      }),
      provider: Joi.string().custom(objectId),
      roles: Joi.array().items(Joi.string().custom(objectId)),
    })
    .min(1),
};

const deleteUser = {
  body: Joi.object().keys({
    userId: Joi.string().custom(objectId),
  }),
};

const deleteMultiply = {
  body: Joi.object().keys({
    userId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const resetPassword = {
  body: Joi.object().keys({
    token: Joi.string().required(),
    password: Joi.string().required().custom(password),
  }),
};

const emailResetPassword = {
  body: Joi.object().keys({
    email: Joi.string().email().required(),
  }),
};

const generateTelegramPassword = {
  params: Joi.object().keys({
    userId: Joi.required().custom(objectId),
  }),
};

const sendTelegramPassword = {
  params: Joi.object().keys({
    userId: Joi.required().custom(objectId),
  }),
  body: Joi.object().keys({
    type: Joi.string(),
    value: Joi.string(),
  }),
};

const resetLoginCount = {
  params: Joi.object().keys({
    userId: Joi.required().custom(objectId),
  }),
};

const userEnableDisableAction = {
  body: Joi.object().keys({
    accessEnable: Joi.bool(),
    userId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

module.exports = {
  createUser,
  getUsers,
  getUser,
  getRegistrationUsers,
  getActiveUsers,
  updateUser,
  deleteMultiply,
  deleteUser,
  setUserSettings,
  generateTelegramPassword,
  sendTelegramPassword,
  resetPassword,
  resetLoginCount,
  emailResetPassword,
  userEnableDisableAction,
  UserCheckEmail,
  UserCheckPhone,
};
