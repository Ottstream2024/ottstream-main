const Joi = require('joi');
const { objectId } = require('../custom.validation');

const getUserActivitys = {
  query: Joi.object().keys({
    type: Joi.string(),
    from: Joi.date(),
    to: Joi.date(),
    search: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    excel: Joi.bool(),
    user: Joi.string().custom(objectId),
  }),
};

module.exports = {
  getUserActivitys,
};
