const Joi = require('joi');

const { objectId } = require('../custom.validation');

const createShippingProviderJoi = Joi.object().keys({
  providerOrders: Joi.string().required(),
  clientsOrder: Joi.string().required(),
  productionToken: Joi.string().required(),
  email: Joi.string().required().email(),
  password: Joi.string().required(),
  apiKey: Joi.string().required(),
  apiSecret: Joi.string().required(),
  token: Joi.string().required(),
});

const createShippingProvider = {
  body: createShippingProviderJoi,
};

const getShippingProviders = {
  query: Joi.object().keys({
    state: Joi.string(),
    role: Joi.string(),
    lang: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getShippingProvider = {
  params: Joi.object().keys({
    shippingProviderId: Joi.string().custom(objectId),
  }),
};

const updateShippingProviderJoi = Joi.object().keys({
  id: Joi.string().custom(objectId),
  providerOrders: Joi.string(),
  clientsOrder: Joi.string(),
  productionToken: Joi.string(),
  email: Joi.string().email(),
  password: Joi.string(),
  apiKey: Joi.string(),
  apiSecret: Joi.string(),
  token: Joi.string(),
});

const updateShippingProvider = Joi.object().keys({
  shippingProviderId: Joi.string().custom(objectId),
  body: updateShippingProviderJoi,
});

const deleteShippingProvider = {
  params: Joi.object().keys({
    shippingProviderId: Joi.string().custom(objectId),
  }),
};
module.exports = {
  createShippingProviderJoi,
  createShippingProvider,
  getShippingProviders,
  getShippingProvider,
  updateShippingProviderJoi,
  updateShippingProvider,
  deleteShippingProvider,
};
