const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createPaymentImplementation = {
  body: Joi.object().keys({
    name: Joi.string().required(),
    key: Joi.string().required(),
  }),
};

const getPaymentImplementations = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getPaymentImplementation = {
  params: Joi.object().keys({
    paymentImplementationId: Joi.string().custom(objectId),
  }),
};

const updatePaymentImplementation = {
  params: Joi.object().keys({
    paymentImplementationId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.string(),
      state: Joi.number(),
      key: Joi.string(),
    })
    .min(1),
};

const deletePaymentImplementation = {
  params: Joi.object().keys({
    paymentImplementationId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createPaymentImplementation,
  getPaymentImplementations,
  getPaymentImplementation,
  updatePaymentImplementation,
  deletePaymentImplementation,
};
