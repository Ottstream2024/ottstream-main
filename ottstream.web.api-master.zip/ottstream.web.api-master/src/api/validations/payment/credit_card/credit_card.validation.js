const BaseJoi = require('joi');
const Extension = require('../../extensions/joi_credit_card');

const Joi = BaseJoi.extend(Extension);
const { objectId } = require('../../custom.validation');

const createCreditCardJoi = Joi.object().keys({
  // cardholderName: Joi.string().required(),
  // cardNumber: Joi.creditCard().number().required(),
  // expireDate: Joi.creditCard().expirationDate().required(),
  // billingAddress: Joi.creditCard().string().required(),
  // cvc: Joi.creditCard().cvc(),
});

const createCreditCard = {
  body: createCreditCardJoi,
};

const getCreditCards = {
  query: Joi.object().keys({
    cardholderName: Joi.string(),
    user: Joi.string().custom(objectId),
    lang: Joi.string(),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getCreditCard = {
  params: Joi.object().keys({
    creditCardId: Joi.string().custom(objectId),
  }),
};

const updateCreditCardJoi = Joi.object().keys({
  id: Joi.string().custom(objectId),
  cardholderName: Joi.string(),
  cardNumber: Joi.number(),
  expireDate: Joi.date(),
  billingAddress: Joi.string(),
  cvc: Joi.string(),
});

const updateCreditCard = {
  params: Joi.object().keys({
    creditCardId: Joi.required().custom(objectId),
  }),
  body: updateCreditCardJoi,
};

const deleteCreditCard = {
  params: Joi.object().keys({
    creditCardId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createCreditCardJoi,
  createCreditCard,
  getCreditCards,
  getCreditCard,
  updateCreditCard,
  updateCreditCardJoi,
  deleteCreditCard,
};
