const Joi = require('joi');

const { objectId } = require('../custom.validation');

const createCreditJoi = Joi.object().keys({
  startNow: Joi.boolean().default(false),
  creditAmount: Joi.number().required().default(0),
  creditStartDate: Joi.date().required(),
  creditTerm: Joi.number().required(),
  days: Joi.boolean().default(false),
  months: Joi.boolean().default(false),
  clientsPauseAfterDays: Joi.number().required(),
  creditComment: Joi.string().required(),
  providerId: Joi.string().custom(objectId),
  clientId: Joi.string().custom(objectId),
  creditAutoextend: Joi.boolean().default(false),
});

const updateCreditJoi = Joi.object().keys({
  id: Joi.string().custom(objectId),
  creditAmount: Joi.number(),
  startNow: Joi.boolean(),
  creditStartDate: Joi.date(),
  creditTerm: Joi.number(),
  days: Joi.boolean(),
  months: Joi.boolean(),
  clientsPauseAfterDays: Joi.string(),
  creditComment: Joi.string(),
  creditAutoextend: Joi.boolean(),
});

const stopCreditJoi = Joi.object().keys({
  params: Joi.object().keys({
    ottProviderId: Joi.string().custom(objectId),
  }),
});

const stopClientCreditJoi = Joi.object().keys({
  params: Joi.object().keys({
    clientId: Joi.string().custom(objectId),
  }),
});

module.exports = {
  createCreditJoi,
  updateCreditJoi,
  stopCreditJoi,
  stopClientCreditJoi,
};
