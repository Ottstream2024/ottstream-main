const Joi = require('joi');

const { objectId } = require('../custom.validation');

const createBankNameJoi = Joi.object().keys({
  name: Joi.string().required(),
});

const createBankName = {
  body: createBankNameJoi,
};

const getBankNames = {
  query: Joi.object().keys({
    state: Joi.string(),
    role: Joi.string(),
    lang: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getBankName = {
  params: Joi.object().keys({
    bankNameId: Joi.string().custom(objectId),
  }),
};

const updateBankNameJoi = Joi.object().keys({
  name: Joi.string(),
});

const updateBankName = Joi.object().keys({
  bankNameId: Joi.string().custom(objectId),
  body: updateBankNameJoi,
});

const deleteBankName = {
  params: Joi.object().keys({
    bankNameId: Joi.string().custom(objectId),
  }),
};
module.exports = {
  createBankNameJoi,
  createBankName,
  getBankNames,
  getBankName,
  updateBankNameJoi,
  updateBankName,
  deleteBankName,
};
