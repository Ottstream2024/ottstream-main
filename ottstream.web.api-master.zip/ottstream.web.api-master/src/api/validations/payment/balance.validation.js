const Joi = require('joi');

const { objectId } = require('../custom.validation');

const addBalance = Joi.object().keys({
  method: Joi.number().required().valid(0, 1, 2, 3),
  moneyOrder: Joi.number().when('method', {
    is: 0,
    then: Joi.required(),
  }),
  checkNumber: Joi.alternatives().conditional('method', {
    is: 1,
    then: Joi.number().required(),
  }),
  balance: Joi.alternatives().conditional('method', {
    is: 2,
    then: Joi.number().required(),
  }),
  comment: Joi.string(),
  providerId: Joi.string().custom(objectId),
  clientId: Joi.string().custom(objectId),
});

const pay = Joi.object().keys({
  action: Joi.number().required().valid(1, 2),
  paymentMethod: Joi.number().required().valid(0, 1, 2, 3),
  checkNumber: Joi.alternatives().conditional('paymentMethod', {
    is: 3,
    then: Joi.number().required(),
  }),
  mailByCheckeeper: Joi.alternatives().conditional('paymentMethod', {
    is: 3,
    then: Joi.boolean().default(true),
  }),
  paymentMethodId: Joi.alternatives().conditional('paymentMethod', {
    is: 0,
    then: Joi.string().custom(objectId).required(),
  }),
  creditCard: Joi.alternatives().conditional('paymentMethod', {
    is: 1,
    then: Joi.object().keys({
      cardNumber: Joi.string().min(1).max(20).required(),
      cardholderName: Joi.string().required(),
      cvc: Joi.string().required().min(3),
      month: Joi.string(),
      year: Joi.string(),
      brand: Joi.string().allow(''),
      anExistingAddress: Joi.bool(),
      existingAddress: Joi.alternatives().conditional('anExistingAddress', {
        is: true,
        then: Joi.string().custom(objectId).required(),
      }),
      billingAddress: Joi.alternatives()
        .conditional('anExistingAddress', {
          is: false,
          then: Joi.object().keys({
            phone: Joi.string().required(),
            address: Joi.string().required(),
            country: Joi.string().required(),
            city: Joi.string().required(),
            suite: Joi.string().allow(''),
            zip: Joi.string().required(),
            state: Joi.string().allow(''),
          }),
        })
        .allow(''),
    }),
  }),
  bankTransfer: Joi.alternatives().conditional('paymentMethod', {
    is: 2,
    then: Joi.object().keys({
      bankName: Joi.string().required(),
      routingNumber: Joi.number().required(),
      accountNumber: Joi.string().min(1).required(),
      account: Joi.string().valid('personalAccount', 'businessAccount'),
      personalData: Joi.alternatives()
        .conditional('account', {
          is: 'personalAccount',
          then: Joi.object().keys({
            firstname: Joi.string().required(),
            lastname: Joi.string().required(),
            nickname: Joi.string().required(),
          }),
        })
        .allow(''),
      companyName: Joi.alternatives()
        .conditional('account', {
          is: 'businessAccount',
          then: Joi.string().required(),
        })
        .allow(''),
    }),
  }),
  amount: Joi.number().required(),
});

const updateBalanceJoi = Joi.object().keys({
  id: Joi.string().custom(objectId),
  balance: Joi.number().required(),
  paymentMethod: Joi.object().keys({
    // moneyOrder: Joi.object.keys({
    //   numberOrder: Joi.number().required(),
    // }),
    // check: Joi.object.keys({
    //   numberOrder: Joi.number().required(),
    // }),
  }),
});

module.exports = {
  pay,
  addBalance,
  updateBalanceJoi,
};
