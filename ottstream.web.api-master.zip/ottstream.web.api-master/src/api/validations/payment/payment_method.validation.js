const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createPaymentMethod = {
  body: Joi.object().keys({
    name: Joi.string().required(),
    key: Joi.string().required(),
    fields: Joi.object().required(),
  }),
};

const getPaymentMethods = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getPaymentMethod = {
  params: Joi.object().keys({
    paymentMethodId: Joi.string().custom(objectId),
  }),
};

const updatePaymentMethod = {
  params: Joi.object().keys({
    paymentMethodId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.string(),
      state: Joi.number(),
      key: Joi.string(),
    })
    .min(1),
};

const deletePaymentMethod = {
  params: Joi.object().keys({
    paymentMethodId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createPaymentMethod,
  getPaymentMethods,
  getPaymentMethod,
  updatePaymentMethod,
  deletePaymentMethod,
};
