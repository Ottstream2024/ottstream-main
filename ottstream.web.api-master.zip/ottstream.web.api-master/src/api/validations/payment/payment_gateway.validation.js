const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createPaymentGatewayJoi = {
  autopay: Joi.string().required(),
  autopayInterval: Joi.number(),
  autopayRetryCount: Joi.number(),
  cards: Joi.string().required(),
  bank: Joi.string().required(),
  collectFreeFromClient: Joi.boolean().required(),
  apiLoginId: Joi.string().required(),
  transactionKey: Joi.string().required(),
  currentSignatureKey: Joi.string(),
  username: Joi.string().required(),
  password: Joi.string().required(),
  signature: Joi.string(),
  secretKey: Joi.string().required(),
  publicKey: Joi.string().required(),
};
const createPaymentGateway = {
  body: createPaymentGatewayJoi,
};

const getPaymentGateways = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getPaymentGateway = {
  params: Joi.object().keys({
    paymentGatewayId: Joi.string().custom(objectId),
  }),
};

const updatePaymentGatewayJoi = Joi.object().keys({
  id: Joi.string().custom(objectId),
  autopay: Joi.string(),
  autopayInterval: Joi.number(),
  autopayRetryCount: Joi.number(),
  cards: Joi.string(),
  bank: Joi.string(),
  collectFreeFromClient: Joi.boolean(),
  apiLoginId: Joi.string(),
  transactionKey: Joi.string(),
  currentSignatureKey: Joi.string(),
  username: Joi.string(),
  password: Joi.string(),
  signature: Joi.string(),
  secretKey: Joi.string(),
  publicKey: Joi.string(),
});

const updatePaymentGateway = {
  params: Joi.object().keys({
    paymentGatewayId: Joi.required().custom(objectId),
  }),
  body: updatePaymentGatewayJoi,
};

const deletePaymentGateway = {
  params: Joi.object().keys({
    paymentGatewayId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createPaymentGatewayJoi,
  createPaymentGateway,
  getPaymentGateways,
  getPaymentGateway,
  updatePaymentGatewayJoi,
  updatePaymentGateway,
  deletePaymentGateway,
};
