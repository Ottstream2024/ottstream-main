const Joi = require('joi');

const { objectId } = require('../custom.validation');

const getInvoices = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    sent: Joi.bool(),
    client: Joi.string().custom(objectId),
  }),
};

const getBillInvoices = {
  body: Joi.object().keys({
    name: Joi.string(),
    type: Joi.number(),
    user: Joi.string().custom(objectId),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    search: Joi.string().trim(),
    searchLogin: Joi.string().trim(),
    searchCardNumber: Joi.string().trim(),
    subscriptionAmountFrom: Joi.number(),
    subscriptionAmountTo: Joi.number(),
    totalAmountFrom: Joi.number(),
    totalAmountTo: Joi.number(),
    dateForPayStart: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    dateForPayEnd: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    // autoPayment
    paymentStatus: Joi.array().items(Joi.number().allow(null)),
    paymentActonBy: Joi.number(),
    paymentMethod: Joi.array().items(Joi.number().allow(null)),
    billSentMethod: Joi.array().items(Joi.number().allow(null)),
    dateForPaymentStart: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    dateForPaymentEnd: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    dateForBillSentStart: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    dateForBillSentEnd: Joi.string().custom((value, helpers) => {
      const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

      if (!datePattern.test(value)) {
        return helpers.error('any.invalid');
      }

      // Split the date into components
      // eslint-disable-next-line no-unused-vars
      const [month, day, year] = value.split('/').map(Number);

      // Validate the components
      if (month < 1 || month > 12 || day < 1 || day > 31) {
        return helpers.error('any.invalid');
      }

      // You can add more specific date validations if needed

      return value; // Return the validated value
    }, 'Custom Date Format'),
    sent: Joi.bool(),
    client: Joi.string().custom(objectId),
    excel: Joi.bool(),
    // billSendMethod
    resellerClients: Joi.boolean(),
    providerId: Joi.string().custom(objectId),
  }),
};

const createInvoiceJoi = Joi.object().keys({
  method: Joi.number().required().valid(0, 1, 2, 3, 4, 5),
  moneyOrder: Joi.number().when('method', {
    is: 0,
    then: Joi.required(),
  }),
  checkNumber: Joi.alternatives().conditional('method', {
    is: 1,
    then: Joi.number().required(),
  }),
  invoice: Joi.alternatives().conditional('method', {
    is: 2,
    then: Joi.number().required(),
  }),
  comment: Joi.string(),
});

const updateInvoiceJoi = Joi.object().keys({
  id: Joi.string().custom(objectId),
  invoice: Joi.number().required(),
  paymentMethod: Joi.object().keys({
    // moneyOrder: Joi.object.keys({
    //   numberOrder: Joi.number().required(),
    // }),
    // check: Joi.object.keys({
    //   numberOrder: Joi.number().required(),
    // }),
  }),
});

const sendCheckoutInvoice = Joi.object().keys({
  params: Joi.object().keys({
    invoiceId: Joi.string().custom(objectId),
  }),
});

const getPayClient = Joi.object().keys({
  params: Joi.object().keys({
    invoiceId: Joi.string().custom(objectId),
  }),
});

const payClientUpdated = Joi.object().keys({
  params: Joi.object().keys({
    invoiceId: Joi.string().custom(objectId),
  }),
  body: Joi.object().keys({
    day: Joi.number(),
    month: Joi.number(),
  }),
});

const payInvoice = Joi.object().keys({
  balance: Joi.object().keys({
    amount: Joi.number(),
  }),
  defaultMethod: Joi.object().keys({
    amount: Joi.number(),
  }),
  paymentMethod: Joi.string().required(),
  cash: Joi.object().keys({
    amount: Joi.number(),
  }),
  checkNumber: Joi.alternatives().conditional('method', {
    is: 3,
    then: Joi.number().required(),
  }),
  bankName: Joi.alternatives().conditional('method', [
    {
      is: 3,
      then: Joi.string(),
    },
    {
      is: 5,
      then: Joi.string(),
    },
  ]),
  moneyOrderNumber: Joi.alternatives().conditional('method', {
    is: 5,
    then: Joi.number().required(),
  }),
  mailByCheckeeper: Joi.alternatives().conditional('method', {
    is: 3,
    then: Joi.boolean().default(true),
  }),
  savedCard: Joi.alternatives().conditional('paymentMethod', {
    is: 0,
    then: Joi.object().keys({
      cardId: Joi.string().custom(objectId).required(),
    }),
  }),
  creditCard: Joi.alternatives().conditional('paymentMethod', {
    is: 1,
    then: Joi.object().keys({
      save: Joi.boolean(),
      cardNumber: Joi.string(),
      cardholderName: Joi.string().required(),
      cvc: Joi.string(),
      month: Joi.string(),
      year: Joi.string(),
      token: Joi.string(),
      brand: Joi.string().allow(''),
      anExistingAddress: Joi.bool(),
      existingAddress: Joi.alternatives().conditional('anExistingAddress', {
        is: true,
        then: Joi.string().custom(objectId).required(),
      }),
      billingAddress: Joi.alternatives()
        .conditional('anExistingAddress', {
          is: false,
          then: Joi.object().keys({
            phone: Joi.string().required(),
            address: Joi.string().required(),
            country: Joi.string().required(),
            city: Joi.string().required(),
            suite: Joi.string().allow(''),
            zip: Joi.string().required(),
            state: Joi.string().allow(''),
          }),
        })
        .allow(''),
    }),
  }),
  bankTransfer: Joi.alternatives().conditional('paymentMethod', {
    is: 2,
    then: Joi.object().keys({
      save: Joi.boolean(),
      bankName: Joi.string().required(),
      routingNumber: Joi.number().required(),
      accountNumber: Joi.string().min(1).required(),
      account: Joi.number().valid(1, 2).default(1),
      personalData: Joi.alternatives()
        .conditional('account', {
          is: 'personalAccount',
          then: Joi.object().keys({
            firstname: Joi.string().required(),
            lastname: Joi.string().required(),
            nickname: Joi.string().required(),
          }),
        })
        .allow(''),
      companyName: Joi.alternatives()
        .conditional('account', {
          is: 'businessAccount',
          then: Joi.string().required(),
        })
        .allow(''),
    }),
  }),
  amount: Joi.number().required(),
});

const getInvoice = {
  params: Joi.object().keys({
    invoiceId: Joi.string().custom(objectId),
  }),
};

const payClientInvoice = {
  params: Joi.object().keys({
    invoiceId: Joi.string().custom(objectId),
  }),
  body: Joi.object().keys({
    month: Joi.number(),
    day: Joi.number(),
    autopayment: Joi.boolean(),
    creditCard: Joi.object().keys({
      save: Joi.boolean(),
      cardNumber: Joi.string().min(1).max(20).required(),
      cardholderName: Joi.string().required(),
      cvc: Joi.string().required().min(3),
      month: Joi.string(),
      year: Joi.string(),
      brand: Joi.string().allow(''),
      anExistingAddress: Joi.bool(),
      existingAddress: Joi.alternatives().conditional('anExistingAddress', {
        is: true,
        then: Joi.string().custom(objectId).required(),
      }),
      billingAddress: Joi.alternatives()
        .conditional('anExistingAddress', {
          is: false,
          then: Joi.object().keys({
            phone: Joi.string().required(),
            address: Joi.string().required(),
            country: Joi.string().required(),
            city: Joi.string().required(),
            suite: Joi.string().allow(''),
            zip: Joi.string().required(),
            state: Joi.string().allow(''),
          }),
        })
        .allow(''),
    }),
  }),
};

const updatePaymentData = {
  params: Joi.object().keys({
    invoice: Joi.string().custom(objectId),
  }),
  body: Joi.object().keys({
    paymentMethod: Joi.string(),
    shipping: Joi.object().keys({
      client: Joi.string().custom(objectId).required(),
      shipFrom: Joi.string().custom(objectId).required(),
      shipTo: Joi.string().custom(objectId).required(),
      isCheck: Joi.boolean().default(false),
      isPremiumShipping: Joi.boolean().default(false),
      isStandartPickup: Joi.boolean().default(false),
      addressOnLabel: Joi.string(),
      returnLabel: Joi.boolean(),
      selectedCourier: Joi.string(),
      pickupAddress: Joi.string(),
      pickupStartDate: Joi.date(),
      pickupEndDate: Joi.date(),
      equipments: Joi.array().items(Joi.string()).required(),
      boxes: Joi.array().items(
        Joi.object().keys({
          width: Joi.number().required(),
          height: Joi.number().required(),
          weight: Joi.number().required(),
          box: Joi.string(),
          length: Joi.number().required(),
          custom: Joi.boolean().required(),
        })
      ),
    }),
  }),
};

const view = {
  params: Joi.object().keys({
    invoiceId: Joi.string().custom(objectId),
  }),
  query: Joi.object().keys({
    type: Joi.number().default(1),
    jpeg: Joi.boolean().default(false),
  }),
};

const views = {
  body: Joi.object().keys({
    invoices: Joi.array().items(Joi.string().custom(objectId)),
  }),
  query: Joi.object().keys({
    type: Joi.number().default(1),
    jpeg: Joi.boolean().default(false),
  }),
};

const sendInvoices = {
  body: Joi.object().keys({
    invoices: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const clientOrderAction = {
  params: Joi.object().keys({
    clientId: Joi.string().custom(objectId),
  }),
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    lang: Joi.string(),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    search: Joi.string(),
  }),
};
module.exports = {
  getInvoice,
  sendCheckoutInvoice,
  getPayClient,
  getInvoices,
  getBillInvoices,
  payInvoice,
  createInvoiceJoi,
  payClientInvoice,
  updatePaymentData,
  updateInvoiceJoi,
  clientOrderAction,
  view,
  views,
  sendInvoices,
  payClientUpdated,
};
