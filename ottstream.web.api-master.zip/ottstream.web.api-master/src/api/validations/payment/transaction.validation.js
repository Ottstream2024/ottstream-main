const Joi = require('joi');

const { objectId } = require('../custom.validation');

const getTransactionsJoy = {
  name: Joi.string(),
  user: Joi.string().custom(objectId),
  state: Joi.number().integer(),
  sortBy: Joi.string(),
  limit: Joi.number().integer(),
  fee: Joi.boolean(),
  page: Joi.number().integer(),
  all: Joi.boolean(),
  v2: Joi.boolean(),
  search: Joi.string().trim(),
  transactionDateStart: Joi.date(),
  transactionDateEnd: Joi.date(),
  transactionState: Joi.number(),
  transactionType: Joi.string().trim(),
  transactionSubType: Joi.string().trim(),
  amountMin: Joi.number(),
  amountMax: Joi.number(),
  autopayment: Joi.boolean(),
  merchant: Joi.string().allow('', null),
  searchBillNumber: Joi.string().trim(),
  billGenerationDateStart: Joi.date(),
  billGenerationDateEnd: Joi.date(),
  allResellers: Joi.boolean(),
  executionStartDate: Joi.string().custom((value, helpers) => {
    const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

    if (!datePattern.test(value)) {
      return helpers.error('any.invalid');
    }

    // Split the date into components
    // eslint-disable-next-line no-unused-vars
    const [month, day, year] = value.split('/').map(Number);

    // Validate the components
    if (month < 1 || month > 12 || day < 1 || day > 31) {
      return helpers.error('any.invalid');
    }

    // You can add more specific date validations if needed

    return value; // Return the validated value
  }, 'Custom Date Format'),
  executionEndDate: Joi.string().custom((value, helpers) => {
    const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

    if (!datePattern.test(value)) {
      return helpers.error('any.invalid');
    }

    // Split the date into components
    // eslint-disable-next-line no-unused-vars
    const [month, day, year] = value.split('/').map(Number);

    // Validate the components
    if (month < 1 || month > 12 || day < 1 || day > 31) {
      return helpers.error('any.invalid');
    }

    // You can add more specific date validations if needed

    return value; // Return the validated value
  }, 'Custom Date Format'),
  initiatorType: Joi.number(),
  participantType: Joi.number(),
  parents: Joi.string(),
  searchLogin: Joi.string().trim(),
  own: Joi.bool(),
  out: Joi.bool(),
  in: Joi.bool(),
  resellers: Joi.string(),
  isRefund: Joi.bool(),
  toProvider: Joi.string(),
  paymentMethodSearch: Joi.string().trim(),
  paymentMethodType: Joi.string().trim(),
  excel: Joi.bool().default(false),
  // myIncomeType
  // searchInitiatorName
  // searchParticipantID
};
const getTransactions = {
  query: Joi.object().keys(getTransactionsJoy),
};

const getClientTransactions = {
  query: Joi.object().keys({ ...getTransactionsJoy, client: Joi.string().custom(objectId) }),
};

const createTransactionJoi = Joi.object().keys({
  method: Joi.number().required().valid(0, 1, 2, 3),
  moneyOrder: Joi.number().when('method', {
    is: 0,
    then: Joi.required(),
  }),
  checkNumber: Joi.alternatives().conditional('method', {
    is: 1,
    then: Joi.number().required(),
  }),
  transaction: Joi.alternatives().conditional('method', {
    is: 2,
    then: Joi.number().required(),
  }),
  comment: Joi.string(),
});

const voidTransaction = Joi.object().keys({
  params: Joi.object().keys({
    transactionId: Joi.string().custom(objectId),
  }),
});

const view = Joi.object().keys({
  params: Joi.object().keys({
    transactionId: Joi.string().custom(objectId),
  }),
  query: Joi.object().keys({
    provider: Joi.string().custom(objectId),
  }),
});

const sendTransaction = Joi.object().keys({
  params: Joi.object().keys({
    transactionId: Joi.string().custom(objectId),
  }),
});

const sendTransactionByInvoice = Joi.object().keys({
  params: Joi.object().keys({
    invoiceId: Joi.string().custom(objectId),
  }),
});

const printTransactionByInvoice = Joi.object().keys({
  params: Joi.object().keys({
    invoiceId: Joi.string().custom(objectId),
  }),
});

const printTransaction = Joi.object().keys({
  params: Joi.object().keys({
    transactionId: Joi.string().custom(objectId),
  }),
});

module.exports = {
  getTransactions,
  createTransactionJoi,
  sendTransaction,
  sendTransactionByInvoice,
  printTransactionByInvoice,
  getClientTransactions,
  printTransaction,
  voidTransaction,
  view,
};
