const Joi = require('joi');

const { objectId } = require('../../custom.validation');

const createBankTransferJoi = Joi.object().keys({
  bankName: Joi.string(),
  routingNumber: Joi.number(),
  accountNumber: Joi.number(),
  companyName: Joi.string(),
  firstname: Joi.string(),
  lastname: Joi.string(),
  nickname: Joi.string(),
  type: Joi.number(),
});

const updateBankTransferJoi = Joi.object().keys({
  id: Joi.string().custom(objectId),
  bankName: Joi.string(),
  routingNumber: Joi.number(),
  accountNumber: Joi.number(),
  companyName: Joi.string(),
  firstname: Joi.string(),
  lastname: Joi.string(),
  nickname: Joi.string(),
  type: Joi.number(),
});

module.exports = {
  createBankTransferJoi,
  updateBankTransferJoi,
};
