const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createDefaultPrice = {
  body: Joi.object()
    .keys({
      interval: Joi.number(),
      intervalType: Joi.string().allow('m', 'd'),
      clientType: Joi.boolean(),
      prices: Joi.array().items(Joi.number()).min(5),
    })
    .min(1),
};

const createPrice = {
  body: Joi.object()
    .keys({
      clientType: Joi.boolean().required(),
      priceGroup: Joi.string().allow(null),
      discount: Joi.string().custom(objectId),
      editPrices: Joi.array().items(
        Joi.object().keys({
          interval: Joi.string().required(),
          priceItems: Joi.array().items(
            Joi.object().keys({
              room: Joi.number().required(),
              price: Joi.number().required(),
            })
          ),
        })
      ),
      removePrices: Joi.array().items(
        Joi.object().keys({
          interval: Joi.string().required(),
        })
      ),
    })
    .min(1),
};

const addPrice = {
  body: Joi.object()
    .keys({
      priceGroup: Joi.string().custom(objectId).allow(null, 'default'),
      discount: Joi.string().custom(objectId),
      clientType: Joi.boolean().required(),
      interval: Joi.number().required(),
      intervalType: Joi.string().allow('m', 'd').required(),
    })
    .min(1),
};

const createPackage = {
  body: Joi.object()
    .keys({
      name: Joi.array()
        .items({
          lang: Joi.string().allow(''),
          name: Joi.string(),
          id: Joi.string(),
        })
        .min(1),
      description: Joi.array()
        .required()
        .items({
          lang: Joi.string().allow(''),
          name: Joi.string().allow(''),
        })
        .min(0),
      type: Joi.number().allow(1, 2),
      vEnable: Joi.boolean(),
      tEnable: Joi.boolean(),
      aEnable: Joi.boolean(),
      forClients: Joi.boolean(),
      forResale: Joi.boolean(),
      status: Joi.number().allow(0, 1, 2),
      prices: Joi.array()
        .items({
          priceGroup: Joi.string().custom(objectId).allow(null, 'default'),
          discount: Joi.string().custom(objectId),
          priceItems: Joi.array()
            .required()
            .items({
              room: Joi.number(),
              interval: Joi.number(),
              intervalType: Joi.string().allow('m', 'd'),
              price: Joi.number(),
            })
            .min(0),
        })
        .min(0),
    })
    .min(1),
};

const getPackages = {
  query: Joi.object().keys({
    search: Joi.string().trim(),
    room: Joi.number(),
    parentDiscounts: Joi.string().custom(objectId),
    clientPriceGroup: Joi.string().custom(objectId),
    clientDiscounts: Joi.string().custom(objectId),
    providerPriceGroup: Joi.string().custom(objectId),
    providerDiscounts: Joi.string().custom(objectId),
    clientsFrom: Joi.number(),
    clientsTo: Joi.number(),
    clientsTotalFrom: Joi.number(),
    clientsTotalTo: Joi.number(),
    vEnable: Joi.number(),
    tEnable: Joi.number(),
    aEnable: Joi.number(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    excel: Joi.bool().default(false),
  }),
};

const getPackagePrice = {
  query: Joi.object().keys({
    clientType: Joi.boolean().required(),
    priceGroup: Joi.string().custom(objectId).allow(null, 'default'),
    discount: Joi.string().custom(objectId),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getPackage = {
  params: Joi.object().keys({
    packageId: Joi.string().custom(objectId),
  }),
};

const updatePackage = {
  params: Joi.object().keys({
    packageId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.array()
        .items({
          lang: Joi.string(),
          name: Joi.string(),
          id: Joi.string(),
        })
        .min(1),
      description: Joi.array()
        .items({
          lang: Joi.string().allow(''),
          name: Joi.string().allow(''),
          id: Joi.string(),
        })
        .min(0),
      type: Joi.number().allow(1, 2),
      vEnable: Joi.boolean(),
      tEnable: Joi.boolean(),
      aEnable: Joi.boolean(),
      forClients: Joi.boolean(),
      forResale: Joi.boolean(),
      status: Joi.number().allow(0, 1, 2),
      state: Joi.number().allow(0, 1, 2),
      prices: Joi.array()
        .items({
          id: Joi.string(),
          priceGroup: Joi.string().custom(objectId).allow(null, 'default'),
          discount: Joi.string().custom(objectId),
          priceItems: Joi.array()
            .required()
            .items({
              id: Joi.string(),
              room: Joi.number(),
              interval: Joi.number(),
              intervalType: Joi.string().allow('m', 'd'),
              price: Joi.number(),
            })
            .min(0),
        })
        .min(0),
    })
    .min(1),
};

const deletePackage = {
  params: Joi.object().keys({
    packageId: Joi.string().custom(objectId),
  }),
};

const disableEnablePackage = {
  params: Joi.object().keys({
    packageId: Joi.string().custom(objectId),
  }),
  body: Joi.object().keys({
    state: Joi.boolean().required(),
  }),
};

const disableEnablePackages = {
  body: Joi.object().keys({
    action: Joi.number().default(1),
    packages: Joi.array().required().items(Joi.string().custom(objectId)).min(1),
  }),
};

module.exports = {
  addPrice,
  createPrice,
  createDefaultPrice,
  createPackage,
  getPackagePrice,
  getPackages,
  disableEnablePackage,
  disableEnablePackages,
  getPackage,
  updatePackage,
  deletePackage,
};
