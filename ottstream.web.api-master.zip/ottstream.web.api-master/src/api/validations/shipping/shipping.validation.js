const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createShipping = {
  body: Joi.object()
    .keys({
      client: Joi.string().custom(objectId).required(),
      shipFrom: Joi.string().custom(objectId).required(),
      shipTo: Joi.string().custom(objectId).required(),
      isCheck: Joi.boolean().default(false),
      isPremiumShipping: Joi.boolean().default(false),
      isStandartPickup: Joi.boolean().default(false),
      addressOnLabel: Joi.string(),
      returnLabel: Joi.boolean(),
      selectedCourier: Joi.string(),
      pickupAddress: Joi.string(),
      pickupStartDate: Joi.date(),
      pickupEndDate: Joi.date(),
      equipments: Joi.array().items(Joi.string()).required(),
      boxes: Joi.array().items(
        Joi.object().keys({
          width: Joi.number().required(),
          height: Joi.number().required(),
          weight: Joi.number().required(),
          box: Joi.string(),
          length: Joi.number().required(),
          custom: Joi.boolean().required(),
        })
      ),
    })
    .min(1),
};

const getShippingJoi = {
  search: Joi.string(),
  courier: Joi.string(),
  startDate: Joi.string().custom((value, helpers) => {
    const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

    if (!datePattern.test(value)) {
      return helpers.error('any.invalid');
    }

    // Split the date into components
    // eslint-disable-next-line no-unused-vars
    const [month, day, year] = value.split('/').map(Number);

    // Validate the components
    if (month < 1 || month > 12 || day < 1 || day > 31) {
      return helpers.error('any.invalid');
    }

    // You can add more specific date validations if needed

    return value; // Return the validated value
  }, 'Custom Date Format'),
  endDate: Joi.string().custom((value, helpers) => {
    const datePattern = /^\d{2}\/\d{2}\/\d{4}$/;

    if (!datePattern.test(value)) {
      return helpers.error('any.invalid');
    }

    // Split the date into components
    // eslint-disable-next-line no-unused-vars
    const [month, day, year] = value.split('/').map(Number);

    // Validate the components
    if (month < 1 || month > 12 || day < 1 || day > 31) {
      return helpers.error('any.invalid');
    }

    // You can add more specific date validations if needed

    return value; // Return the validated value
  }, 'Custom Date Format'),
  sortBy: Joi.string(),
  limit: Joi.number().integer(),
  page: Joi.number().integer(),
  allResellers: Joi.boolean(),
  all: Joi.boolean(),
  excel: Joi.boolean(),
};
const getShippings = {
  query: Joi.object().keys(getShippingJoi),
};

const getClientShippings = {
  query: Joi.object().keys({ ...getShippingJoi, client: Joi.string().custom(objectId).required() }),
};

const getRates = {
  params: Joi.object().keys({
    shippingId: Joi.string().custom(objectId),
  }),
};

const getCategories = {};

const getShipping = {
  params: Joi.object().keys({
    shippingId: Joi.string().custom(objectId),
  }),
};

const generateLabel = {
  params: Joi.object().keys({
    shippingId: Joi.string().custom(objectId),
  }),
};

const cancel = {
  params: Joi.object().keys({
    shippingId: Joi.string().custom(objectId),
  }),
};

const updateShipping = {
  params: Joi.object().keys({
    shippingId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      comment: Joi.string().custom(objectId),
    })
    .min(1),
};

const shippingEnableDisableAction = {
  body: Joi.object().keys({
    enableForSale: Joi.bool(),
    shippingId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const deleteShipping = {
  params: Joi.object().keys({
    shippingId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createShipping,
  getShippings,
  generateLabel,
  getCategories,
  getRates,
  getClientShippings,
  getShipping,
  cancel,
  updateShipping,
  deleteShipping,
  shippingEnableDisableAction,
};
