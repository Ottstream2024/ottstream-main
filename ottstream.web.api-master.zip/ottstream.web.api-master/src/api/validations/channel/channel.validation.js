const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createChannel = {
  body: Joi.object().keys({
    name: Joi.array()
      .items({
        lang: Joi.string().required(),
        name: Joi.string().required(),
      })
      .min(1),
    description: Joi.array()
      .items({
        lang: Joi.string().required(),
        name: Joi.string().required(),
      })
      .min(0),
    icons: Joi.array().items({
      id: Joi.string().custom(objectId),
      iconType: Joi.string().custom(objectId),
      iconSet: Joi.string().required().custom(objectId),
    }),
    state: Joi.number().valid(0, 1, 2),
    hidden: Joi.boolean(),
    protected: Joi.boolean(),
    archive: Joi.boolean(),
  }),
};

const getChannels = {
  query: Joi.object().keys({
    name: Joi.string(),
    user: Joi.string().custom(objectId),
    lang: Joi.string(),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const syncChannels = {
  query: Joi.object().keys({}),
};

const getChannel = {
  params: Joi.object().keys({
    channelId: Joi.string().custom(objectId),
  }),
};

const getPackageChannels = {
  params: Joi.object().keys({
    packageId: Joi.string().custom(objectId),
  }),
};

const getChannelIcon = {
  params: Joi.object().keys({
    ratiox: Joi.number().required(),
    ratioy: Joi.number().required(),
    width: Joi.string().required(),
    setId: Joi.number().required(),
    channelIdPlusExt: Joi.string().required(),
  }),
};

const updateChannel = {
  params: Joi.object().keys({
    channelId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.array()
        .items({
          id: Joi.string(),
          lang: Joi.string(),
          name: Joi.string(),
        })
        .min(1),
      description: Joi.array()
        .items({
          id: Joi.string(),
          lang: Joi.string(),
          name: Joi.string(),
        })
        .min(0),
      icons: Joi.array().items({
        id: Joi.string().custom(objectId),
        iconType: Joi.string().custom(objectId),
        iconSet: Joi.string().required().custom(objectId),
      }),
      state: Joi.number().valid(0, 1, 2),
      hidden: Joi.boolean(),
      protected: Joi.boolean(),
      archive: Joi.boolean(),
    })
    .min(1),
};

const updateChannelOrder = {
  params: Joi.object().keys({
    channelId: Joi.required().custom(objectId),
  }),
  body: Joi.array()
    .items({
      id: Joi.required().custom(objectId),
      order: Joi.number().required(),
    })
    .min(0),
};

const deleteChannel = {
  params: Joi.object().keys({
    channelId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createChannel,
  syncChannels,
  getChannels,
  getPackageChannels,
  getChannel,
  getChannelIcon,
  updateChannel,
  updateChannelOrder,
  deleteChannel,
};
