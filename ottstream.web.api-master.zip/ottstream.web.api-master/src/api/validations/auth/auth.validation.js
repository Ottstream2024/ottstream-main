const Joi = require('joi');
const { password } = require('../custom.validation');

const registerUserAndProvider = {
  body: Joi.object().keys({
    email: Joi.string().required().email(),
    password: Joi.string().required().custom(password),
    firstname: Joi.string().required(),
    lastname: Joi.string().required(),
    companyName: Joi.array()
      .items({
        lang: Joi.string().required(),
        name: Joi.string().required(),
      })
      .min(1),
    companyEmail: Joi.string().required().email(),
    website: Joi.string().required(),
    phone: Joi.object().keys({
      phoneNumber: Joi.string().required(),
      countryCode: Joi.string().required(),
    }),
    description: Joi.string().required(),
    channelAmount: Joi.number().required(),
    clientAmount: Joi.number().required(),
  }),
};

const login = {
  body: Joi.object().keys({
    email: Joi.string().required(),
    password: Joi.string().required(),
  }),
};

const me = {};

const logout = {
  body: Joi.object().keys({
    refreshToken: Joi.string().required(),
  }),
};

const refreshTokens = {
  body: Joi.object().keys({
    refreshToken: Joi.string().required(),
  }),
};

const forgotPassword = {
  body: Joi.object().keys({
    email: Joi.string().email().required(),
  }),
};

const otpCheck = {
  body: Joi.object().keys({
    otp: Joi.string().required(),
  }),
};

const emailCheck = {
  body: Joi.object().keys({
    email: Joi.string().required(),
  }),
};

const resetPassword = {
  // query: Joi.object().keys({
  //   token: Joi.string().required(),
  // }),
  body: Joi.object().keys({
    token: Joi.string().required(),
    password: Joi.string().required().custom(password),
    confirmPassword: Joi.any().valid(Joi.ref('password')).required(),
  }),
};

module.exports = {
  registerUserAndProvider,
  login,
  me,
  logout,
  refreshTokens,
  forgotPassword,
  otpCheck,
  resetPassword,
  emailCheck,
};
