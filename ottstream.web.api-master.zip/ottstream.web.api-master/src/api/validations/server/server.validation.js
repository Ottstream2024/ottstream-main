const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createServer = {
  body: Joi.object()
    .keys({
      name: Joi.array()
        .items({
          lang: Joi.string().allow(''),
          name: Joi.string(),
          id: Joi.string(),
        })
        .min(1),
      description: Joi.array()
        .required()
        .items({
          lang: Joi.string().allow(''),
          name: Joi.string(),
        })
        .min(0),
      type: Joi.number().allow(1, 2),
      vEnable: Joi.boolean(),
      tEnable: Joi.boolean(),
      aEnable: Joi.boolean(),
      forClients: Joi.boolean(),
      forResale: Joi.boolean(),
      status: Joi.number().allow(0, 1, 2),
      prices: Joi.array()
        .items({
          priceGroup: Joi.string().custom(objectId).allow(null),
          discount: Joi.string().custom(objectId).allow(null),
          priceItems: Joi.array()
            .required()
            .items({
              room: Joi.number(),
              interval: Joi.number(),
              intervalType: Joi.string().allow('m', 'd'),
              price: Joi.number(),
            })
            .min(0),
        })
        .min(0),
    })
    .min(1),
};

const getServers = {
  query: Joi.object().keys({
    search: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getServer = {
  params: Joi.object().keys({
    serverId: Joi.string().custom(objectId),
  }),
};

const updateServer = {
  params: Joi.object().keys({
    serverId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.array()
        .items({
          lang: Joi.string(),
          name: Joi.string(),
          id: Joi.string(),
        })
        .min(1),
      description: Joi.array()
        .items({
          lang: Joi.string(),
          name: Joi.string(),
          id: Joi.string(),
        })
        .min(0),
      type: Joi.number().allow(1, 2),
      vEnable: Joi.boolean(),
      tEnable: Joi.boolean(),
      aEnable: Joi.boolean(),
      forClients: Joi.boolean(),
      forResale: Joi.boolean(),
      status: Joi.number().allow(0, 1, 2),
      prices: Joi.array()
        .items({
          id: Joi.string(),
          priceGroup: Joi.string().custom(objectId).allow(null),
          discount: Joi.string().custom(objectId).allow(null),
          priceItems: Joi.array()
            .required()
            .items({
              id: Joi.string(),
              room: Joi.number(),
              interval: Joi.number(),
              intervalType: Joi.string().allow('m', 'd'),
              price: Joi.number(),
            })
            .min(0),
        })
        .min(0),
    })
    .min(1),
};

const deleteServer = {
  params: Joi.object().keys({
    serverId: Joi.string().custom(objectId),
  }),
};

const disableEnableServer = {
  params: Joi.object().keys({
    serverId: Joi.string().custom(objectId),
  }),
  body: Joi.object().keys({
    status: Joi.boolean().required(),
  }),
};

const disableEnableServers = {
  body: Joi.object().keys({
    action: Joi.number().default(1),
    servers: Joi.array().required().items(Joi.string().custom(objectId)).min(1),
  }),
};

module.exports = {
  createServer,
  getServers,
  disableEnableServer,
  disableEnableServers,
  getServer,
  updateServer,
  deleteServer,
};
