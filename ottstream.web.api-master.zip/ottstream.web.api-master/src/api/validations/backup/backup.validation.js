const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createBackup = {
  body: Joi.object()
    .keys({
      name: Joi.array()
        .items({
          lang: Joi.string().allow(''),
          name: Joi.string(),
        })
        .min(1),
      description: Joi.string().allow(''),
      price: Joi.number(),
      type: Joi.number(),
      enableForSale: Joi.bool(),
    })
    .min(1),
};

const getBackups = {
  query: Joi.object().keys({
    search: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    type: Joi.string().required(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    // name: Joi.string(),
    // description: Joi.string(),
    // priceFrom: Joi.number(),
    // priceTo: Joi.number(),
    excel: Joi.boolean(),
  }),
};

const getBackup = {
  params: Joi.object().keys({
    backupId: Joi.string().custom(objectId),
  }),
};

const updateBackup = {
  params: Joi.object().keys({
    backupId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.array()
        .items({
          lang: Joi.string().allow(''),
          name: Joi.string().allow(''),
        })
        .min(1),
      description: Joi.string().allow(''),
      price: Joi.number(),
      type: Joi.number(),
      enableForSale: Joi.bool(),
    })
    .min(1),
};

const backupEnableDisableAction = {
  body: Joi.object().keys({
    enableForSale: Joi.bool(),
    backupId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const deleteBackup = {
  body: Joi.object().keys({
    backupId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

module.exports = {
  createBackup,
  getBackups,
  getBackup,
  updateBackup,
  deleteBackup,
  backupEnableDisableAction,
};
