const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createEquipment = {
  body: Joi.object()
    .keys({
      name: Joi.array()
        .items({
          lang: Joi.string().allow(''),
          name: Joi.string(),
        })
        .min(1),
      description: Joi.string().allow(''),
      sku: Joi.string(),
      prices: Joi.array().items(
        Joi.object().keys({
          md: Joi.string().allow(''),
          priceGroup: Joi.string().allow(null),
          pieces: Joi.array(),
          showPriceGroupSelect: Joi.bool(),
        })
      ),
      type: Joi.string().custom(objectId),
      enableForSale: Joi.bool(),
      isService: Joi.bool(),
      information: Joi.object().keys({
        category: Joi.number(),
        manufacturer: Joi.string(), // String
        certification: Joi.string(), // String
        condition: Joi.string(), // String
        standart: Joi.string(), // String
        os: Joi.string(), // String
        unitSize: Joi.string(), // String (sm, in)
        height: Joi.number(), // Number
        width: Joi.number(), // Number
        length: Joi.number(), // Number
        unitWeight: Joi.string(), // String (kg, lb)
        productWeight: Joi.number(), // Number
      }),
      options: Joi.object().keys({
        selectedColor: Joi.object().allow(null), // Object
        colorsList: Joi.array(), // Array
      }),
      productImage: Joi.object().keys({
        imagesList: Joi.array(), // Array
        colorCode: Joi.string(), // String
        colorFromList: Joi.object(), // Object
      }),
      discount: Joi.object().keys({
        selectedDiscounts: Joi.array(), // Array
      }),
    })
    .min(1),
};

const getEquipments = {
  query: Joi.object().keys({
    search: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    type: Joi.string().custom(objectId),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    name: Joi.string(),
    description: Joi.string(),
    priceFrom: Joi.number(),
    priceTo: Joi.number(),
    service: Joi.boolean(),
    excel: Joi.boolean(),
  }),
};

const getEquipment = {
  params: Joi.object().keys({
    equipmentId: Joi.string().custom(objectId),
  }),
};

const updateEquipment = {
  params: Joi.object().keys({
    equipmentId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.array()
        .items({
          lang: Joi.string().allow(''),
          name: Joi.string().allow(''),
        })
        .min(1),
      description: Joi.string().allow(''),
      sku: Joi.string(),
      prices: Joi.array().items(
        Joi.object().keys({
          md: Joi.string().allow(''),
          priceGroup: Joi.string().allow(null),
          pieces: Joi.array(),
          showPriceGroupSelect: Joi.bool(),
        })
      ),
      type: Joi.string().custom(objectId),
      enableForSale: Joi.bool(),
      isService: Joi.bool(),
      information: Joi.object().keys({
        category: Joi.number(),
        manufacturer: Joi.string(), // String
        certification: Joi.string(), // String
        condition: Joi.string(), // String
        standart: Joi.string(), // String
        os: Joi.string(), // String
        unitSize: Joi.string(), // String (sm, in)
        height: Joi.number(), // Number
        width: Joi.number(), // Number
        length: Joi.number(), // Number
        unitWeight: Joi.string(), // String (kg, lb)
        productWeight: Joi.number(), // Number
      }),
      options: Joi.object().keys({
        selectedColor: Joi.object().allow(null), // Object
        colorsList: Joi.array(), // Array
      }),
      productImage: Joi.object().keys({
        imagesList: Joi.array(), // Array
        colorCode: Joi.string(), // String
        colorFromList: Joi.object(), // Object
      }),
      discount: Joi.object().keys({
        selectedDiscounts: Joi.array(), // Array
      }),
    })
    .min(1),
};

const returnEquipment = {
  body: Joi.object()
    .keys({
      invoice: Joi.string().custom(objectId),
      equipment: Joi.string().custom(objectId),
      count: Joi.number(),
    })
    .min(1),
};

const equipmentEnableDisableAction = {
  body: Joi.object().keys({
    enableForSale: Joi.bool(),
    equipmentId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const deleteEquipment = {
  body: Joi.object().keys({
    equipmentId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

module.exports = {
  returnEquipment,
  createEquipment,
  getEquipments,
  getEquipment,
  updateEquipment,
  deleteEquipment,
  equipmentEnableDisableAction,
};
