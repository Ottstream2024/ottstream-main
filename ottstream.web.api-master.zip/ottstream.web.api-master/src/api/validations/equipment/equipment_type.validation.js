const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createEquipmentType = {
  body: Joi.object()
    .keys({
      name: Joi.array()
        .items({
          lang: Joi.string().allow(''),
          name: Joi.string(),
        })
        .min(1),
      description: Joi.string().allow(''),
    })
    .min(1),
};

const getEquipmentTypes = {
  query: Joi.object().keys({
    search: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    type: Joi.number(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    name: Joi.string(),
    description: Joi.string(),
    priceFrom: Joi.number(),
    priceTo: Joi.number(),
    excel: Joi.boolean(),
  }),
};

const getEquipmentType = {
  params: Joi.object().keys({
    equipmentTypeId: Joi.string().custom(objectId),
  }),
};

const updateEquipmentType = {
  params: Joi.object().keys({
    equipmentTypeId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.array()
        .items({
          lang: Joi.string().allow(''),
          name: Joi.string().allow(''),
        })
        .min(1),
      description: Joi.string().allow(''),
    })
    .min(1),
};

const equipmentTypeEnableDisableAction = {
  body: Joi.object().keys({
    enableForSale: Joi.bool(),
    equipmentTypeId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const deleteEquipmentType = {
  body: Joi.object().keys({
    equipmentTypeId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

module.exports = {
  createEquipmentType,
  getEquipmentTypes,
  getEquipmentType,
  updateEquipmentType,
  deleteEquipmentType,
  equipmentTypeEnableDisableAction,
};
