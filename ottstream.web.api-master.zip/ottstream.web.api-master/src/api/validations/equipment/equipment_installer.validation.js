const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createEquipmentInstaller = {
  body: Joi.object()
    .keys({
      name: Joi.array()
        .items({
          lang: Joi.string().allow(''),
          name: Joi.string(),
        })
        .min(1),
      description: Joi.string().allow(''),
    })
    .min(1),
};

const getEquipmentInstallers = {
  query: Joi.object().keys({
    search: Joi.string(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    type: Joi.number(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
    name: Joi.string(),
    excel: Joi.boolean(),
  }),
};

const getEquipmentInstaller = {
  params: Joi.object().keys({
    equipmentInstallerId: Joi.string().custom(objectId),
  }),
};

const updateEquipmentInstaller = {
  params: Joi.object().keys({
    equipmentInstallerId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      name: Joi.array()
        .items({
          lang: Joi.string().allow(''),
          name: Joi.string().allow(''),
        })
        .min(1),
      description: Joi.string().allow(''),
    })
    .min(1),
};

const equipmentInstallerEnableDisableAction = {
  body: Joi.object().keys({
    enableForSale: Joi.bool(),
    equipmentInstallerId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

const deleteEquipmentInstaller = {
  body: Joi.object().keys({
    equipmentInstallerId: Joi.array().items(Joi.string().custom(objectId)),
  }),
};

module.exports = {
  createEquipmentInstaller,
  getEquipmentInstallers,
  getEquipmentInstaller,
  updateEquipmentInstaller,
  deleteEquipmentInstaller,
  equipmentInstallerEnableDisableAction,
};
