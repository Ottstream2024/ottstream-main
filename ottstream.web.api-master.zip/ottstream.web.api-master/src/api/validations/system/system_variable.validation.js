const Joi = require('joi');
const { objectId } = require('../custom.validation');

const createSystemVariable = {
  body: Joi.object().keys({
    formats: Joi.array().items(Joi.string()).required(),
  }),
};

const getSystemVariables = {
  query: Joi.object().keys({
    name: Joi.string(),
    state: Joi.number().integer(),
    sortBy: Joi.string(),
    limit: Joi.number().integer(),
    page: Joi.number().integer(),
    all: Joi.boolean(),
  }),
};

const getSystemVariable = {
  params: Joi.object().keys({
    systemVariableId: Joi.string().custom(objectId),
  }),
};

const updateSystemVariable = {
  params: Joi.object().keys({
    systemVariableId: Joi.required().custom(objectId),
  }),
  body: Joi.object()
    .keys({
      formats: Joi.array().items(Joi.string()),
      state: Joi.number().valid(0, 1, 2),
    })
    .min(1),
};

const deleteSystemVariable = {
  params: Joi.object().keys({
    systemVariableId: Joi.string().custom(objectId),
  }),
};

module.exports = {
  createSystemVariable,
  getSystemVariables,
  getSystemVariable,
  updateSystemVariable,
  deleteSystemVariable,
};
