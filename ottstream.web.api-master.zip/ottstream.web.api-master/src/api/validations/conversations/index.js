const Joi = require('joi');
const { isValidObjectId } = require('mongoose');

const createConversation = {
  body: Joi.object().keys({
    userId: Joi.string().custom((value) => isValidObjectId(value)),
  }),
};

const createClientConversation = {
  body: Joi.object().keys({
    clientId: Joi.string().custom((value) => isValidObjectId(value)),
  }),
};

const getConversations = {
  query: Joi.object().keys({
    page: Joi.number().required(),
    limit: Joi.number().required(),
  }),
  params: Joi.object().keys({
    type: Joi.string().required(),
  }),
};

const createGroupConversation = {
  body: Joi.object().keys({
    members: Joi.array().items(Joi.string()),
    name: Joi.string().required(),
  }),
};

const getMemberById = {
  params: Joi.object().keys({
    id: Joi.string().required(),
  }),
};

const findConversation = {
  params: Joi.object().keys({
    type: Joi.string().required(),
  }),
  query: Joi.object().keys({
    search: Joi.string().required(),
  }),
};

module.exports = {
  createConversation,
  getConversations,
  createGroupConversation,
  createClientConversation,
  getMemberById,
  findConversation,
};
