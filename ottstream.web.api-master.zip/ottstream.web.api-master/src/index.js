const path = require('path');

// eslint-disable-next-line import/no-extraneous-dependencies
const { Config } = require('ottstream.services.config');
// eslint-disable-next-line import/no-extraneous-dependencies
const dataAccess = require('ottstream.dataaccess');

// read config
const envPath = path.join(__dirname, '../.env');

Config.readEnv(envPath);

// set api ocnfig
const appConfig = require('./config');

appConfig.initConfig();

// set dataacess config dataacess

dataAccess.config.initConfig(appConfig.getConfig());
dataAccess.DbSetup.initDb();

const config = require('./config');

const app = require('./app');

const logger = require('./utils/logger/logger');
require('./services/service_collection');
const AppEventBusProcessor = require('./hosted/event_bus/app_evenbus_processor');

const eventBusProcessor = new AppEventBusProcessor();
eventBusProcessor
  .processSocketStreams()
  .then(() => {})
  .catch(() => {});

// const {
//   basicUserRoles,
//   basicOttProvider,
//   defaultChannelIconSet,
//   defaultIconType,
//   supportedPaymentMethods,
//   supportedPaymentImplementations,
// } = require('./utils/startup');
// await resetAllTimezones();
const server = app.listen(config.getConfig().port, () => {
  logger.info(`Listening to port ${config.getConfig().port}`);
});

const exitHandler = () => {
  if (server) {
    server.close(() => {
      logger.info('Server closed');
      process.exit(1);
    });
  } else {
    process.exit(1);
  }
};

const unexpectedErrorHandler = (error) => {
  logger.error(error);
  exitHandler();
};

process.on('uncaughtException', unexpectedErrorHandler);
process.on('unhandledRejection', unexpectedErrorHandler);

process.on('SIGTERM', () => {
  logger.info('SIGTERM received');
  if (server) {
    server.close();
  }
});
