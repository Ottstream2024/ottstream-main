const nodemailer = require('nodemailer');
const config = require('../../config');

const sendEmail = async (email, text) => {
  try {
    const smtpTransport = nodemailer.createTransport(config.getConfig().email.smtp.full);

    await smtpTransport.sendMail({
      from: config.getConfig().email.smtp.auth.user,
      to: email,
      subject: 'Your password has been changed',
      // eslint-disable-next-line no-undef
      text,
    });
  } catch {
    throw new Error('Email not sent');
  }
};

module.exports = { sendEmail };
