module.exports.basicUserRoles = require('./basic_user_roles');
module.exports.basicOttProvider = require('./basic_ottprovider');
module.exports.basicCountry = require('./basic_country');
module.exports.defaultChannelIconSet = require('./defaut_channel_icon_set');
module.exports.defaultIconType = require('./default_icon_type');
module.exports.supportedPaymentMethods = require('./supported_payment_methods');
module.exports.supportedPaymentImplementations = require('./supported_payment_implementations');
