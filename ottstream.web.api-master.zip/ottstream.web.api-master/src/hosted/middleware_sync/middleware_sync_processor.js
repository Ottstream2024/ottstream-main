// schedule to generate invoices
const cron = require('node-cron');
const logger = require('../../utils/logger/logger');
const OttSyncService = require('../../services/sync/ott_provider/ott_sync.service');
const LocationSyncService = require('../../services/sync/location/location_sync.service');
const PackageSyncService = require('../../services/sync/package/package_sync.service');
// const serviceCollection = require('../../services/service_collection');

const middlewareSyncCron = async () => {
  const callMinutes = '*/5 * * * *';
  cron.schedule(callMinutes, async function () {
    try {
      logger.info(`cron job: processing middleware syncs..`);
      await OttSyncService.syncProviders();
      await LocationSyncService.syncLocations(null, [1, 2]);
      // await LocationSyncService.syncUsedDevices();
      await PackageSyncService.syncOptionsHosted();
      logger.info(`cron job. middleare syncs done...`);
    } catch (ex) {
      logger.error(ex);
    }
  });
};

const middlewareSyncCronActives = async () => {
  const callMinutes = '*/51 * * * *';
  cron.schedule(callMinutes, async function () {
    try {
      logger.info(`cron job: processing middleware syncs..`);
      await OttSyncService.syncProviders();
      await LocationSyncService.syncLocations(null, [3]);
      // await LocationSyncService.syncUsedDevices();
      await PackageSyncService.syncOptionsHosted();
      logger.info(`cron job. middleare syncs done...`);
    } catch (ex) {
      logger.error(ex);
    }
  });
};

module.exports = {
  middlewareSyncCron,
  middlewareSyncCronActives,
};
