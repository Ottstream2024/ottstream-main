const companyTypes = ['0', '1', '2']; // base, ottprovider, reseller

module.exports = {
  companyTypes,
};
