const equipmentTypes = [
  {
    type: 0,
    name: [
      {
        en: 'Box',
      },
    ],
  },
  {
    type: 1,
    name: [
      {
        en: 'Pult',
      },
    ],
  },
  {
    type: 2,
    name: [
      {
        en: 'Element',
      },
    ],
  },
]; // base, ottprovider, reseller

module.exports = {
  equipmentTypes,
};
