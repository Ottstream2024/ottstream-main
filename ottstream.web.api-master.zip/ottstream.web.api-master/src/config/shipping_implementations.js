const paymentImplementations = ['eashship', 'shiprocket', 'shipstation', 'shippo'];

module.exports = {
  paymentImplementations,
};
