const languages = ['en', 'ru'];

module.exports = {
  languages,
};
