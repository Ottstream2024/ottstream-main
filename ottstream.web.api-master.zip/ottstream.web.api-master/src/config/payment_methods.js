const paymentMethods = ['credit-card', 'money-orders', 'bank-transfer', 'cash'];
const paymentMethodTypes = ['Visa', 'MasterCard', 'American Express', 'PayPal'];

module.exports = {
  paymentMethods,
  paymentMethodTypes,
};
