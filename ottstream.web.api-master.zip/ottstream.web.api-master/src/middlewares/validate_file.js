const httpStatus = require('http-status');
const ApiError = require('../api/utils/error/ApiError');

const validateFile = (field) => (req, res, next) => {
  if (!req.file && !req.files) {
    return next(new ApiError(httpStatus.BAD_REQUEST, `'${field}' is missing`));
  }
  return next();
};

module.exports = validateFile;
