const passport = require('passport');
const httpStatus = require('http-status');
const ApiError = require('../api/utils/error/ApiError');
const RoleService = require('../services/role/role.service');
const CacheService = require('../services/cache/CacheService');
const logger = require('../utils/logger/logger');
const config = require('../config');
const { userRepository } = require('../repository');
// const logger = require('../utils/logger/logger');
// const GeoIpService = require('../services/geoip/geoip.service');
// const CacheService = require('../services/cache/CacheService');

// eslint-disable-next-line no-unused-vars
const verifyCallback = (req, resolve, reject, requiredRights) => async (err, payload, info) => {
  if (!payload) {
    logger.error(`logoutscenar 1 ${JSON.stringify(payload)}`);
    return reject(new ApiError(httpStatus.UNAUTHORIZED, 'Please authenticate'));
  }
  const { userId, token } = payload;
  if (!userId || !token) {
    logger.error(`logoutscenar 2 ${JSON.stringify(payload)}`);
    return reject(new ApiError(httpStatus.UNAUTHORIZED, 'Please authenticate'));
  }
  // Check if the token has expired
  // const currentTime = Date.now().valueOf() / 1000; // Current time in seconds
  const cacheKey = `token-user-${token}`;
  let login = false;
  let user = null;
  // eslint-disable-next-line no-constant-condition
  // eslint-disable-next-line no-await-in-loop
  const hasKey = await CacheService.get(cacheKey);
  if (!hasKey) {
    logger.error(`logoutscenar 3 ${JSON.stringify(payload)}`);
    login = false;
  } else {
    // if (payload.exp && payload.exp < currentTime) {
    //   return done(null, false, { message: 'Token expired' });
    // }
    // eslint-disabl e-next-line no-await-in-loop
    await CacheService.updateex(cacheKey, config.getConfig().jwt.accessExpirationMinutes * 60);
    // eslint-disable-next-line no-await-in-loop
    user = await userRepository.getUserById(userId);
    if (!user) {
      logger.error(`logoutscenar 4 ${JSON.stringify(payload)}`);
      login = false;
    } else {
      login = true;
    }
  }
  if (!login) {
    return reject(new ApiError(httpStatus.UNAUTHORIZED, 'Please authenticate'));
  }

  req.user = user;
  await user.updateOne({
    email: user.email,
    $set: { lastActiveTime: Date.now() },
    new: true,
  });
  // check user login state
  // if (!req.isAuthenticated()) {
  //   await user.updateOne({
  //     email: user.email,
  //     $set: { loginStatus: 0, logoutTime: Date.now() },
  //     new: true,
  //   });
  // } else if (!user) {
  //   await user.updateOne({
  //     email: user.email,
  //     $set: { loginStatus: 2 },
  //     new: true,
  //   });
  // } else {
  //   await user.updateOne({
  //     email: user.email,
  //     $set: { loginStatus: 1 },
  //     new: true,
  //   });
  // }

  const hasPermission = RoleService.UserHasPermission(user, requiredRights.permissions ?? []);
  if (!hasPermission) {
    logger.error('asdasd4');
    return reject(new ApiError(httpStatus.FORBIDDEN, 'Forbidden'));
  }
  if (requiredRights.baseOnly) {
    if (!user.provider || user.provider.type === 1) {
      logger.error('asdasd5');
      return reject(new ApiError(httpStatus.FORBIDDEN, 'Forbidden'));
    }
  }
  resolve();
  // let permissionFound = false;
  //
  // if (requiredRights.roles && !requiredRights.roles.includes(req.user.role)) {
  //   return reject(new ApiError(httpStatus.FORBIDDEN, 'Forbidden'));
  // }
  // if (requiredRights.permissions.length) {
  //   requiredRights.permissions.forEach(function (requiredRight) {
  //     user.roles.forEach(function (userRole) {
  //       userRole.permissions.forEach(function (permission) {
  //         if (!permissionFound) {
  //           permissionFound = permission.keyword === requiredRight;
  //         }
  //       });
  //     });
  //   });
  //   if (!permissionFound) {
  //     return reject(new ApiError(httpStatus.FORBIDDEN, 'Forbidden'));
  //   }
  // }
  //
  // resolve();
};

module.exports = (requiredRights) => {
  // eslint-disable-next-line no-unused-vars
  return async function auth(req, res, next) {
    return new Promise((resolve, reject) => {
      passport.authenticate('jwt', { session: false }, verifyCallback(req, resolve, reject, requiredRights))(req, res, next);
    })
      .then(async () => {
        // const key = `user-auth-data-${req.user.id}`;
        // const ip = GeoIpService.getIp(req);
        // let data = null;
        // if (!(await CacheService.hasKey(key))) {
        //   await CacheService.setex(key, { ip }, 3600);
        // }
        // data = await CacheService.get(key);
        // if (!data) {
        //   logger.error(`auth middleware error: storing data in cache`);
        //   next();
        //   return;
        // }
        // if (data.ip !== ip) {
        //   next();
        //   // next(new ApiError(401, 'unauthorized'));
        // } else {
        //   next();
        // }
        next();
      })
      .catch((err) => next(err));
  };
};
