const { randomNumberSequence } = require('../utils/crypto/random');
const { userRepository } = require('../repository');

const generateTelegramAccess = async (req, res, next) => {
  const { rolesInfo, accessEnable } = req.body;
  const { userId } = req.params;

  let user = null;
  if (userId) {
    user = await userRepository.getUserById(userId);
  }

  if (accessEnable) {
    if (!rolesInfo && user?.rolesInfo?.accessEnable !== accessEnable) {
      req.body.telegramLogin = randomNumberSequence(6);
      req.body.telegramPassword = randomNumberSequence(6);
    }
    if (rolesInfo?.equipmentInstaller && rolesInfo?.equipmentInstaller !== user?.rolesInfo?.equipmentInstaller) {
      req.body.telegramLogin = randomNumberSequence(6);
      req.body.telegramPassword = randomNumberSequence(6);
    }
    if (rolesInfo?.equipmentInstaller && rolesInfo?.equipmentInstaller === user?.rolesInfo?.equipmentInstaller) {
      req.body.telegramLogin = user.telegramLogin;
      req.body.telegramPassword = user.telegramPassword;
    }
    if (rolesInfo?.equipmentInstaller === false) {
      req.body.telegramLogin = '';
      req.body.telegramPassword = '';
    }
  } else {
    req.body.telegramLogin = '';
    req.body.telegramPassword = '';
  }
  next();
};

module.exports = {
  generateTelegramAccess,
};
