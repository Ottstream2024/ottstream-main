const GeoIpService = require('../services/geoip/geoip.service');

const getGeoIpInfo = async (req, res, next) => {
  let ip = req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for'] || req.ip;
  // eslint-disable-next-line no-const-assign
  // ip = '45.146.38.206';
  ip = ip.toString().replace('::ffff:', '');
  if (ip === '::1' || ip === '127.0.0.1') {
    req.geoIpInfo = {
      realIp: '127.0.0.1',
      countryCode: 'Local',
      country: 'Local',
      city: 'Local',
      timezone: 'Local',
    };
    next();
  } else {
    const geopInfo = await GeoIpService.look(ip);
    req.geoIpInfo = geopInfo;
    next();
    // .then((response) => {
    //   req.geoIpInfo = response;
    //   next();
    // })
    // .catch((err) => {
    //   logger.error(err);
    //   req.geoIpInfo = {};
    //   next();
    // });
  }
};
// ip + timezone
module.exports = getGeoIpInfo;
