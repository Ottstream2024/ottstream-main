import mongoose, { connection, Schema as _Schema, model } from 'mongoose';
import aggregatePaginate from 'mongoose-aggregate-paginate-v2';
import { initialize } from '../../utils/mongoose-auto-increment';
import { toJSON, paginate } from '../plugins';
import calendarEventCommendSchema from './calendar_event_comment';

// initialize(connection);

const { Schema } = mongoose;

const calendarEvent = new mongoose.Schema(
  {
    provider: { type: Schema.Types.ObjectId, ref: 'OttProvider' },
    client: { type: Schema.Types.ObjectId, ref: 'Client' },
    location: { type: Schema.Types.ObjectId, ref: 'ClientLocation' },
    equipmentInstaller: { type: Schema.Types.ObjectId, ref: 'User' },
    lat: { type: Schema.Types.Number },
    comments: [calendarEventCommendSchema],
    long: { type: Schema.Types.Number },
    title: { type: Schema.Types.String },
    startDate: { type: Date },
    allDay: { type: Boolean },
    endDate: { type: Date },
    paymentType: { type: String },
    paymentPrice: { type: Number },
    paymentPaid: { type: Number },
    customerAddress: { type: Object },
    officeAddress: { type: Object },
    description: { type: Schema.Types.String },
    state: { type: Schema.Types.String },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
calendarEvent.plugin(toJSON);
calendarEvent.plugin(paginate);
calendarEvent.plugin(aggregatePaginate);

/**
 * @typedef calendarEvent
 */
const calendarEventSchema = model('CalendarEvent', calendarEvent, 'calendar_events');

export default calendarEventSchema;
