import mongoose, { Schema as _Schema } from 'mongoose';
import { toJSON } from '../plugins';

const { Schema } = mongoose;

const calendarEventCommendSchema = new mongoose.Schema(
  {
    comment: {
      type: String,
      required: true,
    },
    isCancel: {
      type: Boolean,
    },
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    userName: {
      type: String,
      required: false,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
calendarEventCommendSchema.plugin(toJSON);

export default calendarEventCommendSchema;
