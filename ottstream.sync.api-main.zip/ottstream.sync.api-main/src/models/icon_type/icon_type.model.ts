import mongoose, { connection, Schema as _Schema } from 'mongoose';
import { initialize, plugin } from '../../utils/mongoose-auto-increment';
import { toJSON, paginate } from '../plugins';

// initialize(connection);
const { Schema } = mongoose;

const iconTypeSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    ratiox: {
      type: Number,
      required: false,
      default: 0,
    },
    ratioy: {
      type: Number,
      required: false,
      default: 0,
    },
    contour: {
      type: String,
      required: true,
    },
    order: {
      type: Number,
      required: false,
    },
    widths: [
      {
        type: Number,
      },
    ],
    formats: [
      {
        type: String,
      },
    ],
    state: {
      type: Number,
      required: true,
      default: 1,
    },
    number: {
      type: Number,
      required: true,
      default: 1,
    },
    provider: { type: Schema.Types.ObjectId, ref: 'OttProvider' },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
iconTypeSchema.plugin(toJSON);
iconTypeSchema.plugin(paginate);
iconTypeSchema.plugin(plugin, {
  model: 'IconType',
  field: 'number',
  startAt: 1,
  incrementBy: 1,
});

// iconTypeSchema.plugin(autoIncrement, { model: 'IconType', field: 'number' });

/**
 * @typedef iconTypeSchema
 */
// const IconType = mongoose.model('IconType', iconTypeSchema, 'icon_types');
//
// module.exports = IconType;
