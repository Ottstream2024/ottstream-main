import mongoose, { Schema as _Schema, model } from 'mongoose';
import { toJSON, paginate } from '../plugins';

const { Schema } = mongoose;

const systemVariableSchema = new mongoose.Schema(
  {
    formats: [
      {
        type: String,
      },
    ],
    state: {
      type: Number,
      required: true,
      default: 1,
    },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
systemVariableSchema.plugin(toJSON);
systemVariableSchema.plugin(paginate);

/**
 * @typedef systemVariableSchema
 */
const SystemVariable = model('SystemVariable', systemVariableSchema, 'system_variables');

export default SystemVariable;
