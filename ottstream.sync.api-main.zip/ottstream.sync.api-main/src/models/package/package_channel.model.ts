import mongoose, { connection, Schema as _Schema, model  } from 'mongoose';
import aggregatePaginate from 'mongoose-aggregate-paginate-v2';
import { initialize, plugin } from '../../utils/mongoose-auto-increment';
import { toJSON, paginate } from '../plugins';

// initialize(connection);

const { Schema } = mongoose;

const _packageChannel = new mongoose.Schema(
  {
    sampleOption: {
      type: Number,
      required: false,
    },
    channelMiddlewareId: {
      type: Number,
      required: false,
    },
    packageMiddlewareId: {
      type: Number,
      required: false,
    },
    package: { type: Schema.Types.ObjectId, ref: 'Package' },
    channel: { type: Schema.Types.ObjectId, ref: 'Channel' },
    provider: { type: Schema.Types.ObjectId, ref: 'OttProvider' },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
_packageChannel.plugin(toJSON);
_packageChannel.plugin(paginate);
_packageChannel.plugin(aggregatePaginate);
_packageChannel.plugin(plugin, {
  model: 'packageSchema',
  field: 'number',
  startAt: 1,
  incrementBy: 1,
});
/**
 * @typedef package
 */
const packageChannelSchema = mongoose.model('PackageChannel', _packageChannel, 'package_channels');

export default packageChannelSchema;
