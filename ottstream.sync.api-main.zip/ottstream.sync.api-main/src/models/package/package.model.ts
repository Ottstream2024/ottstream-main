import mongoose, { connection, Schema as _Schema, model  } from 'mongoose';
import aggregatePaginate from 'mongoose-aggregate-paginate-v2';
import { initialize, plugin } from '../../utils/mongoose-auto-increment';
import { toJSON, paginate } from '../plugins';
import translationSchema from '../translation.model';

// initialize(connection);

const { Schema } = mongoose;

const _package = new mongoose.Schema(
  {
    name: [translationSchema],
    description: [translationSchema],
    middlewareId: {
      type: Number,
      required: false,
    },
    middlewareName: [translationSchema],
    vEnable: {
      type: Number,
      required: false,
      default: false,
    },
    aEnable: {
      type: Number,
      required: false,
      default: false,
    },
    tEnable: {
      type: Number,
      required: false,
      default: false,
    },
    type: {
      type: Number,
      default: 1,
      enum: [1, 2],
    },
    state: {
      type: Number,
      default: 1,
      enum: [0, 1, 2],
    },
    forClients: {
      type: Boolean,
      default: true,
    },
    forResale: {
      type: Boolean,
      default: true,
    },
    status: {
      type: Number,
      default: 1,
      enum: [0, 1, 2],
    },
    channels: [{ type: Schema.Types.ObjectId, ref: 'Channel' }],
    provider: { type: Schema.Types.ObjectId, ref: 'OttProvider' },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);

_package.index({ provider: 1 });
// add plugin that converts mongoose to json
_package.plugin(toJSON);
_package.plugin(paginate);
_package.plugin(aggregatePaginate);
_package.plugin(plugin, {
  model: 'packageSchema',
  field: 'number',
  startAt: 1,
  incrementBy: 1,
});
/**
 * @typedef package
 */
const packageSchema = mongoose.model('Package', _package, 'packages');

export default packageSchema;
