import mongoose, { connection, Schema as _Schema, model } from 'mongoose';
import aggregatePaginate from 'mongoose-aggregate-paginate-v2';
import { initialize } from '../../utils/mongoose-auto-increment';
import { toJSON, paginate } from '../plugins';
import packagePriceSchema from './package_price.model';

// initialize(connection);

const { Schema } = mongoose;

const _packageOption = new mongoose.Schema(
  {
    sampleOption: {
      type: Number,
      required: false,
    },
    state: {
      type: Number,
      default: 1,
      enum: [0, 1, 2],
    },
    prices: [packagePriceSchema],
    package: { type: Schema.Types.ObjectId, ref: 'Package' },
    provider: { type: Schema.Types.ObjectId, ref: 'OttProvider' },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);

_packageOption.index({ provider: 1 });
_packageOption.index({ package: 1 });
_packageOption.index({ provider: 1, package: 1 });

// add plugin that converts mongoose to json
_packageOption.plugin(toJSON);
_packageOption.plugin(paginate);
_packageOption.plugin(aggregatePaginate);

/**
 * @typedef package
 */
const packageOptionSchema = model('PackageOption', _packageOption, 'package_options');

export default packageOptionSchema;
