import mongoose, { Schema as _Schema, model } from 'mongoose';
import { toJSON } from '../plugins';

const { Schema } = mongoose;

const historySchema = new mongoose.Schema(
  {
    table: {
      type: String,
      required: true,
    },
    fields: {
      type: Schema.Types.Mixed,
      required: true,
    },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
historySchema.plugin(toJSON);

/**
 * @typedef historySchema
 */
const History = model('History', historySchema, 'histories');

export default History;
