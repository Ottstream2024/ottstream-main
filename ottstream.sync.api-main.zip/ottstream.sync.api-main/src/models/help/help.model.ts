import mongoose from 'mongoose'
import aggregatePaginate from 'mongoose-aggregate-paginate-v2';
import * as autoIncrement from '../../utils/mongoose-auto-increment/index';
import { toJSON, paginate } from'../plugins';

autoIncrement.// initialize(mongoose.connection);

const { Schema } = mongoose;

const help = new mongoose.Schema(
  {
    video: {
      type: String,
      required: false,
    },
    videoDescription: {
      type: String,
      required: false,
    },
    categoryName: {
      type: String,
      required: false,
    },
    type: {
      type: String,
      required: false,
    },
    name: {
      type: String,
      required: false,
    },
    number: {
      type: Number,
      required: false,
    },
    parent: { type: Schema.Types.ObjectId, ref: 'Help' },
    provider: { type: Schema.Types.ObjectId, ref: 'OttProvider' },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
help.plugin(toJSON);
help.plugin(paginate);
help.plugin(aggregatePaginate);
/**
 * @typedef help
 */
const helpSchema = mongoose.model('Help', help, 'helps');

export default helpSchema;
