import mongoose, { connection, Schema as _Schema, model } from 'mongoose';
import aggregatePaginate from 'mongoose-aggregate-paginate-v2';
import { initialize } from '../../utils/mongoose-auto-increment';
import { toJSON, paginate } from '../plugins';
import translationSchema from '../translation.model';

// initialize(connection);

const { Schema } = mongoose;

const equipmentInstaller = new mongoose.Schema(
  {
    name: [translationSchema],
    provider: { type: Schema.Types.ObjectId, ref: 'OttProvider' },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
equipmentInstaller.plugin(toJSON);
equipmentInstaller.plugin(paginate);
equipmentInstaller.plugin(aggregatePaginate);

/**
 * @typedef equipmentInstaller
 */
const equipmentInstallerSchema = model('EquipmentInstaller', equipmentInstaller, 'equipment_installers');

export default equipmentInstallerSchema;
