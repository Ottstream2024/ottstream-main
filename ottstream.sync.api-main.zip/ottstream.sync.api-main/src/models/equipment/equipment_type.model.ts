import mongoose, { connection, Schema as _Schema, model  } from 'mongoose';
import aggregatePaginate from 'mongoose-aggregate-paginate-v2';
import { initialize, plugin } from '../../utils/mongoose-auto-increment';
import { toJSON, paginate } from '../plugins';
import translationSchema from '../translation.model';

// initialize(connection);

const { Schema } = mongoose;

const equipmentType = new mongoose.Schema(
  {
    name: [translationSchema],
    description: {
      type: String,
      required: false,
    },
    provider: { type: Schema.Types.ObjectId, ref: 'OttProvider' },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
equipmentType.plugin(toJSON);
equipmentType.plugin(paginate);
equipmentType.plugin(aggregatePaginate);
equipmentType.plugin(plugin, {
  model: 'equipmentTypeSchema',
  field: 'number',
  startAt: 1,
  incrementBy: 1,
});
/**
 * @typedef equipmentType
 */
const equipmentTypeSchema = mongoose.model('EquipmentType', equipmentType, 'equipment_types');

export default equipmentTypeSchema;
