import mongoose, { Schema as _Schema, model } from 'mongoose';
import aggregatePaginate from 'mongoose-aggregate-paginate-v2';
import { paginate, toJSON } from '../plugins';

const { Schema } = mongoose;

const transactionSchema = new mongoose.Schema(
  {
    hash: {
      type: String,
      required: false,
    },
    invoice: { type: Schema.Types.ObjectId, ref: 'Invoice', index: true },
    provider: { type: Schema.Types.ObjectId, ref: 'OttProvider', index: true },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    payload: {
      type: Object,
      required: false,
    },
    sourcePay: {
      type: Object,
      requirxed: false,
    },
    payloadExecuted: {
      type: Boolean,
      required: true,
      default: false,
    },
    balanceHistory: {
      type: Object,
      required: false,
    },
    executionDate: {
      type: Date,
      required: false,
    },
    stateMessage: {
      type: String,
      required: false,
    },
    isRefund: {
      type: Boolean,
      required: false,
    },
    checkeeper: {
      type: Object,
      required: false,
    },
    state: {
      type: Number,
      required: true,
      default: 1,
    },
    number: {
      type: String,
      required: false,
    },
    transactionId: {
      type: String,
      required: false,
    },
    payloadError: {
      type: String,
      required: false,
    },
    amount: {
      type: Number,
      required: true,
    },
    fee: {
      type: Number,
      required: true,
      default: 0,
    },
    totalAmount: {
      type: Number,
      required: true,
    },
    fixed: {
      type: Boolean,
      required: false,
    },
    autopayment: {
      type: Boolean,
      required: false,
    },
    voidable: {
      type: Boolean,
      required: false,
    },
    transaction_type: {
      type: String,
      required: true,
      // enum: ['B_TO_B', 'C_TO_A', 'TO_B'],
    },
    source_type: {
      type: String,
      required: true,
      // enum: ['INVOICE', 'PAY_BALANCE', 'ADD_BALANCE', 'ADD_CREDIT', 'PAY_CREDIT', 'VOID_TRANSACTION'],
    },
    from_type: {
      type: Number,
      required: true,
      default: 1,
    },
    from_client: { type: Schema.Types.ObjectId, ref: 'Client' },
    from_provider: { type: Schema.Types.ObjectId, ref: 'OttProvider' },
    to_type: {
      type: Number,
      required: true,
      default: 1,
    },
    to_client: { type: Schema.Types.ObjectId, ref: 'Client' },
    to_provider: { type: Schema.Types.ObjectId, ref: 'OttProvider' },
    version: { type: String },
  },
  {
    timestamps: true,
  }
);

transactionSchema.index({ from_client: 1 });
transactionSchema.index({ from_provider: 1 });
transactionSchema.index({ to_client: 1 });
transactionSchema.index({ to_provider: 1 });
transactionSchema.index({ transaction_type: 1 });
transactionSchema.index({ invoice: 1 });
transactionSchema.index({ provider: 1 });

// add plugin that converts mongoose to json
transactionSchema.plugin(toJSON);
transactionSchema.plugin(paginate);
transactionSchema.plugin(aggregatePaginate);
/**
 * @typedef transactionSchema
 */
const Transaction = model('Transaction', transactionSchema, 'transactions');
export default Transaction;
