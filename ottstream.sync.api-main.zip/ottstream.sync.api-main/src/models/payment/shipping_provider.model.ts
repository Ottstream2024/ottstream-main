import { Schema, model } from 'mongoose';
import { toJSON } from '../plugins';

const shippingProviderSchema = new mongoose.Schema(
  {
    providerOrders: {
      type: String,
      required: true,
    },
    clientsOrder: {
      type: String,
      required: true,
    },
    productionToken: {
      type: String,
      required: true,
      index: true,
    },
    email: {
      type: String,
      required: true,
      trim: true,
    },
    password: {
      type: String,
      required: true,
      trim: true,
    },
    apiKey: {
      type: String,
      required: true,
    },
    apiSecret: {
      type: String,
      required: true,
    },
    token: {
      type: String,
      required: true,
      index: true,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
shippingProviderSchema.plugin(toJSON);

/**
 * @typedef shippingProviderSchema
 */
const ShippingProvider = model('shippingProvider', shippingProviderSchema, 'shipping_provider');

export default ShippingProvider;
