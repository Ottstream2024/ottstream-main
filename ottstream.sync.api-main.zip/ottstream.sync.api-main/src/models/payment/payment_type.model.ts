import mongoose, { Schema as _Schema, model } from 'mongoose';
import { toJSON, paginate } from '../plugins';

const { Schema } = mongoose;

const paymentTypeSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    key: {
      type: String,
      required: true,
    },
    state: {
      type: Number,
      required: true,
      default: 1,
    },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
paymentTypeSchema.plugin(toJSON);
paymentTypeSchema.plugin(paginate);

/**
 * @typedef paymentTypeSchema
 */
const PaymentType = model('PaymentType', paymentTypeSchema, 'payment_types');

export default PaymentType;
