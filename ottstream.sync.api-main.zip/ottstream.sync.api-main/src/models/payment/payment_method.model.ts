import { Schema, model } from 'mongoose';
import { paginate, toJSON } from '../plugins';

const paymentMethodSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    identifier: {
      type: String,
      required: true,
    },
    oneTime: {
      type: Boolean,
      required: true,
      default: false,
    },
    state: {
      type: Number,
      required: true,
      default: 1,
    },
  },
  {
    timestamps: true,
  }
);
// add plugin that converts mongoose to json
paymentMethodSchema.plugin(toJSON);
paymentMethodSchema.plugin(paginate);

/**
 * @typedef paymentMethodSchema
 */
const PaymentMethod = model('PaymentMethod', paymentMethodSchema, 'payment_methods');

export default PaymentMethod;
