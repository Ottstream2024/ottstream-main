import mongoose from 'mongoose';
import authorizeClientPaymentProfileSchema from './authorize_client_payment_profile.model';

const authorizeClientProfileSchema = new mongoose.Schema(
  {
    profileId: {
      type: String,
      required: true,
    },
    state: {
      type: Number,
      required: true,
      default: 1,
    },
    paymentProfiles: [authorizeClientPaymentProfileSchema],
  },
  {
    timestamps: true,
  }
);

export default authorizeClientProfileSchema;
