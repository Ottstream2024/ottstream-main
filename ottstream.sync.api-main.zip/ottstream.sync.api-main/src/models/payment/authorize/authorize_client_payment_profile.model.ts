import mongoose from 'mongoose';

const authorizeClientPaymentProfileSchema = new mongoose.Schema(
  {
    profileId: {
      type: String,
      required: true,
    },
    state: {
      type: Number,
      required: true,
      default: 1,
    },
  },
  {
    timestamps: true,
  }
);

export default authorizeClientPaymentProfileSchema;
