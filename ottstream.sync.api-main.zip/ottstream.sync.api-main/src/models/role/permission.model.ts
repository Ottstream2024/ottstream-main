import mongoose, { Schema as _Schema, model } from 'mongoose';
import { toJSON, paginate } from '../plugins';

const { Schema } = mongoose;

const permissionSchema = new mongoose.Schema(
  {
    keyword: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      required: false,
    },
    state: {
      type: Number,
      required: true,
      default: 1,
    },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
permissionSchema.plugin(toJSON);
permissionSchema.plugin(paginate);

/**
 * @typedef permissionSchema
 */
const Permission = model('Permission', permissionSchema, 'permissions');

export default Permission;
