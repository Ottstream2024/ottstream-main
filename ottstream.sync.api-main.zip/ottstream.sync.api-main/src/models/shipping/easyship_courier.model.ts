import mongoose, { connection, Schema as _Schema, model  } from 'mongoose';
import aggregatePaginate from 'mongoose-aggregate-paginate-v2';
import { initialize, plugin } from '../../utils/mongoose-auto-increment';
import { toJSON, paginate } from '../plugins';

// initialize(connection);

const { Schema } = mongoose;

const easyshipCourier = new mongoose.Schema(
  {
    courier_id: { type: Schema.Types.String, required: true },
    logo_url: { type: Schema.Types.String },
    data: {},
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
easyshipCourier.plugin(toJSON);
easyshipCourier.plugin(paginate);
easyshipCourier.plugin(aggregatePaginate);
easyshipCourier.plugin(plugin, {
  model: 'easyshipCourierSchema',
  field: 'number',
  startAt: 1,
  incrementBy: 1,
});
/**
 * @typedef easyshipCourier
 */
const easyshipCourierSchema = mongoose.model('EasyshipCourier', easyshipCourier, 'easyship_couriers');

export default easyshipCourierSchema;
