import mongoose, { connection, Schema as _Schema, model } from 'mongoose';
import aggregatePaginate from 'mongoose-aggregate-paginate-v2';
import { initialize } from '../../utils/mongoose-auto-increment';
import { toJSON, paginate } from '../plugins';

// initialize(connection);

const { Schema } = mongoose;

const shipping = new mongoose.Schema(
  {
    returnLabel: { type: Schema.Types.Boolean },
    shipFrom: {},
    boxes: [],
    equipments: [],
    shipping_documents: [],
    trackings: [],
    shipTo: {},
    selectedCourier: {},
    insurance: {},
    label: {},
    easyShipData: {},
    totalShipping: { type: Schema.Types.Number },
    isPremiumShipping: { type: Schema.Types.Boolean },
    isStandartPickup: { type: Schema.Types.Boolean },
    selected_courier: { type: Schema.Types.String },
    delivery_state: { type: Schema.Types.String },
    shipment_state: { type: Schema.Types.String },
    pickup_state: { type: Schema.Types.String },
    label_state: { type: Schema.Types.String },
    easyship_updated_at: { type: Schema.Types.Date },
    tracking_page_url: { type: Schema.Types.String },
    client: { type: Schema.Types.ObjectId, ref: 'Client' },
    provider: { type: Schema.Types.ObjectId, ref: 'OttProvider' },
    invoice: { type: Schema.Types.ObjectId, ref: 'Invoice' },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    easyship_shipment_id: { type: Schema.Types.String },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
shipping.plugin(toJSON);
shipping.plugin(paginate);
shipping.plugin(aggregatePaginate);
/**
 * @typedef shipping
 */
const shippingSchema = model('Shipping', shipping, 'shippings');

export default shippingSchema;
