import mongoose, { Schema as _Schema, model } from 'mongoose';
import { paginate, toJSON } from '../plugins';

const { Schema } = mongoose;

const deviceOptionSchema = new mongoose.Schema(
  {
    http_caching: [],
    bitrate: [],
    servers: [],
    audiotrack_default: [],
    definition_filter: [],
    lang: [],
    stream_quality: [],
    background_player: [],
    ui_font_size: [],
    box_models: [],
    provider: { type: Schema.Types.ObjectId, ref: 'OttProvider' },
  },
  {
    timestamps: true,
  }
);
// add plugin that converts mongoose to json
deviceOptionSchema.plugin(toJSON);
deviceOptionSchema.plugin(paginate);

/**
 * @typedef deviceOptionSchema
 */
const DeviceOption = model('DeviceOption', deviceOptionSchema, 'device_options');

export default DeviceOption;
