import mongoose from 'mongoose';
import { toJSON } from '../plugins';

const discountNotificationSchema = new mongoose.Schema(
  {
    beforeDays: {
      type: Number,
      required: false,
      default: 0,
    },
    repeatDays: {
      type: Number,
      required: false,
      default: 0,
    },
    notificationTextForUpcoming: {
      type: String,
      required: false,
    },
    notificationTextForCurrent: {
      type: String,
      required: false,
    },
    notificationsMode: {
      type: String,
      required: false,
      default: 'manualOnly',
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
discountNotificationSchema.plugin(toJSON);

export default discountNotificationSchema;
