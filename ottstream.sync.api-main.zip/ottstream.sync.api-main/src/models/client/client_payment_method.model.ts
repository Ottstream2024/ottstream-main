import { Schema as _Schema, model } from 'mongoose';
// const clientAddressSchema = require('./client_address.model');
import mongoose from 'mongoose';
import creditCardSchema from '../payment/credit_card/credit_card.model';
import bankTransferSchema from '../payment/bank_transfer/bank_transfer.model';
import { toJSON, paginate } from '../plugins';

const clientPaymentMethodSchema = new mongoose.Schema(
  {
    paymentMethod: {
      type: Number,
      required: false,
      default: 0,
    },
    creditCard: creditCardSchema.creditCardSchema,
    bankTransfer: bankTransferSchema,
    default: {
      type: Boolean,
      required: false,
      default: false,
    },
    authorizeId: {
      type: String,
    },
    authorizeProviderId: {
      type: String,
    },
    authorizePaymentProfileId: {
      type: String,
    },
    cloverId: {
      type: String,
    },
    squareId: {
      type: String,
    },
    cloverSourceId: {
      type: String,
    },
    cloverProviderId: {
      type: String,
    },
    squareProviderId: {
      type: String,
    },
    squareSourceId: {
      type: String,
    },
    cloverPaymentProfileId: {
      type: String,
    },
    squarePaymentId: {
      type: String,
    },
    validationMessage: {
      type: String,
    },
    inUse: {
      type: Boolean,
      required: false,
      default: true,
    },
    isValid: {
      type: Boolean,
      required: false,
      default: false,
    },
    clientId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Client',
      index: true,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
clientPaymentMethodSchema.plugin(toJSON);
clientPaymentMethodSchema.plugin(paginate);

const ClientPaymentMethod = model('ClientPaymentMethod', clientPaymentMethodSchema, 'client_payment_methods');
export default ClientPaymentMethod;
