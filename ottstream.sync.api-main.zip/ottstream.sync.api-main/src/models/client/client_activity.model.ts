import mongoose, { Schema as _Schema, model  } from 'mongoose';
import aggregatePaginate from 'mongoose-aggregate-paginate-v2';
import { plugin } from '../../utils/mongoose-auto-increment';
import { toJSON, paginate } from '../plugins';

const { Schema } = mongoose;

const clientActivitySchema = new mongoose.Schema(
  {
    type: {
      type: String,
      required: true,
    },
    action: {
      type: Object,
    },
    number: {
      type: Number,
      required: true,
      default: 1,
    },
    actionDescription: {
      type: String,
    },
    userDescription: {
      type: String,
    },
    typeDescription: {
      type: String,
    },
    provider: { type: Schema.Types.ObjectId, ref: 'OttProvider', index: true },
    client: { type: Schema.Types.ObjectId, ref: 'Client', index: true },
    user: { type: Schema.Types.ObjectId, ref: 'User', index: true },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
clientActivitySchema.plugin(toJSON);
clientActivitySchema.plugin(paginate);
clientActivitySchema.plugin(aggregatePaginate);
clientActivitySchema.plugin(plugin, {
  model: 'ClientActivity',
  field: 'number',
  startAt: 1,
  incrementBy: 1,
});

/**
 * @typedef ClientActivity
 */
const ClientActivity = mongoose.model('ClientActivity', clientActivitySchema, 'client_activities');

export default ClientActivity;
