import mongoose, { Schema as _Schema } from 'mongoose';
import { toJSON } from '../plugins';

const { Schema } = mongoose;

const clientDeviceSchema = new mongoose.Schema(
  {
    product: { type: Schema.Types.ObjectId, ref: 'Product' },
    interval: {
      type: String,
      required: false,
    },
    count: {
      type: Number,
      required: true,
    },
    expireDtae: {
      type: Date,
      required: false,
      default: Date.now(),
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
clientDeviceSchema.plugin(toJSON);

/**
 * @typedef channelSchema
 */

export default clientDeviceSchema;
