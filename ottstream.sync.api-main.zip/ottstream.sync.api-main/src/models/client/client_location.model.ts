import mongoose, {Schema, model} from 'mongoose';
import aggregatePaginate from 'mongoose-aggregate-paginate-v2';
import ClientUsedDevice from './client_used_device.model';

import { toJSON, paginate } from '../plugins';

const clientLocationSchema = new mongoose.Schema({
  locationName: {
    type: String,
    required: false,
    trim: false,
    default: 'Default',
  },
  roomsCount: {
    type: Number,
    required: false,
    default: 1,
  },
  roomsCountNew: {
    type: Number,
    required: false,
    default: 1,
  },
  priceGroup: {
    type: String,
    required: true,
    default: 'Price Group Example01',
  },
  keywords: {
    type: Object,
  },
  discount: {
    type: String,
    required: false,
  },
  //     discount: {
  //       type: Schema.Types.ObjectId,
  //       ref: 'Discount',
  //     },
  settingsUpdateUts: {
    type: Number,
    required: false,
  },
  subscriptionActivationDate: {
    type: Date,
    required: false,
  },
  subscriptionCancelDate: {
    type: Date,
    required: false,
  },
  subscriptionPendingDate: {
    type: Date,
    required: false,
  },
  login: {
    type: String,
    required: false,
    trim: true,
    index: true,
  },
  syncState: {
    type: Number,
    required: true,
    default: 2,
  },
  syncMessage: {
    type: String,
  },
  comment: {
    type: String,
  },
  password: {
    type: String,
    required: false,
    trim: true,
    private: false,
  },
  lastChangedPassword: {
    type: Date,
    required: false,
  },
  timezone: {
    type: String,
    required: false,
    // default: new Date(), for future
  },
  // server: {
  //   type: Schema.Types.ObjectId,
  //   ref: 'Server',
  // },
  server: {
    type: Schema.Types.ObjectId,
    ref: 'Server',
    index: true,
  },
  maxDevice: {
    type: Number,
    required: false,
    default: 5,
  },
  parentalCode: {
    type: String,
    required: false,
    private: false,
  },
  isBlockLocation: {
    type: Boolean,
    required: true,
    default: false,
  },
  isPauseSubscriptions: {
    type: Boolean,
    required: false,
    default: false,
  },
  pauses: [],
  pauseStartDate: {
    type: Date,
  },
  VODEnable: {
    type: Boolean,
    required: false,
    default: true,
  },
  archiveEnable: {
    type: Boolean,
    required: false,
    default: true,
  },
  autostartStatus: {
    type: Number,
    required: true,
    default: 0,
  },
  startDate: {
    type: Date,
    required: false,
  },
  recurringPayment: {
    type: Boolean,
    required: false,
  },
  endDate: {
    type: Date,
    required: false,
  },
  packetStart: {
    type: Number,
    required: false,
  },
  packetExpire: {
    type: Number,
    required: false,
  },
  timeShiftEnable: {
    type: Boolean,
    required: false,
    default: true,
  },
  lastActiveTime: {
    type: Date,
    required: false,
    default: Date.now,
  },
  geoInfo: {
    type: Object,
    required: false,
    default: {},
  },
  subscriptionState: {
    type: Number,
    required: true,
    default: 0,
  },
  subscriptionExpireDate: {
    type: Date,
    required: false,
  },
  isRecurring: {
    type: Boolean,
    required: false,
  },
  subscriptionPauses: {
    type: Object,
    required: false,
  },
  migrated: {
    type: Boolean,
    required: false,
    default: false,
  },
  clientId: {
    type: Schema.Types.ObjectId,
    ref: 'Client',
    index: true,
  },
  middlewareId: {
    type: String,
    required: false,
  },
  provider: {
    type: Schema.Types.ObjectId,
    ref: 'OttProvider',
    index: true,
  },
  commentUser: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    index: true,
  },
  subscriptions: [
    {
      type: Schema.Types.ObjectId,
      ref: 'Subscription',
      index: true,
    },
  ],
  usedDevices: [],
},
  {
    timestamps: true,
  });

const ClientLocation = mongoose.model('ClientLocation', clientLocationSchema, 'client_locations');

export default ClientLocation;
