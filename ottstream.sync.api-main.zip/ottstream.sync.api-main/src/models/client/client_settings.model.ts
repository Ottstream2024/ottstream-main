import mongoose from 'mongoose';
import { toJSON } from '../plugins';
import clientSettingsTableSchema from './client_settings_table.model';
import clientSettingsExtendedTableSchema from './client_settings_extended_table.model';

const clientSettingsSchema = new mongoose.Schema(
  {
    extendedType: {
      type: Number,
      required: false,
      default: 0, // 0 - off, 1 - on
    },
    table: clientSettingsTableSchema,
    extendedTable: clientSettingsExtendedTableSchema,
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
clientSettingsSchema.plugin(toJSON);

export default clientSettingsSchema;
