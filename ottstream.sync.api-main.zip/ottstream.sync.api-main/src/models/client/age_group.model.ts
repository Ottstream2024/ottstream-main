import mongoose, { Schema as _Schema, model } from 'mongoose';
import { toJSON, paginate } from '../plugins';

const { Schema } = mongoose;

const ageGroupSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: false,
      default: '',
    },
    from: {
      type: Number,
      required: true,
      default: 1,
    },
    to: {
      type: Number,
      required: true,
      default: 1,
    },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
ageGroupSchema.plugin(toJSON);
ageGroupSchema.plugin(paginate);

/**
 * @typedef ageGroupSchema
 */
const AgeGroup = model('AgeGroup', ageGroupSchema, 'price_groups');

export default AgeGroup;
