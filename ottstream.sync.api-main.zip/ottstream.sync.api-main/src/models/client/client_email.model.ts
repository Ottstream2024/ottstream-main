import mongoose from 'mongoose';
import { toJSON } from '../plugins';

const clientEmailSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      required: false,
      trim: true,
      lowercase: true,
    },
    isMain: {
      type: Boolean,
      required: false,
      default: false,
    },
    forContactInvoice: {
      type: Boolean,
      required: false,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
clientEmailSchema.plugin(toJSON);

export default clientEmailSchema;
