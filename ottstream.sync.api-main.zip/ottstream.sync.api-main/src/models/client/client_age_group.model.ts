import mongoose, { Schema, model } from 'mongoose';
import { toJSON, paginate } from '../plugins';

const clientSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    from: {
      type: Number,
      required: true,
    },
    to: {
      type: Number,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);
// add plugin that converts mongoose to json
clientSchema.plugin(toJSON);
clientSchema.plugin(paginate);

/**
 * @typedef clientAgeGroupSchema
 */
const ClientAgeGroup = model('ClientAgeGroup', clientSchema, 'client_age_groups');

export default ClientAgeGroup;
