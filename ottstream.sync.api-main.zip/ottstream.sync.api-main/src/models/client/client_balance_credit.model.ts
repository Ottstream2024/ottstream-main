import mongoose, { Schema as _Schema } from 'mongoose';
import { toJSON } from '../plugins';

const { Schema } = mongoose;

const clientBalanceCreditSchema = new mongoose.Schema(
  {
    balance: { type: Schema.Types.ObjectId, ref: 'Balance' },
    credit: { type: Schema.Types.ObjectId, ref: 'Credit' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
clientBalanceCreditSchema.plugin(toJSON);

export default clientBalanceCreditSchema;
