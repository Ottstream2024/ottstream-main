import mongoose, { Schema as _Schema, model } from 'mongoose';
import { toJSON, paginate } from '../plugins';
import translationSchema from '../translation.model';
import productPriceSchema from './product_price.model';
import productOptions from './product_options.model';
import channelIconSet from './product_icon_set.model';

const { Schema } = mongoose;

const product = new mongoose.Schema(
  {
    name: [translationSchema],
    description: [translationSchema],
    prices: [productPriceSchema],
    stock: {
      type: Number,
      required: false,
      default: 0,
    },
    type: {
      type: Schema.Types.ObjectId,
      ref: 'ProductType',
    },
    state: {
      type: Number,
      required: false,
      default: 1,
    },
    isClient: {
      type: Boolean,
      required: true,
    },
    isResale: {
      type: Boolean,
      required: true,
    },
    options: [productOptions],
    icons: [channelIconSet],
    packageUnitDimensions: {
      type: Number,
      required: false,
    },
    packageDimensions: {
      type: Schema.Types.Mixed,
      required: false,
    },
    packageUnitWeight: {
      type: Number,
      required: false,
    },
    packageWeight: {
      type: Number,
      required: false,
    },
    information: {
      type: Schema.Types.Mixed,
      required: false,
    },
    provider: { type: Schema.Types.ObjectId, ref: 'OttProvider' },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    creationDate: {
      type: Date,
      required: false,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
product.plugin(toJSON);
product.plugin(paginate);

/**
 * @typedef package
 */
const productSchema = model('Product', product, 'products');

export default productSchema;
