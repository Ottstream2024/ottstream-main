import mongoose from 'mongoose';
import { toJSON } from '../plugins';

const productPriceItemSchema = new mongoose.Schema(
  {
    piece: {
      type: Number,
      required: true,
    },
    month: {
      type: String,
      required: true,
    },
    price: {
      type: Number,
      required: false,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
productPriceItemSchema.plugin(toJSON);

/**
 * @typedef channelSchema
 */

export default productPriceItemSchema;
