import mongoose, { Schema as _Schema } from 'mongoose';
import { toJSON, paginate } from '../plugins';

const { Schema } = mongoose;

const productPiece = new mongoose.Schema(
  {
    number: {
      type: Number,
      required: true,
    },
    provider: { type: Schema.Types.ObjectId, ref: 'OttProvider' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
productPiece.plugin(toJSON);
productPiece.plugin(paginate);

/**
 * @typedef productPieceSchema
 */

export default productPiece;
