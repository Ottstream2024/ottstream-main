import mongoose, { Schema as _Schema, model } from 'mongoose';
import { toJSON, paginate } from '../plugins';
import invoiceSettings from './ottprovider_invoice_settings.model';
import invoiceDesign from './ottprovider_invoice_design.model';

const { Schema } = mongoose;

const ottproviderInvoiceSchema = new mongoose.Schema(
  {
    settings: invoiceSettings,
    design: invoiceDesign,
    providerId: {
      type: Schema.Types.ObjectId,
      ref: 'OttProvider',
      index: true,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
ottproviderInvoiceSchema.plugin(toJSON);
ottproviderInvoiceSchema.plugin(paginate);

/**
 * @typedef ottproviderSchema
 */
const OttProviderInvoice = model('OttProviderInvoice', ottproviderInvoiceSchema, 'ottprovider_invoice');

export default OttProviderInvoice;
