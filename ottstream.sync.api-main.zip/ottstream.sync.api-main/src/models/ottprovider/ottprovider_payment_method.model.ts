import mongoose, { Schema as _Schema, model } from 'mongoose';
import 'validator';
import { toJSON, paginate } from '../plugins';
import creditCardSchema from '../payment/credit_card/credit_card.model';
import bankTransferSchema from '../payment/bank_transfer/bank_transfer.model';

const { Schema } = mongoose;

const paymentMethodSchema = new mongoose.Schema(
  {
    paymentMethod: {
      type: Number,
      required: false,
      default: 0,
    },
    creditCard: creditCardSchema,
    bankTransfer: bankTransferSchema,
    default: {
      type: Boolean,
      required: false,
      default: false,
    },
    inUse: {
      type: Boolean,
      required: false,
      default: true,
    },
    providerId: {
      type: Schema.Types.ObjectId,
      ref: 'OttProvider',
      index: true,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
paymentMethodSchema.plugin(toJSON);
paymentMethodSchema.plugin(paginate);

/**
 * @typedef ottproviderSchema
 */
const OttProviderPaymentMethod = model(
  'OttProviderPaymentMethod',
  paymentMethodSchema,
  'ottprovider_payment_methods'
);
export default OttProviderPaymentMethod;
