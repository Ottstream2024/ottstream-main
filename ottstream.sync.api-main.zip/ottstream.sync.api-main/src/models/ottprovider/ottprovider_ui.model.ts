import mongoose, { Schema as _Schema, model  } from 'mongoose';
import { toJSON, paginate } from '../plugins';

const { Schema } = mongoose;

const ottproviderUiSchema = new mongoose.Schema(
  {
    domain: {
      type: String,
      required: false,
    },
    dns: {
      type: String,
      required: false,
    },
    providerId: {
      type: Schema.Types.ObjectId,
      ref: 'OttProvider',
      index: true,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
ottproviderUiSchema.plugin(toJSON);
ottproviderUiSchema.plugin(paginate);

/**
 * @typedef ottproviderSchema
 */
const OttProviderUi = mongoose.model('OttProviderUi', ottproviderUiSchema, 'ottprovider_ui');

export default OttProviderUi;
