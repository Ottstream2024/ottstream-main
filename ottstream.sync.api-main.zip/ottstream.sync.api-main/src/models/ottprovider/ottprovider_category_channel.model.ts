import mongoose, { Schema as _Schema } from 'mongoose';
import { toJSON } from '../plugins';
import ottProviderCategoryChannelItemSchema from './ottprovider_category_channel_item.model';

const { Schema } = mongoose;

const ottProviderCategoryChannelSchema = new mongoose.Schema(
  {
    category: { type: Schema.Types.ObjectId, ref: 'ChannelCategory' },
    channels: [ottProviderCategoryChannelItemSchema],
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
ottProviderCategoryChannelSchema.plugin(toJSON);

/**
 * @typedef channelSchema
 */

export default ottProviderCategoryChannelSchema;
