import mongoose from 'mongoose';
import { toJSON } from '../plugins';

const ottproviderCountryTaxSchema = new mongoose.Schema(
  {
    country: {
      type: String,
      required: true,
    },
    countryState: {
      type: String,
      required: false,
    },
    serviceTaxPercent: {
      type: Number,
      required: false,
      trim: false,
      min: 0,
      max: 100,
    },
    productTaxPercent: {
      type: Number,
      required: true,
      trim: false,
      min: 0,
      max: 100,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
ottproviderCountryTaxSchema.plugin(toJSON);

export default ottproviderCountryTaxSchema;
