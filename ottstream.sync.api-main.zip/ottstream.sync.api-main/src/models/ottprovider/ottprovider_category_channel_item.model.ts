import mongoose, { Schema as _Schema } from 'mongoose';
import { toJSON } from '../plugins';

const { Schema } = mongoose;

const ottProviderCategoryChannelItemSchema = new mongoose.Schema(
  {
    channel: {
      type: Schema.Types.ObjectId,
      ref: 'Channel',
    },
    order: {
      type: String,
      required: false,
    },
  },
  {
    timestamps: true,
  }
);

ottProviderCategoryChannelItemSchema.pre('save', function (next) {
  if (!this.order) this.order = this.get('_id'); // considering _id is input by client
  next();
});

// add plugin that converts mongoose to json
ottProviderCategoryChannelItemSchema.plugin(toJSON);

/**
 * @typedef channelSchema
 */

export default ottProviderCategoryChannelItemSchema;
