import mongoose, { Schema as _Schema } from 'mongoose';
import { toJSON } from '../plugins';

const { Schema } = mongoose;

const priceGroupCurrencySchema = new mongoose.Schema(
  {
    currency: {
      type: String,
      required: true,
    },
    country: {
      type: Schema.Types.ObjectId,
      ref: 'Country',
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
priceGroupCurrencySchema.plugin(toJSON);

/**
 * @typedef channelSchema
 */

export default priceGroupCurrencySchema;
