import mongoose from 'mongoose';
import { toJSON } from '../plugins';

const priceGroupDiscountSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    startDate: {
      type: Date,
      required: false,
    },
    endDate: {
      type: Date,
      required: false,
    },
    discount: {
      type: Number,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
priceGroupDiscountSchema.plugin(toJSON);

/**
 * @typedef channelSchema
 */

export default priceGroupDiscountSchema;
