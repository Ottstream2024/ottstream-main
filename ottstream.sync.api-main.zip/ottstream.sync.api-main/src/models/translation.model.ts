import mongoose from 'mongoose';
import { toJSON } from './plugins';

const translationSchema = new mongoose.Schema(
  {
    lang: {
      type: String,
      required: false,
      trim: true,
    },
    name: {
      type: String,
      required: false,
      trim: true,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
translationSchema.plugin(toJSON);

/**
 * @typedef channelSchema
 */

export default translationSchema;
