import { Schema, model } from 'mongoose';

const history_log = new mongoose.Schema(
  {
    data: {
        type: Object,
        default: null
    }
  },
  {
    timestamps: true,
  }
);
const HistoryLog = model('history_log', history_log);

export default HistoryLog;
