import mongoose, { Schema as _Schema, model } from 'mongoose';
import { toJSON, paginate } from '../plugins';

const { Schema } = mongoose;

const countrySchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      default: 1,
    },
    code: {
      type: String,
      required: true,
      default: 1,
    },
    state: {
      type: Number,
      required: true,
      default: 1,
    },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
countrySchema.plugin(toJSON);
countrySchema.plugin(paginate);

/**
 * @typedef countrySchema
 */
const Country = model('Country', countrySchema, 'countries');

export default Country;
