import mongoose, { Schema as _Schema, model } from 'mongoose';
import aggregatePaginate from 'mongoose-aggregate-paginate-v2';
import { toJSON, paginate } from '../plugins';

const { Schema } = mongoose;

const userActivitySchema = new mongoose.Schema(
  {
    type: {
      type: String,
      required: true,
    },
    message: {
      type: String,
      required: false,
    },
    data: {
      type: Object,
      required: false,
    },
    provider: { type: Schema.Types.ObjectId, ref: 'OttProvider', index: true },
    user: { type: Schema.Types.ObjectId, ref: 'User', index: true },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
userActivitySchema.plugin(toJSON);
userActivitySchema.plugin(paginate);
userActivitySchema.plugin(aggregatePaginate);

/**
 * @typedef UserActivity
 */
const UserActivity = model('UserActivity', userActivitySchema, 'user_activities');

export default UserActivity;
