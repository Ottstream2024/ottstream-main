import mongoose, { Schema as _Schema, model } from 'mongoose';
import { toJSON, paginate } from '../plugins';

const { Schema } = mongoose;

const languageUnitSchema = new mongoose.Schema(
  {
    keyword: {
      type: String,
      required: true,
      trim: true,
    },
    state: {
      type: Number,
      required: true,
      default: 1,
    },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
languageUnitSchema.plugin(toJSON);
languageUnitSchema.plugin(paginate);

/**
 * @typedef languageUnitSchema
 */
const LanguageUnit = model('LanguageUnit', languageUnitSchema, 'language_units');

export default LanguageUnit;
