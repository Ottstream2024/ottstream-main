import mongoose, { Schema as _Schema, model } from 'mongoose';
import { toJSON, paginate } from '../plugins';

const { Schema } = mongoose;

const languageUnitTranslationSchema = new mongoose.Schema(
  {
    translation: {
      type: String,
      required: true,
      trim: true,
    },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    unit: { type: Schema.Types.ObjectId, ref: 'LanguageUnit' },
    language: { type: Schema.Types.ObjectId, ref: 'Language' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
languageUnitTranslationSchema.plugin(toJSON);
// eslint-disable-next-line no-undef
languageUnitTranslationSchema.plugin(paginate);

/**
 * @typedef languageSchema
 */
// eslint-disable-next-line no-unused-vars
const LanguageUnitTranslation = model(
  'LanguageUnitTranslation',
  languageUnitTranslationSchema,
  'language_unit_translation'
);

export default LanguageUnitTranslation;
