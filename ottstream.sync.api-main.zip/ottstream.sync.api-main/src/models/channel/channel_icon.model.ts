import mongoose, { Schema as _Schema } from 'mongoose';
import { toJSON } from '../plugins';

const { Schema } = mongoose;

const channelIconSchema = new mongoose.Schema(
  {
    iconSet: {
      type: Schema.Types.ObjectId,
      ref: 'ChannelIconSet',
      required: true,
    },
    setName: {
      type: String,
      required: true,
    },
    iconType: {
      type: Schema.Types.ObjectId,
      ref: 'IconType',
      required: false,
    },
    provider: {
      type: Schema.Types.ObjectId,
      ref: 'OttProvider',
      required: false,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
channelIconSchema.plugin(toJSON);

/**
 * @typedef channelSchema
 */

// module.exports = channelIconSchema;
