import mongoose, { Schema as _Schema, model } from 'mongoose';
import aggregatePaginate from 'mongoose-aggregate-paginate-v2';
import { toJSON, paginate } from '../plugins';
import translationSchema from '../translation.model';

// eslint-disable-next-line no-unused-vars
const { Schema } = mongoose;

const channelSchema = new mongoose.Schema(
  {
    middlewareId: {
      // depending on payment state this variable is changed so we know invoice is payed
      type: Number,
      required: false,
    },
    group_id: {
      // depending on payment state this variable is changed so we know invoice is payed
      type: Number,
      required: false,
    },
    name: [translationSchema],
    icon_path: {
      // needed to know to send invoice with right date (will be updated while unpausing)
      type: String,
      required: false,
    },
    enabled: {
      // needed to know to send invoice with right date (will be updated while unpausing)
      type: Number,
      required: false,
    },
    packets: [{ type: Number }],
    provider: { type: Schema.Types.ObjectId, ref: 'OttProvider' },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);
// add plugin that converts mongoose to json
channelSchema.plugin(toJSON);
channelSchema.plugin(paginate);
channelSchema.plugin(aggregatePaginate);

/**
 * @typedef channelSchema
 */
const Channel = model('Channel', channelSchema, 'channels');

export default Channel;
