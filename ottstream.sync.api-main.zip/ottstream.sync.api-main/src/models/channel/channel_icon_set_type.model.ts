import mongoose, { connection, Schema as _Schema } from 'mongoose';
import { initialize, plugin } from '../../utils/mongoose-auto-increment';
import { toJSON, paginate } from '../plugins';

const { Schema } = mongoose;
// initialize(connection);

const channelIconSetTypeSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    state: {
      type: Number,
      required: true,
      default: 1,
    },
    number: {
      type: Number,
      required: true,
      default: 1,
    },
    provider: { type: Schema.Types.ObjectId, ref: 'OttProvider' },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
channelIconSetTypeSchema.plugin(toJSON);
channelIconSetTypeSchema.plugin(paginate);
channelIconSetTypeSchema.plugin(plugin, {
  model: 'ChannelIconSetType',
  field: 'number',
  startAt: 1,
  incrementBy: 1,
});

/**
 * @typedef channelIconSetTypeSchema
 */
// const ChannelIconSetType = mongoose.model('ChannelIconSetType', channelIconSetTypeSchema, 'channel_icon_set_types');
//
// module.exports = ChannelIconSetType;
