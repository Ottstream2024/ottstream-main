import mongoose, { Schema as _Schema } from 'mongoose';
import { toJSON } from '../plugins';

const { Schema } = mongoose;

const channelIconSetItemSchema = new mongoose.Schema(
  {
    iconType: {
      type: Schema.Types.ObjectId,
      ref: 'IconType',
      required: true,
    },
    data: {
      type: Schema.Types.Mixed,
      required: false,
    },
    originalImage: { type: Schema.Types.ObjectId, ref: 'File', required: false },
    changedImage: { type: Schema.Types.ObjectId, ref: 'File', required: false },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
channelIconSetItemSchema.plugin(toJSON);

/**
 * @typedef channelSchema
 */

// module.exports = channelIconSetItemSchema;
