import mongoose, { connection, Schema as _Schema, model } from 'mongoose';
import aggregatePaginate from 'mongoose-aggregate-paginate-v2';
import { initialize } from '../../utils/mongoose-auto-increment';
import { toJSON, paginate } from '../plugins';

// initialize(connection);

const { Schema } = mongoose;

const sms = new mongoose.Schema(
  {
    deliveryState: { type: Schema.Types.Number, required: true },
    deliveryMessage: { type: Schema.Types.String },
    deliveryDate: { type: Schema.Types.Date },
    deliverySystem: { type: Schema.Types.String, required: true },
    messageSource: { type: Schema.Types.String },
    messageId: { type: Schema.Types.String },
    message: { type: Schema.Types.String, required: true },
    provider: { type: Schema.Types.ObjectId, ref: 'OttProvider', required: true },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
sms.plugin(toJSON);
sms.plugin(paginate);
sms.plugin(aggregatePaginate);

/**
 * @typedef sms
 */
const smsSchema = model('sms', sms, 'smss');

export default smsSchema;
