import mongoose, { Schema as _Schema, model } from 'mongoose';
import { toJSON, paginate } from '../plugins';

const { Schema } = mongoose;
const botMessages = new mongoose.Schema(
  {
    botId: {
      type: String,
      required: true,
    },
    chatId: {
      type: Number,
      required: true,
    },
    messageIds: [
      {
        type: Number,
        required: false,
      },
    ],
    lastClearingDate: {
      type: Date,
      required: false,
    },
  },
  {
    timestamps: true,
  }
);

/**
 * @typedef botMessages
 */
const botMessagesSchema = mongoose.model('BotMessages', botMessages, 'bot_messages');

export default botMessagesSchema;
