import { Schema, model } from 'mongoose';
import aggregatePaginate from 'mongoose-aggregate-paginate-v2';
import { toJSON, paginate } from '../plugins';

const telegramBot = new mongoose.Schema(
  {
    botId: {
      type: String,
      required: false,
    },
    users: {
      type: Object,
    },
    lastMessageId: {
      type: Number,
      required: false,
    },
  },
  {
    timestamps: true,
  }
);

// add plugin that converts mongoose to json
telegramBot.plugin(toJSON);
telegramBot.plugin(paginate);
telegramBot.plugin(aggregatePaginate);
/**
 * @typedef telegramBot
 */
const telegramBotSchema = model('TelegramBot', telegramBot, 'telegram_bots');

export default telegramBotSchema;
