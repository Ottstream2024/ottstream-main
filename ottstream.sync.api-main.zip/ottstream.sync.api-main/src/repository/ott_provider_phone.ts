import OttProviderPhone from "../models/ottprovider/ottprovider_phone.model";

export const getOttProviderPhones = async (id, options = {}) => {
    return OttProviderPhone.find({ providerId: id });
};
  