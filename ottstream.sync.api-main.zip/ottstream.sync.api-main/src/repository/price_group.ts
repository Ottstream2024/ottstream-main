import PriceGroup from "../models/price/price_group.model";

export const getPriceGroupById = async (id, options = {}) => {
    return PriceGroup.findById(id);
  };