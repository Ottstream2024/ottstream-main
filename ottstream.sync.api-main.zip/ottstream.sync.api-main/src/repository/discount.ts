import Discount from '../models/discount/discount.model'
export const discountProjection = []

export const getDiscountById = async (id, options = {}) => {
    return Discount.findById(id).populate(discountProjection);
  };
  