import OttProviderEmail from "../models/ottprovider/ottprovider_email.model";

export const getOttProviderEmails = async (id, options = {}) => {
    return OttProviderEmail.find({ providerId: id });
};