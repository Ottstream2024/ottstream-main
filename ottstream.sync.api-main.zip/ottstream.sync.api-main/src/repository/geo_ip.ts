import Geoip from "../models/geoip/geoip.model";

const geoipPopulateObject = []

export const getGeoipByIp = async (ip, options = {}) => {
    const list = await Geoip.find({ ip }).populate(geoipPopulateObject);
    return list.length ? list[0] : null;
};

export const createGeoip = async (itemBody) => {
    // eslint-disable-next-line no-console
    const created: any = await Geoip.create(itemBody);
    return getGeoipByIp(created.ip);
};