import Server from "../models/server/server.model";

const serverPopulateObject = [
  {
    path: 'provider',
  },
];

export const getList = async (filter = {}, populate = [], projection = null) => {
    const query = Server.find(filter).populate(populate);
    if (projection) query.projection(projection);
    return query;
};

export const getServerById = async (id, options = {}) => {
  return Server.findById(id).populate(serverPopulateObject);
};