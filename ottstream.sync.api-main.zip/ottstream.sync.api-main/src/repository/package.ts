import httpStatus from "http-status";
import { ApiError } from "../utils/api_error";
import { updateSubDocument } from "../utils/update_sub_document";
import PackageOption from '../models/package/package_options.model'
import Package from '../models/package/package.model'
export const packagePopulateObject = [
    {
      path: 'provider',
    },
];

export const getPackageOptions = async (providerId) => {
    return PackageOption.find({ provider: providerId });
};

export const getList = async (filter = {}, populate = [], projection = null) => {
    const query = Package.find(filter).populate(populate);
    if (projection) query.projection(projection);
    return query;
};

export const getPackageByMiddlewareId = async (id, options = {}) => {
    const packages = await Package.find({
      middlewareId: id,
    }).populate(packagePopulateObject);
    if (packages.length) return packages[0];
    return null;
};

export const getPackageById = async (id, options = {}) => {
    return Package.findById(id).populate(packagePopulateObject);
};

export const createPackage = async (itemBody, user) => {
    const body = itemBody;
    // eslint-disable-next-line no-console
    body.user = user._id;
    body.provider = user.provider.id;
    const created = await Package.create(body);
    return getPackageById(created.id);
};

export const getMiddlewarePackages = async (id?: any, options?:any) => {
    return Package.find({ middlewareId: { $ne: null } });
};

export const updatePackageById = async (packageId, updateBody) => {
    const item: any = await getPackageById(packageId);
    if (!item) {
      throw new ApiError(httpStatus.NOT_FOUND, 'Package not found');
    }
    if (updateBody.prices) {
      item.prices = updateSubDocument(item, 'prices', updateBody, 'prices');
      // eslint-disable-next-line no-param-reassign
      delete updateBody.prices;
    }
    Object.assign(item, updateBody);
    await item.save();
    return getPackageById(packageId);
};