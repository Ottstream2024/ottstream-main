import Transaction from "../models/payment/transaction.model";

export const getList = async (filter = {}, populate = [], projection = null) => {
    const query = Transaction.find(filter).populate(populate);
    if (projection) query.projection(projection);
    return query;
  };