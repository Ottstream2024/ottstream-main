import httpStatus from "http-status";
import { ApiError } from "../utils/api_error";
import Icon from "../models/icon/icon.model";

export const iconPopulateObject = [
    {
      path: 'provider',
    },
];

export const getIconBySize = async (size, options = {}) => {
    const icons = await Icon.find({
      size,
    }).populate(iconPopulateObject);
    if (icons.length) return icons[0];
    return null;
};

export const getIconById = async (id, options = {}) => {
    return Icon.findById(id).populate(iconPopulateObject);
};

export const createIcon = async (itemBody, user) => {
    const body = itemBody;
    // eslint-disable-next-line no-console
    body.provider = user.provider.id;
    const created = await Icon.create(body);
    return getIconById(created.id);
};

export const updateIconBySize = async (size, updateBody) => {
    const item = await getIconBySize(size);
    if (!item) {
      throw new ApiError(httpStatus.NOT_FOUND, 'Icon by size not found');
    }
    Object.assign(item, updateBody);
    await item.save();
    return getIconBySize(size);
  };