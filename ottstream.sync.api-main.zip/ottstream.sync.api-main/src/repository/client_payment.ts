import ClientPaymentMethod from "../models/client/client_payment_method.model";

export const getClientPaymentMethodByClientId = async (clientId?: any, options?: any) => {
    return ClientPaymentMethod.find({ clientId });
};