import httpStatus from "http-status";
import { ApiError } from "../utils/api_error";
import { updateSubDocument } from "../utils/update_sub_document";
import Client from "../models/client/client.model";

export const clientPopulateObject = [
    {
      path: 'provider',
    },
  ];

export const getClientById = async (id, options = {}) => {
    const client = await Client.findById(id).populate(
      clientPopulateObject.concat([{ path: 'locations' }, { path: 'finance.forPackages' }])
    );
    return client;
};

export const getClients = async (filter: object = {}) => {
  return await Client.find(filter).populate(
    clientPopulateObject.concat([{ path: 'locations' }, { path: 'finance.forPackages' }])
  );
}

export const removeMain = async (clientId) => {
    if (clientId) {
      await Client.updateMany(
        {
          clientId,
        },
        { $set: { 'emails.$.isMain': false } },
        { multi: true }
      );
    }
  };

export const selectOneMain = async (clientId) => {
    if (clientId) {
      await Client.updateOne(
        {
          clientId,
        },
        { $set: { isMain: true } },
        { multi: false }
      );
    }
  };

export const updateClientEmailById = async (clientId, updateBody) => {
    const item: any = await getClientById(clientId);
    if (!item) {
      throw new ApiError(httpStatus.NOT_FOUND, 'ClientEmail not found');
    }
    if (item && item.emails && item.emails.length) {
      const list = item.emails[item.emails.length - 1];
      const mainUpdated = list.isMain !== updateBody.isMain;
      if (mainUpdated) {
        if (updateBody.isMain) {
          await removeMain(item._id);
        } else {
          await selectOneMain(item._id);
        }
      }
    }
    Object.assign(item, updateBody);
    await item.save();
    return item;
  };

export const updateClientById = async (clientId, updateBody) => {
    try {
      const item: any = await getClientById(clientId);
      if (!item) {
        throw new ApiError(httpStatus.NOT_FOUND, 'Client not found');
      }
      if (updateBody?.personalInfo?.provider && updateBody?.personalInfo?.provider !== item?.provider._id?.toString()) {
        // TODO important check if provider exists
        item.provider = updateBody.personalInfo.provider;
      }
      if (updateBody.phones) {
        item.phones = updateSubDocument(item, 'phones', updateBody, 'phones');
        // eslint-disable-next-line no-param-reassign
        delete updateBody.phones;
      }
      if (updateBody.emails) {
        // eslint-disable-next-line no-restricted-syntax,guard-for-in
        for (const i in updateBody.emails) {
          const val = updateBody.emails[i];
          // eslint-disable-next-line no-await-in-loop
          try {
            // eslint-disable-next-line no-await-in-loop
            await updateClientEmailById(item._id, val);
          } catch (e) {
            // eslint-disable-next-line no-console
            console.error(e);
          }
        }
      }
      if (updateBody.notifications) {
        item.notifications = updateSubDocument(item, 'notifications', updateBody, 'notifications');
        // eslint-disable-next-line no-param-reassign
        delete updateBody.notifications;
      }
      if (updateBody.addresses) {
        item.addresses = updateSubDocument(item, 'addresses', updateBody, 'addresses');
        // eslint-disable-next-line no-param-reassign
        delete updateBody.addresses;
      }
      // paperlessBilling check, if client have one for Contacts/Invoices email
      // if (item.emails) {
      //   // esli`h
      //   for (let i = 0; i < item.emails.length; i++) {
      //     if (item.emails[i].forContactInvoice) {
      //       item.finance.paperlessBilling = true;
      //       // eslint-disable-next-line no-await-in-loop
      //       await item.save();
      //     }
      //   }
      // }
      // return item;
      Object.assign(item, updateBody);
      await item.save();
      return getClientById(clientId);
    } catch (e) {
      throw new ApiError(httpStatus.BAD_REQUEST, e);
    }
  };

  export const updateAll = async (filter = {}, fields = {}) => {
    await Client.updateMany(filter, fields);
  };