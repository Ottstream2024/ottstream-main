import DeviceOption from "../models/device/device_options.model";

/**
 * Get DeviceOption by id
 * @param {ObjectId} providerId
 * @returns {Promise<DeviceOption>}
 */
export const getDeviceOptions = async (providerId?: any) => {
  const list = await DeviceOption.find({ provider: providerId });
  return list.length ? list[0] : null;
};

/**
 * Update deviceOption by id
 * @param {ObjectId} providerId
 * @param {Object} updateBody
 * @returns {Promise<DeviceOption>}
 */
export const updateDeviceOptions = async (providerId, updateBody) => {
  let deviceOption: any = await getDeviceOptions(providerId);
  if (!deviceOption) {
    deviceOption = await DeviceOption.create(updateBody);
  }
  deviceOption.updatedAt = new Date();
  Object.assign(deviceOption, updateBody);
  await deviceOption.save();
  return deviceOption;
};
