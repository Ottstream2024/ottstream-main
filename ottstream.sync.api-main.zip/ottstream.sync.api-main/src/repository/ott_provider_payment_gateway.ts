import OttProviderPaymentGateway from "../models/ottprovider/ottprovider_payment_gateway.model";

export const getOttProviderPaymentGatewayByProviderId = async (ottProviderId) => {
    return OttProviderPaymentGateway.find({ providerId: ottProviderId });
};