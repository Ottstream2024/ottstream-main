import Equipment from '../models/equipment/equipment.model'
export const getEquipmentById = async (id, options = {}) => {
    const item: any = await Equipment.findById(id).populate([{ path: 'type' }]);
    
    if (item) {
      item.typeName = item.type?.name?.length ? item.type.name[0].name : '';
    }
    return item;
  };