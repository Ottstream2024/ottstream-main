import OttProvider from "../models/ottprovider/ottprovider.model";
import { Logger } from "../utils/logger";

export const getOttProviders = async (filter = {}, populate = [], projection = null) => {
    const query = OttProvider.find(filter).populate(populate);
    if (projection) query.projection(projection);
    return query;
};

export const ottProviderPopulateObject = [
  {
    path: 'parent',
  },
  {
    path: 'priceGroup',
  },
  {
    path: 'user',
  },
];

export const getBaseOttProvider = async (id?: any, options?:any) => {
  return OttProvider.findOne({ type: 0 }, {}).populate(ottProviderPopulateObject);
};

export const orderParents = async (providerId, list) => {
  const foundList = list.filter((r) => r._id.toString() === providerId.toString());
  if (!foundList.length) {
    Logger.error(`provider not found list in orderParents()`);
    return [];
  }
  const parent = foundList[0].parent ? foundList[0].parent.toString() : null;
  let results = [];
  const filteredList = list.filter((r) => r._id.toString() === parent);
  // eslint-disable-next-line no-unused-vars,no-restricted-syntax
  for (const provider of filteredList) {
    results.push(provider);
    // eslint-disable-next-line no-await-in-loop
    results = results.concat(await orderParents(provider._id.toString(), list));
  }
  return results;
};

export const getOttParents = async (providerId) => {
  const list = await OttProvider.find({ status: 1 }, '_id parent number name priceGroup');
  return orderParents(providerId, list);
};

export const getParentProviders = async (id) => {
  return OttProvider.find({ parent: id });
}

export const getProvidersList = async (filter) => {
  return OttProvider.find(filter);
}

export const updateOttProvidersByNumber = async (number, body) => {
  await OttProvider.updateMany({ number }, body);
};

export const getOttProviderById = async (id, populateObject = null, projection = null) => {
  const findResult = OttProvider.findById(id, {}).populate(populateObject || ottProviderPopulateObject);
  if (projection) findResult.projection(projection);
  return findResult;
};

export const getById = async (id) => {
  return OttProvider.findById(id);
}

export const addInvoice = async (provider?: any, invoice?: any) => {
  return invoice
}