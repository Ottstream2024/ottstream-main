import OttProviderAddress from "../models/ottprovider/ottprovider_address.model";

export const getOttProviderAddressesByProviderId = async (ottProviderId?: any, options?:any) => {
    return OttProviderAddress.find({ providerId: ottProviderId });
  };