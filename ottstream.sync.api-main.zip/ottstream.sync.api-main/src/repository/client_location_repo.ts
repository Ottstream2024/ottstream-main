import httpStatus from 'http-status';
import { ApiError } from '../utils/api_error';
import { updateSubDocument } from '../utils/update_sub_document';
import Client from '../models/client/client.model';
import ClientLocation from '../models/client/client_location.model';

export const extractLocationData = async (locationObject, packageSubscriptions = []) => {
    return {
      login: locationObject.login,
      subscriptionExpireDate: locationObject.subscriptionExpireDate,
      server: locationObject.server,
      subscriptionState: locationObject.subscriptionState,
      updatedAt: locationObject.updatedAt,
      packageSubscriptions,
    };
  };
  

export const getClientLocation = async (filter = {}, populate = [], projection = null) => {
    const query: any = await ClientLocation.findOne(filter).populate(populate);
    if (projection && query.projection) query.projection(projection);
    return query;
};

export const getClientLocationById = async (id, populateObject = null, projection = null) => {
    const defaultPopulateObject = [
      {
        path: 'clientId',
        populate: [
          {
            path: 'finance.priceGroup',
            select: 'id name',
          },
        ],
        select: 'personalInfo provider id finance',
      },
      // {
      //   path: 'commentUser',
      //   select: 'id firstname lastname',
      // },
    ];
    const findResult = ClientLocation.findById(id, {}).populate(populateObject || defaultPopulateObject);
    if (projection) findResult.projection(projection);
    return findResult;
  };

export const updateClientLocationInfo = async (locationObject, remove = false, packageSubscriptoins = []) => {
    if (locationObject.clientId) {
      const clientId = locationObject.clientId._id
        ? locationObject.clientId._id.toString()
        : locationObject.clientId.toString();
      const client = await Client.findOne({ _id: clientId });
      const key = 'info';
      const subKey = 'locations';
      if (client) {
        let infoObject: any = {};
        if (client[key]) {
          infoObject = client[key];
        }
        if (!infoObject[subKey]) {
          infoObject[subKey] = [];
        }
        // infoObject[subKey] = infoObject[subKey].toJSON();
        const found = client[key][subKey].filter((r) => r.login === locationObject.login);
        if (!remove) {
          if (found.length) {
            // eslint-disable-next-line no-restricted-syntax
            for (const i in infoObject[subKey]) {
              if (infoObject[subKey][i].login === locationObject.login) {
                // eslint-disable-next-line no-await-in-loop
                infoObject[subKey][i] = await extractLocationData(locationObject, packageSubscriptoins);
              }
            }
          } else infoObject[subKey].push(await extractLocationData(locationObject, packageSubscriptoins));
        } else {
          infoObject[subKey] = infoObject[subKey].filter((r) => r.login !== locationObject.login);
        }
        infoObject.activePackages = 0;
        const names = [];
        // eslint-disable-next-line no-restricted-syntax
        for (const location of infoObject[subKey]) {
          if (location.subscriptionState === 3) {
            // eslint-disable-next-line no-restricted-syntax
            for (const packageSubscription of location.packageSubscriptions) {
              const { name } = packageSubscription.name[0];
              // eslint-disable-next-line no-unused-expressions
              !names.includes(name) ? names.push(name) : null;
            }
          }
        }
        infoObject.activePackages = names.length;
        await Client.updateOne({ _id: clientId }, { info: infoObject });
      }
    }
  };

export const updateClientLocationById = async (clientLocationId, updateBody) => {
    const clientLocation: any = await getClientLocationById(clientLocationId);
    if (!clientLocation) {
      throw new ApiError(httpStatus.NOT_FOUND, 'ClientLocation not found');
    }
    if (updateBody.locations) {
      clientLocation.locations = updateSubDocument(clientLocation, 'locations', updateBody, 'locations');
      // eslint-disable-next-line no-param-reassign
      delete updateBody.locations;
    }
    // email for reset, this is your updated Email
    Object.assign(clientLocation, updateBody);
    await clientLocation.save();
    await updateClientLocationInfo(clientLocation);
    return clientLocation;
  };

  export const update = async (filter, data) => {
    return ClientLocation.updateMany(filter, data)
  }

  export const getClientLocations = async (filter = {}, populate = [], projection = null) => {
    const query: any = await ClientLocation.find(filter).populate(populate);
    if (projection && query.projection) query.projection(projection);
    return query;
  };
  

  export const updateLocationById = async (_id, body) => {
    await ClientLocation.updateMany({ _id }, body);
    const current = await getClientLocationById(_id);
    await updateClientLocationInfo(current);
    return current;
  };

export const getClientLocationsList = async (filter, populate = []) => {
  return await ClientLocation.find(filter).populate(populate)
}
