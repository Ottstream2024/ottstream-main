import * as clientLocationRepository from './client_location_repo'
import * as deviceOptionRepository from './device_options'
import * as ottProviderRepository from './ott_provider'
import * as serverRepository from './server'
import * as subscriptionRepository from './subscription'
import * as clientUsedDeviceRepository from './used_devices'
import * as geoipRepository from './geo_ip'
import * as clientSharedRepository from './client_shared'
import * as clientRepository from './client'
import * as clientPaymentMethodRepository from './client_payment'
import * as ottProviderPaymentGatewayRepository from './ott_provider_payment_gateway'
import * as packageRepository from './package'
import * as equipmentRepository from './equipment'
import * as transactionRepository from './transaction'
import * as discountRepository from './discount'
import * as priceGroupRepository from './price_group'
import * as ottProviderAddressRepository from './ott_provider_address'
import * as ottProviderPhoneRepository from './ott_provider_phone'
import * as ottProviderEmailRepository from './ott_provider_email'
import * as packageChannelRepository from './package_channer'
import * as channelRepository from './channel'
import * as groupRepository from './group'
import * as iconRepository from './icon'
import * as invoiceRepository from './invoice'

export {
    clientLocationRepository,
    deviceOptionRepository,
    ottProviderRepository,
    serverRepository,
    subscriptionRepository,
    clientUsedDeviceRepository,
    geoipRepository,
    clientSharedRepository,
    clientRepository,
    clientPaymentMethodRepository,
    ottProviderPaymentGatewayRepository,
    packageRepository,
    equipmentRepository,
    transactionRepository,
    discountRepository,
    priceGroupRepository,
    ottProviderAddressRepository,
    ottProviderPhoneRepository,
    ottProviderEmailRepository,
    packageChannelRepository,
    channelRepository,
    groupRepository,
    iconRepository,
    invoiceRepository
}