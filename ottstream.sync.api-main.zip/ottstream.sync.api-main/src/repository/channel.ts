import httpStatus from "http-status";
import { ApiError } from "../utils/api_error";
import Channel from "../models/channel/channel.model";

export const channelPopulateObject = [
    {
      path: 'provider',
    },
];

export const getChannelByMiddlewareId = async (id, options = {}) => {
    const channels = await Channel.find({
      middlewareId: id,
    }).populate(channelPopulateObject);
    if (channels.length) return channels[0];
    return null;
};
  
export const getChannelById = async (id, options = {}) => {
    return Channel.findById(id).populate(channelPopulateObject);
};

export const createChannel = async (itemBody, user) => {
    const body = itemBody;
    body.provider = user.provider.id;
    const created = await Channel.create(body);
    return getChannelById(created.id);
};

export const updateChannelById = async (channelId, updateBody) => {
    const item = await getChannelById(channelId);
    if (!item) {
      throw new ApiError(httpStatus.NOT_FOUND, 'Channel not found');
    }
    Object.assign(item, updateBody);
    await item.save();
    return getChannelById(channelId);
  };