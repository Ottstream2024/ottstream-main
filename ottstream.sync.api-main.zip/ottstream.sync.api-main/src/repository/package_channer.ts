import PackageChannel from '../models/package/package_channel.model'

export const getPackageChannelsByPackageMiddlewareId = async (id, options = {}) => {
    return PackageChannel.find({
      packageMiddlewareId: id,
    }).populate([
      {
        path: 'package',
      },
      {
        path: 'channel',
      },
    ]);
};

export const RemovePackageChannel = async (id) => {
    const item: any = await PackageChannel.findById(id);
    if (item) {
      await item.remove();
    }
    return item;
};

export const getPackageChannelByIds = async (_package, channel) => {
    const packages = await PackageChannel.find({
      package: _package,
      channel,
    }).populate([
      {
        path: 'package',
      },
      {
        path: 'channel',
      },
    ]);
    if (packages && packages.length) return packages[0];
    return null;
  };

export const AddChannelToPackage = async (_package, _channel, packageMiddlewareId, channelMiddlewareId) => {
    const prev = await getPackageChannelByIds(_package, _channel);
    if (prev) return;
  
    const body: any = {};
    // eslint-disable-next-line no-console
    body.package = _package;
    body.channel = _channel;
    body.packageMiddlewareId = packageMiddlewareId;
    body.channelMiddlewareId = channelMiddlewareId;
    return PackageChannel.create(body);
  };