import httpStatus from "http-status";
import { ApiError } from "../utils/api_error";
import Subscription from "../models/subscription/subsciption.model";

export const getSubscriptions = async (filter = {}, populate = [], projection = null) => {
    const query = Subscription.find(filter).populate(populate);
    if (projection) query.projection(projection);
    return query;
  };

export const getSubscriptionById = async (id, options = {}) => {
  return Subscription.findById(id);
};

export const updateSubscriptionById = async (subscriptionId?: any, updateBody?: any) => {
  const channel = await getSubscriptionById(subscriptionId);
  if (!channel) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Subscription not found');
  }
  Object.assign(channel, updateBody);
  await channel.save();
  return channel;
};

export const getList = async (filter = {}, populate = [], projection = null) => {
  const query = Subscription.find(filter).populate(populate);
  if (projection) query.projection(projection);
  return query;
};

export const queryLocationSubscriptions = async (locationId) => {
  return Subscription.find({ location: locationId, state: 1 }).populate([
    {
      path: 'invoice',
      select: 'id name createAt payloadCalculated totalAmount amount',
    },
    {
      path: 'client',
      select: 'id personalInfo',
      populate: [
        {
          path: 'finance.priceGroup',
          select: 'id name',
        },
      ],
    },
  ]);
};

export const getLocationSubscriptions = async (locationId) => {
  const subscription = await Subscription.find({
    location: locationId,
    state: 1,
  }).populate([
    {
      path: 'package',
    },
    {
      path: 'client',
    },
    {
      path: 'location',
    },
  ]);
  return subscription;
};

export const updateAll = async (filter, update) => {
  return await Subscription.updateMany(filter, update);
}
