import httpStatus from "http-status";
import { ApiError } from "../utils/api_error";
import Group from "../models/group/group.model";

export const groupPopulateObject = [
    {
      path: 'provider',
    },
];

export const getGroupByMiddlewareId = async (id, options = {}) => {
    const groups = await Group.find({
      middlewareId: id,
    }).populate(groupPopulateObject);
    if (groups.length) return groups[0];
    return null;
};

export const getGroupById = async (id, options = {}) => {
    return Group.findById(id).populate(groupPopulateObject);
};

export const createGroup = async (itemBody, user) => {
    const body = itemBody;
    // eslint-disable-next-line no-console
    body.provider = user.provider.id;
    const created = await Group.create(body);
    return getGroupById(created.id);
};

export const updateGroupById = async (groupId, updateBody) => {
    const item = await getGroupById(groupId);
    if (!item) {
      throw new ApiError(httpStatus.NOT_FOUND, 'Group not found');
    }
    Object.assign(item, updateBody);
    await item.save();
    return getGroupById(groupId);
};