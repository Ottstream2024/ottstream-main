import ClientUsedDevice from "../models/client/client_used_device.model";

export const getClientUsedDevices = async (filter = {}, populate = [], projection = null) => {
    const query = ClientUsedDevice.find(filter).populate(populate);
    if (projection) query.projection(projection);
    return query;
};

export const createClientUsedDevice = async (clientUsedDeviceBody?: any, user?: any) => {
  const body = clientUsedDeviceBody;
  if (user) body.user = user._id;
  return ClientUsedDevice.create(body);
};

export const getClientUsedDeviceById = async (id, options = {}) => {
  return ClientUsedDevice.findById(id);
};

export const updateClientUsedDeviceById = async (clientUsedDeviceId, updateBody) => {
  await ClientUsedDevice.updateOne({ _id: clientUsedDeviceId }, updateBody);
  const clientUsedDevice: any = await getClientUsedDeviceById(clientUsedDeviceId);
  clientUsedDevice.lastActiveTime = updateBody.lastActiveTime;
  await clientUsedDevice.save();
  return clientUsedDevice;
};