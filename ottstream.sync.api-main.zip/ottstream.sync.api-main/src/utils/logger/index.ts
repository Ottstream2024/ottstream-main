import winston from 'winston'

const winstonLogger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.colorize(),
    winston.format.splat(),
    winston.format.printf(({ level, message }) => `${level}: ${message}`)
  ),
  transports: [
    new winston.transports.Console({
      stderrLevels: ['error'],
    }),
  ],
});

export const Logger = {
  info(e, send = true) {
    winstonLogger.info(`${new Date()}\n--${e}`);
  },
  error(e, send = true) {
    winstonLogger.error(`${new Date()}\n--${e}`);
  },
  warn(e, send = true) {
    // eslint-disable-next-line no-console
    winstonLogger.warn(`${new Date()}\n--${e}`);
  },
};


