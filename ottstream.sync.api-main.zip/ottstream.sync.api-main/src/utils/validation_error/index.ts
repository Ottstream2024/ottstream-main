import { Response } from "express";

export class ValidationError {
    
    public message: string;
    
    constructor(message: string, res: Response) {
        this.message = message;
        this.send(res)
    }

    private send(response: Response) {
        response.status(400).send({ message: this.message, success: false })
    } 
}