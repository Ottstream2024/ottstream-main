import 'reflect-metadata'

export function injectable(target?: any) {
    return function(target: any) {
        Reflect.defineMetadata("design:type", target.name, target);
    }
}