import 'reflect-metadata'

export function inject() {
    return function(target?: any, propertyKey?: string) {
        const metadata = Reflect.getMetadata('design:type', target, propertyKey);
        const instance = new metadata()
        bindMethods(instance);
        target[propertyKey] = instance;
    };
}

function bindMethods(instance: any) {
    const properties = Object.getOwnPropertyNames(Object.getPrototypeOf(instance));

    properties.forEach(property => {
        if (property !== 'constructor') {
            const value = instance[property];
            if (value instanceof Function) {
                instance[property] = value.bind(instance);
            }
        }
    });
}