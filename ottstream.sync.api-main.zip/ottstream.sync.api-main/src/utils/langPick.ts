/**
 * Choose translation language for user
 * @param {Object} options
 * @param {Object} user
 * @returns {String}
 */
export const langPick = (options, user) => {
    if (options.lang) return options.lang;
  
    if (user.lang) return user.lang;
  
    return 'en';
};