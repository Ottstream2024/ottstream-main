class ResponseModel<T> {
    public success: boolean;
    public message: string;
    public data: T;
    constructor(success: boolean, message: string, data: T) {
        this.success = success;
        this.message = message;
        this.data = data;
    }
}

export const getResponse = <T>(message: string, data: T, success: boolean = true) => {
    return new ResponseModel<T>(success, message, data);
}

export const getErrorResponse = <T>(message: string, data?: T) => {
    return new ResponseModel<T>(false, message, data);
}