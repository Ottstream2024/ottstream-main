import { Response } from "express";
import { getErrorResponse } from "../../utils/response";
import { Logger } from "../logger";

export class ApiError extends Error {
  public statusCode: any
  public isOperational: any
  constructor(statusCode, message, isOperational = true, stack = '') {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = isOperational;
    if (stack) {
      this.stack = stack;
    } else {
      Error.captureStackTrace(this, this.constructor);
    }
  } 
  }