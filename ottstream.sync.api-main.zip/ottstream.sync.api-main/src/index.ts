// import dotenv from 'dotenv'
// dotenv.config()
import "./database"
import server from './server'
import http from 'http'
import { config } from './config'
import { Logger } from './utils/logger'

import { useWorkers } from './workers'
import path from 'path'
import mongoose from 'mongoose'

mongoose.connect(config.mongoose.url, {
    minPoolSize: 90,
}).then(() => {
    Logger.info('Mongod connected...!')
}).catch(err =>Logger.error(err))


http.createServer(server).listen(config.PORT, () => {
    Logger.info(`Server running on port ${config.PORT}`)
    useWorkers()
})
