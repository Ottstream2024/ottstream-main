import { WorkerService } from "./modules/worker"

export function useWorkers() {
    const handler = new WorkerService()
    handler.register({ time: '0 */8 * * *', cb: () => handler.generateInvoice(20) })
    handler.register({ time: '0 */14 * * *', cb: () => handler.generateInvoice(15) })
    handler.register({ time: '0 */13 * * *', cb: () => handler.generateInvoice(14) })
    handler.register({ time: '0 */12 * * *', cb: () => handler.generateInvoice(13) })
    handler.register({ time: '0 */11 * * *', cb: () => handler.generateInvoice(12) })
    handler.register({ time: '0 */10 * * *', cb: () => handler.generateInvoice(11) })
    handler.register({ time: '*/5 * * * *', cb: handler.expireLocations })
    handler.register({ time: '*/11 * * * *', cb: handler.syncProviders })
    handler.schedule()
}
