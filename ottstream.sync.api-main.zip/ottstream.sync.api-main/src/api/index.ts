import { Router } from 'express'
import SyncController from './sync'
import UserController from './user'

class Routes {
    
    public router = Router()
    constructor() {
        this.config()
    }

    private config() {
        this.router.use(SyncController.prefx, SyncController.router);
        this.router.use(UserController.prefx, UserController.router);
    }
}

export default new Routes().router