import { injectable } from "../../utils/dependency/injectable";
import { ottProviderRepository } from "../../repository";
import { clientLocationRepository } from "../../repository";
import moment from "moment-timezone";
import mongoose, { isValidObjectId } from "mongoose";

@injectable()
export class UserService {
  public async getProviders(providerId: string) {
    if (!providerId || !isValidObjectId(providerId)) return null;

    const provider = await ottProviderRepository.getById(providerId);
    if (!provider) return null;

    const childProviders = await ottProviderRepository.getProvidersList({
      parent: providerId,
      status: {
        $ne: 0
      }
    });
    const data = childProviders.map((item) => {
      return {
        _id: item._id,
        name: item.name[0].name,
      }
    })
    data.push({
      _id: provider._id,
      name: provider.name[0].name
    })
    return data;
  }

  public async uploadProviderStatistic(body) {
    const { provider, startDate, endDate, state } = body;

    if (!provider || !startDate || !endDate || !state) return null;

    const providerData = await ottProviderRepository.getById(provider);

    const providerTimeZone = providerData.timezone || providerData._doc.timezone || 'America/Los_Angeles';

    console.log(providerData);
    

    let from = moment(startDate).startOf('day').toDate();
    let to = moment(endDate).endOf('day').toDate();

    const locations = await clientLocationRepository.getClientLocationsList({
      provider: new mongoose.Types.ObjectId(provider),
      subscriptionState: state || 3,
      subscriptionExpireDate: {
        $gte: from,
        $lte: to
      }
    }, [{ path: 'clientId' }, { path: 'provider' }])

    const sampleData = {
      fullName: "John Doe",
      status: "Active",
      provider: "Provider A",
      login: "johndoe",
      expireAt: "2023-09-30",
      phoneNumber: "1234567890",
      paperless: "Off"
    };

    const data = [];

    locations.map((item) => {
      data.push({
        fullName: `${item?.clientId?.personalInfo?.firstname} ${item?.clientId?.personalInfo?.lastname}`,
        status: this.getState(item.subscriptionState),
        provider: item.provider?.name[0]?.name,
        login: item.login,
        expireAt: moment.utc(item.subscriptionExpireDate).tz(providerTimeZone).format('YYYY-MM-DD HH:mm:ss'),
        phoneNumber: item?.clientId?.phones[0]?.phone,
        paperless: item?.clientId?.finance?.paperlessBilling ? 'On' : 'Off'
      })});

    return data;

  }

  public getState(stateKey) {
    let state = 'Inactive';
    if (stateKey === 0)
      state = 'Inactive'
    if (stateKey === 1)
      state = 'Pending'
    if (stateKey === 2)
      state = 'Cancel'
    if (stateKey === 3)
      state = 'Active'
    return state;
  }
}