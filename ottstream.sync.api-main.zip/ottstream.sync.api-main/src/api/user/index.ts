import { Response, Router } from 'express'
import { controller } from '../../decorators/controller'
import { Controller } from '../../base/controller'
import { UserService } from './service'
import { inject } from '../../utils/dependency/inject'
import { IRequest } from '../../interface/request'
import { ApiError } from '../../utils/api_error'
import { getErrorResponse } from '../../utils/response'
import { downloadInExel } from '../../services/file_generator'

@controller('user')
class SyncController extends Controller {
    @inject()
    public service: UserService

    public router = Router()
    
    constructor() {
        super()
        this.routes()
    }

    private routes() {
        this.router.get('/providers', this.getProviders)
        this.router.get('/export-report', this.exportReport)
    }

    public async getProviders(req: IRequest, res: Response) {
        try {
            const service = new UserService();
            const result = await service.getProviders(req.query.provider as string);
            return res.send(result)
        } catch (error) {
            res.status(403).send(getErrorResponse(error.message))
            throw new ApiError(res, error)
        }
    }

    public async exportReport(req: IRequest, res: Response) {
      try {
          const service = new UserService();
          const result = await service.uploadProviderStatistic(req.query);
          req.meta = result;
          return downloadInExel(req, res);
      } catch (error) {
          res.status(403).send(getErrorResponse(error.message))
          throw new ApiError(res, error)
      }
  }
}

export default new SyncController()