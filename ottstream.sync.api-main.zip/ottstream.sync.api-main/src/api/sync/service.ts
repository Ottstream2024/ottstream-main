import moment from "moment";
import { clientLocationRepository, clientRepository, deviceOptionRepository, invoiceRepository, ottProviderPaymentGatewayRepository, ottProviderRepository, serverRepository, subscriptionRepository }  from "../../repository";
import LocationSyncCrudService from "../../services/location_sync_crud_service";
import LocationSyncService from "../../services/location_sync_service";
import OttSyncService from "../../services/ott_provider_sync_service";
import OttSyncCrudService from "../../services/ott_sync_crud_service";
import PackageSyncService from "../../services/package_sync_service";
import SubscriptionService from "../../services/subscription_service";
import { ApiError } from "../../utils/api_error";
import { injectable } from "../../utils/dependency/injectable";
import { Logger } from "../../utils/logger";
import { getErrorResponse, getResponse } from "../../utils/response";
import { SyncApplyReqModel } from "./models/req_model";

@injectable()
export class SyncService {

    private async getActiveSubscriptions(location: any) {
        const subscriptions = await subscriptionRepository.getSubscriptions({
            state: 1, location
        }, [{ path: 'package' }])
        return subscriptions
    } 

    public async syncApply(data: SyncApplyReqModel) {
        Logger.info(`Location ${data.login} sync started`)
        const location = await clientLocationRepository.getClientLocation(
            { login: data.login }, [{ path: 'provider' }, { path: 'clientId' }], {
                _id: 1,
                syncState: 1,
                login: 1,
                name: 1,
                clientId: 1,
                provider: 1,
                migrated: 1,
                settingsUpdateUts: 1,
                isBlockLocation: 1,
                password: 1,
                parentalCode: 1,
                updatedAt: 1,
                isPauseSubscriptions: 1,
                server: 1,
                VODEnable: 1,
                archiveEnable: 1,
                roomsCount: 1,
                lastUpdate: 1,
                maxDevice: 1,
        })
        
        //! what if location doesnt exits
        if (!location) {
            return getResponse('Location not found', null, false)
        } // make functionality

        const subscriptions = await this.getActiveSubscriptions(location.id)
        const servers = await serverRepository.getList({ status: 1 })

        if (data.autostart_status === -1) {
            Logger.info(`Location first time activation ${data.login}`)
            await Promise.all([
                SubscriptionService.locationFirstTimeLogin(location, data),
                LocationSyncService.markAsSync(location._id)
            ])
        }

        let updateBody: { [key: string]: any } = {
            settingsUpdateUts: data.settings_update_uts,
          };

          const serverIndex = servers.findIndex((x: any) => x.middlewareId === data.server)
          if (serverIndex > -1) {
            updateBody.server = servers[serverIndex]._id.toString()
          }
          await clientLocationRepository.update({ _id: location._id }, updateBody)
          Logger.info(`Location ${data.login} updated...`)
          await LocationSyncCrudService.resetCache();
          Logger.info(`Location ${data.login} reset cache...`)
          return getResponse('Sync applyed', null, true)
    }

    public async syncLocationCdn(data: { location: string }) {
        const location: any = await clientLocationRepository.getClientLocation(data.location)
        if (!location) {} //! what if location not found
        if (location.syncState === 2 && location.status !== 0) {
            const subscriptions = await this.getActiveSubscriptions(location._id)
            const middlewareResult = await LocationSyncService.GetLocationFieldsForMiddleware(location, subscriptions)
            
            middlewareResult.devices =[]
            const updateDataList = []

            const reuslt = { ...middlewareResult }
            delete reuslt.locationId
            updateDataList.push(reuslt)
            await LocationSyncCrudService.updateLocation(updateDataList);
            Logger.info(`location ${location.login} updated to remote!`);
            await LocationSyncCrudService.resetCache();
        }
        return getResponse('Sync cdn done', data.location, true)
    }

    public async syncNewLocationCdn(data: { location: string }) {
        const location = await clientLocationRepository.getClientLocation(data.location)
        if (!location) {} //! return 403
        const subscriptions = await this.getActiveSubscriptions(location._id)
        const middlewareResult = await LocationSyncService.GetLocationFieldsForMiddleware(location, subscriptions)

        const result = { ...middlewareResult }
        delete result.locationId
        const response: any = await LocationSyncCrudService.createLocation(result)
        if (response && response.login === result.login) {
            await clientLocationRepository.update({ login: result.login }, { syncState: 1 });
            await LocationSyncCrudService.resetCache();
          } else {
            Logger.error(`remote location create error ${location.login}`);
            throw new Error(`remote location create error ${location.login}`)
          }        
        return getResponse('Remote location created', data.location, true)
    }

    public async syncCndProviders() {
        const allProviders: any = await ottProviderRepository.getOttProviders(
            { status: 1 },
            [
            {
                path: 'parent',
            },
            ],
            { _id: 1, syncState: 1, number: 1, name: 1, parent: 1, comment: 1 }
        );
        const providersThatNeedSync = allProviders.filter((r) => r.syncState !== 1);
        const createList: any = [];
        const updateList = [];
        const deleteList = [];
        const remoteProviders = await OttSyncCrudService.getProviders();

        const toAddList = providersThatNeedSync.filter(
            (r) => !remoteProviders.filter((a) => a.id === r.number).length && r.status !== 0
        );
        const toUpdateList = providersThatNeedSync.filter(
            (r) => remoteProviders.filter((a) => a.id === r.number).length && r.status !== 0
        );
        let toDeleteList = providersThatNeedSync.filter(
            (r) => remoteProviders.filter((a) => a.id === r.number).length && r.status === 0
        );
        toDeleteList = toDeleteList.concat(
            remoteProviders.filter((r) => !allProviders.filter((a) => a.number === r.id).length)
        );
        for (const item of toAddList) {
            const fields = await OttSyncService.GetProviderFieldsForMiddleware(item._id);
            createList.push({
            providerId: item._id,
            id: item.number,
            name: item.name?.length ? item.name[0].name : `no name for Ott number ${item.number}`,
            parent_provider_id: item?.parent?.number || 0,
            contacts_provider_id: fields.contacts_provider_id,
            email: fields.email,
            comment: item.comment,
            address: fields.address,
            phone: fields.phone,
            });
            if (item._id) await OttSyncService.markAsSyncing(item._id);
        }
        for (const item of toUpdateList) {
            const fields = await OttSyncService.GetProviderFieldsForMiddleware(item._id);
            let parent_provider_id: any = item?.parent?.number || 0
            updateList.push({
            providerId: item._id,
            id: item.number,
            name: item.name?.length ? item.name[0].name : `no name for Ott number: ${item.number}`,
            parent_provider_id,
            contacts_provider_id: fields.contacts_provider_id,
            email: fields.email,
            comment: item.comment,
            address: fields.address,
            phone: fields.phone,
            });
            if (item._id) await OttSyncService.markAsSyncing(item._id);
        }
        for (const item of toDeleteList) {
            deleteList.push({ id: item.number || item.id, providerId: item._id });
            if (item._id) await OttSyncService.markAsSyncing(item._id);
        }
        Logger.info(
            `providers to sync - create: ${createList.length} update: ${updateList.length} delete: ${deleteList.length}`
        );
        for (const item of updateList) {
            const sendData = { ...item };
            delete sendData.providerId;
            const updateResponse: any = await OttSyncCrudService.updateProvider(sendData);
            if (updateResponse.filter((r) => r.id === item.id).length) {
            if (item.providerId) await OttSyncService.markAsSync(item.providerId);
            Logger.info(`ott number: ${item.id} synced updated successfully`);
            }
        }
        for (const item of createList) {
            const sendData = { ...item };
            delete sendData.providerId;
            const updateResponse: any = await OttSyncCrudService.createProvider(sendData);
            if (updateResponse.id === item.id) {
            if (item.providerId) await OttSyncService.markAsSync(item.providerId);
            Logger.info(`ott number: ${item.id} synced created successfully`);
            }
        }
        for (const item of deleteList) {
            const deleteResponse = await OttSyncCrudService.deleteProvider(item.id);
            if (deleteResponse) {
            if (item.providerId) await OttSyncService.markAsSync(item.providerId);
            Logger.info(`ott number: ${item.id} synced deleted successfully`);
            }
        }
        return getResponse('Providers synced successfuly', null, true)
    }

    public async syncCdnOptionsHosted() {
        let result = false;
        const deviceOptions: any = await deviceOptionRepository.getDeviceOptions();
        if (
        !deviceOptions ||
        !deviceOptions.updatedAt ||
        new Date().getTime() - deviceOptions.updatedAt.getTime() > 1000 * 60 * 60
        ) {
        await PackageSyncService.syncOptions();
        }
        return result;
    }

    public async updateBill(data: { login: string, startDate: Date, endDate: Date }, billNumber: number = null) {
        let startDate = new Date(data.startDate), endDate = new Date(data.endDate)
        const location = await clientLocationRepository.getClientLocation({ login: data.login })
        const client = await clientRepository.getClientById(location.clientId)
        const invoice = await invoiceRepository.getLast({ "payloadCalculated.locations.locationId": location._id.toString() })
        
        if (invoice.type === 2) {
            await subscriptionRepository.updateAll({ location: location._id, state: 1 }, { startDate, endDate })
            await clientLocationRepository.update({ _id: location._id }, { subscriptionExpireDate: endDate })
            
            let availablePackages = client.info.availablePackages, locations = client.info.locations.map(item => {
                if (item.login === data.login) {
                    item.subscriptionExpireDate = endDate
                }

                return item
            })
            
            await clientRepository.updateClientById(client._id, {
                info: { availablePackages, locations }
            })

            const invoicePayload = { ...invoice.payloadCalculated, locations: invoice.payloadCalculated.locations.map(item => {
                if (item.locationLogin === data.login) {
                    item.packages = item.packages.map(pack => {
                        pack.expireNew = endDate
                        return pack
                    })
                }

                return item
            })}    

            await invoiceRepository.updateInvoicePayload(invoice._id, invoicePayload)

            return getResponse('Bill upated', billNumber)
        } return getResponse('Warning. Data for update not found, Bill generated', billNumber)

    }

    public async generateBill(data: { login: string }) {
        if (!data.login) return getErrorResponse('Login is required')
        let billNumber = null
        let filter = {
            subscriptionState: 3,
            clientId: { $ne: null },
            login: data.login
        }
        const locations = await clientLocationRepository.getClientLocations(filter, [
            { path: 'clientId' } 
        ])
        let count = 1
    
        if (!locations.length) {
            return Logger.warn(`Locations for generationg invoices not found...!`)
        }
    
        for (let i = 0; i < locations.length; i++) {
            const location = locations[i];
    
            const locationLastInvoice = await invoiceRepository.getLast({ "payloadCalculated.locations.locationId": location._id.toString() })
    
            // if (!locationLastInvoice || locationLastInvoice.type !== 2) {
                  const subscriptions = await subscriptionRepository.getList({
                    location: location._id, state: 1
                })
                let endDate = null
                const packageInfos = subscriptions.map(item => {
                    if (!endDate) endDate = moment(item.endDate)
                    else if (moment(endDate).isBefore(item.endDate)) endDate = moment(item.endDate)
                    return item.package.toString()
                })
    
                const payload = {
                    locations: [
                      {
                        locationId: location._id.toString(),
                        packageInfos,
                        packageRemoves: [],
                        recurringPaymentInfos: [],
                        room: location.roomsCount,
                        globalAction: 1,
                        month: 1,
                      },
                    ],
                    equipments: [],
                    client: location.clientId._id.toString(),
                  };
    
                  const payload6Month = { ...payload };
                  const payload12Month = { ...payload };
                  const { client } = payload;
                  const clientInfo = await clientRepository.getClientById(client);
                  try {
                    if (!clientInfo.finance || (clientInfo.finance && !clientInfo.finance.paperlessBilling)) {
                        count++
                        const { provider } = clientInfo;
                        const paymentGateways = await ottProviderPaymentGatewayRepository.getOttProviderPaymentGatewayByProviderId(
                            provider._id.toString()
                          );
                        let bankFeePercent = 0;
                        let bankFeeFixed = 0;
                        if (paymentGateways.length && paymentGateways[0].cardsFee && paymentGateways[0].cardsFee.percent) {
                            bankFeePercent = paymentGateways[0].cardsFee.percent;
                        }
                        if (paymentGateways.length && paymentGateways[0].cardsFee && paymentGateways[0].cardsFee.fixed) {
                            bankFeeFixed = paymentGateways[0].cardsFee.fixed;
                        }
                        const calculatedPayload = await SubscriptionService.calculateSubscription(false, payload, provider);
                        let { price, totalPrice} = calculatedPayload;
                        let bankFee = 0;
                        if (bankFeePercent) {
                            bankFee = (price * bankFeePercent) / 100;
                            bankFee += bankFeeFixed;
                          }
                    
                        totalPrice = price + bankFee;
                        calculatedPayload.totalPrice = totalPrice;
                        calculatedPayload.bankFee = bankFee;
                        payload6Month.locations.forEach((item) => {
                            item.month = 6;
                        });
                        const calculated6Month = await SubscriptionService.calculateSubscription(false, payload6Month, provider);
                        price = calculated6Month.price;
                        totalPrice = calculated6Month.totalPrice;
                        bankFee = 0;
                        if (bankFeePercent) {
                            bankFee = (price * bankFeePercent) / 100;
                            bankFee += bankFeeFixed;
                        }
            
                        totalPrice = price + bankFee;
                        calculated6Month.totalPrice = totalPrice;
                        calculated6Month.bankFee = bankFee;
                        const calculated6MonthTotal = calculated6Month.totalPrice;
                        payload12Month.locations.forEach((item) => {
                            item.month = 12;
                        });
                        const calculated12Month = await SubscriptionService.calculateSubscription(false, payload12Month, provider);
                        price = calculated12Month.price;
                        totalPrice = calculated12Month.totalPrice;
                        bankFee = 0;
                        if (bankFeePercent) {
                        bankFee = (price * bankFeePercent) / 100;
                        bankFee += bankFeeFixed;
                        }
                        totalPrice = price + bankFee;
                        calculated12Month.totalPrice = totalPrice;
                        calculated12Month.bankFee = bankFee;
                        const calculated12MonthTotal = calculated12Month.totalPrice;
                        const generateDisplayInfo = {
                            client,
                            clientAddress:
                              clientInfo.addresses && clientInfo.addresses.filter((r) => r.forContactInvoice).length
                                ? clientInfo.addresses.filter((r) => r.forContactInvoice)[0]
                                : null,
                            locationsInfo: {
                              totalTax: calculatedPayload.totalTax,
                              bankFee: calculatedPayload.bankFee,
                              locationTax: calculatedPayload.locationTax,
                              locations: calculatedPayload.locations,
                            },
                            equipmentInfo: {
                              totalTax: calculatedPayload.totalTax,
                              bankFee: calculatedPayload.bankFee,
                              equipmentTax: calculatedPayload.equipmentTax,
                              equipments: calculatedPayload.equipments,
                              equipment: calculatedPayload.equipment,
                            },
                            refund: calculatedPayload.refund,
                            lastPaymentType: calculatedPayload.refund,
                            availablePaymentTypes: calculatedPayload.availablePaymentTypes,
                            calculated6Month,
                            calculated12Month,
                            calculated6MonthTotal,
                            calculated12MonthTotal,
                            subscriptionEndDate: endDate.toDate(),
                          };
            
                          const invoiceBill = await invoiceRepository.createSubscriptionInvoice(
                            2,
                            false,
                            calculatedPayload.totalPrice,
                            payload,
                            calculatedPayload,
                            generateDisplayInfo,
                            provider._id.toString(),
                            client,
                            location._id.toString(),
                            {
                              provider,
                            }
                          );
                          billNumber = invoiceBill.number
                          for (const subscription of subscriptions) {
                            await subscriptionRepository.updateSubscriptionById(subscription._id.toString(), {
                              leftInvoiceGenerated: true,
                            });
                          }
            
                          Logger.info(`Generated invoice for location ${location.login} total(${count} from ${locations.length-i})`)
                      }
                  } catch (error) {
                        Logger.error(`Generating invoice error...!`)
                  }
            // } else {
            //   Logger.info(`Bill for ${location.login} already created`)
            // }
        }

        return getResponse('Bill generated', billNumber)    
    }

    public async updateByInvoiceDuration(data: { login: string }) {
        try {
            let filter = {
                subscriptionState: 3,
                clientId: { $ne: null },
                login: data.login
            }
            const locations = await clientLocationRepository.getClientLocations(filter, [
                { path: 'clientId' } 
            ])

            if (!locations.length) {
                return Logger.warn(`Locations for generationg invoices not found...!`)
            }
        
            for (let i = 0; i < locations.length; i++) {
                const location = locations[i];
                
                const locationLastInvoice = await invoiceRepository.getLast({
                    "payloadCalculated.locations.locationId": location._id.toString(),
                    "payloadCalculated.locations.packages": { $ne: [] },
                    "payed": { $ne: 0 }
                })

                let expireNew = null;

                const updatedPayload = locationLastInvoice.payloadCalculated;
                updatedPayload.locations.map(location => {
                    location.packages = location.packages.map(locPackage => {
                        expireNew = moment(locPackage.startDate).add(location.month, 'months');
                        locPackage.expireNew = expireNew;
                        return locPackage;
                    })                    
                    return location
                })

                await invoiceRepository.updateInvoicePayload(locationLastInvoice._id, updatedPayload);

                const subscriptions = await subscriptionRepository.getList({
                    location: location._id,
                    state: 1
                })

                const subscriptionIds = subscriptions.map(item => item._id);
                await subscriptionRepository.updateAll({ _id: { $in: subscriptionIds } }, { endDate: expireNew })

                const client = await clientRepository.getClientById(location.clientId._id)

                const clientInfo = client.info;

                clientInfo.locations = client.info.locations.map(x => {
                    x.subscriptionExpireDate = expireNew
                    return x
                });

                await clientRepository.updateClientById(client._id, clientInfo);
                

            }

            return getResponse('Process successed!', true);
        } catch (error) {
            Logger.error(`Fixing operation failed by error...!: \n ${error}`)
            return error;
        }
    }

}