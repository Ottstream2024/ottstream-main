export interface ISyncApplyDeviceMode {
    device_serial: string;
    timeshift: number;
    lang: string;
    http_caching: number;
    ip: string;
    user_agent: string;
    room_n: number;
    device: string;
    serial: string;
    mac_address: string;
    model_code: string;
    manufacturer: string;
    android_version: {
        ndk: number;
        semver: string;
        name: string;
        api: number;
    };
    app_id: string;
    app_version: string;
    sw_version: string;
    hw_version: string;
    fw_version: string;
    fw_version_curr: string;
    fw_update_url: string;
    model_id: number
    audiotrack_default: string;
    definition_filter: number[];
    stream_quality: number;
    background_player: number;
    ui_font_size: number;
    time_create: number;
    time_update: number;
    time_close: number;
    settings_update_uts: number;
}

export interface ISyncApplyModel {
    login: string;
    autostart_status: number;
    packet_start: number;
    packet_expire: number;
    server: number;
    timezone: number;
    settings_update_uts: number;
    devices: ISyncApplyDeviceMode[];
}

export class SyncApplyReqModel {
    constructor(data: ISyncApplyModel) {
        this.map(data)
    }

    private map(data: ISyncApplyModel) {
        this.login = data.login
        this.autostart_status = data.autostart_status
        this.packet_start = data.packet_start
        this.packet_expire = data.packet_expire
        this.server = data.server
        this.timezone = data.timezone
        this.settings_update_uts = data.settings_update_uts
        this.devices = data.devices
    }


    public login: string;
    public autostart_status: number;
    public packet_start: number;
    public packet_expire: number;
    public server: number;
    public timezone: number;
    public settings_update_uts: number;
    public devices: ISyncApplyDeviceMode[];
}