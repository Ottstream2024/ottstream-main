import { Response, Router } from 'express'
import { controller } from '../../decorators/controller'
import { Controller } from '../../base/controller'
import { SyncService } from './service'
import { inject } from '../../utils/dependency/inject'
import { IRequest } from '../../interface/request'
import { ApiError } from '../../utils/api_error'
import { getErrorResponse, getResponse } from '../../utils/response'

@controller('sync')
class SyncController extends Controller {
    @inject()
    private service: SyncService

    public router = Router()
    
    constructor() {
        super()
        this.routes()
    }

    private routes() {
        this.router.post('/apply', this.syncApply)
        this.router.post('/cdn', this.syncLocationCdn)
        this.router.post('/cdn/create', this.syncCdnCreate)
        this.router.post('/cdn/providers', this.syncCndProviders)
        this.router.post('/cdn/options', this.syncCdnOptionsHosted)

        this.router.post('/bill', this.generateBill)
        this.router.post('/duration', this.updateByInvoiceDuration)
        this.router.put('/bill/update', this.updateBill)
    }

    private syncApply = async (req: IRequest, res: Response) => {
        try {
            const result = await this.service.syncApply(req.body)
            if (result.success) { res.status(200).send(result) }
            else { res.status(403).send(result) }
        } catch (error) {
            res.status(403).send(getErrorResponse(error.message))
        }
    }

    private async syncLocationCdn(req: IRequest, res: Response) {
        try {
            const result = await this.service.syncLocationCdn(req.body)
            res.send(result)
        } catch (error) {
            res.status(403).send(getErrorResponse(error.message))
            res.status(403).send(getErrorResponse(error.message))
            throw new ApiError(res, error)
        }
    }

    private async syncCdnCreate(req: IRequest, res: Response) {
        try {
            const result = await this.service.syncNewLocationCdn(req.body)
            return res.send(result)
        } catch (error) {
            res.status(403).send(getErrorResponse(error.message))
            throw new ApiError(res, error)
        }
    }

    private async syncCndProviders(req: IRequest, res: Response) {
        try {
            const result = await this.service.syncCndProviders()
            return res.send(result)
        } catch (error) {
            res.status(403).send(getErrorResponse(error.message))
            throw new ApiError(res, error)
        }
    }

    private async syncCdnOptionsHosted(req: IRequest, res: Response) {
        try {
            const result = await this.service.syncCdnOptionsHosted()
            return res.send(result)
        } catch (error) {
            res.status(403).send(getErrorResponse(error.message))
            throw new ApiError(res, error)
        }
    }

    private async generateBill(req: IRequest, res: Response) {
        try {
            const sr = new SyncService()
            const result = await sr.generateBill(req.body)
            return res.send(result)
        } catch (error) {
            res.status(403).send(getErrorResponse(error.message))
            throw new ApiError(res, error)
        }
    }

    private async updateBill(req: IRequest, res: Response) {
        try {
            const sr = new SyncService()
            const result = await sr.updateBill(req.body)
            return res.send(result)
        } catch (error) {
            res.status(403).send(getErrorResponse(error.message))
            throw new ApiError(res, error)
        }
    }

    private async updateByInvoiceDuration(req: IRequest, res: Response) {
        try {
            const sr = new SyncService()
            const result = await sr.updateByInvoiceDuration(req.body)
            return res.send(result)
        } catch (error) {
            res.status(403).send(getErrorResponse(error.message))
            throw new ApiError(res, error)
        }
    }
}

export default new SyncController()