import moment from "moment";
import { clientLocationRepository, clientRepository, invoiceRepository } from "../repository";

async function execInvalidBillClients() {
  const clientsLocationsFilter = {
    "subscriptionState": 3
  };

  const notCreatedBillsList = [];
  const invoiceNotGeneratedList = []

  const locations = await clientLocationRepository.getClientLocationsList(clientsLocationsFilter);
  console.log('Find ', locations.length, ' locations')
  if (!locations.length) return console.log('locations not found');

  for (let i = 0; i < locations.length; i++) {
    const location = locations[i];

    const invoice = await invoiceRepository.getLast({
      "payloadCalculated.locations.locationId": location._id
    })

    // check is invoice bill {}
    const subscriptionExpireDate = location.subscriptionExpireDate;

    if (invoice.payed === 0) {
      const loactionRef = invoice.payloadCalculated.locations.filter(x => x.locationId === location._id.toString())
      const dateValue = loactionRef.month ? 'months' : 'days';
      const doubleDate = Math.round(loactionRef.month * 1.1)

      if (moment(subscriptionExpireDate).isBefore(moment(invoice.createdAt).add(doubleDate, dateValue))) {
        invoiceNotGeneratedList.push({
          lastBillId: invoice._id.toString(),
          billDuration: loactionRef.month,
          billExpireDate: loactionRef.packages[0].expireNew,
          locationExpireDate: location.subscriptionExpireDate,
          location: location.login,
          client: invoice.client
        })
        console.log(`${i}. For ${location.login} bill not created long time - client = ${invoice.client}`)
      }

      if (moment(invoice.createdAt).isBefore(subscriptionExpireDate))
      return console.log(`${i}. Invoice ${invoice.number} is a bill, for client ${invoice.client}`)
    }

    // if invoice is not a bill, just payment invoice
    if (moment().add(20, 'days').isAfter(moment(subscriptionExpireDate))) {
      // bill should be created but not
      notCreatedBillsList.push({
        invoiceId: invoice._id.toString(),
        invocieNumber: invoice.number,
        client: invoice.client,
        locationId: location._id.toString(),
        location: location.login
      })
    }



  }

  console.log('notCreatedBillsList', JSON.stringify(notCreatedBillsList))
  console.log('--------------------------------------------------------');
  console.log('invoiceNotGeneratedList', JSON.stringify(invoiceNotGeneratedList))

}

execInvalidBillClients()