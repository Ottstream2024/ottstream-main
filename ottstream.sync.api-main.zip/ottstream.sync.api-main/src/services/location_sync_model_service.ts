class LocationSyncModel {
    constructor(props) {}
  }
  
export default LocationSyncModel;
  