import net from 'net'
import GeoIpService from './geoip_service';
import { Logger } from '../utils/logger';
import { clientUsedDeviceRepository } from '../repository';
import LocationUsedDeviceSyncCrudService from './location_used_device_sync_crud_service';
function validateIP(ip) {
  return net.isIPv4(ip) || net.isIPv6(ip);
}

class LocationUsedDeviceSyncService {
  static async GetUsedDeviceFieldsForMiddleware(remoteFields) {
    const result: any = {
      locationId: remoteFields.location._id,
      providerName: remoteFields.location?.provider?.name?.length
        ? remoteFields.location?.provider?.name[0].name
        : 'No Provider Name',
      serialN: remoteFields.device_serial,
      roomN: remoteFields.room_n,
      ipAddress: remoteFields.ip,
      type: remoteFields.device,
      modelCode: remoteFields.model_code,
      remoteControl: remoteFields.model_id ?? '0',
      model: remoteFields.model_id,
      lastActiveTime: new Date(remoteFields.time_close ? remoteFields.time_close * 1000 : remoteFields.time_update * 1000),
      manufacturer: remoteFields.manufacturer,
      macAddress: remoteFields.mac_address,
      userAgent: remoteFields.user_agent,
      appVersion: remoteFields.app_version,
      android_version: remoteFields.android_version?.name
        ? `${remoteFields.android_version?.name},${remoteFields.android_version?.api}`
        : remoteFields.android_version,
      timeShift: remoteFields.timeshift,
      language: remoteFields.lang,
      audioTrackDefault: remoteFields.audiotrack_default,
      httpCaching: remoteFields.http_caching,
      streamQuality: remoteFields.stream_quality,
      isBackgroundPlayer: remoteFields.background_player,
      isSD: remoteFields.definition_filter.filter((r) => r === 2).length,
      isHD: remoteFields.definition_filter.filter((r) => r === 3).length,
      isFHD: remoteFields.definition_filter.filter((r) => r === 4).length,
      isUHD: remoteFields.definition_filter.filter((r) => r === 5).length,
      uiFontSize: remoteFields.ui_font_size,
      lastUpdate: remoteFields.time_update,
      ott_client_id: null,
    };
    if (validateIP(remoteFields.ip)) {
      try {
        result.geoIpInfo = await GeoIpService.look(remoteFields.ip);
      } catch (err) {
        Logger.error(err);
      }
    }
    if (remoteFields.cdn_sessions) {
      result.cdn_sessions = remoteFields.cdn_sessions;
      result.isLive = true;
    }
    return result;
  }

  static async AddUsedDeviceStatistics(usedDevice, userDeviceId, cdnSessions) {
  }

  static async GetUsedDeviceUpdates(allUsedDevices, remoteUsedDevices) {
    const updateList = [];
    const toUpdateList = remoteUsedDevices.filter(
      (
        r
      ) =>
        allUsedDevices.filter(
          (a) =>
            a.locationId &&
            a.locationId.login === r.location.login &&
            a.status !== 0 &&
            a.serialN === r.device_serial &&
            (!a.lastUpdate || a.lastUpdate > r.time_update)
        ).length
    );
    for (const item of toUpdateList) {
      const foundList = allUsedDevices.filter(
        (r) => r.serialN === item.device_serial && r.locationId && r.locationId.id === item.location.id
      );
      if (foundList.length) {
        for (const currentItem of foundList) {
          const definitionFilter = [];
          if (currentItem.isSD) definitionFilter.push(2);
          if (currentItem.isHD) definitionFilter.push(3);
          if (currentItem.isFHD) definitionFilter.push(4);
          if (currentItem.isUHD) definitionFilter.push(5);

          const saveItem = {
            device_serial: currentItem.serialN,
            timeshift: currentItem.timeShift,
            lang: currentItem.language,
            definition_filter: definitionFilter,
            audiotrack_default: currentItem.audioTrackDefault,
            background_player: currentItem.isBackgroundPlayer ? 1 : 0,
            stream_quality: currentItem.streamQuality,
            ui_font_size: currentItem.uiFontSize,
            http_caching: currentItem.httpCaching,
          };


          updateList.push({
            usedDeviceId: currentItem.id,
            item: {
              devices: [saveItem],
              login: currentItem.locationId.login,
            },
          });
        }
      }
    }
    return updateList;
  }

  static async DoUsedDeviceSync(allUsedDevices, remoteUsedDevices) {
    const deleteList = [];
    const fromUpdates = [];
    const toAddList = [];
    const allUsedDevicesDict = allUsedDevices.reduce((obj, item) => {
      obj[item.locationId?.login + item.serialN] = item;
      return obj;
    }, {});
    const fromUpdateList = [];
    for (const remoteUsedDevice of remoteUsedDevices) {
      const { login } = remoteUsedDevice.location;
      const { device_serial } = remoteUsedDevice;
      if (allUsedDevicesDict[login + device_serial]) {
        const localUsedDevice = allUsedDevicesDict[login + device_serial];

        if (
          !localUsedDevice.lastUpdate ||
          localUsedDevice.lastUpdate < remoteUsedDevice.time_update ||
          remoteUsedDevice.cdn_sessions
        ) {
          fromUpdateList.push(remoteUsedDevice);
        }
      } else {
        toAddList.push(remoteUsedDevice);
      }
    }

    const toUpdateUsedDevices = await LocationUsedDeviceSyncService.GetUsedDeviceUpdates(allUsedDevices, remoteUsedDevices);
    Logger.info(
      `used devices to sync - create: ${toAddList.length} update: ${toUpdateUsedDevices.length} delete: ${deleteList.length} updateFrom: ${fromUpdateList.length}`
    );
    for (const item of toAddList) {
      const result = await LocationUsedDeviceSyncService.GetUsedDeviceFieldsForMiddleware(item);
      Logger.info(`adding ${item.location._id.toString()}  ${item.location.login}`);
      const sendData = { ...result };
      const updateResponse = await clientUsedDeviceRepository.createClientUsedDevice(sendData);
      if (updateResponse) {
        Logger.info(`used device ${updateResponse._id} created synced successfully`);
      }
    }
    for (const item of fromUpdateList) {
      const result = await LocationUsedDeviceSyncService.GetUsedDeviceFieldsForMiddleware(item);
      if (result) fromUpdates.push(result);
    }
    for (const item of toUpdateUsedDevices) {
      const updateResponse: any = await LocationUsedDeviceSyncCrudService.updateLocation(item.item);
      if (updateResponse.length && updateResponse[0].devices.length) {
        const device = updateResponse[0].devices.filter((r) => r.device_serial === item.item.devices[0].device_serial)[0];
        await clientUsedDeviceRepository.updateClientUsedDeviceById(item.usedDeviceId, {
          lastUpdate: device.time_update,
        });
      }
    }
    for (const item of fromUpdates) {
      const saveData = { ...item };
      const findDevices = allUsedDevices.filter(
        (r) =>
          r.serialN === saveData.serialN && r.locationId && r.locationId._id.toString() === saveData.locationId.toString()
      );
      if (findDevices.length) {
        for (const updateDevice of findDevices) {
          if (updateDevice.isLive && !saveData.cdn_sessions) {
            const currentDate = new Date();
            const secondsPass = (currentDate.getTime() - updateDevice.liveDate.getTime()) / 1000;
            if (secondsPass > 60 * 5) saveData.isLive = false;
          }
          const updated = await clientUsedDeviceRepository.updateClientUsedDeviceById(updateDevice._id.toString(), saveData);
          if (updated) {
            Logger.info(`used device ${item.serialN} updated!`);
          }

          if (item.cdn_sessions) {
            await LocationUsedDeviceSyncService.AddUsedDeviceStatistics(
              updateDevice.locationId._id.toString(),
              updateDevice._id.toString(),
              item.cdn_sessions
            );
            Logger.info(`used device ${item.serialN} statistics updated!`);
          }

        }
      }

      if (fromUpdates.length) {
      }

    }
  }
}

export default LocationUsedDeviceSyncService;
