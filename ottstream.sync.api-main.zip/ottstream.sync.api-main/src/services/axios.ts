import { Logger } from "../utils/logger";

const axios = require('axios');

export class AxiosService {
  post(url, data, headers = {}) {
    const config = {
      headers,
    };
    return new Promise(function (resolve, reject) {
      axios
        .post(url, data, config)
        .then(function (response) {
          resolve(response);
        })
        .catch(function (error) {
          Logger.error(error);
          reject(error);
        });
    });
  }

  put(url, data, headers = {}) {
    const config = {
      headers,
    };
    return new Promise(function (resolve, reject) {
      axios
        .put(url, data, config)
        .then(function (response) {
          resolve(response);
        })
        .catch(function (error) {
          reject(error);
        });
    });
  }

  delete(url, data = {}, headers = {}) {
    const config = {
      headers,
    };
    return new Promise(function (resolve, reject) {
      axios
        .delete(url, { ...config, data })
        .then(function (response) {
          resolve(response);
        })
        .catch(function (error) {
          reject(error);
        });
    });
  }

  read(url, headers = {}) {
    const config = {
      headers,
    };
    return new Promise(function (resolve, reject) {
      axios
        .get(url, config)
        .then(function (response) {
          resolve(response);
        })
        .catch(function (error) {
          reject(error);
        });
    });
  }
}