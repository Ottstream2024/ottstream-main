import ExcelJS from 'exceljs';
import fs from 'fs-extra';
import path from 'path';
import { IRequest } from '../interface/request';
import { Response } from 'express';

export const downloadInExel = async (req: IRequest, res: Response) => {
  try {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Credentials');

    // Add headers
    worksheet.addRow(['Full Name', 'Status', 'Provider', 'Login', 'Expire At', 'Phone Number', 'Paperless']);

    // Add data
    req.meta.map((item) => {
      worksheet.addRow([item.fullName, item.status, item.provider, item.login, item.expireAt, item.phoneNumber, item.paperless]);
    })

    // Temporary file path
    const fileName = `login_credentials_${Date.now()}.xlsx`;
    const filePath = path.join(__dirname, '..', 'temp', fileName);

    // Ensure temp folder exists
    await fs.ensureDir(path.dirname(filePath));

    // Write to file
    await workbook.xlsx.writeFile(filePath);

    // Send file as response
    res.download(filePath, fileName, async (err) => {
      if (err) {
        console.error('Download error:', err);
      }
      // Delete file after download
      await fs.remove(filePath);
    });
  } catch (err) {
    console.error('Error creating Excel:', err);
    res.status(500).send('Failed to generate Excel');
  }
}