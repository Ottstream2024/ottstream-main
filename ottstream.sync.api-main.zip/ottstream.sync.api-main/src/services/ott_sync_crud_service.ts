import { config } from "../config";
import { Logger } from "../utils/logger";
import request from 'request';
import { AxiosService } from "./axios";

const statistic: any = {
  locationWithoutProviderId: 0,
  locations: [],
  providers: [],
};

class OttSyncCrudService {
  static providerUrl() {
    return `https://iptv.ottstream.live/api_test/ottstream/providers`;
  }

  static constructProviderQuery(withDevices) {
    let query = `use_new_billing=1&`;
    if (withDevices) {
      query += `with_devices&`;
    }
    return `${OttSyncCrudService.providerUrl()}?${query}`;
  }

  static async getProviders() {
    if (statistic.providers && statistic.providers.length) {
      const currentDate = new Date();
      const secondsPass: any = (currentDate.getTime() - statistic.lastUpdate.getTime()) / 1000;
      if (secondsPass < config.sync.provider_pull_time) return statistic.providers;
      Logger.warn(`ott sync service: provider remote list needs to pull again (old Data) seconds pass: ${secondsPass}`);
    }
    const url = OttSyncCrudService.constructProviderQuery(false);

    return new Promise((resolve, reject) => {
      request(url, { json: true }, async (error, res, body) => {
        if (error) {
          reject(error);
          Logger.error(error);
        }
        try {
          if (!error && res.statusCode === 200) {
            Logger.info(`ott sync service: new remote providers fetched`);
            statistic.providers = body.providers;
            statistic.lastUpdate = new Date();
          } else {
            Logger.warn(`getProviders() statusCode: ${res.statusCode}`);
          }

          resolve(body.providers || []);
        } catch (exc) {
          reject(exc);
        }
      });
    });
  }

  static async deleteProvider(numericId) {
    const url = OttSyncCrudService.providerUrl();
    const body = {
      id: numericId,
    };

    const axiosService = new AxiosService();

    return new Promise((resolve) => {
      return axiosService
        .delete(url, body)
        .then((data: any) => {
          if (data.status === 200 && data.data?.message) {
            if (data.data.message !== 'OK') Logger.warn(`deleteProvider() response is not OK`);
            resolve(data.data);
          } else {
            Logger.warn(`deleteProvider() statusCode: ${data.status}`);
            resolve({});
          }
        })
        .catch((error) => {
          Logger.warn(`deleteProvider() failed statusCode: ${error.response?.status} ${error.response?.statusText}`);
          resolve(null);
        });
    });
  }

  static async updateProvider(body: any) {
    const url = OttSyncCrudService.providerUrl();

    const axiosService = new AxiosService();

    return new Promise((resolve) => {
      return axiosService
        .put(url, body)
        .then((data: any) => {
          if (data.status === 200 && data.data?.affected_providers?.length) resolve(data.data?.affected_providers);
          else {
            Logger.warn(`updateProvider() statusCode: ${data.status}`);
            resolve({});
          }
        })
        .catch((error) => {
          Logger.warn(`updateProvider() failed statusCode: ${error.response?.status} ${error.response?.statusText}`);
          resolve(null);
        });
    });
  }

  static async createProvider(body: any) {
    const url = OttSyncCrudService.providerUrl();

    const axiosService = new AxiosService();

    return new Promise((resolve) => {
      return axiosService
        .post(url, body)
        .then((data: any) => {
          if (data.status === 200 && data.data) resolve(data.data);
          else {
            Logger.warn(`createProvider() statusCode: ${data.status}`);
            resolve({});
          }
        })
        .catch((error) => {
          Logger.warn(`createProvider() failed statusCode: ${error.response?.status} ${error.response?.statusText}`);
          resolve(null);
        });
    });
  }
}

export default OttSyncCrudService;
