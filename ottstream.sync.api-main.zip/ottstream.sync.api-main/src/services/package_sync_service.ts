import request from "request";
import { Logger } from "../utils/logger";
import { packageChannelRepository, packageRepository, channelRepository, ottProviderRepository, groupRepository, deviceOptionRepository, iconRepository } from "../repository";
class PackageSyncService {
  static async updatePackageChannels(packageChannelsToUpdate) {
    Logger.info('updating package channel bindings');
    for (const item of packageChannelsToUpdate) {
      const currentList: any = await packageChannelRepository.getPackageChannelsByPackageMiddlewareId(item.packageMiddlewareId);
      Logger.info(
        `current packet: ${item.packageMiddlewareId} in channels: ${item.channels.length} list: ${currentList.length}`
      );
      const _package = await packageRepository.getPackageByMiddlewareId(item.packageMiddlewareId);

      if (_package) {
        for (const curListItem of currentList) {
          if (parseInt(`${curListItem.channelMiddlewareId}`, 10) === 8) {
            Logger.info(`exist channel ${curListItem.channelMiddlewareId} ${!item.channels.filter(
              (r) => r.cid === curListItem.channelMiddlewareId
            ).length}
          ${!item.channels.filter((r) => parseInt(r.cid, 10) === parseInt(`${curListItem.channelMiddlewareId}`, 10)).length}`);
          }
          if (!item.channels.filter((r) => r.cid === curListItem.channelMiddlewareId).length) {
            Logger.info(`removing package channel from ${curListItem.channelMiddlewareId} ${curListItem._id.toString()}`);
            await packageChannelRepository.RemovePackageChannel(curListItem._id.toString());
          }
        }

        for (const packet of item.channels) {
          const id = packet.cid;
          if (!currentList.filter((r) => r.channelMiddlewareId === id).length) {
            const _channel = await channelRepository.getChannelByMiddlewareId(id);
            if (_channel) {
              const added = await packageChannelRepository.AddChannelToPackage(
                _package._id,
                _channel._id,
                item.packageMiddlewareId,
                id
              );
              Logger.info(
                `channel package added package: ${item.packageMiddlewareId}, channel: ${id}, status: ${added !== null}`
              );
            }
          } else {
            Logger.info(`channel package exists  package: ${item.packageMiddlewareId}, channel: ${id}`);
          }
        }
      }
    }
  }

  static async syncPackages() {
    const url = 'https://iptv.ottstream.live/api_test/ottstream/configs';

    const options = { json: true };

    return new Promise((resolve, reject) => {
      request(url, options, async (error, res, body) => {
        if (error) {
          reject(error);
          Logger.error(error);
        }
        try {
          if (!error && res.statusCode === 200) {

            if (body.packets && body.packets.length) {
              for (const i in body.packets) {
                const packet = body.packets[i];
                const { id } = packet;
                const _package = await packageRepository.getPackageByMiddlewareId(id);
                if (!_package) {
                  Logger.info(`new package: ${id}`);
                  const baseOttProvider = await ottProviderRepository.getBaseOttProvider();
                  if (!baseOttProvider) {
                    Logger.error(`no base ott provider to sync channels`);
                  } else {
                    const created: any = await packageRepository.createPackage(
                      {
                        name: packet.name,
                        middlewareName: packet.name,
                        middlewareId: packet.id,
                        aEnable: packet.a_enbl,
                        vEnable: packet.v_enbl,
                        tEnable: packet.t_enbl,
                      },
                      {
                        provider: {
                          id: baseOttProvider._id,
                        },
                      }
                    );
                    if (!created) {
                      Logger.error(`error create new sync package middlewareId: ${packet.id}`);
                    } else {
                      Logger.info(`middleware package created: ${created._id} - ${created.middlewareId}`);
                    }
                  }
                } else {
                  const updated: any = await packageRepository.updatePackageById(_package._id, {
                    middlewareName: packet.name,
                    aEnable: packet.a_enbl,
                    vEnable: packet.v_enbl,
                    tEnable: packet.t_enbl,
                  });
                  Logger.info(`update package: ${updated._id} - ${updated.middlewareId}`);
                }
              }
            }
          }
          resolve(true);
        } catch (exc) {
          reject(exc);
        }
      });
    });
  }

  static async syncGroups() {
    const url = 'https://iptv.ottstream.live/api_test/ottstream/channels_groups';

    const options = { json: true };

    return new Promise((resolve, reject) => {
      request(url, options, async (error, res, body) => {
        if (error) {
          reject(error);
          Logger.error(error);
        }
        try {
          if (!error && res.statusCode === 200) {

            if (body.groups && body.groups.length) {
              for (const i in body.groups) {
                const packet = body.groups[i];
                const id = packet.group_id;
                const _group = await groupRepository.getGroupByMiddlewareId(id);
                if (!_group) {
                  Logger.info(`new group: ${id}`);
                  const baseOttProvider = await ottProviderRepository.getBaseOttProvider();
                  if (!baseOttProvider) {
                    Logger.error(`no base ott provider to sync groups`);
                  } else {
                    const created: any = await groupRepository.createGroup(
                      {
                        name: packet.name,
                        middlewareId: packet.group_id,
                        color: packet.color,
                        channels: packet.channels,
                      },
                      {
                        provider: {
                          id: baseOttProvider._id,
                        },
                      }
                    );
                    if (!created) {
                      Logger.error(`error create new sync group middlewareId: ${packet.group_id}`);
                    } else {
                      Logger.info(`middleware group created: ${created._id} - ${created.middlewareId}`);
                    }
                  }
                } else {
                  const updated: any = await groupRepository.updateGroupById(_group._id, {
                    name: packet.name,
                    color: packet.color,
                    channels: packet.channels,
                  });
                  Logger.info(`update group: ${updated._id} - ${updated.middlewareId}`);
                }
              }
            }
          }
          resolve(true);
        } catch (exc) {
          reject(exc);
        }
      });
    });
  }

  static async syncOptionsHosted() {
    let result = false;
    try {
      const deviceOptions: any = await deviceOptionRepository.getDeviceOptions();
      if (
        !deviceOptions ||
        !deviceOptions.updatedAt ||
        new Date().getTime() - deviceOptions.updatedAt.getTime() > 1000 * 60 * 60 
      ) {
        await PackageSyncService.syncOptions();
      }
    } catch (e) {
      Logger.error(e);
      result = false;
    }
    return result;
  }

  static async syncOptions() {
    const url = 'https://iptv.ottstream.live/api_test/ottstream/configs';

    const options = { json: true };

    return new Promise((resolve, reject) => {
      request(url, options, async (error, res, body) => {
        if (error) {
          reject(error);
          Logger.error(error);
        }
        try {
          if (!error && res.statusCode === 200) {
            await deviceOptionRepository.updateDeviceOptions(null, {
              http_caching: body.http_caching,
              bitrate: body.bitrate,
              servers: body.servers,
              audiotrack_default: body.audiotrack_default,
              definition_filter: body.definition_filter,
              stream_quality: body.stream_quality,
              lang: body.lang,
              background_player: body.background_player,
              ui_font_size: body.ui_font_size,
              box_models: body.box_models,
            });
          }
          resolve(true);
        } catch (exc) {
          reject(exc);
        }
      });
    });
  }

  static async syncChannels() {
    const url = 'https://iptv.ottstream.live/api_test/ottstream/channels';

    const options = { json: true };

    return new Promise((resolve, reject) => {
      request(url, options, async (error, res, body) => {
        if (error) {
          reject(error);
          Logger.error(error);
        }
        try {
          if (!error && res.statusCode === 200) {

            const updatePackageChannelHelperObject = {};
            const updatePackageChannelList = [];
            if (body.channels && body.channels.length) {
              for (const i in body.channels) {
                try {
                  const packet = body.channels[i];

                  Logger.info(`channel: ${packet.cid} packets: ${packet.packets.length}`);
                  for (const pack of packet.packets) {
                    if (pack in updatePackageChannelHelperObject) {
                      Logger.info(`list push packet channel: ${pack}  channel: ${packet.cid}`);
                      updatePackageChannelHelperObject[pack].channels.push(packet);
                    } else {
                      Logger.info(`list new packet channel: ${pack}  channel: ${packet.cid}`);
                      updatePackageChannelHelperObject[pack] = {
                        packageMiddlewareId: pack,
                        channels: [packet],
                      };
                    }
                  }
                  const id = packet.cid;
                  const _channel = await channelRepository.getChannelByMiddlewareId(id);
                  if (!_channel) {
                    Logger.info(`new channel: ${id}`);
                    const baseOttProvider = await ottProviderRepository.getBaseOttProvider();
                    if (!baseOttProvider) {
                      Logger.error(`no base ott provider to sync channels`);
                    } else {
                      const created: any = await channelRepository.createChannel(
                        {
                          name: packet.name,
                          middlewareId: packet.cid,
                          group_id: packet.group_id,
                          icon_path: packet.icon_path,
                          enabled: packet.enabled,
                          packets: packet.packets,
                        },
                        {
                          provider: {
                            id: baseOttProvider._id,
                          },
                        }
                      );
                      if (!created) {
                        Logger.error(`error create new sync channel middlewareId: ${packet.channel_id}`);
                      } else {
                        Logger.info(`middleware channel created: ${created._id} - ${created.middlewareId}`);
                      }
                    }
                  } else {
                    const updated: any = await channelRepository.updateChannelById(_channel._id, {
                      name: packet.name,
                      group_id: packet.group_id,
                      icon_path: packet.icon_path,
                      enabled: packet.enabled,
                      packets: packet.packets,
                    });
                    Logger.info(`update channel: ${updated._id} - ${updated.middlewareId}`);
                  }
                } catch (e) {
                  Logger.error(e.message);
                }
              }

              const middlewarePackages: any = await packageRepository.getMiddlewarePackages();
              for (const middlewarePackage of middlewarePackages) {
                if (!(middlewarePackage.middlewareId in updatePackageChannelHelperObject)) {
                  updatePackageChannelHelperObject[middlewarePackage.middlewareId] = {
                    packageMiddlewareId: middlewarePackage.middlewareId,
                    channels: [],
                  };
                }
              }

              for (const [, value] of Object.entries(updatePackageChannelHelperObject)) {
                updatePackageChannelList.push(value);
              }
            }

            await PackageSyncService.updatePackageChannels(updatePackageChannelList);
          }
          resolve(true);
        } catch (exc) {
          reject(exc);
        }
      });
    });
  }

  static async syncIcons() {
    const url = 'https://iptv.ottstream.live/api_test/ottstream/channels';

    const options = { json: true };

    return new Promise((resolve, reject) => {
      request(url, options, async (error, res, body) => {
        if (error) {
          reject(error);
          Logger.error(error);
        }
        try {
          if (!error && res.statusCode === 200) {

            if (body.icons && body.icons.length) {
              for (const i in body.icons) {
                const packet = body.icons[i];
                const { size } = packet;
                const _icon: any = await iconRepository.getIconBySize(size);
                if (!_icon) {
                  Logger.info(`new icon: ${size}`);
                  const baseOttProvider = await ottProviderRepository.getBaseOttProvider();
                  if (!baseOttProvider) {
                    Logger.error(`no base ott provider to sync icons`);
                  } else {
                    const created: any = await iconRepository.createIcon(
                      {
                        size: packet.size,
                        base_url: packet.base_url,
                        formats: packet.formats,
                      },
                      {
                        provider: {
                          id: baseOttProvider._id,
                        },
                      }
                    );
                    if (!created) {
                      Logger.error(`error create new sync icon middlewareId: ${packet.size}`);
                    } else {
                      Logger.info(`middleware icon created: ${created._id} - ${created.size}`);
                    }
                  }
                } else {
                  const updated: any = await iconRepository.updateIconBySize(_icon.size, {
                    size: packet.size,
                    base_url: packet.base_url,
                    formats: packet.formats,
                  });
                  Logger.info(`update icon: ${updated._id} - ${updated.size}`);
                }
              }
            }
          }
          resolve(true);
        } catch (exc) {
          reject(exc);
        }
      });
    });
  }
}

export default PackageSyncService;
