import { randomNumberSequence } from "../helpers/random";
import ClientLocation from "../models/client/client_location.model";
import  { clientLocationRepository, serverRepository, subscriptionRepository, clientUsedDeviceRepository }  from "../repository";
import { Logger } from "../utils/logger";
import LocationSyncCrudService from "./location_sync_crud_service";
import LocationUsedDeviceSyncService from "./location_used_device_sync_service";
import SubscriptionService from "./subscription_service";
const storage = { locations: {} };


class LocationSyncService {
  static async syncLocation(login, async = true) {
    const func = async (cb) => {
      try {
        const allLocations = await clientLocationRepository.getClientLocations(
          { login },
          [{ path: 'provider' }, { path: 'clientId' }],
          {
            _id: 1,
            syncState: 1,
            login: 1,
            name: 1,
            clientId: 1,
            provider: 1,
            migrated: 1,
            settingsUpdateUts: 1,
            isBlockLocation: 1,
            password: 1,
            parentalCode: 1,
            updatedAt: 1,
            isPauseSubscriptions: 1,
            server: 1,
            VODEnable: 1,
            archiveEnable: 1,
            roomsCount: 1,
            lastUpdate: 1,
            maxDevice: 1,
          }
        );
        Logger.info(`downloading remote locations...'`);
        const allRemoteLocations = await LocationSyncCrudService.getLocation(login, true);
        Logger.info(`downloading remote locations done'`);

        Logger.info(`starting sync.. ${login}'`);
        await LocationSyncService.DoLocationsSync(allLocations, allRemoteLocations, [], []);
        Logger.info(`starting done.. ${login}`);

        await LocationSyncService.syncUsedDevice(login, allRemoteLocations);

        if (login) {
          if (!storage.locations[login]) {
            storage.locations[login] = {};
          }
          storage.locations[login].lastUpdate = new Date();
        }

        if (async) {
          cb(null, `success`);
        }
      } catch (ex) {
        Logger.error(ex);
        return false;
      }
      return true;
    };

    Logger.info(`syncing locations is not enabled from .env (SUBSCRIPTION_SYNC_NOW=false)`);
    return true;
  }

  static async markToSync(locationId, syncNow = false) {
    const syncState = 2;
    const location: any = await clientLocationRepository.getClientLocationById(locationId, [], {
      _id: 1,
      login: 1,
      syncState: 1,
    });
    if (location?.login) {
      await clientLocationRepository.updateLocationById(location?._id, {
        syncState,
        settingsUpdateUts: Math.round(Date.now() / 1000),
      });
      if (syncNow) {
        Logger.info(`fast syncing location ${location.login}`);
        await LocationSyncService.syncLocation(location.login);
      }
    }
  }

  static async markAsSync(item) {
    const syncState = 1;
    const location: any = await clientLocationRepository.getClientLocationById(item.locationId, [], {
      _id: 1,
      login: 1,
      syncState: 1,
    });
    if (location?.login && location.syncState === 3) {
      const saveBody: any = {
        syncState,
        settingsUpdateUts: item.settings_update_uts,
      };
      if (item.password) saveBody.password = item.password;
      if (item.pin_code) saveBody.parentalCode = item.pin_code;
      await clientLocationRepository.updateLocationById(location?._id, saveBody);
    }
  }

  static async markAsSyncMultiple(itemList) {
    const syncState = 1;
    const ids = itemList.map((r) => r.locationId.toString());
    await clientLocationRepository.update({ _id: { $in: ids } }, { syncState });
    Logger.info(`location marked as synced`);
    for (const item of itemList) {
      const saveBody: any = {};
      if (item.password || item.pin_code) {
        if (item.password) saveBody.password = item.password;
        if (item.pin_code) saveBody.parentalCode = item.pin_code;
        await clientLocationRepository.updateLocationById(item?.locationId, saveBody);
        Logger.info(
          `locations: location ${item.login} password: ${item.password}, pin: ${item.pin_code} synced successfully`
        );
      }
    }
  }

  static async markAsSyncing(locationId) {
    const syncState = 3;
    await clientLocationRepository.updateLocationById(locationId, { syncState });
  }

  static async markAsSyncingMultiple(list) {
    const syncState = 3;
    const ids = list.map((r) => r.toString());
    await clientLocationRepository.update({ _id: { $in: ids } }, { syncState });
  }

  static async GenerateLocationLogin() {
    return LocationSyncCrudService.createLocation({ login_length: 8, pass_length: 6, pin_length: 6 });
  }

  static async GetLocationFieldsForMiddleware(locationFields, allSubscriptions = []) {
    const subscriptions = allSubscriptions.filter(
      (r) => r.location && r.location.toString() === locationFields._id.toString()
    );
    const minimumPacketStartDate = Math.min.apply(
      Math,
      subscriptions.map(function (o) {
        return o.startDate.getTime();
      })
    );
    const maximumPacketEndDate = Math.max.apply(
      Math,
      subscriptions.map(function (o) {
        return o.endDate.getTime();
      })
    );
    let server = null;
    if (locationFields.server) {
      const DbServer: any = await serverRepository.getServerById(locationFields.server);
      if (DbServer) {
        server = DbServer.middlewareId;
      }
    }
    if (server !== null) {
    }
    let autoStart = 0;
    if (
      !subscriptions.filter((r) => r.isActive && r.state === 1).length &&
      subscriptions.filter((r) => r.state === 1).length
    ) {
      autoStart = 1;
    }
    const result: any = {
      locationId: locationFields._id,
      login: locationFields.login,
      ott_provider_id: null,
      ott_client_id: null,
      disabled: locationFields.isBlockLocation ? 1 : 0,
      packets: subscriptions
        .filter((r) => r.package)
        .map((r) => r.package.middlewareId),
      autostart_status: autoStart,
      packet_start: Math.round(minimumPacketStartDate / 1000) || 0,
      packet_expire: Math.round(maximumPacketEndDate / 1000) || 0,
      in_pause: locationFields.isPauseSubscriptions ? 1 : 0,
      vod_enabled: locationFields.VODEnable ? 1 : 0,
      archive_enabled: locationFields.archiveEnable ? 1 : 0,
      multiroom: locationFields.roomsCount,
      use_new_billing: 1,
      max_devices: locationFields.maxDevice,
    };
    if (!result.packets.length) {
      result.packet_start = 0;
      result.packet_expire = 0;
    }
    result.server = server;
    if (locationFields.password && locationFields.password !== ``) {
      result.password = locationFields.password;
    } else {
      result.password = randomNumberSequence(6);
    }
    if (locationFields.parentalCode && locationFields.parentalCode !== ``) {
      result.pin_code = locationFields.parentalCode;
    } else {
      result.pin_code = result.password;
    }
    if (locationFields.provider) {
      result.ott_provider_id = locationFields.provider.number;
    }
    if (locationFields.clientId) {
      result.ott_client_id = locationFields.clientId?.number_id;
    }
    Logger.info(`location sync service: gathering location info ${result.login}`);
    return result;
  }

  static async DoLocationsSync(allLocations, remoteLocations, allUsedDevices, allRemoteUsedDevices) {
    const allSubscriptions = await subscriptionRepository.getSubscriptions({ state: 1 }, [{ path: 'package' }]);
    const servers: any = await serverRepository.getList({ status: 1 });
    const serverDict = servers.reduce((obj, item) => {
      obj[item.middlewareId] = item;
      return obj;
    }, {});
    const deleteList = [];
    const remoteLocationsDict = remoteLocations.reduce((obj, item) => {
      obj[item.login] = item;
      return obj;
    }, {});
    const toAddList = [];
    let fromUpdateList = [];
    const toUpdateList = [];
    const toDeleteList = [];
    Logger.info(`remote locations: ${remoteLocations.length}`);
    for (const localLocationKey in allLocations) {
      const localLocation = allLocations[localLocationKey];
      let remoteLocation = null;
      if (typeof remoteLocationsDict[localLocation.login] !== 'undefined') {
        remoteLocation = remoteLocationsDict[localLocation.login];
      }

      if (!remoteLocation && !localLocation.migrated) {
      }

      if (remoteLocation) {
        if (localLocation.syncState === 2) {
          if (localLocation.status === 0) {
            toDeleteList.push(localLocation);
          } else {
            toUpdateList.push(localLocation);
          }
        } else if (remoteLocation.autostart_status === -1) {
        }
      }
    }
    const fromUpdates = allLocations.filter(
      (
        r
      ) =>
        remoteLocations.filter((a) => a.login === r.login && Math.round(r.updatedAt / 1000) < a.settings_update_uts)
          .length && r.status !== 0
    );
    fromUpdateList = fromUpdateList.concat(fromUpdates);
    Logger.info(
      `locations to sync - create: ${toAddList.length} update: ${toUpdateList.length} delete: ${toDeleteList.length} updateFrom: ${fromUpdateList.length}`
    );
    for (const item of toAddList) {
      const result = await LocationSyncService.GetLocationFieldsForMiddleware(
        allLocations.filter((r) => r._id === item._id)[0],
        allSubscriptions
      );
      const sendData = { ...result };
      delete sendData.locationId;
      const updateResponse: any = await LocationSyncCrudService.createLocation(sendData);
      if (updateResponse && updateResponse.login === result.login) {
        const currentResponse: any = updateResponse;
        const toSave = { ...result };
        if (currentResponse.password) toSave.password = currentResponse.password;
        if (currentResponse.pin_code) toSave.pin_code = currentResponse.pin_code;
        if (updateResponse.conflict) toSave.conflict = updateResponse.constructor;
        await ClientLocation.updateOne({ login: result.login }, { syncState: 1 });
      } else {
        Logger.error(`remote location create error ${item.login}`);
      }
    }
    let index = 0;
    for (const item of toUpdateList) {
      index += 1;
      try {
        const result = await LocationSyncService.GetLocationFieldsForMiddleware(
          allLocations.filter((r) => r._id === item._id)[0],
          allSubscriptions
        );
        result.devices = [];
        const updateSendData = [];
        const sendData = { ...result };
        delete sendData.locationId;
        updateSendData.push(sendData);
        let multiUpdateResponse: any = [];
        if (updateSendData.length) multiUpdateResponse = await LocationSyncCrudService.updateLocation(updateSendData);
        if (multiUpdateResponse && multiUpdateResponse.filter((r) => r.login === item.login).length) {
          Logger.info(`location ${item.login} updated to remote ${index}/${toUpdateList.length}`);
          const currentResponse = multiUpdateResponse.filter((r) => r.login === item.login)[0];
          const toSave = { ...item };
          if (currentResponse.password) toSave.password = currentResponse.password;
          if (currentResponse.pin_code) toSave.pin_code = currentResponse.pin_code;
        }
        await ClientLocation.updateOne({ login: item.login }, { syncState: 1 });
      } catch (ex) {
        Logger.error(`problematic login update ${item.login}`);
      }
    }
    for (const item of toDeleteList) {
      deleteList.push({ login: item.login || item.id, locationId: item._id });
    }
    index = 0;
    for (const dbLocation of fromUpdateList) {
      index += 1;
      const item = remoteLocationsDict[dbLocation.login];
      if (item.autostart_status === -1) {
        Logger.info(`location first time activation ${dbLocation.login}`);
        await SubscriptionService.locationFirstTimeLogin(dbLocation, item);
        await LocationSyncService.markToSync(dbLocation._id.toString());
      }
      const updateBody: any = {
        isBlockLocation: item.disabled === 1,
        isPauseSubscriptions: item.disabled === 1,
        VODEnable: item.disabled === 1,
        archiveEnable: item.disabled === 1,
        settingsUpdateUts: item.settings_update_uts,
      };

      if (typeof serverDict[item.server] !== 'undefined') {
        updateBody.server = serverDict[item.server]._id.toString();
      }
      await clientLocationRepository.updateClientLocationById(dbLocation._id, updateBody);
      Logger.info(`location ${dbLocation.login} updated from remote ${index}/${fromUpdateList.length}`);

      try {
        Logger.info(`broadcasting location info from update. client: ${dbLocation.clientId.id}`);
      } catch (ex) {
        Logger.error(ex);
      }
    }

    if (toUpdateList.length || toAddList.length || toDeleteList.length || fromUpdateList.length) {
      await LocationSyncCrudService.resetCache();
    }
  }

  static async syncLocations(login, states = []) {
    const func = async (cb) => {
      try {
        const filter: any = { subscriptionState: { $in: states } };
        if (login) filter.login = login;
        const allRemoteLocations = await LocationSyncCrudService.getLocations();
        const allLocations = await clientLocationRepository.getClientLocations(
          filter,
          [{ path: 'provider' }, { path: 'clientId' }],
          {
            _id: 1,
            syncState: 1,
            login: 1,
            name: 1,
            clientId: 1,
            provider: 1,
            migrated: 1,
            settingsUpdateUts: 1,
            isBlockLocation: 1,
            password: 1,
            parentalCode: 1,
            updatedAt: 1,
            isPauseSubscriptions: 1,
            server: 1,
            VODEnable: 1,
            archiveEnable: 1,
            roomsCount: 1,
            lastUpdate: 1,
            maxDevice: 1,
          }
        );
        const allRemoteUsedDevices = [];

        await LocationSyncService.DoLocationsSync(allLocations, allRemoteLocations, [], allRemoteUsedDevices);

        cb(null, `success`);
      } catch (ex) {
        Logger.error(ex);
      }
    };
  }

  static async syncCdnSessions(login, roomN) {
    try {
      const filter: any = {};
      if (login) filter.login = login;
      const cdnSessionResponse: any = await LocationSyncCrudService.getCdnSessions(login, roomN);
      const allLocations = await clientLocationRepository.getClientLocations(
        filter,
        [{ path: 'provider' }, { path: 'clientId' }],
        {
          _id: 1,
          syncState: 1,
          login: 1,
          name: 1,
          clientId: 1,
          provider: 1,
          migrated: 1,
          settingsUpdateUts: 1,
          isBlockLocation: 1,
          password: 1,
          parentalCode: 1,
          updatedAt: 1,
          isPauseSubscriptions: 1,
          server: 1,
          VODEnable: 1,
          archiveEnable: 1,
          roomsCount: 1,
          lastUpdate: 1,
          maxDevice: 1,
        }
      );

      const usedDeviceGetFilter: any = {};
      if (allLocations.length === 1) {
        usedDeviceGetFilter.locationId = allLocations[0].id;
      }
      const allUsedDevices: any = await clientUsedDeviceRepository.getClientUsedDevices(
        usedDeviceGetFilter,
        [{ path: 'locationId', populate: [{ path: 'provider' }] }, { path: 'clientId' }],
        {
          locationId: 1,
          updatedAt: 1,
          lastUpdate: 1,
          serialN: 1,
          roomN: 1,
          timeShift: 1,
          audioTrackDefault: 1,
          isBackgroundPlayer: 1,
          streamQuality: 1,
          uiFontSize: 1,
          httpCaching: 1,
          language: 1,
          isSD: 1,
          isHD: 1,
          isFHD: 1,
          isUHD: 1,
          cdn_sessions: 1,
        }
      );
      const toUpdateUsedDevices: any = allUsedDevices.filter((r) => r.roomN === roomN);

      if (cdnSessionResponse.cdn_sessions) {
        for (const updateDevice of toUpdateUsedDevices) {
          await LocationUsedDeviceSyncService.AddUsedDeviceStatistics(
            updateDevice,
            updateDevice._id.toString(),
            cdnSessionResponse.cdn_sessions
          );
          Logger.info(`used device cdn ${updateDevice.serialN} statistics updated!`);
        }
      }
    } catch (ex) {
      Logger.error(ex);
      return true;
    }
    return false;
  }

  static async syncUsedDevice(login, remoteLocations) {
    try {
      const filter: any = {};
      if (login) filter.login = login;
      const allRemoteLocations = remoteLocations || (await LocationSyncCrudService.getLocation(login));
      const allLocations = await clientLocationRepository.getClientLocations(
        filter,
        [{ path: 'provider' }, { path: 'clientId' }],
        {
          _id: 1,
          syncState: 1,
          login: 1,
          name: 1,
          clientId: 1,
          provider: 1,
          migrated: 1,
          settingsUpdateUts: 1,
          isBlockLocation: 1,
          password: 1,
          parentalCode: 1,
          updatedAt: 1,
          isPauseSubscriptions: 1,
          server: 1,
          VODEnable: 1,
          archiveEnable: 1,
          roomsCount: 1,
          lastUpdate: 1,
          maxDevice: 1,
        }
      );
      const allRemoteUsedDevices = [];
      const localLocationsDict = allLocations.reduce((obj, item) => {
        obj[item.login] = item;
        return obj;
      }, {});
      allRemoteLocations.forEach((r) =>
        r.devices.forEach((a) => {
          const saveObj = {
            ...a,
          };
          if (localLocationsDict[r.login]) {
            saveObj.location = localLocationsDict[r.login];
            allRemoteUsedDevices.push(saveObj);
          }
        })
      );

      const usedDeviceGetFilter: any = {};
      if (allLocations.length === 1) {
        usedDeviceGetFilter.locationId = allLocations[0].id;
      }
      const allUsedDevices = await clientUsedDeviceRepository.getClientUsedDevices(
        usedDeviceGetFilter,
        [{ path: 'locationId', populate: [{ path: 'provider' }] }, { path: 'clientId' }],
        {
          locationId: 1,
          updatedAt: 1,
          lastUpdate: 1,
          serialN: 1,
          roomN: 1,
          timeShift: 1,
          audioTrackDefault: 1,
          isBackgroundPlayer: 1,
          streamQuality: 1,
          uiFontSize: 1,
          httpCaching: 1,
          language: 1,
          isSD: 1,
          isHD: 1,
          isFHD: 1,
          isUHD: 1,
        }
      );

      await LocationUsedDeviceSyncService.DoUsedDeviceSync(allUsedDevices, allRemoteUsedDevices);
    } catch (ex) {
      Logger.error(ex);
      return true;
    }
    return false;
  }

  static async syncUsedDevices(login) {
    const func = async (cb) => {
      try {
        const filter: any = {};
        if (login) filter.login = login;
        const allRemoteLocations: any = await LocationSyncCrudService.getLocations();
        const allLocations = await clientLocationRepository.getClientLocations(
          filter,
          [{ path: 'provider' }, { path: 'clientId' }],
          {
            _id: 1,
            syncState: 1,
            login: 1,
            name: 1,
            clientId: 1,
            provider: 1,
            migrated: 1,
            settingsUpdateUts: 1,
            isBlockLocation: 1,
            password: 1,
            parentalCode: 1,
            updatedAt: 1,
            isPauseSubscriptions: 1,
            server: 1,
            VODEnable: 1,
            archiveEnable: 1,
            roomsCount: 1,
            lastUpdate: 1,
            maxDevice: 1,
          }
        );
        const allRemoteUsedDevices = [];
        const localLocationsDict = allLocations.reduce((obj, item) => {
          obj[item.login] = item;
          return obj;
        }, {});
        allRemoteLocations.forEach((r) =>
          r.devices.forEach((a) => {
            const saveObj = {
              ...a,
            };
            if (localLocationsDict[r.login]) {
              saveObj.location = localLocationsDict[r.login];
              allRemoteUsedDevices.push(saveObj);
            }
          })
        );
        const allUsedDevices = await clientUsedDeviceRepository.getClientUsedDevices(
          {},
          [{ path: 'locationId', populate: [{ path: 'provider' }] }, { path: 'clientId' }],
          {
            locationId: 1,
            updatedAt: 1,
            lastUpdate: 1,
            serialN: 1,
          }
        );
        await LocationUsedDeviceSyncService.DoUsedDeviceSync(allUsedDevices, allRemoteUsedDevices);
        cb(null, `success`);
      } catch (ex) {
        Logger.error(ex);
      }
    };
  }
}

export default LocationSyncService;
