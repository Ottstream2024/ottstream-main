import { config } from '../config';
import { clientLocationRepository, clientRepository, commentRepository, ottProviderEmailRepository, ottProviderPhoneRepository, ottProviderRepository, packageRepository, priceGroupRepository, subscriptionRepository, userRepository } from "../repositories";
import { Logger } from "../utils/logger";
import { AxiosService } from './axios';
import TimezoneService from "./timezone";

class LiveSyncService {
    static async savePriceGroup(incomingPriceGroup, providerId) {
      const finalResponse = {
        status: true,
        messages: [],
      };
      const createdPriceGroup = await priceGroupRepository.createPriceGroup({
        type: 2,
        name: [{ lang: 'en', name: incomingPriceGroup.name }],
        provider: providerId,
        middlewareId: incomingPriceGroup.priceGroupId,
        providerMiddlewareId: incomingPriceGroup.providerMiddlewareId,
        migrated: true,
      });
      if (!createdPriceGroup) {
        finalResponse.status = false;
        finalResponse.messages.push(`savePriceGroup() unable to create user`);
        return finalResponse;
      }
  
      if (createdPriceGroup.providerMiddlewareId) {
        await ottProviderRepository.updateAll(
          { middlewareId: parseInt(createdPriceGroup.providerMiddlewareId, 10) },
          { priceGroup: createdPriceGroup._id }
        );
      }
      return finalResponse;
    }
  
    static async saveOttProvider(incomingProvider, providerId, existingClients, existingLocations) {
      const existingPackages = await packageRepository.getList({ migrated: true });
      const existingProviders = await ottProviderRepository.getList({ migrated: true });
      const existingUsers = await userRepository.getList({ migrated: true });
      const finalResponse = {
        status: true,
        messages: [],
      };
      if (!incomingProvider) {
        finalResponse.status = false;
        finalResponse.messages.push(`saveOttProvider(incomingProvider, user, providerId) ott provider is null`);
        return finalResponse;
      }
  
      if (!incomingProvider.users.length) {
        finalResponse.status = false;
        finalResponse.messages.push(`saveOttProvider(incomingProvider, user, providerId) provider have no users`);
        return finalResponse;
      }
  
      const exisitingsFound = existingProviders.filter(
        (r) =>
          r.syncIdentifier && r.syncIdentifier !== '' && r.syncIdentifier === incomingProvider.syncIdentifier && r.status === 1
      );
      let createdProvider = exisitingsFound.length ? exisitingsFound[0] : null;
      const createdUsers = [];
      if (createdProvider) {
        const exisitingsUserFound = existingUsers.filter((r) => r.provider.toString() === createdProvider._id.toString());
        if (exisitingsUserFound.length) {
          createdUsers.push(exisitingsUserFound[0]);
        } else {
          Logger.error(`provider user not found ${createdProvider._id}`);
        }
      }
      if (!createdProvider || !createdUsers.length) {
        for (const incomingUser of incomingProvider.users) {
          if (!incomingUser.email || incomingUser.email === '') {
            incomingUser.email = `no_user_email_${clientLocationRepository.generateRandomNumber()}@ottstream.live`;
          }
          const exisitingUserFound = existingUsers.filter((r) => r.email === incomingUser.email && r.status === 1);
          if (exisitingUserFound.length) {
            if (createdProvider) {
              const updatedUser = await userRepository.updateUserById(exisitingUserFound[0]._id, {
                provider: createdProvider._id,
              });
              createdUsers.push(updatedUser);
            } else {
              createdUsers.push(exisitingUserFound[0]);
            }
          } else {
            const userBody: any = {
              email: incomingUser.email,
              password: 'asdASD#2!',
              timezone: TimezoneService.GetTimeZoneFromWindowsName(incomingUser.timezone) ?? '',
              firstname: incomingUser.firstname,
              lastname: incomingUser.lastname,
              phone: incomingUser.phone,
              migrated: true,
              state: 1,
              geoInfo: {},
            };
            if (createdProvider) {
              userBody.provider = createdProvider._id.toString();
            }
            const newUser = await userRepository.createUser(userBody);
            if (!newUser) {
              finalResponse.status = false;
              finalResponse.messages.push(`saveOttProvider(incomingProvider, user, providerId) unable to create user`);
              return finalResponse;
            }
            createdUsers.push(newUser);
          }
        }
      }
  
      const { subProviders } = incomingProvider;
      if (!createdProvider) {
        createdProvider = await ottProviderRepository.createOttProvider(
          {
            name: incomingProvider.name,
            website: incomingProvider.website,
            balance: incomingProvider.balance,
            timezone: TimezoneService.GetTimeZoneFromWindowsName(incomingProvider.timezone) ?? '',
            comment: incomingProvider.comment,
            clientAmount: incomingProvider.clientAmount,
            channelAmount: incomingProvider.channelAmount,
            description: incomingProvider.description,
            migrated: true,
            syncIdentifier: incomingProvider.syncIdentifier,
            parent: providerId,
            middlewareId: incomingProvider.middlewareId,
            migrationFails: [],
            type: 1,
            state: incomingProvider.state,
          },
          createdUsers[0]
        );
      }
      if (!createdProvider) {
        finalResponse.status = false;
        finalResponse.messages.push(`saveOttProvider(incomingProvider, user, providerId) unable to create ott provider`);
        return finalResponse;
      }
  
      if (!exisitingsFound.length) {
        for (const currentEmail of incomingProvider.emails) {
          try {
            await ottProviderEmailRepository.createOttProviderEmail({
              providerId: createdProvider._id,
              inUse: true,
              isMain: true,
              address: currentEmail.address,
            });
          } catch (ex) {
            createdProvider.migrationFails.push({
              type: 'email',
              value: currentEmail.address,
              message: ex.message,
            });
          }
        }
      }
      if (!exisitingsFound.length) {
        for (const currentPhone of incomingProvider.phones) {
          try {
            await ottProviderPhoneRepository.createOttProviderPhone({
              providerId: createdProvider._id,
              inUse: true,
              isMain: true,
              number: currentPhone.number,
            });
          } catch (ex) {
            createdProvider.migrationFails.push({
              type: 'phone',
              value: currentPhone.number,
              message: ex.message,
            });
          }
        }
      }
  
      for (const client of incomingProvider.clients) {
        const clientBody = { ...client };
        clientBody.user = createdUsers[0]._id;
        clientBody.provider = createdProvider._id;
        clientBody.balance = client.balance;
        clientBody.migrated = true;
        clientBody.subscriptionState = 0;
        if (clientBody.locations.filter((r) => r.subscriptions.length).length) {
          clientBody.subscriptionState = 1;
          if (
            clientBody.locations.filter((r) => r.subscriptions.length && r.subscriptions.filter((a) => a.isActive).length)
              .length
          )
            clientBody.subscriptionState = 3;
        }
        delete clientBody.locations;
        delete clientBody.comments;
        try {
          let newClient = null;
          const existingClientsList = existingClients.filter(
            (r) => clientBody.middlewareId === r.middlewareId && r.provider.toString() === createdProvider._id.toString()
          );
          if (existingClientsList.length) {
            if (existingClientsList.length !== 1)
              Logger.error(`live sync: existing clients more than 1: client: ${existingClientsList[0]._id.toString()}`);
            newClient = existingClientsList[0];
            await clientRepository.updateClientById(newClient._id.toString(), {
              balance: clientBody.balance,
              subscriptionState: clientBody.subscriptionState,
            });
          } else {
            newClient = await clientRepository.createClient(clientBody);
          }
          for (const incomingComment of client.comments) {
            try {
              incomingComment.user = createdUsers[0]._id;
              incomingComment.migrated = true;
              incomingComment.client = newClient._id.toString();
              await commentRepository.createComment(incomingComment, createdUsers[0]);
            } catch (ex) {
              Logger.error(ex);
            }
          }
          for (const incomingLocation of client.locations) {
            try {
              const saveLocation = { ...incomingLocation };
              saveLocation.provider = createdProvider._id;
              saveLocation.user = createdUsers[0]._id;
              saveLocation.migrated = true;
              saveLocation.clientId = newClient._id.toString();
              saveLocation.syncState = 2;
              saveLocation.isBlockLocation = false;
              saveLocation.autostartStatus = 0;
              saveLocation.subscriptionState = 0;
              if (saveLocation.subscriptions && saveLocation.subscriptions.length) {
                if (saveLocation.subscriptions.filter((a) => a.isActive).length) saveLocation.subscriptionState = 3;
                else saveLocation.subscriptionState = 1;
              }
              if (saveLocation.subscriptionState === 3) {
                saveLocation.startDate = incomingLocation.subscriptions[0].startDate;
                saveLocation.endDate = incomingLocation.subscriptions[0].endDate;
              }
              delete saveLocation.subscriptions;
              let newLocation = null;
              const existingLocationsList = existingLocations.filter(
                (r) => saveLocation.middlewareId === r.middlewareId && r.clientId.toString() === newClient._id.toString()
              );
              if (existingLocationsList.length) {
                if (existingLocationsList.length !== 1)
                  Logger.error(`live sync: existing location more than 1: client: ${existingLocationsList[0]._id.toString()}`);
                newLocation = existingLocationsList[0];
                await clientLocationRepository.updateClientLocationById(newLocation._id.toString(), {
                  subscriptionState: saveLocation.subscriptionState,
                  syncState: saveLocation.syncState,
                  settingsUpdateUts: 0,
                });
              } else {
                newLocation = await clientLocationRepository.createClientLocation(saveLocation, {}, {});
              }
              let basePlusPlusAdded = false;
              const changeChannels = [0, 8, 12, 29, 31];
              for (const incomingSubscription of incomingLocation.subscriptions) {
                try {
                  incomingSubscription.provider = createdProvider._id;
                  incomingSubscription.user = createdUsers[0]._id;
                  incomingSubscription.migrated = true;
                  incomingSubscription.state = 1;
                  incomingSubscription.recurringPayment = saveLocation.recurringPayment;
                  incomingSubscription.client = newClient._id.toString();
                  incomingSubscription.location = newLocation._id.toString();
                  if (changeChannels.includes(incomingSubscription.packageMiddlewareId)) {
                    incomingSubscription.packageMiddlewareId = 28; // base++ id
                  }
                  if (incomingSubscription.packageMiddlewareId !== 28 || !basePlusPlusAdded) {
                    const findPackages = existingPackages.filter(
                      (r) => r.middlewareId === incomingSubscription.packageMiddlewareId
                    );
                    if (findPackages.length) {
                      incomingSubscription.package = findPackages[0]._id.toString();
                    }
                    await subscriptionRepository.createSubscription(incomingSubscription);
                    if (incomingSubscription.packageMiddlewareId === 28) {
                      basePlusPlusAdded = true;
                    }
                  }
                } catch (ex) {
                  Logger.error(ex);
                }
              }
            } catch (ex) {
              Logger.error(ex);
            }
          }
        } catch (exc) {
          Logger.error(exc);
        }
      }
      for (const subProvider of subProviders) {
        const curResp = await LiveSyncService.saveOttProvider(
          subProvider,
          createdProvider._id.toString(),
          existingClients,
          existingLocations
        );
        if (!curResp.status) {
          finalResponse.status = !curResp.status;
          finalResponse.messages = finalResponse.messages.concat(curResp.messages);
        }
      }
      return finalResponse;
    }
  
    static async syncLive(user) {
      const func = async (cb) => {
        try {
          const response: any = {
            status: false,
            messages: [],
          };
          const axiosService = new AxiosService();
          const axiosResponse: any = await axiosService.read(config.sync.live_url);
          const incomingResponse = axiosResponse.data;
          const incomingProviders = incomingResponse.ottProviders;
          response.data = incomingResponse;
          const migratedProviders = await ottProviderRepository.getOttProviders({ migrated: true });
          const existingUsers = await userRepository.getAllUsers({ migrated: true });
          const existingClients = await clientRepository.getAll({ migrated: true });
          const existingLocations = await clientLocationRepository.getAll({ migrated: true });
          const existingPriceGroups = await priceGroupRepository.getList({ migrated: true });
          const existingSubsciptions = await subscriptionRepository.getList({ migrated: true });
          const baseProviderId = user.provider._id.toString();

          Logger.info(`incoming providers count: ${incomingProviders.length}`);
          Logger.info(`removing existing providers count: ${migratedProviders.length}`);
          Logger.info(`removing existing users count: ${existingUsers.length}`);
          Logger.info(`removing existing clients count: ${existingClients.length}`);
          Logger.info(`removing existing locations count: ${existingLocations.length}`);
          Logger.info(`removing existing price groups: ${existingPriceGroups.length}`);
          Logger.info(`removing existing subscriptions groups: ${existingSubsciptions.length}`);
  
          await subscriptionRepository.deleteMany({ migrated: true });
          await commentRepository.deleteMany({ migrated: true });
          for (const incomingProvider of incomingProviders) {
            await LiveSyncService.saveOttProvider(incomingProvider, baseProviderId, existingClients, existingLocations);
          }
          Logger.info(axiosResponse, false);
          cb(null, response);
        } catch (ex) {
          Logger.error(ex);
        }
      };
      return {
        success: true,
        message: `live sync task started...`,
      };
    }
  }

  export default new LiveSyncService()