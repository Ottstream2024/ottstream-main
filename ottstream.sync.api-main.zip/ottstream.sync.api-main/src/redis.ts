import { config } from "./config";
import { injectable } from "./utils/dependency/injectable";
import redis from 'redis'
import { Logger } from "./utils/logger";

@injectable()
export class RedisService {
    private client: redis.RedisClientType = null
    private connected: boolean

    constructor() {
        this.connect()
    }

    private async connect() {
        const url = `redis://${config.redis.host}:${config.redis.port}`
        this.client = redis.createClient({
            url,
            password: config.redis.password
        })
        this.client.connect()
        return new Promise((resolve) => {
            this.client.on('connect', () => {
                Logger.info('Redis server connected...!')
                this.connected = true
                resolve({ status: true })
            })
            this.client.on('error', (err) => {
              this.connected = false;
              resolve({ status: false });
              Logger.error('Redis connection error', err)
            })
          })
    }

    public async disconnect() {
        if (this.client) this.client.disconnect()
    }

    public async deleteData(key: string) {
        await this.client.del([key])
    }

    public async setData(key: string, value: string) {
        await this.client.set(key, value)
        return this.client.get(key)
    } 

    public async getData(key: string) {
        return this.client.get(key)
    }
}