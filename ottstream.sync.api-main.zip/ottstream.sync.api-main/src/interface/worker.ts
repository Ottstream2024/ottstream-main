export interface IWorkerJob {
    time: string;
    cb: () => void;
}