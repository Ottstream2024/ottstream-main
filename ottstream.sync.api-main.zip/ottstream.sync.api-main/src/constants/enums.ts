export enum SyncActionTypeEnum {
    update = 1,
    craete,
    delete,
    skip
}