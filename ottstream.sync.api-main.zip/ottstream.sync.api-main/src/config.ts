import dotenv from 'dotenv';
dotenv.config()

export interface IEnvironment {
    PORT: string | number;
    LOGGER_LVL: string;
    FRONT_URL: string;
}


class Config implements IEnvironment {

    public PORT = +process.env.PORT || 5014
    public LOGGER_LVL: string = process.env.LOGGER_LVL || '1';
    public FRONT_URL: string = process.env.FRONT_URL || 'http://localhost:5014';
    public env = process.env.NODE_ENV
    public global = {
      equipment_per_provider: process.env.EQUIPMENT_PER_PROVIDER,
    }
    public port = process.env.PORT
    public front_url = process.env.FRONT_URL
    public file = {
      file_storage_path: process.env.FILE_STORAGE_PAT,
      root_path: process.env.STORAGE_ROOT_PATH,
      template_path: process.env.TEMPLATE_PATH,
    }
    public mongoose = {
      url: process.env.MONGODB_URL || 'mongodb://admin:admin@127.0.0.1:27017/ottstream?authSource=admin',
      options: {
        minPoolSize: 90,
      }
    }
    public jwt = {
      secret: process.env.JWT_SECRET,
      accessExpirationMinutes: process.env.JWT_ACCESS_EXPIRATION_MINUTES,
      refreshExpirationDays: process.env.JWT_REFRESH_EXPIRATION_DAYS,
      resetPasswordExpirationMinutes: 10
    }
    public sync = {
      live_url: process.env.SYNC_URL,
      locations_pull_time: process.env.SYNC_LOCATIONS_PULL_TIME,
      provider_pull_time: process.env.SYNC_PROVIDER_PULL_TIME,
      sync_middleware: process.env.SYNC_MIDDLEWARE,
      generate_login: process.env.SYNC_GENERATE_LOGIN,
    }
    public google = {
      clientId: process.env.GOOGLE_CONSUMER_KEY,
      secret: process.env.GOOGLE_CONSUMER_SECRET,
      callbackUrl: process.env.GOOGLE_CALLBACK_URL,
    }
    public smartStreet = {
      front_url: process.env.SMARTSTREET_SOURCE_URL,
      publicKey: process.env.SMART_STREET_KEY,
      smartyStreetAuthId: process.env.SMART_STREET_AUTH_ID,
      smartyStreetAuthToken: process.env.SMART_STREET_AUTH_TOKEN,
    }
    public taxJar = {
      token: process.env.TAXJAR_API_TOKEN,
    }
    public email = {
      smtp: {
        full: process.env.SMTP_FULL,
        host: process.env.SMTP_HOST,
        port: process.env.SMTP_PORT,
        auth: {
          user: process.env.SMTP_USERNAME,
          pass: process.env.SMTP_PASSWORD,
        }
      },
      from: process.env.EMAIL_FROM,
    }
    public maxmind = {
      dailyLimit: process.env.MAXMIND_DAILY_LIMIT,
    }
    public subscription = {
      left_expire_hours: process.env.SUBSCRIPTION_LEFT_EXPIRE_HOURS,
      left_expire_hours_start: process.env.SUBSCRIPTION_LEFT_EXPIRE_HOURS_START,
      generate_invoice: process.env.SUBSCRIPTION_INVOICE_GENERATE,
      allowCardCharge: process.env.SUBSCRIPTION_CARDS_CHARGE,
      recurring_charge_hour: process.env.SUBSCRIPTION_CARDS_HOURS,
      recurring_retry: process.env.SUBSCRIPTION_CARDS_RETRY,
      syncNow: process.env.SUBSCRIPTION_SYNC_NOW,
    }
    public payment = {
      payment_card_sync: process.env.PAYMENT_CARD_SYNC,
    }
    public redis = {
      host: process.env.REDIS_HOST,
      port: process.env.REDIS_PORT,
      password: process.env.REDIS_PASSWORD,
    }
    public hosted = {
      processCards: process.env.CARDS_PROCESS,
      processShippings: process.env.SHIPPINGS_PROCESS,
      processSubscriptions: process.env.SUBSCRIPTION_PROCESS,
      processPostalMethods: process.env.POSTALMETHODS_PROCESS,
      processNotifications: process.env.NOTIFICATIONS_PROCESS,
      processCredits: process.env.CREDITS_PROCESS,
      processAuthorize: process.env.AUTHORIZE_PROCESS,
      processClover: process.env.CLOVER_PROCESS,
      processCheckeeper: process.env.CHECKEEPER_PROCESS,
      processInvoices: process.env.INVOICES_PROCESS,
      processTwilio: process.env.TWILIO_PROCESS,
      processTelegramBots: process.env.TELEGRAM_BOTS_PROCESS,
    }
    public postal = {
      sendInvoices: process.env.POSTAL_SEND_INVOICES,
    }
    public telegram = {
      polling: process.env.TELEGRAM_POLLING,
      webhookurl: process.env.TELEGRAM_WEBHOOKURL,
    }
    public graylog = {
      host: process.env.GRAYLOG_HOST,
      port: process.env.GRAYLOG_PORT,
      name: process.env.GRAYLOG_NAME,
    }
    public public_url = process.env.PUBLIC_URL
    public square_prod = process.env.SQUARE_PROD
    public authorize_prod_endpoint = process.env.AUTHORIZE_ENDPOINT
    public clover_prod = process.env.CLOVER_PROD
}

export const config = new Config()