// import { config } from './config'
// import { Logger } from './utils/logger'
// import mongoose from 'mongoose'

// mongoose.connect(config.mongoose.url, config.mongoose.options).then(() => {
//     Logger.info('Mongod connected...!')
// })