import express, { Response } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { getErrorResponse, getResponse } from './utils/response';
import morgan from 'morgan';
import fs from 'fs';
import path from 'path';
import { IRequest } from './interface/request';
import { Logger } from './utils/logger';
import { config } from './config';
import routes from './api';

class Server {

    public app = express();

    constructor() {
        this.config();
        this.routes();
    }

    private config() {
        this.app.use(express.json())
        this.app.use(cors({ origin: '*' }));
        this.app.use(helmet());
        this.app.use(morgan('dev'));
        this.app.use('/api', routes)
        if (!fs.existsSync(path.join(__dirname, '../', 'migrations'))) {
            Logger.info('migration folder created...')
            fs.mkdirSync(path.join(__dirname, '../', 'migrations'))
        }

    }

    private routes () {
        this.app.get('/', (req: IRequest, res: Response) => {
            res.send(getResponse('Detected', null, true))
        })
        this.app.use((req, res, next) => {
            res.status(404).send(getErrorResponse('Not found'));
        });
    }
}

export default new Server().app