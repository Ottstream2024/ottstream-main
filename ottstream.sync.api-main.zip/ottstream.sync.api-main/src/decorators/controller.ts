import 'reflect-metadata'

export function controller(value: any) {
    return function (constructor: Function) {
      constructor.prototype['name'] = value;
      constructor.prototype['prefx'] = `/${value}`;
    };
  }