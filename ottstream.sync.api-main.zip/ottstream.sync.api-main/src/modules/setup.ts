import mongoose from "mongoose"
import { Logger } from "../utils/logger"
import { config } from "../config"

export const ConnectWorker = async (pid: number | string) => {
    mongoose.connect(config.mongoose.url, {
    minPoolSize: 90,
    }).then(async () => {
        Logger.info(`${pid} connected to mongodb...!`)
    }).catch(err =>Logger.error(err))
}