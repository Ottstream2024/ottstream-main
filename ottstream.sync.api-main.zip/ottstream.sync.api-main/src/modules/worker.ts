import { injectable } from "../utils/dependency/injectable";
import { fork } from "child_process";
import * as cron from 'node-cron'
import { Logger } from "../utils/logger";
import path from 'path'
import { IWorkerJob } from "../interface/worker";

@injectable()
export class WorkerService {
    private jobs: IWorkerJob[] = []

    public register(data: IWorkerJob) {
        this.jobs.push(data)
    } 

    public schedule() {
        Logger.info(`Registered ${this.jobs.length} jobs..`)        
        this.jobs.forEach(job => cron.schedule(job.time, () => {
            job.cb()
        }));
    }

    public expireLocations() {
        try {
            Logger.info('Sync job running')
            const jobPath = path.join(__dirname, './jobs/locations.ts')
            const worker = fork(jobPath)
    
            worker.on('exit', code => {
                Logger.info(`Worker (${worker.pid}) finished job, ${code}`)
            })
    
            worker.on('error', error => {
                Logger.info(`Worker (${worker.pid}) out from error, ${error.message}`)
            })
        } catch (error) {
            Logger.error(error)
        }
    }

    public test() {
        try {
            const jobPath = path.join(__dirname, './jobs/test.ts')

            const worker = fork(jobPath)
    
            worker.on('exit', code => {
                Logger.info(`Worker (${worker.pid}) finished job, ${code}`)
            })
    
            worker.on('error', error => {
                Logger.info(`Worker (${worker.pid}) out from error, ${error.message}`)
            })
        } catch (error) {
            Logger.error(error)
        }
    }

    public generateInvoice(days: number) {
        try {
            const jobPath = path.join(__dirname, './jobs/invoices.ts')
            const worker = fork(jobPath)
            worker.send({ days});
            Logger.info(`Worker setup days is - ${days}`)
            worker.on('exit', code => {
                Logger.info(`Worker (${worker.pid}) with ${days} day interval finished job, ${code}`)
            })
    
            worker.on('error', error => {
                Logger.info(`Worker (${worker.pid}) with ${days} day interval out from error, ${error.message}`)
            })
        } catch (error) {
            Logger.error(error)
        }
    }

    public syncProviders() {
        try {
            const jobPath = path.join(__dirname, './jobs/providers.ts')
            const worker = fork(jobPath)
            worker.on('exit', code => {
                Logger.info(`Worker (${worker.pid}) finished job, ${code}`)
            })
    
            worker.on('error', error => {
                Logger.info(`Worker (${worker.pid}) out from error, ${error.message}`)
            })
        } catch (error) {
            Logger.error(error)
        }
    }
}