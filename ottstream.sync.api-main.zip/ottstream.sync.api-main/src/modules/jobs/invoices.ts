import moment from "moment"
import { ConnectWorker } from "../setup"
import { clientLocationRepository, clientRepository, invoiceRepository, ottProviderPaymentGatewayRepository, subscriptionRepository } from "../../repository"
import SubscriptionService from "../../services/subscription_service"
import { Logger } from "../../utils/logger"

process.on('message', async (data: any) => {
  const { days } = data;
  Logger.info(`Sent days ${days}`);

  await invoicesHandler(days); // Pass variables to your handler function
});

async function invoicesHandler(days: number) {
  try {
    await ConnectWorker(process.pid)

    const currentDate = moment()
    const expireDate = currentDate.add(days, 'days').format('YYYY-MM-DD')

    const startDate = moment().add(16, 'days').format('YYYY-MM-DD')

    let filter = {
        subscriptionState: 3,
        clientId: { $ne: null },
        subscriptionExpireDate: {
          $gte: moment(expireDate).startOf('day').toDate(),
          // $gte: moment(startDate).startOf('day').toDate(),
          $lte: moment(expireDate).endOf('day').toDate()
        }
    }
    const locations = await clientLocationRepository.getClientLocations(filter, [
        { path: 'clientId' }
    ])
    let count = 1

    if (!locations.length) {
        Logger.warn(`Locations for generationg invoices not found...!`)
        process.exit()
    }

    for (let i = 0; i < locations.length; i++) {
        const location = locations[i];

        const locationLastInvoice = await invoiceRepository.getLast({ "payloadCalculated.locations.locationId": location._id.toString() })

        if (!locationLastInvoice || locationLastInvoice.type !== 2) {
              const subscriptions = await subscriptionRepository.getList({
                location: location._id, state: 1
            })
            let endDate = null
            const packageInfos = subscriptions.map(item => {
                if (!endDate) endDate = moment(item.endDate)
                else if (moment(endDate).isBefore(item.endDate)) endDate = moment(item.endDate)
                return item.package.toString()
            })

            const payload = {
                locations: [
                  {
                    locationId: location._id.toString(),
                    packageInfos,
                    packageRemoves: [],
                    recurringPaymentInfos: [],
                    room: location.roomsCount,
                    globalAction: 1,
                    month: 1,
                  },
                ],
                equipments: [],
                client: location.clientId._id.toString(),
              };

              const payload6Month = { ...payload };
              const payload12Month = { ...payload };
              const { client } = payload;
              const clientInfo = await clientRepository.getClientById(client);
              try {
                if (!clientInfo.finance || (clientInfo.finance && !clientInfo.finance.paperlessBilling)) {
                    count++
                    const { provider } = clientInfo;
                    const paymentGateways = await ottProviderPaymentGatewayRepository.getOttProviderPaymentGatewayByProviderId(
                        provider._id.toString()
                      );
                    let bankFeePercent = 0;
                    let bankFeeFixed = 0;
                    if (paymentGateways.length && paymentGateways[0].cardsFee && paymentGateways[0].cardsFee.percent) {
                        bankFeePercent = paymentGateways[0].cardsFee.percent;
                    }
                    if (paymentGateways.length && paymentGateways[0].cardsFee && paymentGateways[0].cardsFee.fixed) {
                        bankFeeFixed = paymentGateways[0].cardsFee.fixed;
                    }
                    const calculatedPayload = await SubscriptionService.calculateSubscription(false, payload, provider);
                    let { price, totalPrice} = calculatedPayload;
                    let bankFee = 0;
                    if (bankFeePercent) {
                        bankFee = (price * bankFeePercent) / 100;
                        bankFee += bankFeeFixed;
                      }
                
                    totalPrice = price + bankFee;
                    calculatedPayload.totalPrice = totalPrice;
                    calculatedPayload.bankFee = bankFee;
                    payload6Month.locations.forEach((item) => {
                        item.month = 6;
                    });
                    const calculated6Month = await SubscriptionService.calculateSubscription(false, payload6Month, provider);
                    price = calculated6Month.price;
                    totalPrice = calculated6Month.totalPrice;
                    bankFee = 0;
                    if (bankFeePercent) {
                        bankFee = (price * bankFeePercent) / 100;
                        bankFee += bankFeeFixed;
                    }
        
                    totalPrice = price + bankFee;
                    calculated6Month.totalPrice = totalPrice;
                    calculated6Month.bankFee = bankFee;
                    const calculated6MonthTotal = calculated6Month.totalPrice;
                    payload12Month.locations.forEach((item) => {
                        item.month = 12;
                    });
                    const calculated12Month = await SubscriptionService.calculateSubscription(false, payload12Month, provider);
                    price = calculated12Month.price;
                    totalPrice = calculated12Month.totalPrice;
                    bankFee = 0;
                    if (bankFeePercent) {
                    bankFee = (price * bankFeePercent) / 100;
                    bankFee += bankFeeFixed;
                    }
                    totalPrice = price + bankFee;
                    calculated12Month.totalPrice = totalPrice;
                    calculated12Month.bankFee = bankFee;
                    const calculated12MonthTotal = calculated12Month.totalPrice;
                    const generateDisplayInfo = {
                        client,
                        clientAddress:
                          clientInfo.addresses && clientInfo.addresses.filter((r) => r.forContactInvoice).length
                            ? clientInfo.addresses.filter((r) => r.forContactInvoice)[0]
                            : null,
                        locationsInfo: {
                          totalTax: calculatedPayload.totalTax,
                          bankFee: calculatedPayload.bankFee,
                          locationTax: calculatedPayload.locationTax,
                          locations: calculatedPayload.locations,
                        },
                        equipmentInfo: {
                          totalTax: calculatedPayload.totalTax,
                          bankFee: calculatedPayload.bankFee,
                          equipmentTax: calculatedPayload.equipmentTax,
                          equipments: calculatedPayload.equipments,
                          equipment: calculatedPayload.equipment,
                        },
                        refund: calculatedPayload.refund,
                        lastPaymentType: calculatedPayload.refund,
                        availablePaymentTypes: calculatedPayload.availablePaymentTypes,
                        calculated6Month,
                        calculated12Month,
                        calculated6MonthTotal,
                        calculated12MonthTotal,
                        subscriptionEndDate: endDate.toDate(),
                      };
        
                      await invoiceRepository.createSubscriptionInvoice(
                        2,
                        false,
                        calculatedPayload.totalPrice,
                        payload,
                        calculatedPayload,
                        generateDisplayInfo,
                        provider._id.toString(),
                        client,
                        location._id.toString(),
                        {
                          provider,
                        }
                      );
                      for (const subscription of subscriptions) {
                        await subscriptionRepository.updateSubscriptionById(subscription._id.toString(), {
                          leftInvoiceGenerated: true,
                        });
                      }
        
                      Logger.info(`Generated invoice for location ${location.login} total(${count} from ${locations.length-i})`)
                  }
              } catch (error) {
                    Logger.error(`Generating invoice error...!`)
              }
        } else {
          Logger.info(`Bill for ${location.login} already created`)
        }
    }

    process.exit()
  } catch (error) {
    process.exit()
  }    
}
