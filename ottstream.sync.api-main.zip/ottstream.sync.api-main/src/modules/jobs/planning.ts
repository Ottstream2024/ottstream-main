import { RedisService } from "../../redis"
import { inject } from "../../utils/dependency/inject"

class PlanningJobs {
    @inject()
    private redis: RedisService

    public async init(){
        
    }

}

const instance = new PlanningJobs()
instance.init()