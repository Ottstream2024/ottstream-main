import { clientLocationRepository, clientRepository, subscriptionRepository } from "../../repository"
import { Logger } from "../../utils/logger"
import { ConnectWorker } from "../setup"
import moment from 'moment'

async function locationsHandler() {
    try {
        await ConnectWorker(process.pid)
        const filter = {
            subscriptionState: 3, //active
            clientId: { $ne: null },
            subscriptionExpireDate: { $lt: moment().add(4, 'hours').toDate() }
        }
        const locations: any = await clientLocationRepository.getClientLocationsList(filter, [{
            path: 'clientId'
        }])
        if (!locations.length) {
            Logger.warn('Locations expires now not found...!')
            process.exit()
        }
        for (let i = 0; i < locations.length; i++) {
            const location = locations[i];
            let updateBody = { subscriptionState: 0 }
            const client: any = location.clientId
            let info = { ...client.info }
            let greatestStatus = null
            info.locations = info.locations.map(item => {
                if (item.login === location.login) item.subscriptionState = 0
                if (!greatestStatus || greatestStatus < item.subscriptionState) greatestStatus = item.subscriptionState
    
                return item
            })
            await Promise.all([
                clientLocationRepository.update({ _id: location._id }, updateBody),
                clientRepository.updateAll({ _id: client._id }, { info, subscriptionState: greatestStatus }),
                subscriptionRepository.updateAll({ location: location._id, state: 1, isActive: true }, { state: 2, isActive: false })
            ])
            Logger.info(`Changed location state to inactive ${i+1}/${locations.length}`)
        }
    
        Logger.info(`Locations process finish, updated ${locations.length} locations`)
        process.exit()
    } catch (error) {
        process.exit()
    }
}

locationsHandler()
