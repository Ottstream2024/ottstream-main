console.log('worker runnning and working correnctly');
// import ClientLocation from "../../models/client/client_location.model";
import { getClientLocation } from "../../repository/client_location_repo";
import mongoose from 'mongoose'
import { Logger } from "../../utils/logger";
import { ConnectWorker } from "../setup";


async function work() {
    await ConnectWorker(process.pid)
    const one = await getClientLocation()
    console.log(one);
}

work()
