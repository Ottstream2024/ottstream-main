import { ottProviderRepository } from "../../repository";
import OttSyncService from "../../services/ott_provider_sync_service";
import OttSyncCrudService from "../../services/ott_sync_crud_service";
import { Logger } from "../../utils/logger";
import { ConnectWorker } from "../setup";

async function syncProviders() {
      try {
        await ConnectWorker(process.pid)

        const allProviders: any = await ottProviderRepository.getOttProviders(
          { status: 1 },
          [
            {
              path: 'parent',
            },
          ],
          { _id: 1, syncState: 1, number: 1, name: 1, parent: 1, comment: 1 }
        );
        const providersThatNeedSync: any = allProviders.filter((r) => r.syncState !== 1);
        const createList = [];
        const updateList = [];
        const deleteList = [];
        const remoteProviders = await OttSyncCrudService.getProviders();

        const toAddList: any = providersThatNeedSync.filter(
          (r) => !remoteProviders.filter((a) => a.id === r.number).length && r.status !== 0
        );
        const toUpdateList: any = providersThatNeedSync.filter(
          (r) => remoteProviders.filter((a) => a.id === r.number).length && r.status !== 0
        );
        let toDeleteList = providersThatNeedSync.filter(
          (r) => remoteProviders.filter((a) => a.id === r.number).length && r.status === 0
        );
        toDeleteList = toDeleteList.concat(
          remoteProviders.filter((r) => !allProviders.filter((a) => a.number === r.id).length)
        );
        for (const item of toAddList) {
          const fields = await OttSyncService.GetProviderFieldsForMiddleware(item._id);
          createList.push({
            providerId: item._id,
            id: item.number,
            name: item.name?.length ? item.name[0].name : `no name for Ott number ${item.number}`,
            parent_provider_id: item?.parent?.number || 0,
            contacts_provider_id: fields.contacts_provider_id,
            email: fields.email,
            comment: item.comment,
            address: fields.address,
            phone: fields.phone,
          });
          if (item._id) await OttSyncService.markAsSyncing(item._id);
        }
        for (const item of toUpdateList) {
          const fields = await OttSyncService.GetProviderFieldsForMiddleware(item._id);
          updateList.push({
            providerId: item._id,
            id: item.number,
            name: item.name?.length ? item.name[0].name : `no name for Ott number: ${item.number}`,
            parent_provider_id: item?.parent?.number || 0,
            contacts_provider_id: fields.contacts_provider_id,
            email: fields.email,
            comment: item.comment,
            address: fields.address,
            phone: fields.phone,
          });
          if (item._id) await OttSyncService.markAsSyncing(item._id);
        }
        for (const item of toDeleteList) {
          deleteList.push({ id: item.number || item.id, providerId: item._id });
          if (item._id) await OttSyncService.markAsSyncing(item._id);
        }
        //
        Logger.info(
          `providers to sync - create: ${createList.length} update: ${updateList.length} delete: ${deleteList.length}`
        );
        for (const item of updateList) {
          const sendData = { ...item };
          delete sendData.providerId;
          const updateResponse: any = await OttSyncCrudService.updateProvider(sendData);
          if (updateResponse.filter((r) => r.id === item.id).length) {
            if (item.providerId) await OttSyncService.markAsSync(item.providerId);
            Logger.info(`ott number: ${item.id} synced updated successfully`);
          }
        }
        for (const item of createList) {
          const sendData = { ...item };
          delete sendData.providerId;
          const updateResponse: any = await OttSyncCrudService.createProvider(sendData);
          if (updateResponse.id === item.id) {
            if (item.providerId) await OttSyncService.markAsSync(item.providerId);
            Logger.info(`ott number: ${item.id} synced created successfully`);
          }
        }
        for (const item of deleteList) {
          const deleteResponse = await OttSyncCrudService.deleteProvider(item.id);
          if (deleteResponse) {
            if (item.providerId) await OttSyncService.markAsSync(item.providerId);
            Logger.info(`ott number: ${item.id} synced deleted successfully`);
          }
        }
        process.exit()
      } catch (ex) {
        Logger.error(ex);
        process.exit()
      }
  }

  syncProviders().then(() => Logger.info('Providers sync executed..!'))