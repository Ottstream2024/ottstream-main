export class Controller {
    public prefx: string;
}