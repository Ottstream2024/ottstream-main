#!/bin/sh
docker-compose -f docker-compose.master.yml build
docker-compose -f docker-compose.master.yml push

