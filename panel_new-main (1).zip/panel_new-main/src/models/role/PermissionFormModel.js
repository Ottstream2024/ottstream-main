export default class PermissionFormModel {
    constructor() {
    }

    fetch(data) {
        this.id = data.id;
        this.keyword = data.keyword;
        this.description = data.description;
        this.state = data.state;
    }

    reset() {
        this.id = null;
        this.keyword = null;
        this.description = null;
        this.state = null;
    }
}
