export default class RoleFormModel {
  constructor() {}
  fetch(data) {
    this.reset();
    this.id = data.id;
    this.name = data.name;
    this.keyword = data.keyword;
    this.permissions = [];
    this.permissions = data.permissions;
    this.state = data.state;
  }
  reset() {
    this.id = null;
    this.name = null;
    this.keyword = null;
    this.permissions = [];
    this.state = null;
  }
  getPermissionsObjects() {
    let perms = [];
    for (let item of this.permissions) {
      perms.push(item.id);
    }
    return perms;
  }
}
