export default class LoginFormModel {
  constructor() {}
  fetch(data) {
    this.email = data.email;
    this.password = data.password;
    this.rememberMe = data.rememberMe;
  }
  reset() {
    this.email = null;
    this.password = null;
    this.rememberMe = null;
  }
}
