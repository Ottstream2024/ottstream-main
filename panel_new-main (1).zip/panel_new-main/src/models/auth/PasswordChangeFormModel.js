export default class PasswordChangeFormModel {
    constructor() {
    }

    fetch(data) {
        this.password = data.password;
        this.new_password = data.new_password;
    }
    reset() {
        this.password = null;
        this.new_password = null;
    }
}
