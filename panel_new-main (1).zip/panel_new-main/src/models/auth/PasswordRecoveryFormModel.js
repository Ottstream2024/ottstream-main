export default class PasswordRecoveryFormModel {
    constructor() {
    }

    fetch(data) {
        this.email = data.email;
    }
    reset() {
        this.email = null;
    }
}
