export default class ChatModel {
    constructor() {
      this.reset();
    }
  
    toSave() {
      return {};
    }
  
    reset() {
      this.search = '';
      this.date = {
        start: null,
        end: null
      },
      this.allResellers = false;
      this.own = true;
      this.resellers = [];
      this.filterCount = [];
    }
  
    resetCurrentData(dataKey) {
      let index = this.filterCount.indexOf(dataKey);
      this.filterCount.splice(index, 1);
      switch (dataKey) {
        case "search": {
          this.search = "";
          break;
        }
        case "date": {
          this.date = {
            start: null,
            end: null
          };
          break;
        }
      }
    }
  
    getFilterCount() {
      if (this.search.trim() && !this.filterCount.includes("search")) {
        this.filterCount.push("search");
      }

      if (
        this.date?.start &&
        this.date?.end &&
        !this.filterCount.includes("date")
      ) {
        this.filterCount.push("date");
      }
    }
  }
  