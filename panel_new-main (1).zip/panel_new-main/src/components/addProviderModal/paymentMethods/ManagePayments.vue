<template>
  <div class="P-manage-payments">
    <div class="P-payment-type G-align-start" v-if="!editMode">
      <ul>
        <li
          class="G-flex secondary--text"
          :class="{
            'P-active-payment': selectedPaymentType === paymentType.creditCard
          }"
          @click="selectPaymentType(paymentType.creditCard)"
        >
          <svg>
            <use xlink:href="sprite.svg#credit-card-icon"></use>
          </svg>
          Credit card
        </li>
        <li
          class="G-flex secondary--text"
          :class="{
            'P-active-payment': selectedPaymentType === paymentType.bankAccount
          }"
          @click="selectPaymentType(paymentType.bankAccount)"
        >
          <svg>
            <use xlink:href="sprite.svg#bank-icon"></use>
          </svg>
          Bank account
        </li>
      </ul>
    </div>
    <div class="P-payment-components">
      <CreditCard
        v-if="selectedPaymentType === paymentType.creditCard"
        ref="CreditCard"
      />
      <BankAccount
        v-if="selectedPaymentType === paymentType.bankAccount"
        ref="BankAccount"
      />
    </div>
  </div>
</template>
<script>
import { mapState, mapMutations } from "vuex";
import CreditCard from "./components/CreditCard";
import BankAccount from "./components/BankAccount";

export default {
  name: "ManagePayments",
  components: { BankAccount, CreditCard },
  computed: {
    ...mapState({
      paymentType: state => state.paymentMethods.paymentType,
      selectedPaymentType: state => state.paymentMethods.selectedPaymentType,
      editMode: state => state.paymentMethods.editMode
    })
  },
  
  methods: {
    ...mapMutations({
      selectPaymentTypeMutation: "paymentMethods/selectPaymentType"
    }),

    selectPaymentType(paymentType) {
      this.selectPaymentTypeMutation(paymentType);
    }
  }
};
</script>
<style lang="scss" scoped>
@import "src/assets/scss/variables";

.P-payment-type {
  ul {
    margin: 0;
    padding: 1px;
    box-shadow: 0 0 5px #00000012;
    border-radius: 27px;
    display: flex;
    align-items: flex-start;

    li {
      svg {
        width: 22px;
        height: 22px;
        fill: $secondary-color;
        margin-right: 10px;
      }

      font-size: $txt14;
      font-weight: $semiBold;
      cursor: pointer;
      padding: 10px 20px;
      border-radius: 27px;
      transition: $transition;
      text-transform: capitalize;

      &.P-active-payment {
        background-color: $neutral-color25;
      }
    }
  }
}
.theme--dark{
  .P-payment-type{
    ul{
      background-color: $darkMode43;

    }
    svg{
      filter: grayscale(1) invert(1);
    }
    .P-active-payment{
      background-color: rgba(255,255,255,0.15);
    }
  }
}
</style>
