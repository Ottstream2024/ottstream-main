<template>
  <div class="content-email-section">
    <div>
      <ott-input
        :error="contactAdminModule.isError || $v.emailValue.$error"
        v-model="emailValue"
        label="Email Address*"
        @emitFunc="validate"
      />
    </div>
    <div class="content-email-checkboxes">
      <ott-checkbox :disabled="inMain || !contactAdminModule.emails.length" label="Disable" v-model="inUse" />
      <ott-checkbox :disabled="inUse || isMainCheck" label="Is main" v-model="inMain" />
      <ott-checkbox label="Is Info" v-model="isInfo" />
      <ott-checkbox label="Is support" v-model="isSupport" />
      <ott-checkbox label="For Invoice" v-model="forInvoice" />
    </div>
    <ott-switch
      v-model="isForSent"
      label="Use For Sent"
      :className="'secondary-dark--text'"
    />
    <div class="P-for-sent-data" v-if="isForSent">
      <div class="for-sent-cont">
        <div>
          <ott-input
            label="SMTP Server"
            v-model="smtpServer"
            :error="$v.smtpServer.$error"
          />
        </div>
        <div>
          <ott-input
            label="SMTP Port"
            v-model="smtpPort"
            :is-percent="true"
            :error="validatePort || $v.smtpPort.$error"
            :maxLength="5"
            :customInputClass="'P-smpt-port'"
            @emitFunc="validateSMTPPort"
          />
        </div>
        <div>
          <ott-input
            label="username"
            v-model="username"
            :error="$v.username.$error"
          />
        </div>
        <div>
          <password-input
            label="Password"
            v-model="useForSentPassword"
            :error="$v.useForSentPassword.$error"
          />
        </div>
      </div>
      <div class="content-email-checkboxes">
        <ott-checkbox label="use SSL" v-model="useSSL" />
      </div>
    </div>
    <ErrorMessageContainer
      v-if="contactAdminModule.isError || contactAdminModule.isCheckError"
      :message="contactAdminModule.errorMessage"
      :styles="{ width: 'max-content' }"
    />
    <save-reset-buttons
      v-if="contactAdminModule.isAddEmail || contactAdminModule.isEditEmail"
      :right-label="!contactAdminModule.isAddEmail ? 'Save' : 'Add'"
      :is-loading="isLoading"
      :left-click-func="() => cancel()"
      :right-click-func="() => save()"
    />
  </div>
</template>

<script>
import { mapActions, mapMutations, mapState } from "vuex";
import { required, email } from "vuelidate/lib/validators";
import { ContactInfoModel } from "@/models/providers/contactInfoModel";
import { AddProviderModel } from "@/models/providers/addProviderModel";
import OttButton from "@/components/vuetifyComponents/OttButton";
import OttCheckbox from "@/components/vuetifyComponents/OttCheckbox";
import OttInput from "@/components/vuetifyComponents/OttInput";
import PasswordInput from "@/components/PasswordInput";
import OttSwitch from "@/components/vuetifyComponents/OttSwitch";
import ErrorMessageContainer from "@/components/customComponents/ErrorMessageContainer";
import SaveResetButtons from "@/components/SaveResetButtons";

export default {
  name: "EmailContent",
  components: {
    SaveResetButtons,
    ErrorMessageContainer,
    OttSwitch,
    PasswordInput,
    OttInput,
    OttCheckbox,
    OttButton
  },
  validations: {
    emailValue: { required, email },
    smtpServer: { required },
    smtpPort: { required },
    username: { required },
    useForSentPassword: { required }
  },
  data() {
    return {
      validatePort: false,
      isMainCheck: false,
      currentEmailValue: ''
    };
  },
  computed: {
    ...mapState({
      contactAdminModule: state => state.contactAdminModule,
      manageAdminModule: state => state.manageAdminModule,
      companyInfo: state => state.companyInfoAdminModule,
      adminPersonalInfoModule: state => state.personalInfoAdminModule,
      isLoading: state => state.appModule.isLoading
    }),

    editableEmailDataIndex() {
      return this.contactAdminModule.editableEmailDataIndex
    },

    emailValue: {
      get() {
        return this.contactAdminModule.emailForm.emailValue;
      },
      set(value) {
        this.updateEmailValue(value);
      }
    },
    inUse: {
      get() {
        return this.contactAdminModule.emailForm.inUse;
      },
      set(value) {
        this.updateInUse(value);
      }
    },
    inMain: {
      get() {
        return this.contactAdminModule.emailForm.inMain;
      },
      set(value) {
        this.updateInMain(value);
      }
    },
    isInfo: {
      get() {
        return this.contactAdminModule.emailForm.isInfo;
      },
      set(value) {
        this.updateIsInfo(value);
      }
    },
    isSupport: {
      get() {
        return this.contactAdminModule.emailForm.isSupport;
      },
      set(value) {
        this.updateIsSupport(value);
      }
    },
    forInvoice: {
      get() {
        return this.contactAdminModule.emailForm.forInvoice;
      },
      set(value) {
        this.updateForInvoice(value);
      }
    },
    isForSent: {
      get() {
        return this.contactAdminModule.emailForm.useForSent.isForSent;
      },
      set(value) {
        this.updateUseForSentIsForSent(value);
      }
    },
    smtpServer: {
      get() {
        return this.contactAdminModule.emailForm.useForSent.smtpServer;
      },
      set(value) {
        this.updateUseForSentSmtpServer(value);
      }
    },
    smtpPort: {
      get() {
        return this.contactAdminModule.emailForm.useForSent.smtpPort;
      },
      set(value) {
        this.updateUseForSentSmtpPort(value);
      }
    },
    username: {
      get() {
        return this.contactAdminModule.emailForm.useForSent.username;
      },
      set(value) {
        this.updateUseForSentUsername(value);
      }
    },
    useSSL: {
      get() {
        return this.contactAdminModule.emailForm.useForSent.useSSL;
      },
      set(value) {
        this.updateUseForSentUseSSL(value);
      }
    },
    useForSentPassword: {
      get() {
        return this.contactAdminModule.emailForm.useForSent.useForSentPassword;
      },
      set(value) {
        this.updateUseForSentUseForSentPassword(value);
      }
    }
  },
  mounted() {
   this.isMainCheck =  this.getCurrentData()
   this.currentEmailValue = this.emailValue
  },
  methods: {
    ...mapActions({
      validateEmail: 'manageAdminModule/validateEmail',
      addEmail: 'contactAdminModule/addEmail',
      manageEmail: 'contactAdminModule/manageEmail',
      editAdmin: 'manageAdminModule/editAdmin',
      getAdminData: 'manageAdminModule/getAdminData',

    }),

    ...mapMutations({
      updateEmailValue: 'contactAdminModule/updateEmailValue',
      updateInUse: 'contactAdminModule/updateInUse',
      updateInMain: 'contactAdminModule/updateInMain',
      updateIsInfo: 'contactAdminModule/updateIsInfo',
      updateIsSupport: 'contactAdminModule/updateIsSupport',
      updateForInvoice: 'contactAdminModule/updateForInvoice',
      updateUseForSentIsForSent: 'contactAdminModule/updateUseForSentIsForSent',
      updateUseForSentSmtpServer: 'contactAdminModule/updateUseForSentSmtpServer',
      updateUseForSentSmtpPort: 'contactAdminModule/updateUseForSentSmtpPort',
      updateUseForSentUsername: 'contactAdminModule/updateUseForSentUsername',
      updateUseForSentUseSSL: 'contactAdminModule/updateUseForSentUseSSL',
      updateUseForSentUseForSentPassword: 'contactAdminModule/updateUseForSentUseForSentPassword',
      setError: 'contactAdminModule/setError',
      setCheckValidateEmail: 'contactAdminModule/setCheckValidateEmail',
      checkIsMainEmail: 'contactAdminModule/checkIsMainEmail',
      addEmailSave: 'contactAdminModule/addEmailSave',
      saveEditEmailForm: 'contactAdminModule/saveEditEmailForm',
      setProviderId: 'manageAdminModule/setProviderId',
      setProviderData: 'manageAdminModule/setProviderData',
      updateContactData: 'contactAdminModule/updateContactData',
      updateCompanyInfo: 'companyInfoAdminModule/updateCompanyInfo',
      updatePersonalInfo: 'personalInfoAdminModule/updatePersonalInfo',
      cancelEditEmailForm: 'contactAdminModule/cancelEditEmailForm',
      addEmailCancel: 'contactAdminModule/addEmailCancel',
    }),

    getCurrentData(){
      let currentIndex = false
      if(!this.contactAdminModule.isAddEmail && this.contactAdminModule.emails.length){
        this.contactAdminModule.emails.forEach((item,index)=>{
          if(item.emailValue===this.emailValue){
              currentIndex = item.inMain
          }
        })
      }
      return currentIndex
    },
    validateSMTPPort() {
      if (+this.smtpPort >= 65535) {
        this.smtpPort = 65534;
      }
      this.validatePort = this.smtpPort < 1;
      this.validatePort = this.smtpPort.split("")[0] === "0";
    },
    validate() {
      this.$v.emailValue.$touch();
      this.setError({
        value: false,
        message: ""
      });
    },
    async validationEmail() {
      let isValidate = false;
      this.$v.emailValue.$touch();
      this.validationCheckList();

      if (this.isForSent) {
        isValidate = this.validateForSent();
      } else {
        isValidate = !this.$v.emailValue.$error;
      }

      this.setCheckValidateEmail(isValidate);
    },

    validationCheckList() {
      if (!this.contactAdminModule.emails.length) {
        this.updateInMain(true);
      }
    },
    validateForSent() {
      this.$v.smtpServer.$touch();
      this.$v.smtpPort.$touch();
      this.$v.username.$touch();
      this.$v.useForSentPassword.$touch();

      return (
        !this.$v.smtpServer.$error &&
        !this.$v.smtpPort.$error &&
        !this.$v.username.$error &&
        !this.$v.useForSentPassword.$error &&
        !this.validatePort &&
        !this.$v.emailValue.$error
      );
    },
    async save() {
      let isDuplicatedEmail = false

      if (this.contactAdminModule.isEditEmail) {
        isDuplicatedEmail = this.contactAdminModule.emails.some((item, index) =>
          item.emailValue === this.emailValue && index !== this.editableEmailDataIndex
        );
      } else {
        isDuplicatedEmail = this.contactAdminModule.emails.some((item) => item.emailValue === this.emailValue);
      }

      this.validationEmail()
      this.checkIsMainEmail(this.contactAdminModule.emailForm);

      if (this.contactAdminModule.validateEmail){
        if (isDuplicatedEmail ) {
          this.setError({
            value: true,
            message: "Duplicate Email Address"
          });

        } else {
          if (this.contactAdminModule.isAddEmail) {

            if (this.manageAdminModule.providerId) {
              const email = new ContactInfoModel()
              await this.addEmail(email.manageEmail(this.contactAdminModule.emailForm, this.manageAdminModule.providerId,this.contactAdminModule.isAddEmail)).then(async data=>{
                this.addEmailSave(email.fetchEmail(data) );
                await this.updateProviderData()
              })
            }else{
              this.addEmailSave();
            }

          } else {

            if (this.manageAdminModule.providerId) {
              const email = new ContactInfoModel()
              let x=  email.manageEmail(this.contactAdminModule.emailForm, this.manageAdminModule.providerId,this.contactAdminModule.isAddEmail)
              const body = {
                id:this.contactAdminModule.emailForm.id,
                data:x
              }
              await this.manageEmail(body).then(async () => {
                this.saveEditEmailForm();
                  await this.updateProviderData()
                })
            } else {
              this.saveEditEmailForm();
            }

          }
        }
      }

      const response = await this.getAdminData()
      if (response) {
        this.updateContactData(response);
      }
    },
    async updateProviderData() {
      const provider = new AddProviderModel();
      const data = provider.updateData(
              this.companyInfo.formData,
              this.contactAdminModule,
              this.adminPersonalInfoModule.companyAddressesForm,
              this.manageAdminModule.providerId
      );
      await this.editAdmin(data).then(data => {
        if (data) {
          this.updateData(data);
        }
      });
    },
    updateData(data) {
      this.setProviderId(data.id);
      this.setProviderData(data)
      this.updateContactData(data);
      this.updateCompanyInfo(data);
      this.updatePersonalInfo(data);
    },
    async cancel() {
      if (!this.contactAdminModule.isAddEmail) {
        this.cancelEditEmailForm();
      } else {
        this.addEmailCancel();
      }

      const response = await this.getAdminData()
      if (response) {
        this.updateContactData(response);
      }
    }
  },

};
</script>

<style lang="scss" scoped>
@import "./src/assets/scss/variables";

.content-email-section {
  & .for-sent-cont {
    display: flex;
    width: 68%;
    flex-wrap: wrap;

    & > div {
      width: 50%;
      padding-right: 20px;
    }
  }

  & > :nth-child(1) {
    width: 47%;
  }

  & > :nth-child(3) {
    width: 16%;
  }
}

.content-email-checkboxes {
  display: flex;
  justify-content: space-between;
  width: 63%;
}

.content-email-section::v-deep {
  .v-text-field__details {
    margin-bottom: 0;
  }
}
</style>
