export const html = {
  html: `
  <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=0.5, user-scalable=1" />
  <title>Document</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;700&display=swap"
    rel="stylesheet"
  />
  <style>
    * {
      -webkit-box-sizing: border-box;
      box-sizing: border-box;
      font-family: "Montserrat", sans-serif;
    }
    body {
      margin: 0;
      padding: 0;
    }

    .ott {
      width: 800px;
      max-width: 800px;
      min-height: 100vh;
      max-height: 2000px;
      height: 100%;
      margin: 0 auto;
      border: 1px solid #edeef4;
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -webkit-box-orient: vertical;
      -webkit-box-direction: normal;
      -ms-flex-direction: column;
      flex-direction: column;
      -webkit-box-pack: justify;
      -ms-flex-pack: justify;
      justify-content: space-between;
    }

    .ott-head {
      padding: 65px 20px 15px;
      background-color: rgba(165, 170, 198, 0.2);
      -webkit-print-color-adjust: exact;
    }

    .ott-header-top {
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -webkit-box-align: center;
      -ms-flex-align: center;
      align-items: center;
      -webkit-box-pack: justify;
      -ms-flex-pack: justify;
      justify-content: space-between;
    }
    .ott-header-logo img {
      width: 141px;
      height: 30px;
    }
    .ott-header-ifo {
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -webkit-box-align: center;
      -ms-flex-align: center;
      align-items: center;
    }
    .ott-header-info-item {
      text-align: center;
      padding: 0 10px;
    }
    .ott-header-info-item + .ott-header-info-item {
      border-left: solid 1px #a5aac6;
    }
    .ott-header-info-item p {
      font-size: 8px;
      color: #164066;
    }
    .ott-head-address h3 {
      font-size: 8px;
      color: #164066;
      margin: 0;
    }
    .ott-head-content {
      margin-top: 30px;
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -webkit-box-pack: justify;
      -ms-flex-pack: justify;
      justify-content: space-between;
    }
    .ott-head-content-item {
      width: 48%;
    }
    .ott-head-content-item h3 {
      color: #164066;
      font-size: 14px;
      margin-bottom: 16px;
    }
    .ott-head-content-item-widget {
      /*width: 270px;*/
      height: 60px;
      background-color: #fff;
      -webkit-print-color-adjust: exact;
      border-radius: 5px;
      padding: 14px 12px;
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -webkit-box-align: center;
      -ms-flex-align: center;
      align-items: center;
    }
    .ott-head-content-item-widget .bill p {
      color: #164066;
      font-size: 8px;
      line-height: 12px;
      margin: 0;
    }
    .ott-head-content-item-widget .invoice {
      width: 100%;
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -webkit-box-align: center;
      -ms-flex-align: center;
      align-items: center;
      -webkit-box-pack: justify;
      -ms-flex-pack: justify;
      justify-content: space-between;
    }
    .ott-head-content-item-widget .invoice h4,
    .ott-head-content-item-widget .invoice p {
      color: #164066;
      font-size: 8px;
      line-height: 12px;
      margin: 0;
    }

    /* // Ott table */
    .ott-table {
      background-color: #fff;
      -webkit-print-color-adjust: exact;
      padding: 12px 20px 0;
    }
    .ott-table-title {
      color: #164066;
      font-size: 10px;
      margin: 0;
      padding-bottom: 12px;
      border-bottom: 2px solid rgba(165, 170, 198, 0.5);
    }
    .ott-table-header {
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -webkit-box-align: center;
      -ms-flex-align: center;
      align-items: center;
      width: 100%;
      padding-left: 12px;
      padding-top: 5px;
    }
    .ott-table-header .item {
      font-size: 8px;
      color: #164066;
      font-weight: 600;
    }
    .ott-table-login {
      width: 100%;
      background-color: rgba(165, 170, 198, 0.2);
      -webkit-print-color-adjust: exact;
      color: #164066;
      font-size: 8px;
      padding: 6px 12px;
      margin-top: 4px;
    }
    .list-item {
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -webkit-box-align: center;
      -ms-flex-align: center;
      align-items: center;
      width: 100%;
      padding: 5px 0 5px 12px;
      border-bottom: 2px solid rgba(165, 170, 198, 0.5);
    }
    .list-item .item {
      color: #164066;
      font-size: 8px;
    }
    .list-item .item span {
      color: #9da8bb;
    }
    .ott-table-total {
      width: 253px;
      margin-left: auto;
      margin-top: 10px;
      /*margin-right: 34px;*/
    }
    .ott-table-total .item {
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      /*-webkit-box-pack: justify;*/
      /*-ms-flex-pack: justify;*/
      /*justify-content: space-between;*/
      font-size: 8px;
      color: #164066;
      margin: 6px 0;
    }
    .ott-table-total .item p {
      min-width: 15px;
      text-align: start;
      margin: 0;
    }
    .ott-table-total .item p:first-child {
      width: 179px;
    }
    .pt-0 {
      padding-top: 0;
    }
    .border {
      border-bottom: 2px solid rgba(165, 170, 198, 0.5);
    }
    .pb-6 {
      padding-bottom: 6px;
    }
    .w-100 {
      width: 100%;
    }
    .flex-end {
      -webkit-box-pack: end;
      -ms-flex-pack: end;
      justify-content: flex-end;
    }
    .payments-block {
      background-color: #fff;
      -webkit-print-color-adjust: exact;
      padding: 0 20px 20px;
    }
    .payments-block-terms h2 {
      font-size: 10px;
      color: #164066
    }
    .payments-block-terms p {
      font-size: 8px;
      color: #164066
    }
    .cut-section {
      display: flex;
      display: -webkit-box;
      justify-content: space-between;
      -webkit-box-pack: justify;
      -ms-flex-pack: justify;
      position: relative;
      margin-bottom: 10px
    }
    .cut-section-border {
      width: 97%;
      position: absolute;
      right: 0;
      top: 8px;
    }
    .invoice-info {
      background-color: #edeef4;
      -webkit-print-color-adjust: exact;
      width: 80%;
      height: fit-content;
      border-radius: 4px;
      padding: 6px 11px;
      font-size: 8px;
      color: #164066
    }
    .invoice-info-qr {
      height: 42px;
      margin-top: -5px;
    }
    .flex {
      display: flex;
      display: -webkit-box;
    }
    .flex-between {
      display: flex;
      display: -webkit-box;
      justify-content: space-between;
      -webkit-box-pack: justify;
      -ms-flex-pack: justify;
    }
    .fill-out {
      font-size: 10px;
      color: #164066;
    }
    .credit-card-info {
      width: 80%;
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -webkit-box-orient: vertical;
      -webkit-box-direction: normal;
      -ms-flex-direction: column;
      flex-direction: column;
      -webkit-box-pack: justify;
      -ms-flex-pack: justify;
      justify-content: space-between;
    }
    .bordered-block {
      border: 1px solid #a5aac6;
      border-radius: 4px;
    }
    .credit-card-info .table {
      display: flex;
      display: -webkit-box;
    }
    .credit-card-info .table-item {
      width: 33.33%;
      border: 1px solid #a5aac6;
      padding: 2px 6px;
    }
    .credit-card-info .table-item:first-child {
      border-left: none ;
    }
    .credit-card-info .table-item:last-child,
    .credit-card-info .table-item:first-child,
    .credit-card-info .table-item:nth-child(2) {
      border-right: none;
    }
    .credit-card-info .bordered {
      border-bottom: 1px solid #a5aac6;
      padding-top: 15px;
    }
    .credit-card-info .terms {
      background-color: #edeef4;
      -webkit-print-color-adjust: exact;
      border-radius: 4px;
      padding: 6px 10px 10px;
    }
    .credit-card-info .terms p {
      color: #164066;
      font-size: 7px;
      margin: 0;
    }
    .credit-card-right-block {
      width: 17%;
      border: 1px solid #a5aac6;
      border-radius: 4px;
      padding: 10px 12px;
    }
    .flex-evenly {
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -webkit-box-pack: space-evenly;
      -ms-flex-pack: space-evenly;
      justify-content: space-evenly;
    }
    .cards {
      margin-bottom: 8px;
    }
    .cards-item {
      width: 32px;
      height: 20px;
      border: 1px solid #a5aac6;
      border-radius: 3px;
      margin-right: 8px;
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      -webkit-box-pack: center;
      -ms-flex-pack: center;
      justify-content: center;
      -webkit-box-align: center;
      -ms-flex-align: center;
      align-items: center;
    }
  </style>
</head>
<body>
<div class="ott">
  <div style="margin-bottom: 0px;">
    <div class="ott-head">
      <div class="ott-header-top">
        <div class="ott-header-logo">
          <img src="CH_logo" alt="logo" />
        </div>
        <div class="ott-header-ifo">
          <div class="ott-header-info-item">
            <div class="item-icon">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="6.988"
                height="9.983"
                viewBox="294 65 6.988 9.983"
              >
                <path
                  d="M297.494 67.246a1.248 1.248 0 1 1 0 2.496 1.248 1.248 0 0 1 0-2.496m0-2.246a3.494 3.494 0 0 1 3.494 3.494c0 2.62-3.494 6.489-3.494 6.489S294 71.115 294 68.494A3.494 3.494 0 0 1 297.494 65m0 .998a2.496 2.496 0 0 0-2.496 2.496c0 .5 0 1.498 2.496 4.847 2.496-3.35 2.496-4.348 2.496-4.847a2.496 2.496 0 0 0-2.496-2.496Z"
                  fill="#164066"
                  fill-rule="evenodd"
                  data-name="map-marker-outline"
                />
              </svg>
            </div>
            <p class="item-text">Mon - Sun 24/7</p>
          </div>
          <div class="ott-header-info-item">
            <div class="item-icon">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="12.479"
                height="9.983"
                viewBox="379 65 12.479 9.983"
              >
                <path
                  d="M391.479 66.248c0-.686-.562-1.248-1.248-1.248h-9.983c-.686 0-1.248.562-1.248 1.248v7.487c0 .686.562 1.248 1.248 1.248h9.983c.686 0 1.248-.562 1.248-1.248v-7.487m-1.248 0-4.992 3.12-4.991-3.12h9.983m0 7.487h-9.983v-6.24l4.991 3.12 4.992-3.12v6.24Z"
                  fill="#164066"
                  fill-rule="evenodd"
                  data-name="email-outline"
                />
              </svg>
            </div>
            <p class="item-text">CH_email</p>
          </div>
          <div class="ott-header-info-item">
            <div class="item-icon">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="9.983"
                height="9.983"
                viewBox="471 65 9.983 9.983"
              >
                <path
                  d="M480.428 71.933c-.665 0-1.386-.111-1.996-.333h-.167a.503.503 0 0 0-.388.166l-1.22 1.22c-1.553-.831-2.884-2.107-3.66-3.66l1.22-1.22c.166-.167.222-.388.11-.555a7.886 7.886 0 0 1-.277-1.996c0-.278-.277-.555-.554-.555h-1.941c-.278 0-.555.277-.555.555a9.42 9.42 0 0 0 9.428 9.428c.278 0 .555-.277.555-.555v-1.94c0-.278-.277-.555-.555-.555m-8.319-5.824h.832c.056.5.167.999.277 1.442l-.665.666a8.906 8.906 0 0 1-.444-2.108m7.765 7.765a8.906 8.906 0 0 1-2.108-.444l.666-.665c.444.11.943.221 1.442.221v.888Z"
                  fill="#164066"
                  fill-rule="evenodd"
                  data-name="phone-outline (1)"
                />
              </svg>
            </div>
            <p class="item-text">CH_phone</p>
          </div>
          <div class="ott-header-info-item">
            <div class="item-icon">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="9.983"
                height="9.983"
                viewBox="546 65 9.983 9.983"
              >
                <path
                  d="M553.168 70.99c.04-.33.07-.66.07-.998 0-.34-.03-.67-.07-.999h1.687c.08.32.13.654.13.999 0 .344-.05.678-.13.998m-2.57 2.775c.299-.554.528-1.153.688-1.777h1.473a4.008 4.008 0 0 1-2.162 1.777m-.124-2.775h-2.336c-.05-.33-.08-.66-.08-.998 0-.34.03-.674.08-.999h2.336c.044.325.08.66.08.999 0 .339-.036.668-.08.998m-1.168 2.975a6.77 6.77 0 0 1-.954-1.977h1.907a6.77 6.77 0 0 1-.953 1.977m-1.997-5.97h-1.458a3.955 3.955 0 0 1 2.157-1.777 8.603 8.603 0 0 0-.7 1.777m-1.457 3.993h1.458c.175.624.4 1.223.699 1.777a3.997 3.997 0 0 1-2.157-1.777m-.409-.998c-.08-.32-.13-.654-.13-.998 0-.345.05-.68.13-.999h1.687c-.04.33-.07.66-.07.999 0 .339.03.668.07.998m2.177-4.977c.414.6.748 1.268.953 1.982h-1.907c.205-.714.54-1.383.954-1.982m3.454 1.982h-1.473a7.811 7.811 0 0 0-.689-1.777 3.987 3.987 0 0 1 2.162 1.777M550.992 65a4.992 4.992 0 1 0 0 9.983 4.992 4.992 0 0 0 0-9.983Z"
                  fill="#164066"
                  fill-rule="evenodd"
                  data-name="web"
                />
              </svg>
            </div>
            <p class="item-text">CH_name</p>
          </div>
        </div>
      </div>
      <div class="ott-head-address">
        <h3>
          CH_zip CH_unit CH_address <br />
          CH_city, CA_province CH_country
        </h3>
      </div>
      <div class="ott-head-content">
        <div class="ott-head-content-item">
          <h3>Bill to</h3>
          <div class="ott-head-content-item-widget">
            <div class="bill">
              <p class="name">CH_client_firstname CH_client_lastname</p>
              <p class="address">
                CH_client_zip CH_client_suite CH_client_address
                CH_client_city, CA_client_province CH_client_country</p>
              <!--            <p class="location">Pocaima CA 91331 - 2041</p>-->
            </div>
          </div>
        </div>
        <div class="ott-head-content-item">
          <h3>Invoice</h3>
          <div class="ott-head-content-item-widget">
            <div class="invoice">
              <div class="item">
                <h4>invoice.</h4>
                <p>CH_number</p>
              </div>
              <div class="item invoice-date">
                <h4>Invoice Date.</h4>
                <p>CH_startDate</p>
              </div>
              <div class="item total-due">
                <h4>Total Due</h4>
                <p>$CH_amount</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="ott-table">
      <div class="ott-table-header">
        <div class="item" style="width: 90px">Action</div>
        <div class="item" style="width: 88px">Action</div>
        <div class="item" style="width: 104px">Start Date</div>
        <div class="item" style="width: 125px">End Date</div>
        <div class="item" style="width: 110px">Month/Days</div>
        <div class="item" style="width: 94px">1M Price</div>
        <div class="item" style="width: 94px">Discount</div>
        <div class="item" style="width: 78px">Amount</div>
      </div>
      CH_locations
      <div class="ott-table-total">
        <div class="item">
          <p>Subtotal</p>
          <p>$CH_subtotal</p>
        </div>
        <div class="item">
          <p>Tax</p>
          <p>$CH_tax</p>
        </div>
        <div class="item" style="color: #01b2b8; font-weight: bold">
          <p>Total /Subscription</p>
          <p>$CH_total</p>
        </div>
      </div>
      <div class="payments-block" style="padding: 0">
        <div class="payments-block-terms">
          <h2>Accepted Payment Methods</h2>
          <p>
            Terms :To avoid an interruption to service , please make full payment before service and date. Unfortunately we do not accept partial payment , you are
            responsible for the delay caused by returned partial payments . A late fee of 7.00 will be added to late payments.
          </p>
        </div>
        <div class="cards flex">
          <div class="cards-item">
            <svg xmlns="http://www.w3.org/2000/svg" width="20.832" height="6.396" viewBox="5.018 5.854 20.832 6.396"><g data-name="visa"><path d="M13.363 5.915h1.675l-1.066 6.213h-1.675l1.066-6.213Z" fill="#3362ab" fill-rule="evenodd" data-name="Path 5"/><path d="m12.663 5.946-2.65 6.182H8.216L6.693 6.951c1.097.7 2.01 1.797 2.345 2.558l.183.64 1.645-4.234h1.797v.03Z" fill="#3362ab" fill-rule="evenodd" data-name="Path 4"/><path d="m5.018 6.007.03-.122h2.62c.365 0 .64.122.73.518l.58 2.74c-.58-1.461-1.92-2.649-3.96-3.136Z" fill="#f9b50b" fill-rule="evenodd" data-name="Path 3"/><path d="M19.88 10.118c0 1.28-1.157 2.132-2.954 2.132-.761 0-1.492-.152-1.888-.335l.244-1.4.213.09c.548.244.914.336 1.584.336.487 0 1.005-.183 1.005-.61 0-.274-.213-.456-.884-.76-.64-.305-1.492-.793-1.492-1.676 0-1.218 1.188-2.04 2.863-2.04.64 0 1.188.121 1.523.274l-.244 1.34-.122-.122a3.273 3.273 0 0 0-1.279-.244c-.64.03-.944.305-.944.548 0 .274.366.488.944.762.975.457 1.432.974 1.432 1.705Z" fill="#3362ab" fill-rule="evenodd" data-name="Path 2"/><path d="M24.449 5.946h-1.31c-.396 0-.7.122-.883.518l-2.497 5.695h1.766s.305-.762.366-.944h2.162c.06.213.213.913.213.913h1.584l-1.401-6.182Zm-2.071 3.99c.152-.366.67-1.736.67-1.736 0 .03.152-.366.213-.58l.122.55s.335 1.491.396 1.796h-1.401v-.03Z" fill="#3362ab" fill-rule="evenodd" data-name="Path 1"/></g></svg>
          </div>
          <div class="cards-item">
            <svg xmlns="http://www.w3.org/2000/svg" width="16.149" height="10.125" viewBox="7.095 4.182 16.149 10.125"><g data-name="mastercard"><path d="M23.243 9.2c.046 2.783-2.135 5.042-4.878 5.052a4.945 4.945 0 0 1-3.077-1.067c1.142-.927 1.849-2.356 1.822-3.964a5.15 5.15 0 0 0-1.954-3.952 4.827 4.827 0 0 1 3.042-1.087c2.742-.01 4.999 2.249 5.045 5.018Z" fill="#f79e1b" fill-rule="evenodd" data-name="Path 8"/><path d="M13.228 9.267a5.004 5.004 0 0 1 1.822-3.964 4.944 4.944 0 0 0-3.077-1.066c-2.742.009-4.924 2.268-4.878 5.051.047 2.784 2.303 5.028 5.045 5.018a4.828 4.828 0 0 0 3.042-1.087 5.13 5.13 0 0 1-1.954-3.952Z" fill="#eb001b" fill-rule="evenodd" data-name="Path 7"/><path d="m17.263 5.283-4.32.015.132 7.907 4.32-.014-.132-7.908Z" fill="#ff5f00" fill-rule="evenodd" data-name="Path 6"/></g></svg>
          </div>
          <div class="cards-item">
            <svg xmlns="http://www.w3.org/2000/svg" width="20.073" height="6.691" viewBox="4.919 5.855 20.073 6.691"><path d="m19.732 6.637-.388.856h.779l-.39-.856Zm-4.481.53c.073-.034.116-.11.116-.204 0-.092-.045-.158-.118-.19a.63.63 0 0 0-.268-.038h-.695v.477h.686c.11 0 .201-.002.279-.045Zm-8.904-.53-.384.856h.77l-.386-.856Zm17.878 5.485h-1.09v-.46h1.086c.107 0 .183-.014.228-.054a.181.181 0 0 0 .067-.14.17.17 0 0 0-.07-.142c-.04-.033-.1-.048-.198-.048-.53-.016-1.19.015-1.19-.665 0-.311.217-.64.809-.64h1.124v-.427h-1.044c-.316 0-.545.069-.707.176v-.176h-1.544c-.247 0-.537.056-.674.176v-.176h-2.759v.176c-.22-.144-.59-.176-.76-.176h-1.82v.176c-.174-.153-.56-.176-.795-.176H12.85l-.466.459-.436-.459H8.907v2.998h2.984l.48-.466.453.466 1.84.001v-.705h.18c.244.004.532-.005.786-.105v.809h1.518v-.781h.073c.093 0 .103.003.103.088v.693h4.61c.292 0 .598-.068.767-.192v.192h1.462c.305 0 .602-.04.828-.138v-.559c-.137.183-.404.275-.766.275Zm-9.356-.708h-.705v.72h-1.096l-.695-.71-.722.71H9.416V9.987h2.27l.693.705.718-.705H14.9c.448 0 .951.113.951.708 0 .597-.49.72-.982.72Zm3.385-.097c.08.104.091.202.094.392v.426h-.567v-.27c0-.128.014-.32-.091-.42-.082-.077-.208-.095-.414-.095h-.603v.785h-.567V9.986h1.303c.285 0 .494.012.679.102.178.098.29.232.29.477a.606.606 0 0 1-.4.571.614.614 0 0 1 .276.18Zm2.331-.886h-1.321v.39h1.289v.438h-1.29v.428l1.322.002v.446h-1.883V9.986h1.883v.445Zm1.45 1.704h-1.099v-.461h1.095c.107 0 .183-.013.23-.053a.183.183 0 0 0 .067-.14.178.178 0 0 0-.069-.143c-.043-.032-.103-.047-.2-.047-.529-.017-1.19.015-1.19-.665 0-.312.216-.64.807-.64h1.132v.458h-1.036c-.102 0-.169.003-.226.038-.061.035-.084.087-.084.155 0 .081.052.136.123.16a.71.71 0 0 0 .22.024l.303.008c.307.007.517.055.645.173.11.103.169.234.169.455 0 .462-.318.678-.887.678Zm-4.376-1.67c-.068-.037-.17-.039-.27-.039h-.694v.483h.685c.11 0 .203-.004.279-.044a.227.227 0 0 0 .117-.207.202.202 0 0 0-.117-.193Zm6.304-.039c-.102 0-.17.004-.228.04-.06.034-.082.086-.082.154 0 .08.05.136.123.16.06.019.124.024.217.024l.306.008c.309.007.515.055.64.173.024.016.037.034.053.053v-.612h-1.028Zm-9.075 0h-.736v.548h.73c.216 0 .351-.098.351-.284 0-.188-.141-.264-.345-.264Zm-4.91 0v.391h1.238v.438H9.978v.428h1.387l.645-.63-.618-.627H9.978ZM13.6 11.93v-1.723l-.866.848.866.875Zm-3.575-3.45v.37h4.714l-.002-.782h.091c.064.002.083.007.083.103v.68h2.438v-.182c.197.095.503.182.905.182h1.026l.22-.477h.486l.215.477h1.977v-.453l.299.453h1.584V5.855h-1.568v.353l-.22-.353h-1.608v.353l-.201-.353H18.29c-.364 0-.684.046-.942.174v-.174h-1.5v.174c-.164-.132-.388-.174-.637-.174H9.734l-.367.773-.378-.773H7.264v.353l-.19-.353H5.603l-.684 1.424v1.139L5.93 6.27h.84l.959 2.034V6.27h.92l.74 1.457.678-1.457h.94v2.148h-.58l-.001-1.682-.819 1.682h-.495l-.82-1.684v1.684H7.143l-.217-.48H5.751l-.219.48H4.92v.432h.964l.218-.477h.487l.216.477h1.897v-.365l.17.366h.984l.17-.371Zm7.429-1.958c.182-.172.468-.25.857-.25h.546v.46h-.535c-.206 0-.322.027-.434.127-.096.09-.162.26-.162.486 0 .23.05.396.155.504.087.085.245.111.393.111h.254l.795-1.689h.845l.956 2.032V6.27h.859l.992 1.496V6.27h.578v2.148h-.8l-1.07-1.612v1.612h-1.148l-.22-.48h-1.172l-.213.48h-.66c-.275 0-.622-.055-.819-.238-.198-.182-.301-.43-.301-.82 0-.318.061-.61.304-.84Zm-1.16-.25h.575v2.147h-.576V6.27Zm-2.597 0h1.298c.289 0 .501.006.684.102a.494.494 0 0 1 .285.475c0 .343-.251.52-.398.573a.657.657 0 0 1 .28.18c.08.108.093.203.093.395v.422h-.57l-.001-.271c0-.13.013-.315-.09-.418-.082-.076-.207-.092-.41-.092h-.606v.78h-.565V6.27Zm-2.274 0h1.885v.446h-1.321v.387h1.289v.44h-1.29v.43h1.322v.444h-1.885V6.27Z" fill="#2557d6" fill-rule="evenodd" data-name="american-express"/></svg>
          </div>
          <div class="cards-item">
            <svg xmlns="http://www.w3.org/2000/svg" width="12.643" height="10.036" viewBox="8.668 4.182 12.643 10.036"><g data-name="diners-club"><path d="M10.837 9.188a2.916 2.916 0 0 1 1.865-2.718v5.435a2.915 2.915 0 0 1-1.865-2.717Zm3.945 2.718V6.47a2.915 2.915 0 0 1 1.866 2.718 2.916 2.916 0 0 1-1.866 2.718Z" fill="#0079be" fill-rule="evenodd" data-name="Path 11"/><path d="M13.734 4.606A4.59 4.59 0 0 0 9.15 9.2a4.59 4.59 0 0 0 4.584 4.594A4.59 4.59 0 0 0 18.318 9.2a4.59 4.59 0 0 0-4.584-4.594Z" fill="#fff" fill-rule="evenodd" data-name="Path 10"/><path d="M21.312 9.244c0-2.994-2.499-5.063-5.237-5.062H13.72C10.95 4.18 8.67 6.25 8.67 9.244c0 2.738 2.28 4.987 5.05 4.974h2.356c2.738.013 5.237-2.237 5.237-4.974Z" fill="#0079be" fill-rule="evenodd" data-name="Path 9"/></g></svg>
          </div>
          <div class="cards-item">
            <svg xmlns="http://www.w3.org/2000/svg" width="20.624" height="3.526" viewBox="4.82 7.527 20.624 3.526"><g data-name="discover"><path d="M24.414 9.556c.498-.1.765-.432.765-.931 0-.599-.433-.965-1.165-.965h-.964v3.26h.632V9.623h.1l.897 1.297h.766l-1.031-1.364Zm-.533-.399h-.2v-.998h.2c.4 0 .632.166.632.5 0 .332-.233.498-.632.498Z" fill="#2b2b2b" fill-rule="evenodd" data-name="Path 19"/><path d="M10.043 8.924c-.4-.133-.499-.233-.499-.399 0-.2.2-.366.466-.366.2 0 .366.067.532.266l.333-.432a1.449 1.449 0 0 0-.965-.366c-.566 0-1.031.4-1.031.931 0 .466.2.666.798.899.266.1.366.133.433.2.133.066.2.199.2.332 0 .266-.2.465-.5.465a.776.776 0 0 1-.698-.432l-.4.4c.3.432.666.631 1.131.631.666 0 1.131-.432 1.131-1.064 0-.566-.2-.799-.931-1.065Z" fill="#2b2b2b" fill-rule="evenodd" data-name="Path 18"/><path d="M8.447 7.66h-.633v3.26h.633V7.66Z" fill="#2b2b2b" fill-rule="evenodd" data-name="Path 17"/><path d="M5.752 7.66H4.82v3.26h.932c.499 0 .865-.133 1.164-.366.366-.3.599-.765.599-1.264 0-.965-.699-1.63-1.763-1.63Zm.765 2.462c-.2.166-.466.266-.865.266h-.2V8.226h.167c.399 0 .665.066.865.266.233.2.366.499.366.798.033.3-.1.632-.333.832Z" fill="#2b2b2b" fill-rule="evenodd" data-name="Path 16"/><path d="M20.788 9.124v1.796h1.829v-.532h-1.165v-.899h1.132v-.565h-1.131v-.698h1.164V7.66h-1.83v1.464Z" fill="#2b2b2b" fill-rule="evenodd" data-name="Path 15"/><path d="m19.678 8.004-.753 1.852-.865-2.196h-.699l1.364 3.36h.366l1.43-3.36h-.698l-.145.344Z" fill="#2b2b2b" fill-rule="evenodd" data-name="Path 14"/><path d="M13.713 10.022c-.258.259-.497.36-.754.365-.626-.005-1.086-.469-1.086-1.13 0-.333.126-.605.325-.838.187-.178.429-.293.706-.293.3 0 .532.1.798.366v-.765a1.671 1.671 0 0 0-.798-.2c-.423.03-.822.201-1.128.47-.088.079-.172.166-.244.267-.223.29-.358.644-.358 1.026 0 .965.765 1.697 1.73 1.697h.033c.266 0 .5-.067.798-.2l-.022-.765c-.011.011.011.022 0 .032v-.032Z" fill="#2b2b2b" fill-rule="evenodd" data-name="Path 13"/><path d="M17.494 9.281a1.713 1.713 0 0 0-.499-1.222 1.712 1.712 0 0 0-1.224-.498h-.006c-.965 0-1.73.765-1.73 1.73 0 .955.774 1.729 1.73 1.729.964 0 1.73-.765 1.73-1.73v-.009Z" fill="#f26e21" fill-rule="evenodd" data-name="Path 12"/></g></svg>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="payments-block">
    <div class="cut-section">
      <div>
        <svg xmlns="http://www.w3.org/2000/svg" width="12.626" height="12.626" viewBox="20.5 562 12.626 12.626"><path d="m31.232 562.631-3.788 3.788 1.263 1.263 4.419-4.42v-.63m-6.313 5.997a.316.316 0 1 1 0-.632.316.316 0 0 1 0 .632m-3.788 4.734a1.263 1.263 0 1 1 0-2.525 1.263 1.263 0 0 1 0 2.525m0-7.575a1.263 1.263 0 1 1 0-2.525 1.263 1.263 0 0 1 0 2.525m2.298-.228a2.46 2.46 0 0 0 .227-1.035 2.525 2.525 0 1 0-2.525 2.525c.373 0 .72-.082 1.035-.227l1.49 1.49-1.49 1.49a2.46 2.46 0 0 0-1.035-.228 2.525 2.525 0 1 0 2.525 2.526c0-.373-.082-.72-.227-1.036l1.49-1.49 4.419 4.42h1.894v-.632l-7.803-7.803Z" fill="#164066" fill-rule="evenodd" data-name="content-cut"/></svg>
      </div>
      <div class="cut-section-border">
        <div style="border-top: 2px dashed"></div>
      </div>
    </div>
    <div class="flex-between">
      <div class="invoice-info flex">
        <div class="invoice-info-item" style="margin-right: 20px;">
          <div class="flex" style="margin-bottom: 4px">
            <span style="width: 50px; display: block; font-weight: 600">Invoice</span>
            <span>CH_number</span>
          </div>
          <div class="flex">
            <span style="width: 50px; display: block; font-weight: 600">Name</span>
            <span>CH_client_firstname CH_client_lastname</span>
          </div>
        </div>
        <div class="invoice-info-item" style="width: 47%">
          <div class="flex" style="margin-bottom: 4px">
            <span style="width: 60px; display: block; font-weight: 600">Due Date</span>
            <span>CH_startDate</span>
          </div>
          <div class="flex">
            <span style="width: 60px; display: block; font-weight: 600">Address</span>
            <span>
                CH_client_zip CH_client_suite CH_client_address
                CH_client_city, CA_client_province CH_client_country</span>
          </div>
        </div>
      </div>
      <div class="invoice-info-qr">
        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="140" height="51" viewBox="454.5 578.5 118.5 51">
          <g data-name="Group 18">
            <g clip-path="url(&quot;#a&quot;)" transform="translate(454.5 589.215)" data-name="barcode">
              <image width="600" height="600"
                     xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAAAXNSR0IArs4c6QAAIABJREFUeF7t2LHOqO1WleGXM7DEio54FMTSilihDcRSE0g8EBJbDSQmVEonnTSeA42nIB12dJpVGBOSTdYeGWPuDc+16m/Obz3XO9efO/9vfP4QIECAAAECzwn8xnMv9mACBAgQIEDgEwCOgAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KCAAHjwo3syAQIECBAQAG6AAAECBAg8KCAAHvzonkyAAAECBASAGyBAgAABAg8KCIAHP7onEyBAgAABAeAGCBAgQIDAgwIC4MGP7skECBAgQEAAuAECBAgQIPCggAB48KN7MgECBAgQEABugAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KCAAHjwo3syAQIECBAQAG6AAAECBAg8KCAAHvzonkyAAAECBASAGyBAgAABAg8KCIAHP7onEyBAgAABAeAGCBAgQIDAgwIC4MGP7skECBAgQEAAuAECBAgQIPCggAB48KN7MgECBAgQEABugAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KCAAHjwo3syAQIECBAQAG6AAAECBAg8KCAAHvzonkyAAAECBASAGyBAgAABAg8KCIAHP7onEyBAgAABAeAGCBAgQIDAgwIC4MGP7skECBAgQEAAuAECBAgQIPCggAB48KN7MgECBAgQEABugAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KDAjwD42wfe/Zff9/3ur9E7f/v7vr86/vv8xfd9v3f8O3/m171wfz/j0P6ZP/++7w/aS3/Bvt/5vu/Hv7HLP3/yfd8fDX7hn/0K/p381vd9fz14y4+Vv/993w+rf+x//vD7vj/9JR95/d+ev/m+7zd/yb/jz/z4j7f/8c/84N/9mR8B8H+SwX9gM//9+75/8Wv0d/5n3/f9z+O/z3/7vu9fHv/On/l1L9zfzzi0f+a/ft/3r9tLf8G+f/593/84+l3/79f8p+/7/u3gd/6X7/v+1WDv37fyn37f979Gv/PffN/3n0e7f53W/rvv+/7jL/kXuv5vz//+vu+f/JJ/x5/58X//fd9/+JkfFACJUn9GAPx/0+t/hP2v+eu5UQBk30UAZG6/6ikBEHwB/wcgQCuMCAABUDijv3eFAMiEBUDm9queEgDBFxAAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiHuVW6AAAIEUlEQVSQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAHyjwD422DuH9rIX37f97u/Rn/p3/6+76+O/z5/8X3f7x3/zp/5dS/c3884tH/mz7/v+4P20l+w73e+7/vxb+zyz5983/dHg1/4Z7+Cfye/9X3fXw/e8mPl73/f98PqH/ufP/y+709/yUde/7fnb77v+81f8u/4Mz/+4+1//DM/+Hd/5kcA+EOAAAECBAg8JiAAHvvgnkuAAAECBH4ICAB3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFBAADz40T2ZAAECBAgIADdAgAABAgQeFBAAD350TyZAgAABAgLADRAgQIAAgQcFBMCDH92TCRAgQICAAHADBAgQIEDgQQEB8OBH92QCBAgQICAA3AABAgQIEHhQQAA8+NE9mQABAgQICAA3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFBAADz40T2ZAAECBAgIADdAgAABAgQeFBAAD350TyZAgAABAgLADRAgQIAAgQcFBMCDH92TCRAgQICAAHADBAgQIEDgQQEB8OBH92QCBAgQICAA3AABAgQIEHhQQAA8+NE9mQABAgQICAA3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFBAADz40T2ZAAECBAgIADdAgAABAgQeFBAAD350TyZAgAABAgLADRAgQIAAgQcFBMCDH92TCRAgQICAAHADBAgQIEDgQQEB8OBH92QCBAgQICAA3AABAgQIEHhQQAA8+NE9mQABAgQICAA3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFDg/wJyyJPCiV8gnQAAAABJRU5ErkJggg==" transform="scale(.07868)"/></g><g clip-path="url(&quot;#b&quot;)" transform="translate(454.5 578.5)" data-name="barcode"><image width="600" height="600" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAAAXNSR0IArs4c6QAAIABJREFUeF7t2LHOqO1WleGXM7DEio54FMTSilihDcRSE0g8EBJbDSQmVEonnTSeA42nIB12dJpVGBOSTdYeGWPuDc+16m/Obz3XO9efO/9vfP4QIECAAAECzwn8xnMv9mACBAgQIEDgEwCOgAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KCAAHjwo3syAQIECBAQAG6AAAECBAg8KCAAHvzonkyAAAECBASAGyBAgAABAg8KCIAHP7onEyBAgAABAeAGCBAgQIDAgwIC4MGP7skECBAgQEAAuAECBAgQIPCggAB48KN7MgECBAgQEABugAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KCAAHjwo3syAQIECBAQAG6AAAECBAg8KCAAHvzonkyAAAECBASAGyBAgAABAg8KCIAHP7onEyBAgAABAeAGCBAgQIDAgwIC4MGP7skECBAgQEAAuAECBAgQIPCggAB48KN7MgECBAgQEABugAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KCAAHjwo3syAQIECBAQAG6AAAECBAg8KCAAHvzonkyAAAECBASAGyBAgAABAg8KCIAHP7onEyBAgAABAeAGCBAgQIDAgwIC4MGP7skECBAgQEAAuAECBAgQIPCggAB48KN7MgECBAgQEABugAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KDAjwD42wfe/Zff9/3ur9E7f/v7vr86/vv8xfd9v3f8O3/m171wfz/j0P6ZP/++7w/aS3/Bvt/5vu/Hv7HLP3/yfd8fDX7hn/0K/p381vd9fz14y4+Vv/993w+rf+x//vD7vj/9JR95/d+ev/m+7zd/yb/jz/z4j7f/8c/84N/9mR8B8H+SwX9gM//9+75/8Wv0d/5n3/f9z+O/z3/7vu9fHv/On/l1L9zfzzi0f+a/ft/3r9tLf8G+f/593/84+l3/79f8p+/7/u3gd/6X7/v+1WDv37fyn37f979Gv/PffN/3n0e7f53W/rvv+/7jL/kXuv5vz//+vu+f/JJ/x5/58X//fd9/+JkfFACJUn9GAPx/0+t/hP2v+eu5UQBk30UAZG6/6ikBEHwB/wcgQCuMCAABUDijv3eFAMiEBUDm9queEgDBFxAAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiHuVW6AAAIEUlEQVSQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAHyjwD422DuH9rIX37f97u/Rn/p3/6+76+O/z5/8X3f7x3/zp/5dS/c3884tH/mz7/v+4P20l+w73e+7/vxb+zyz5983/dHg1/4Z7+Cfye/9X3fXw/e8mPl73/f98PqH/ufP/y+709/yUde/7fnb77v+81f8u/4Mz/+4+1//DM/+Hd/5kcA+EOAAAECBAg8JiAAHvvgnkuAAAECBH4ICAB3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFBAADz40T2ZAAECBAgIADdAgAABAgQeFBAAD350TyZAgAABAgLADRAgQIAAgQcFBMCDH92TCRAgQICAAHADBAgQIEDgQQEB8OBH92QCBAgQICAA3AABAgQIEHhQQAA8+NE9mQABAgQICAA3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFBAADz40T2ZAAECBAgIADdAgAABAgQeFBAAD350TyZAgAABAgLADRAgQIAAgQcFBMCDH92TCRAgQICAAHADBAgQIEDgQQEB8OBH92QCBAgQICAA3AABAgQIEHhQQAA8+NE9mQABAgQICAA3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFBAADz40T2ZAAECBAgIADdAgAABAgQeFBAAD350TyZAgAABAgLADRAgQIAAgQcFBMCDH92TCRAgQICAAHADBAgQIEDgQQEB8OBH92QCBAgQICAA3AABAgQIEHhQQAA8+NE9mQABAgQICAA3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFDg/wJyyJPCiV8gnQAAAABJRU5ErkJggg==" transform="scale(.07868)"/></g><g clip-path="url(&quot;#c&quot;)" transform="translate(489.97 589.215)" data-name="barcode"><image width="600" height="600" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAAAXNSR0IArs4c6QAAIABJREFUeF7t2LHOqO1WleGXM7DEio54FMTSilihDcRSE0g8EBJbDSQmVEonnTSeA42nIB12dJpVGBOSTdYeGWPuDc+16m/Obz3XO9efO/9vfP4QIECAAAECzwn8xnMv9mACBAgQIEDgEwCOgAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KCAAHjwo3syAQIECBAQAG6AAAECBAg8KCAAHvzonkyAAAECBASAGyBAgAABAg8KCIAHP7onEyBAgAABAeAGCBAgQIDAgwIC4MGP7skECBAgQEAAuAECBAgQIPCggAB48KN7MgECBAgQEABugAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KCAAHjwo3syAQIECBAQAG6AAAECBAg8KCAAHvzonkyAAAECBASAGyBAgAABAg8KCIAHP7onEyBAgAABAeAGCBAgQIDAgwIC4MGP7skECBAgQEAAuAECBAgQIPCggAB48KN7MgECBAgQEABugAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KCAAHjwo3syAQIECBAQAG6AAAECBAg8KCAAHvzonkyAAAECBASAGyBAgAABAg8KCIAHP7onEyBAgAABAeAGCBAgQIDAgwIC4MGP7skECBAgQEAAuAECBAgQIPCggAB48KN7MgECBAgQEABugAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KDAjwD42wfe/Zff9/3ur9E7f/v7vr86/vv8xfd9v3f8O3/m171wfz/j0P6ZP/++7w/aS3/Bvt/5vu/Hv7HLP3/yfd8fDX7hn/0K/p381vd9fz14y4+Vv/993w+rf+x//vD7vj/9JR95/d+ev/m+7zd/yb/jz/z4j7f/8c/84N/9mR8B8H+SwX9gM//9+75/8Wv0d/5n3/f9z+O/z3/7vu9fHv/On/l1L9zfzzi0f+a/ft/3r9tLf8G+f/593/84+l3/79f8p+/7/u3gd/6X7/v+1WDv37fyn37f979Gv/PffN/3n0e7f53W/rvv+/7jL/kXuv5vz//+vu+f/JJ/x5/58X//fd9/+JkfFACJUn9GAPx/0+t/hP2v+eu5UQBk30UAZG6/6ikBEHwB/wcgQCuMCAABUDijv3eFAMiEBUDm9queEgDBFxAAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiHuVW6AAAIEUlEQVSQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAHyjwD422DuH9rIX37f97u/Rn/p3/6+76+O/z5/8X3f7x3/zp/5dS/c3884tH/mz7/v+4P20l+w73e+7/vxb+zyz5983/dHg1/4Z7+Cfye/9X3fXw/e8mPl73/f98PqH/ufP/y+709/yUde/7fnb77v+81f8u/4Mz/+4+1//DM/+Hd/5kcA+EOAAAECBAg8JiAAHvvgnkuAAAECBH4ICAB3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFBAADz40T2ZAAECBAgIADdAgAABAgQeFBAAD350TyZAgAABAgLADRAgQIAAgQcFBMCDH92TCRAgQICAAHADBAgQIEDgQQEB8OBH92QCBAgQICAA3AABAgQIEHhQQAA8+NE9mQABAgQICAA3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFBAADz40T2ZAAECBAgIADdAgAABAgQeFBAAD350TyZAgAABAgLADRAgQIAAgQcFBMCDH92TCRAgQICAAHADBAgQIEDgQQEB8OBH92QCBAgQICAA3AABAgQIEHhQQAA8+NE9mQABAgQICAA3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFBAADz40T2ZAAECBAgIADdAgAABAgQeFBAAD350TyZAgAABAgLADRAgQIAAgQcFBMCDH92TCRAgQICAAHADBAgQIEDgQQEB8OBH92QCBAgQICAA3AABAgQIEHhQQAA8+NE9mQABAgQICAA3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFDg/wJyyJPCiV8gnQAAAABJRU5ErkJggg==" transform="scale(.07868)"/></g><g clip-path="url(&quot;#d&quot;)" transform="translate(532.714 589.215)" data-name="barcode"><image width="600" height="600" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAAAXNSR0IArs4c6QAAIABJREFUeF7t2LHOqO1WleGXM7DEio54FMTSilihDcRSE0g8EBJbDSQmVEonnTSeA42nIB12dJpVGBOSTdYeGWPuDc+16m/Obz3XO9efO/9vfP4QIECAAAECzwn8xnMv9mACBAgQIEDgEwCOgAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KCAAHjwo3syAQIECBAQAG6AAAECBAg8KCAAHvzonkyAAAECBASAGyBAgAABAg8KCIAHP7onEyBAgAABAeAGCBAgQIDAgwIC4MGP7skECBAgQEAAuAECBAgQIPCggAB48KN7MgECBAgQEABugAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KCAAHjwo3syAQIECBAQAG6AAAECBAg8KCAAHvzonkyAAAECBASAGyBAgAABAg8KCIAHP7onEyBAgAABAeAGCBAgQIDAgwIC4MGP7skECBAgQEAAuAECBAgQIPCggAB48KN7MgECBAgQEABugAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KCAAHjwo3syAQIECBAQAG6AAAECBAg8KCAAHvzonkyAAAECBASAGyBAgAABAg8KCIAHP7onEyBAgAABAeAGCBAgQIDAgwIC4MGP7skECBAgQEAAuAECBAgQIPCggAB48KN7MgECBAgQEABugAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KDAjwD42wfe/Zff9/3ur9E7f/v7vr86/vv8xfd9v3f8O3/m171wfz/j0P6ZP/++7w/aS3/Bvt/5vu/Hv7HLP3/yfd8fDX7hn/0K/p381vd9fz14y4+Vv/993w+rf+x//vD7vj/9JR95/d+ev/m+7zd/yb/jz/z4j7f/8c/84N/9mR8B8H+SwX9gM//9+75/8Wv0d/5n3/f9z+O/z3/7vu9fHv/On/l1L9zfzzi0f+a/ft/3r9tLf8G+f/593/84+l3/79f8p+/7/u3gd/6X7/v+1WDv37fyn37f979Gv/PffN/3n0e7f53W/rvv+/7jL/kXuv5vz//+vu+f/JJ/x5/58X//fd9/+JkfFACJUn9GAPx/0+t/hP2v+eu5UQBk30UAZG6/6ikBEHwB/wcgQCuMCAABUDijv3eFAMiEBUDm9queEgDBFxAAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiHuVW6AAAIEUlEQVSQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAHyjwD422DuH9rIX37f97u/Rn/p3/6+76+O/z5/8X3f7x3/zp/5dS/c3884tH/mz7/v+4P20l+w73e+7/vxb+zyz5983/dHg1/4Z7+Cfye/9X3fXw/e8mPl73/f98PqH/ufP/y+709/yUde/7fnb77v+81f8u/4Mz/+4+1//DM/+Hd/5kcA+EOAAAECBAg8JiAAHvvgnkuAAAECBH4ICAB3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFBAADz40T2ZAAECBAgIADdAgAABAgQeFBAAD350TyZAgAABAgLADRAgQIAAgQcFBMCDH92TCRAgQICAAHADBAgQIEDgQQEB8OBH92QCBAgQICAA3AABAgQIEHhQQAA8+NE9mQABAgQICAA3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFBAADz40T2ZAAECBAgIADdAgAABAgQeFBAAD350TyZAgAABAgLADRAgQIAAgQcFBMCDH92TCRAgQICAAHADBAgQIEDgQQEB8OBH92QCBAgQICAA3AABAgQIEHhQQAA8+NE9mQABAgQICAA3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFBAADz40T2ZAAECBAgIADdAgAABAgQeFBAAD350TyZAgAABAgLADRAgQIAAgQcFBMCDH92TCRAgQICAAHADBAgQIEDgQQEB8OBH92QCBAgQICAA3AABAgQIEHhQQAA8+NE9mQABAgQICAA3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFDg/wJyyJPCiV8gnQAAAABJRU5ErkJggg==" transform="scale(.07868)"/></g><g clip-path="url(&quot;#e&quot;)" transform="translate(489.97 578.5)" data-name="barcode"><image width="600" height="600" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAAAXNSR0IArs4c6QAAIABJREFUeF7t2LHOqO1WleGXM7DEio54FMTSilihDcRSE0g8EBJbDSQmVEonnTSeA42nIB12dJpVGBOSTdYeGWPuDc+16m/Obz3XO9efO/9vfP4QIECAAAECzwn8xnMv9mACBAgQIEDgEwCOgAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KCAAHjwo3syAQIECBAQAG6AAAECBAg8KCAAHvzonkyAAAECBASAGyBAgAABAg8KCIAHP7onEyBAgAABAeAGCBAgQIDAgwIC4MGP7skECBAgQEAAuAECBAgQIPCggAB48KN7MgECBAgQEABugAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KCAAHjwo3syAQIECBAQAG6AAAECBAg8KCAAHvzonkyAAAECBASAGyBAgAABAg8KCIAHP7onEyBAgAABAeAGCBAgQIDAgwIC4MGP7skECBAgQEAAuAECBAgQIPCggAB48KN7MgECBAgQEABugAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KCAAHjwo3syAQIECBAQAG6AAAECBAg8KCAAHvzonkyAAAECBASAGyBAgAABAg8KCIAHP7onEyBAgAABAeAGCBAgQIDAgwIC4MGP7skECBAgQEAAuAECBAgQIPCggAB48KN7MgECBAgQEABugAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KDAjwD42wfe/Zff9/3ur9E7f/v7vr86/vv8xfd9v3f8O3/m171wfz/j0P6ZP/++7w/aS3/Bvt/5vu/Hv7HLP3/yfd8fDX7hn/0K/p381vd9fz14y4+Vv/993w+rf+x//vD7vj/9JR95/d+ev/m+7zd/yb/jz/z4j7f/8c/84N/9mR8B8H+SwX9gM//9+75/8Wv0d/5n3/f9z+O/z3/7vu9fHv/On/l1L9zfzzi0f+a/ft/3r9tLf8G+f/593/84+l3/79f8p+/7/u3gd/6X7/v+1WDv37fyn37f979Gv/PffN/3n0e7f53W/rvv+/7jL/kXuv5vz//+vu+f/JJ/x5/58X//fd9/+JkfFACJUn9GAPx/0+t/hP2v+eu5UQBk30UAZG6/6ikBEHwB/wcgQCuMCAABUDijv3eFAMiEBUDm9queEgDBFxAAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiHuVW6AAAIEUlEQVSQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAHyjwD422DuH9rIX37f97u/Rn/p3/6+76+O/z5/8X3f7x3/zp/5dS/c3884tH/mz7/v+4P20l+w73e+7/vxb+zyz5983/dHg1/4Z7+Cfye/9X3fXw/e8mPl73/f98PqH/ufP/y+709/yUde/7fnb77v+81f8u/4Mz/+4+1//DM/+Hd/5kcA+EOAAAECBAg8JiAAHvvgnkuAAAECBH4ICAB3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFBAADz40T2ZAAECBAgIADdAgAABAgQeFBAAD350TyZAgAABAgLADRAgQIAAgQcFBMCDH92TCRAgQICAAHADBAgQIEDgQQEB8OBH92QCBAgQICAA3AABAgQIEHhQQAA8+NE9mQABAgQICAA3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFBAADz40T2ZAAECBAgIADdAgAABAgQeFBAAD350TyZAgAABAgLADRAgQIAAgQcFBMCDH92TCRAgQICAAHADBAgQIEDgQQEB8OBH92QCBAgQICAA3AABAgQIEHhQQAA8+NE9mQABAgQICAA3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFBAADz40T2ZAAECBAgIADdAgAABAgQeFBAAD350TyZAgAABAgLADRAgQIAAgQcFBMCDH92TCRAgQICAAHADBAgQIEDgQQEB8OBH92QCBAgQICAA3AABAgQIEHhQQAA8+NE9mQABAgQICAA3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFDg/wJyyJPCiV8gnQAAAABJRU5ErkJggg==" transform="scale(.07868)"/></g><g clip-path="url(&quot;#f&quot;)" transform="translate(532.714 578.5)" data-name="barcode"><image width="600" height="600" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAAAXNSR0IArs4c6QAAIABJREFUeF7t2LHOqO1WleGXM7DEio54FMTSilihDcRSE0g8EBJbDSQmVEonnTSeA42nIB12dJpVGBOSTdYeGWPuDc+16m/Obz3XO9efO/9vfP4QIECAAAECzwn8xnMv9mACBAgQIEDgEwCOgAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KCAAHjwo3syAQIECBAQAG6AAAECBAg8KCAAHvzonkyAAAECBASAGyBAgAABAg8KCIAHP7onEyBAgAABAeAGCBAgQIDAgwIC4MGP7skECBAgQEAAuAECBAgQIPCggAB48KN7MgECBAgQEABugAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KCAAHjwo3syAQIECBAQAG6AAAECBAg8KCAAHvzonkyAAAECBASAGyBAgAABAg8KCIAHP7onEyBAgAABAeAGCBAgQIDAgwIC4MGP7skECBAgQEAAuAECBAgQIPCggAB48KN7MgECBAgQEABugAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KCAAHjwo3syAQIECBAQAG6AAAECBAg8KCAAHvzonkyAAAECBASAGyBAgAABAg8KCIAHP7onEyBAgAABAeAGCBAgQIDAgwIC4MGP7skECBAgQEAAuAECBAgQIPCggAB48KN7MgECBAgQEABugAABAgQIPCggAB786J5MgAABAgQEgBsgQIAAAQIPCgiABz+6JxMgQIAAAQHgBggQIECAwIMCAuDBj+7JBAgQIEBAALgBAgQIECDwoIAAePCjezIBAgQIEBAAboAAAQIECDwoIAAe/OieTIAAAQIEBIAbIECAAAECDwoIgAc/uicTIECAAAEB4AYIECBAgMCDAgLgwY/uyQQIECBAQAC4AQIECBAg8KDAjwD42wfe/Zff9/3ur9E7f/v7vr86/vv8xfd9v3f8O3/m171wfz/j0P6ZP/++7w/aS3/Bvt/5vu/Hv7HLP3/yfd8fDX7hn/0K/p381vd9fz14y4+Vv/993w+rf+x//vD7vj/9JR95/d+ev/m+7zd/yb/jz/z4j7f/8c/84N/9mR8B8H+SwX9gM//9+75/8Wv0d/5n3/f9z+O/z3/7vu9fHv/On/l1L9zfzzi0f+a/ft/3r9tLf8G+f/593/84+l3/79f8p+/7/u3gd/6X7/v+1WDv37fyn37f979Gv/PffN/3n0e7f53W/rvv+/7jL/kXuv5vz//+vu+f/JJ/x5/58X//fd9/+JkfFACJUn9GAPx/0+t/hP2v+eu5UQBk30UAZG6/6ikBEHwB/wcgQCuMCAABUDijv3eFAMiEBUDm9queEgDBFxAAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiHuVW6AAAIEUlEQVSQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAGyAAjQCiMCQAAUzkgADBAFwAD1YKUACJAFQIBWGBEAAqBwRgJggCgABqgHKwVAgCwAArTCiAAQAIUzEgADRAEwQD1YKQACZAEQoBVGBIAAKJyRABggCoAB6sFKARAgC4AArTAiAARA4YwEwABRAAxQD1YKgABZAARohREBIAAKZyQABogCYIB6sFIABMgCIEArjAgAAVA4IwEwQBQAA9SDlQIgQBYAAVphRAAIgMIZCYABogAYoB6sFAABsgAI0AojAkAAFM5IAAwQBcAA9WClAAiQBUCAVhgRAAKgcEYCYIAoAAaoBysFQIAsAAK0wogAEACFMxIAA0QBMEA9WCkAAmQBEKAVRgSAACickQAYIAqAAerBSgEQIAuAAK0wIgAEQOGMBMAAUQAMUA9WCoAAWQAEaIURASAACmckAAaIAmCAerBSAATIAiBAK4wIAAFQOCMBMEAUAAPUg5UCIEAWAAFaYUQACIDCGQmAAaIAGKAerBQAAbIACNAKIwJAABTOSAAMEAXAAPVgpQAIkAVAgFYYEQACoHBGAmCAKAAGqAcrBUCALAACtMKIABAAhTMSAANEATBAPVgpAAJkARCgFUYEgAAonJEAGCAKgAHqwUoBECALgACtMCIABEDhjATAAFEADFAPVgqAAFkABGiFEQEgAApnJAAGiAJggHqwUgAEyAIgQCuMCAABUDgjATBAFAAD1IOVAiBAFgABWmFEAAiAwhkJgAGiABigHqwUAAHyjwD422DuH9rIX37f97u/Rn/p3/6+76+O/z5/8X3f7x3/zp/5dS/c3884tH/mz7/v+4P20l+w73e+7/vxb+zyz5983/dHg1/4Z7+Cfye/9X3fXw/e8mPl73/f98PqH/ufP/y+709/yUde/7fnb77v+81f8u/4Mz/+4+1//DM/+Hd/5kcA+EOAAAECBAg8JiAAHvvgnkuAAAECBH4ICAB3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFBAADz40T2ZAAECBAgIADdAgAABAgQeFBAAD350TyZAgAABAgLADRAgQIAAgQcFBMCDH92TCRAgQICAAHADBAgQIEDgQQEB8OBH92QCBAgQICAA3AABAgQIEHhQQAA8+NE9mQABAgQICAA3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFBAADz40T2ZAAECBAgIADdAgAABAgQeFBAAD350TyZAgAABAgLADRAgQIAAgQcFBMCDH92TCRAgQICAAHADBAgQIEDgQQEB8OBH92QCBAgQICAA3AABAgQIEHhQQAA8+NE9mQABAgQICAA3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFBAADz40T2ZAAECBAgIADdAgAABAgQeFBAAD350TyZAgAABAgLADRAgQIAAgQcFBMCDH92TCRAgQICAAHADBAgQIEDgQQEB8OBH92QCBAgQICAA3AABAgQIEHhQQAA8+NE9mQABAgQICAA3QIAAAQIEHhQQAA9+dE8mQIAAAQICwA0QIECAAIEHBQTAgx/dkwkQIECAgABwAwQIECBA4EEBAfDgR/dkAgQIECAgANwAAQIECBB4UEAAPPjRPZkAAQIECAgAN0CAAAECBB4UEAAPfnRPJkCAAAECAsANECBAgACBBwUEwIMf3ZMJECBAgIAAcAMECBAgQOBBAQHw4Ef3ZAIECBAgIADcAAECBAgQeFDg/wJyyJPCiV8gnQAAAABJRU5ErkJggg==" transform="scale(.07868)"/></g></g><defs><clipPath id="f"><path d="M0 0h40.286v40.286H0V0z"/></clipPath><clipPath id="e"><path d="M0 0h40.286v40.286H0V0z"/></clipPath><clipPath id="d"><path d="M0 0h40.286v40.286H0V0z"/></clipPath><clipPath id="c"><path d="M0 0h40.286v40.286H0V0z"/></clipPath>
          <clipPath id="b"><path d="M0 0h40.286v40.286H0V0z"/></clipPath>
          <clipPath id="a"><path d="M0 0h40.286v40.286H0V0z"/></clipPath>
        </defs></svg>
      </div>
    </div>
    <div>
      <h2 class="fill-out">Fill Out If Pay By Credit Card</h2>
    </div>
    <div class="fill-out-section flex-between">
      <div class="credit-card-info">
        <div class="bordered-block">
          <div class="flex-between" style="padding: 10px 10px 5px">
            <div style="font-size: 7px; color: #164066">
              <p style="margin: 0">Name</p>
              <p style="margin-top: 5px">Credit Card</p>
              <p style="margin-top: 23px; margin-bottom: 0">Address</p>
              <p style="margin-top: 7px; margin-bottom: 0">Phone</p>
            </div>
            <div style="width: 86%; margin-top: 7px">
              <div class="table" style="font-size: 8px; color: #164066">
                <div class="table-item" style="border-bottom: none"></div>
                <div class="table-item" style="border-bottom: none">Exp.</div>
                <div class="table-item" style="border-bottom: none">Cvv1/CVC2</div>
              </div>
              <div class="table" style="font-size: 8px; color: #164066">
                <div class="table-item"></div>
                <div class="table-item">One Time Payment</div>
                <div class="table-item">Auto Payment</div>
              </div>
              <div class="bordered"></div>
              <div class="bordered"></div>
            </div>
          </div>
          <div class="terms">
            <p>
              I authorize the above named business to charge the credit card indicated in those authorize form according to the terms outlined above.
              those payment authorization is for the goods/services described above , for the amount credit card company , so long as the transaction
              corresponds  to the terms indicated in this form
            </p>
          </div>
        </div>
        <div class="bordered-block flex-between" style="background-color: #edeef4;-webkit-print-color-adjust: exact;border: 1px solid #a5aac6; border-radius: 4px; margin-top: 11px; padding: 10px; font-size: 8px; color: #164066">
          <span>Name</span>
          <p style="width: 250px; margin: 0; border-bottom: 1px solid #a5aac6; transform: translateY(-3px);"></p>
          <span>Date</span>
          <div class="flex-evenly" style="transform: translateY(-3px);margin: 0; border-bottom: 1px solid #a5aac6; width: 200px;">
            <span>/</span>
            <span>/</span>
          </div>
        </div>
      </div>
      <div class="credit-card-right-block">
        <div style="font-size: 8px; margin-bottom: 5px">
          <div class="flex-between" style="margin-bottom: 5px">
            <div style="margin-right: 22px">
              <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="465 664 10 10"><g data-name="Rectangle 45"><path d="M466 664h8a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1h-8a1 1 0 0 1-1-1v-8a1 1 0 0 1 1-1z" fill="#fff" fill-rule="evenodd"/><path d="M466.2 664.25h7.6a.95.95 0 0 1 .95.95v7.6a.95.95 0 0 1-.95.95h-7.6a.95.95 0 0 1-.95-.95v-7.6a.95.95 0 0 1 .95-.95z" stroke-linejoin="round" stroke-linecap="round" stroke-width=".475" stroke="#a5aac6" fill="transparent"/></g></svg>
            </div>
            <div>
              <span style="color: #164066; font-weight: bold">1 Month</span>
            </div>
          </div>
          <div style="font-size: 8px; border-bottom: 1px solid #a5aac6">
            <div class="flex-between" style="margin-bottom: 5px">
              <span style="display: block; color: #164066">Cash</span>
              <span style="color: #01B2B8; font-weight: bold">$30</span>
            </div>
            <div class="flex-between" style="margin-bottom: 6px">
              <span style="display: block; color: #164066">Card</span>
              <span style="color: #01B2B8; font-weight: bold">$31.15</span>
            </div>
          </div>
        </div>
        <div style="font-size: 8px; margin-bottom: 5px">
          <div class="flex-between" style="margin-bottom: 5px">
            <div style="margin-right: 22px">
              <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="465 664 10 10"><g data-name="Rectangle 45"><path d="M466 664h8a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1h-8a1 1 0 0 1-1-1v-8a1 1 0 0 1 1-1z" fill="#fff" fill-rule="evenodd"/><path d="M466.2 664.25h7.6a.95.95 0 0 1 .95.95v7.6a.95.95 0 0 1-.95.95h-7.6a.95.95 0 0 1-.95-.95v-7.6a.95.95 0 0 1 .95-.95z" stroke-linejoin="round" stroke-linecap="round" stroke-width=".475" stroke="#a5aac6" fill="transparent"/></g></svg>
            </div>
            <div>
              <span style="color: #164066; font-weight: bold">1 Month</span>
            </div>
          </div>
          <div style="font-size: 8px; border-bottom: 1px solid #a5aac6">
            <div class="flex-between" style="margin-bottom: 5px">
              <span style="display: block; color: #164066">Cash</span>
              <span style="color: #01B2B8; font-weight: bold">$30</span>
            </div>
            <div class="flex-between" style="margin-bottom: 6px">
              <span style="display: block; color: #164066">Card</span>
              <span style="color: #01B2B8; font-weight: bold">$31.15</span>
            </div>
          </div>
        </div>
        <div style="font-size: 8px">
          <div class="flex" style="margin-bottom: 5px">
            <div style="margin-right: 22px">
              <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="465 664 10 10"><g data-name="Rectangle 45"><path d="M466 664h8a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1h-8a1 1 0 0 1-1-1v-8a1 1 0 0 1 1-1z" fill="#fff" fill-rule="evenodd"/><path d="M466.2 664.25h7.6a.95.95 0 0 1 .95.95v7.6a.95.95 0 0 1-.95.95h-7.6a.95.95 0 0 1-.95-.95v-7.6a.95.95 0 0 1 .95-.95z" stroke-linejoin="round" stroke-linecap="round" stroke-width=".475" stroke="#a5aac6" fill="transparent"/></g></svg>
            </div>
            <div>
              <span style="color: #164066; font-weight: bold">1 Month</span>
            </div>
          </div>
          <div style="font-size: 8px;">
            <div class="flex-between" style="margin-bottom: 5px">
              <span style="display: block; color: #164066">Cash</span>
              <span style="color: #01B2B8; font-weight: bold">$30</span>
            </div>
            <div class="flex-between">
              <span style="display: block; color: #164066">Card</span>
              <span style="color: #01B2B8; font-weight: bold">$31.15</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
  `,
};
