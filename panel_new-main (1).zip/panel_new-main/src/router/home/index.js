const Home = () => import("@/views/Home");

export const homeRout = {
  path: "/home",
  name: "Home",
  component: {
    render(c) {
      return c("router-view");
    }
  },
  children: [
    {
      path: "dashboard",
      name: "Dashboard",
      component: Home
    }
  ]
};
