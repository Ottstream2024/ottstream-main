const About = () => import("@/views/About");
const Home = () => import("@/views/Home");

export const aboutRout = {
  path: "/",
  redirect: "/about",
  name: "Products",
  component: {
    render(c) {
      return c("router-view");
    }
  },
  children: [
    {
      path: "about",
      name: "List",
      component: About,
      meta: { auth: true, roles: ["ottprovider"], permissions: [] }
    },
    {
      path: "home",
      name: "Product Type",
      component: Home,
      meta: { auth: true, roles: ["ottprovider"], permissions: [] }
    }
  ]
};
