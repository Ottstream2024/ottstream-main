class ImageService {

    constructor(api_url) {
        this.api_url = api_url;
    }

    getPath(path, version) {
        if (version)
            path = path + "?v=" + version;
        return this.api_url + path;
    }
}

const imageService = new ImageService(process.env.VUE_APP_API_URL);

export default imageService;
