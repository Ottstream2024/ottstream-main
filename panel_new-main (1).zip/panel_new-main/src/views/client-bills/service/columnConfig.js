/**
 *
 *    // example: {
      //   title: "Age1",
      //   isTranslate: true,
      //   style: { minWidth: "500px" },
      //   isShow: true,
      //   isDrag: false,
      //   sortData: {
      //     isSort: true,
      //     sortKey: "age1",
      //     sortValue: ""
      //   },
      //   className: "P-border-dashed",
      //   cellView: row => `<p>${row.age}</p>`
      //   totalData:true,
      //   totalText:'Total sum',
      //   cellTotalData: data=> `<p class="G-text-table">${data.totalCliet}</p>`
      // },
 *
 * **/


export const columnConfigMain = [
  {
    title: "Discount Name",
    isTranslate: false,
    style: {minWidth: 160},
    isShow: true,
    isDrag: true,
    sortData: {
      isSort: true,
      sortKey: "fullname",
      sortValue: ""
    },
    cellView: row => `<p class="G-text-table">${row.generalInfo.name}</p>`
  },
  {
    title: "Start Date",
    isTranslate: false,
    style: {minWidth: 160},
    isShow: true,
    isDrag: true,
    sortData: {
      isSort: true,
      sortKey: "startDate",
      sortValue: ""
    },
    cellView: row => `<p class="G-text-table">${row.generalInfo.dateStart !== undefined ? row.generalInfo.dateStart : '-'}</p>`
  },
  {
    title: "End Date",
    isTranslate: false,
    style: {minWidth: 160},
    isShow: true,
    isDrag: true,
    sortData: {
      isSort: true,
      sortKey: "endDate",
      sortValue: ""
    },
    cellView: row => `<p class="G-text-table">${row.generalInfo.dateEnd !== undefined ? row.generalInfo.dateEnd : '-'}</p>`
  },
  {
    title: "Timeline Status",
    isTranslate: false,
    style: {minWidth: 160},
    isShow: true,
    isDrag: true,
    cellView: row => `<p class="G-text-table">${row.timlineStatus}</p>`
  },
  {
    title: "Type",
    isTranslate: false,
    style: {minWidth: 160},
    isShow: true,
    isDrag: true,
    cellView: row => `<p class="G-text-table">${row.generalInfo.type}</p>`
  },
  {
    title: "Price Groups",
    isTranslate: false,
    style: {minWidth: 160},
    isShow: true,
    isDrag: true,
    cellView: row => `<p class="G-text-table">${row.type}</p>`
  },
  {
    title: "Status",
    isTranslate: false,
    style: {minWidth: 160},
    isShow: true,
    isDrag: true,
    cellView: row => `<p class="G-text-table">${row.status}</p>`
  },
  {
    title: "Default Sale Percent",
    isTranslate: false,
    style: {minWidth: 160},
    isShow: true,
    isDrag: true,
    cellView: row => `<p class="G-text-table">${row.status}</p>`
  },
  {
    title: "Packages",
    isTranslate: false,
    style: {minWidth: 160},
    isShow: true,
    isDrag: true,
    cellView: row => `<p class="G-text-table">${row.status}</p>`
  },
];
