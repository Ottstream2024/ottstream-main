<template>
  <div class="G-page-component">
    <div class="G-component-title">
      <h3 class="secondary--text">Credit Card Details</h3>
    </div>

    <div class="G-component-body page-background">
      
    </div>
  </div>
</template>

<script>
export default {

}
</script>
