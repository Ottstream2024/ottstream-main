<template>
  <div class="auth-cont ">
    <auth-header />
    <div class="auth-body">
      <div
        class="main-icon"
        :style="{
          backgroundImage:
            `url(${require('@/assets/images/designImages/rejected.svg')})`
        }"
      />
      <h6>Rejected</h6>
      <p class="description">
        Sorry Your account was not approved You will receive an email about why
        your application was rejected.
      </p>
    </div>

    <auth-footer />
  </div>
</template>

<script>
import AuthFooter from "./components/authFooter";
import AuthHeader from "./components/authHeader";

export default {
  name: "RegisterPending",
  components: {
    AuthHeader,
    AuthFooter
  }
};
</script>

<style lang="scss" scoped>
@import "./src/assets/scss/authGeneral";
.description {
  padding: 15px 0 30px;
}
</style>
