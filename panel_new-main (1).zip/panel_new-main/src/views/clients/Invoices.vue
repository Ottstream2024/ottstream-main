<template>
  <div>
    Invoices
  </div>
</template>
<script>
  export default {
    name:'Invoices'
  }
</script>