<template>
  <div>
    Orders
  </div>
</template>
<script>
  export default {
    name:'Orders'
  }
</script>