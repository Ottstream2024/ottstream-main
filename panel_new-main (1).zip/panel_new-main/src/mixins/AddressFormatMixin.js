import Vue from "vue";
import { FormatClientAddress, FormatProviderAddress } from './AddressFormat'

Vue.mixin({
    methods: {
        FormatClientAddress: FormatClientAddress,
        FormatProviderAddress: FormatProviderAddress
    },
})