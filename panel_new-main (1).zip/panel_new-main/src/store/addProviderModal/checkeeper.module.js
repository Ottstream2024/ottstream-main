const InitialState = {};

export const checkeeper = {
  namespaced: true,
  actions: {},
  state: JSON.parse(JSON.stringify(InitialState)),
  mutations: {}
};
