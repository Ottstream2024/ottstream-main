export const defaultColumnConfig = [
  {
    "defaultHide": true,
    "defaultDragIndex": 0,
    "mainIndex": 0,
    "name": "Provider ID"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 1,
    "mainIndex": 1,
    "name": "Company Name"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 2,
    "mainIndex": 2,
    "name": "Country"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 3,
    "mainIndex": 3,
    "name": "Company email"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 4,
    "mainIndex": 4,
    "name": "Company Address"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 5,
    "mainIndex": 5,
    "name": "Clients"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 6,
    "mainIndex": 6,
    "name": "Resellers"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 7,
    "mainIndex": 7,
    "name": "Total Logins"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 8,
    "mainIndex": 8,
    "name": "Active Logins"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 9,
    "mainIndex": 9,
    "name": "Inactive Logins"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 10,
    "mainIndex": 10,
    "name": "Price Group"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 11,
    "mainIndex": 11,
    "name": "Current Month Payments"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 12,
    "mainIndex": 12,
    "name": "Current Month Income"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 13,
    "mainIndex": 13,
    "name": "Credit from Parent"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 14,
    "mainIndex": 14,
    "name": "Credit grant date "
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 15,
    "mainIndex": 15,
    "name": "Credit Term"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 16,
    "mainIndex": 16,
    "name": "Credit Autoextend "
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 17,
    "mainIndex": 17,
    "name": "Clients to pause after days "
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 18,
    "mainIndex": 18,
    "name": "Days remain to credit end"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 19,
    "mainIndex": 19,
    "name": "Days remain to pause client"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 20,
    "mainIndex": 20,
    "name": "Balance"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 21,
    "mainIndex": 21,
    "name": "Debt"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 22,
    "mainIndex": 22,
    "name": "Own Channels"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 23,
    "mainIndex": 23,
    "name": "Client Packages"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 24,
    "mainIndex": 24,
    "name": "Channels in Client Packages"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 25,
    "mainIndex": 25,
    "name": "Reselling Packages"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 26,
    "mainIndex": 26,
    "name": "Channels in Reselling Packages"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 27,
    "mainIndex": 27,
    "name": "Statuses "
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 28,
    "mainIndex": 28,
    "name": "Date Registered"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 29,
    "mainIndex": 29,
    "name": "Registered By"
  }
]