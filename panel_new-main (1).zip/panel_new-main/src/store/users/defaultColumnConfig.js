export const defaultColumnConfig = [
  {
    "defaultHide": true,
    "defaultDragIndex": 0,
    "mainIndex": 0,
    "name": "Avatar"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 1,
    "mainIndex": 1,
    "name": "Full Name"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 2,
    "mainIndex": 2,
    "name": "ID"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 3,
    "mainIndex": 3,
    "name": "Role"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 4,
    "mainIndex": 4,
    "name": "Last IP"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 5,
    "mainIndex": 5,
    "name": "Last Geoip Country"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 6,
    "mainIndex": 6,
    "name": "Last Active Time"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 7,
    "mainIndex": 7,
    "name": "Unsuccessful Login Try"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 8,
    "mainIndex": 8,
    "name": "Create Time"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 9,
    "mainIndex": 9,
    "name": "Created By"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 10,
    "mainIndex": 10,
    "name": "Phone Number"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 11,
    "mainIndex": 11,
    "name": "Email Address"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 12,
    "mainIndex": 12,
    "name": "Disabled"
  }
]