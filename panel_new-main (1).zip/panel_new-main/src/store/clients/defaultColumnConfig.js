export const defaultColumnConfig = [
  {
    "defaultHide": true,
    "defaultDragIndex": 0,
    "mainIndex": 0,
    "name": "Full Name"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 1,
    "mainIndex": 1,
    "name": "ID"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 2,
    "mainIndex": 2,
    "name": "Status"
  },
  {"defaultHide": true,
    "defaultDragIndex": 3,
    "mainIndex": 3,
    "name": "Provider"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 4,
    "mainIndex": 4,
    "name": "Reseller"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 5,
    "mainIndex": 5,
    "name": "Email Address"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 6,
    "mainIndex": 6,
    "name": "Address"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 7,
    "mainIndex": 7,
    "name": "Price Group"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 8,
    "mainIndex": 8,
    "name": "Currency"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 9,
    "mainIndex": 9,
    "name": "Last Payment Method"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 10,
    "mainIndex": 10,
    "name": "Monthly Payments"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 11,
    "mainIndex": 11,
    "name": "Subscriptions Recurring Payment"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 12,
    "mainIndex": 12,
    "name": "Balance"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 13,
    "mainIndex": 13,
    "name": "Credit"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 14,
    "mainIndex": 14,
    "name": "Credit Grant Date"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 15,
    "mainIndex": 15,
    "name": "Credit Expire Date"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 16,
    "mainIndex": 16,
    "name": "Days Remains To Credit Expire"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 17,
    "mainIndex": 17,
    "name": "Credit Autoextend"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 18,
    "mainIndex": 18,
    "name": "Debt"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 19,
    "mainIndex": 19,
    "name": "Location"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 20,
    "mainIndex": 20,
    "name": "Login"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 21,
    "mainIndex": 21,
    "name": "Room"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 22,
    "mainIndex": 22,
    "name": "Profile"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 23,
    "mainIndex": 23,
    "name": "Server"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 24,
    "mainIndex": 24,
    "name": "Timezone"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 25,
    "mainIndex": 25,
    "name": "Active Packages"
  },
  {
    "defaultHide": true,
    "defaultDragIndex": 26,
    "mainIndex": 26,
    "name": "Package Expire"
  }
]
