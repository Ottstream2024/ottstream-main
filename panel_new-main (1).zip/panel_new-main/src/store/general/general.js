export const general = {
  namespaced: true,
  state: {
    isSelectedAll: false
  },
  mutations: {
    setData(state, data) {
      for (let key in data) {
        state[key] = data[key]
      }
    },
  },
};
